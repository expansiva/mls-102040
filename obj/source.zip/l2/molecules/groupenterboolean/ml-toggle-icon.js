var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupenterboolean/ml-toggle-icon.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML TOGGLE ICON MOLECULE
// =============================================================================
// Skill Group: groupEnterBoolean
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    yes: 'Yes',
    no: 'No',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlToggleIconMolecule = class MlToggleIconMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = false;
        this.error = '';
        this.name = '';
        this.isEditing = true;
        this.disabled = false;
        // Optional icon configuration (SVG path data)
        this.iconOn = '';
        this.iconOff = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.hasFocus = false;
        this.labelId = `label-${Math.random().toString(36).slice(2, 9)}`;
        this.helperId = `helper-${Math.random().toString(36).slice(2, 9)}`;
        this.errorId = `error-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle() {
        if (!this.isEditing || this.disabled)
            return;
        this.value = !this.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleKeyDown(e) {
        if (!this.isEditing || this.disabled)
            return;
        if (e.key === ' ' || e.key === 'Spacebar' || e.code === 'Space') {
            e.preventDefault();
            this.handleToggle();
        }
    }
    handleFocus() {
        if (!this.isEditing || this.disabled)
            return;
        this.hasFocus = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        if (!this.isEditing || this.disabled)
            return;
        this.hasFocus = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getTrackClasses(hasError) {
        return [
            'relative inline-flex h-8 w-14 items-center',
            'ml-toggle-icon-track',
            this.value ? 'ml-toggle-icon-track-on' : '',
            hasError ? 'ml-toggle-icon-track-error' : '',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getThumbClasses() {
        return [
            'inline-flex h-6 w-6 transform items-center justify-center ml-toggle-icon-thumb',
            this.value ? 'translate-x-7' : 'translate-x-1',
        ].join(' ');
    }
    getButtonClasses() {
        return [
            'inline-flex items-center gap-3',
            'focus:outline-none',
            this.disabled ? 'cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderIcon() {
        const onPath = this.iconOn || 'M5 13l4 4L19 7';
        const offPath = this.iconOff || 'M6 6l12 12M6 18L18 6';
        const path = this.value ? onPath : offPath;
        return html `
      <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        ${svg `<path d="${path}"></path>`}
      </svg>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id="${this.labelId}" class="${cn('block mb-2 text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderHelper(hasError) {
        if (!this.isEditing || hasError || !this.hasSlot('Helper'))
            return html ``;
        return html `
      <p id="${this.helperId}" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">
        ${unsafeHTML(this.getSlotContent('Helper'))}
      </p>
    `;
    }
    renderError(hasError) {
        if (!this.isEditing || !hasError)
            return html ``;
        return html `
      <p id="${this.errorId}" class="mt-2 text-xs ml-error-text">
        ${unsafeHTML(String(this.error))}
      </p>
    `;
    }
    renderEditMode() {
        const hasError = Boolean(this.error);
        const describedBy = hasError
            ? this.errorId
            : (this.hasSlot('Helper') ? this.helperId : undefined);
        return html `
      <div class="flex flex-col">
        <button
          class="${this.getButtonClasses()}"
          type="button"
          role="switch"
          aria-checked="${this.value ? 'true' : 'false'}"
          aria-disabled="${this.disabled ? 'true' : 'false'}"
          aria-invalid="${hasError ? 'true' : 'false'}"
          ${this.hasSlot('Label') ? `aria-labelledby="${this.labelId}"` : ''}
          ${describedBy ? `aria-describedby="${describedBy}"` : ''}
          ?disabled=${this.disabled}
          @click=${this.handleToggle}
          @keydown=${this.handleKeyDown}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
        >
          <span class="${this.getTrackClasses(hasError)}">
            <span class="${this.getThumbClasses()}">
              ${this.renderIcon()}
            </span>
          </span>
        </button>
        ${this.name ? html `<input type="hidden" name="${this.name}" value="${String(this.value)}" />` : html ``}
        ${this.renderError(hasError)}
        ${this.renderHelper(hasError)}
      </div>
    `;
    }
    renderViewMode() {
        return html `
      <div class="text-sm ml-text">
        ${this.value ? this.msg.yes : this.msg.no}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        ${this.isEditing ? this.renderEditMode() : this.renderViewMode()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlToggleIconMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlToggleIconMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlToggleIconMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlToggleIconMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlToggleIconMolecule.prototype, "disabled", void 0);
__decorate([
    property({ type: String, attribute: 'icon-on' })
], MlToggleIconMolecule.prototype, "iconOn", void 0);
__decorate([
    property({ type: String, attribute: 'icon-off' })
], MlToggleIconMolecule.prototype, "iconOff", void 0);
__decorate([
    state()
], MlToggleIconMolecule.prototype, "hasFocus", void 0);
MlToggleIconMolecule = __decorate([
    customElement('groupenterboolean--ml-toggle-icon')
], MlToggleIconMolecule);
export { MlToggleIconMolecule };
