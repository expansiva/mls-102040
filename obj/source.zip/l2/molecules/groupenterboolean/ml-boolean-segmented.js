var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupenterboolean/ml-boolean-segmented.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BOOLEAN SEGMENTED MOLECULE
// =============================================================================
// Skill Group: groupEnterBoolean
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    yes: 'Yes',
    no: 'No',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let BooleanSegmentedMolecule = class BooleanSegmentedMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = false;
        this.error = '';
        this.name = '';
        this.isEditing = true;
        this.disabled = false;
        // ===========================================================================
        // INTERNAL IDS
        // ===========================================================================
        this.labelId = `segmented-label-${Math.random().toString(36).slice(2)}`;
        this.helperId = `segmented-helper-${Math.random().toString(36).slice(2)}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(nextValue) {
        if (this.disabled || !this.isEditing)
            return;
        if (this.value === nextValue)
            return;
        this.value = nextValue;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleKeyDown(e, nextValue) {
        if (this.disabled || !this.isEditing)
            return;
        if (e.key === ' ' || e.key === 'Spacebar') {
            e.preventDefault();
            this.handleSelect(nextValue);
        }
    }
    handleFocus() {
        if (this.disabled || !this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        if (this.disabled || !this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div
        id=${this.labelId}
        class="${cn('mb-1 text-sm ml-label', this.getSlotClass('Label'))}"
      >
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `
        <div
          id=${this.helperId}
          class="mt-1 text-xs ml-error-text"
        >
          ${unsafeHTML(String(this.error))}
        </div>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <div
          id=${this.helperId}
          class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}"
        >
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </div>
      `;
        }
        return html ``;
    }
    getSegmentClasses(isSelected) {
        return [
            'flex-1 px-3 py-2 text-sm ml-segmented-option',
            isSelected ? 'ml-segmented-option-active' : '',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
            this.error ? 'ml-segmented-option-error' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderViewMode() {
        const text = this.value ? this.msg.yes : this.msg.no;
        return html `
      <div class="text-sm ml-text">
        ${text}
      </div>
    `;
    }
    renderEditMode() {
        const ariaLabelledBy = this.hasSlot('Label') ? this.labelId : undefined;
        const ariaDescribedBy = this.error || this.hasSlot('Helper') ? this.helperId : undefined;
        return html `
      <div
        class="inline-flex w-full gap-2 ml-segmented-track"
        role="radiogroup"
        aria-labelledby=${ariaLabelledBy || ''}
        aria-describedby=${ariaDescribedBy || ''}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-disabled=${this.disabled ? 'true' : 'false'}
      >
        <button
          type="button"
          role="radio"
          aria-checked=${this.value ? 'true' : 'false'}
          class=${this.getSegmentClasses(this.value)}
          @click=${() => this.handleSelect(true)}
          @keydown=${(e) => this.handleKeyDown(e, true)}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
          ?disabled=${this.disabled}
        >
          ${this.msg.yes}
        </button>
        <button
          type="button"
          role="radio"
          aria-checked=${!this.value ? 'true' : 'false'}
          class=${this.getSegmentClasses(!this.value)}
          @click=${() => this.handleSelect(false)}
          @keydown=${(e) => this.handleKeyDown(e, false)}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
          ?disabled=${this.disabled}
        >
          ${this.msg.no}
        </button>
        ${this.name
            ? html `<input type="hidden" name=${this.name} .value=${String(this.value)} />`
            : html ``}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        ${this.isEditing ? this.renderEditMode() : this.renderViewMode()}
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], BooleanSegmentedMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], BooleanSegmentedMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], BooleanSegmentedMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], BooleanSegmentedMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'disabled' })
], BooleanSegmentedMolecule.prototype, "disabled", void 0);
BooleanSegmentedMolecule = __decorate([
    customElement('groupenterboolean--ml-boolean-segmented')
], BooleanSegmentedMolecule);
export { BooleanSegmentedMolecule };
