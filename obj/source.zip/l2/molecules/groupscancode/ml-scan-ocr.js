var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupscancode/ml-scan-ocr.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SCAN OCR MOLECULE
// =============================================================================
// Skill Group: groupScanCode
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    openCamera: 'Open camera scanner',
    capture: 'Capture',
    close: 'Close',
    loading: 'Processing...',
    permissionDenied: 'Camera access denied. Please allow permissions.',
    cameraUnavailable: 'Camera is not available on this device.',
    resultLabel: 'Scan result',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlScanOcrMolecule = class MlScanOcrMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Result'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.facing = 'environment';
        this.autoCapture = false;
        this.captureInterval = 500;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.localError = '';
        this.isCapturing = false;
        this.stream = null;
        this.captureTimer = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        this.stopCamera();
    }
    updated(changed) {
        if (changed.has('value')) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            if (this.value && this.isOpen) {
                this.closeCamera();
            }
        }
        if (changed.has('loading')) {
            if (this.loading) {
                this.stopAutoCapture();
            }
            else if (this.isOpen && this.autoCapture) {
                this.startAutoCapture();
            }
        }
    }
    // ===========================================================================
    // CAMERA MANAGEMENT
    // ===========================================================================
    async openCamera() {
        if (this.disabled || this.loading || this.isOpen)
            return;
        this.localError = '';
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            this.localError = this.msg.cameraUnavailable;
            return;
        }
        try {
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facing },
            });
            this.isOpen = true;
            await this.attachStream();
            if (this.autoCapture && !this.loading) {
                this.startAutoCapture();
            }
            this.dispatchEvent(new CustomEvent('open', {
                bubbles: true,
                composed: true,
                detail: {},
            }));
        }
        catch (e) {
            this.localError = this.msg.permissionDenied;
        }
    }
    async attachStream() {
        if (!this.stream || !this.videoEl)
            return;
        this.videoEl.srcObject = this.stream;
        try {
            await this.videoEl.play();
        }
        catch {
            this.localError = this.msg.permissionDenied;
        }
    }
    closeCamera() {
        if (!this.isOpen)
            return;
        this.stopAutoCapture();
        this.stopCamera();
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('close', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    stopCamera() {
        if (this.stream) {
            this.stream.getTracks().forEach((t) => t.stop());
            this.stream = null;
        }
    }
    startAutoCapture() {
        this.stopAutoCapture();
        if (!this.isOpen || this.loading)
            return;
        this.captureTimer = window.setInterval(() => {
            this.captureFrame();
        }, Math.max(200, this.captureInterval));
    }
    stopAutoCapture() {
        if (this.captureTimer !== null) {
            window.clearInterval(this.captureTimer);
            this.captureTimer = null;
        }
    }
    captureFrame() {
        if (this.loading || !this.isOpen || !this.videoEl || !this.canvasEl)
            return;
        const video = this.videoEl;
        const canvas = this.canvasEl;
        const width = video.videoWidth || 640;
        const height = video.videoHeight || 480;
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        ctx.drawImage(video, 0, 0, width, height);
        const image = canvas.toDataURL('image/png');
        this.isCapturing = true;
        setTimeout(() => (this.isCapturing = false), 250);
        this.dispatchEvent(new CustomEvent('capture', {
            bubbles: true,
            composed: true,
            detail: { image },
        }));
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        if (this.disabled || this.loading)
            return;
        this.openCamera();
    }
    handleTriggerKey(e) {
        if (this.disabled || this.loading)
            return;
        if (e.key === 'Enter' || e.key === '') {
            e.preventDefault();
            this.openCamera();
        }
    }
    handleCaptureClick() {
        if (this.disabled || this.loading)
            return;
        this.captureFrame();
    }
    handleRootKey(e) {
        if (e.key === 'Escape') {
            this.closeCamera();
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
 <div class="${cn('mb-2 text-sm font-medium ml-text-muted', this.getSlotClass('Label'))}">
 ${unsafeHTML(this.getSlotContent('Label'))}
 </div>
 `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `
 <div class="${cn('mt-2 text-xs ml-text-muted', this.getSlotClass('Helper'))}">
 ${unsafeHTML(this.getSlotContent('Helper'))}
 </div>
 `;
    }
    renderError() {
        const err = this.error || this.localError;
        if (!err)
            return html ``;
        return html `
 <div
 id="error-text"
 class="mt-2 text-xs ml-error-text"
 role="status"
 >
 ${err}
 </div>
 `;
    }
    renderTrigger() {
        const hasCustom = this.hasSlot('Trigger');
        const triggerClasses = [
            'w-full flex items-center justify-center gap-2 rounded-lg px-4 py-2 text-sm border transition',
            'ml-surface-bg',
            'ml-text',
            'ml-border',
            'hover:ml-surface-dim-bg',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ]
            .filter(Boolean)
            .join(' ');
        return html `
 <div
 class=${triggerClasses}
 role="button"
 tabindex=${this.disabled ? -1 : 0}
 aria-label=${this.msg.openCamera}
 @click=${this.handleTriggerClick}
 @keydown=${this.handleTriggerKey}
 >
 ${hasCustom
            ? unsafeHTML(this.getSlotContent('Trigger'))
            : html `<span>${this.msg.openCamera}</span>`}
 </div>
 `;
    }
    renderResult() {
        const hasCustom = this.hasSlot('Result');
        return html `
 <div
 class="w-full rounded-lg border ml-border ml-surface-bg p-4"
 aria-live="polite"
 >
 <div class="text-xs uppercase tracking-wide ml-text-muted mb-1">
 ${this.msg.resultLabel}
 </div>
 ${hasCustom
            ? unsafeHTML(this.getSlotContent('Result'))
            : html `<div class="text-sm ml-text">${this.value}</div>`}
 </div>
 `;
    }
    renderCamera() {
        const captureButtonClasses = [
            'mt-3 inline-flex items-center justify-center rounded-full px-4 py-2 text-sm border transition',
            'ml-surface-bg',
            'ml-text',
            'ml-border',
            'hover:ml-surface-dim-bg',
            this.loading ? 'ml-disabled' : 'cursor-pointer',
        ]
            .filter(Boolean)
            .join(' ');
        return html `
 <div class="relative w-full overflow-hidden rounded-lg border ml-border ml-surface-dim-bg">
 <video
 class="w-full h-64 object-cover"
 autoplay
 playsinline
 aria-hidden="true"
 ></video>

 <div
 class="pointer-events-none absolute inset-6 rounded-lg border-2 border-dashed ml-border-focus"
 ></div>

 ${this.isCapturing
            ? html `<div class="absolute inset-0 ml-capture-flash"></div>`
            : html ``}
 </div>

 <div class="mt-3 flex items-center gap-3">
 <button
 class=${captureButtonClasses}
 aria-label=${this.msg.capture}
 @click=${this.handleCaptureClick}
 ?disabled=${this.loading}
 >
 ${this.msg.capture}
 </button>

 <button
 class="text-xs ml-text-muted hover:underline"
 @click=${this.closeCamera}
 aria-label=${this.msg.close}
 >
 ${this.msg.close}
 </button>
 </div>

 <canvas class="hidden" aria-hidden="true"></canvas>
 `;
    }
    renderLoading() {
        return html `
 <div class="mt-2 text-xs ml-text-muted">
 ${this.msg.loading}
 </div>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const rootClasses = [
            'w-full flex flex-col',
            this.disabled ? 'opacity-50' : '',
        ]
            .filter(Boolean)
            .join(' ');
        const hasResult = !!this.value;
        return html `
 <div class=${cn(rootClasses, this.cssClass)} @keydown=${this.handleRootKey}>
 ${this.renderLabel()}

 ${hasResult
            ? this.renderResult()
            : this.isOpen
                ? this.renderCamera()
                : this.renderTrigger()}

 ${this.loading ? this.renderLoading() : nothing}

 ${this.renderHelper()}
 ${this.renderError()}

 ${this.name
            ? html `<input type="hidden" name=${this.name} .value=${this.value ?? ''} />`
            : nothing}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlScanOcrMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanOcrMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanOcrMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanOcrMolecule.prototype, "facing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'auto-capture' })
], MlScanOcrMolecule.prototype, "autoCapture", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'capture-interval' })
], MlScanOcrMolecule.prototype, "captureInterval", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanOcrMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanOcrMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlScanOcrMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlScanOcrMolecule.prototype, "localError", void 0);
__decorate([
    state()
], MlScanOcrMolecule.prototype, "isCapturing", void 0);
__decorate([
    query('video')
], MlScanOcrMolecule.prototype, "videoEl", void 0);
__decorate([
    query('canvas')
], MlScanOcrMolecule.prototype, "canvasEl", void 0);
MlScanOcrMolecule = __decorate([
    customElement('groupscancode--ml-scan-ocr')
], MlScanOcrMolecule);
export { MlScanOcrMolecule };
