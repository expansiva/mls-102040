/// <mls fileReference="_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-preview.ts" enhancement="_102020_/l2/enhancementAura"/>

// =============================================================================
// ML FILE UPLOAD PREVIEW MOLECULE
// =============================================================================
// Skill Group: select + fileForUpload
// This molecule does NOT contain business logic.

import { html, svg, TemplateResult, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';

/// **collab_i18n_start**
const message_en = {
labelDefault: 'Upload files',
triggerTitle: 'Click to select files',
triggerSubtitle: 'or drag and drop here',
addMore: 'Add more files',
replaceFile: 'Replace file',
loading: 'Uploading...',
remove: 'Remove',
noPreview: 'No preview',
};
type MessageType = typeof message_en;
const messages: Record<string, MessageType> = {
  en: message_en,
  pt: {
    labelDefault: 'Enviar arquivos',
    triggerTitle: 'Clique para selecionar arquivos',
    triggerSubtitle: 'ou arraste e solte aqui',
    addMore: 'Adicionar mais arquivos',
    replaceFile: 'Substituir arquivo',
    loading: 'Enviando...',
    remove: 'Remover',
    noPreview: 'Sem prévia',
  },
};
/// **collab_i18n_end**

@customElement('groupselectfileforupload--ml-file-upload-preview')
export class MlFileUploadPreviewMolecule extends MoleculeAuraElement {
  private msg: MessageType = messages.en;

  // ==========================================================================
  // SLOT TAGS
  // ==========================================================================
  slotTags = ['Label', 'Helper', 'Trigger'];

  // ==========================================================================
  // PROPERTIES — From Contract
  // ==========================================================================
  @propertyDataSource({ type: Array })
  value: File[] = [];

  @propertyDataSource({ type: String })
  error: string = '';

  @propertyDataSource({ type: Boolean })
  multiple = false;

  @propertyDataSource({ type: String })
  accept = '';

  @propertyDataSource({ type: Number, attribute: 'max-size-kb' })
  maxSizeKb = 0;

  @propertyDataSource({ type: Number, attribute: 'max-files' })
  maxFiles = 0;

  @propertyDataSource({ type: Boolean })
  disabled = false;

  @propertyDataSource({ type: Boolean })
  loading = false;

  // ==========================================================================
  // INTERNAL STATE
  // ==========================================================================
  @state()
  private isDragging = false;

  private previewUrls: Map<string, string> = new Map();
  private uid = `ml-fup-${Math.random().toString(36).slice(2)}`;

  // ==========================================================================
  // STATE CHANGE HANDLER (derived values)
  // ==========================================================================
  handleIcaStateChange(key: string, value: any) {
    const valueAttr = this.getAttribute('value');
    if (valueAttr === `{{${key}}}`) {
      this.syncPreviewUrls(value as File[]);
    }
    this.requestUpdate();
  }

  // ==========================================================================
  // LIFECYCLE
  // ==========================================================================
  disconnectedCallback() {
    this.revokeAllPreviews();
    super.disconnectedCallback();
  }

  // ==========================================================================
  // EVENT HANDLERS
  // ==========================================================================
  private handleTriggerClick() {
    if (this.disabled || this.loading) return;
    const input = this.getFileInput();
    if (input) input.click();
  }

  private handleTriggerKeydown(e: KeyboardEvent) {
    if (this.disabled || this.loading) return;
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      this.handleTriggerClick();
    }
  }

  private handleInputChange(e: Event) {
    e.stopPropagation();
    const input = e.target as HTMLInputElement;
    const files = input.files ? Array.from(input.files) : [];
    this.processFiles(files);
    input.value = '';
  }

  private handleDragOver(e: DragEvent) {
    if (this.disabled || this.loading) return;
    e.preventDefault();
    this.isDragging = true;
  }

  private handleDragLeave() {
    if (this.disabled || this.loading) return;
    this.isDragging = false;
  }

  private handleDrop(e: DragEvent) {
    if (this.disabled || this.loading) return;
    e.preventDefault();
    this.isDragging = false;
    const files = e.dataTransfer?.files ? Array.from(e.dataTransfer.files) : [];
    this.processFiles(files);
  }

  private handleRemoveFile(index: number) {
    if (this.disabled || this.loading) return;
    if (!Array.isArray(this.value)) return;
    const next = this.value.filter((_, i) => i !== index);
    this.value = next;
    this.syncPreviewUrls(next);
  }

  // ==========================================================================
  // FILE PROCESSING
  // ==========================================================================
  private processFiles(files: File[]) {
    if (!files.length) return;

    const existing = this.value || [];
    const allowCount = this.multiple ? (this.maxFiles > 0 ? this.maxFiles : Infinity) : 1;
    let remaining = allowCount - existing.length;

    const accepted: File[] = [];
    const rejectedByReason: Record<'size' | 'type' | 'count', File[]> = {
      size: [],
      type: [],
      count: [],
    };

    files.forEach((file) => {
      if (remaining <= 0) {
        rejectedByReason.count.push(file);
        return;
      }
      if (!this.isAcceptedType(file)) {
        rejectedByReason.type.push(file);
        return;
      }
      if (this.maxSizeKb > 0 && file.size > this.maxSizeKb * 1024) {
        rejectedByReason.size.push(file);
        return;
      }
      accepted.push(file);
      remaining -= 1;
    });

    if (accepted.length > 0) {
      const next = this.multiple ? [...existing, ...accepted] : [accepted[0]];
      this.value = next;
      this.syncPreviewUrls(next);
    }

    (Object.keys(rejectedByReason) as Array<'size' | 'type' | 'count'>).forEach((reason) => {
      const rejected = rejectedByReason[reason];
      if (rejected.length > 0) {
        this.dispatchEvent(new CustomEvent('reject', {
          bubbles: true,
          composed: true,
          detail: { files: rejected, reason },
        }));
      }
    });
  }

  private isAcceptedType(file: File): boolean {
    if (!this.accept) return true;
    const accepted = this.accept.split(',').map((v) => v.trim()).filter(Boolean);
    if (accepted.length === 0) return true;

    return accepted.some((rule) => {
      if (rule.startsWith('.')) {
        return file.name.toLowerCase().endsWith(rule.toLowerCase());
      }
      if (rule.endsWith('/*')) {
        const base = rule.replace('/*', '');
        return file.type.startsWith(`${base}/`);
      }
      return file.type === rule;
    });
  }

  // ==========================================================================
  // PREVIEW MANAGEMENT
  // ==========================================================================
  private syncPreviewUrls(files: File[] = []) {
    const nextKeys = new Set(files.map((f) => this.getFileKey(f)));

    this.previewUrls.forEach((url, key) => {
      if (!nextKeys.has(key)) {
        URL.revokeObjectURL(url);
        this.previewUrls.delete(key);
      }
    });

    files.forEach((file) => {
      const key = this.getFileKey(file);
      if (!this.previewUrls.has(key) && file.type.startsWith('image/')) {
        this.previewUrls.set(key, URL.createObjectURL(file));
      }
    });
  }

  private revokeAllPreviews() {
    this.previewUrls.forEach((url) => URL.revokeObjectURL(url));
    this.previewUrls.clear();
  }

  private getFileKey(file: File): string {
    return `${file.name}-${file.size}-${file.lastModified}`;
  }

  private getPreviewUrl(file: File): string | null {
    const key = this.getFileKey(file);
    return this.previewUrls.get(key) || null;
  }

  // ==========================================================================
  // RENDER HELPERS
  // ==========================================================================
  private getContainerClasses(): string {
    return [
      'w-full',
      this.disabled || this.loading ? 'ml-disabled' : '',
    ].filter(Boolean).join(' ');
  }

  private getDropZoneClasses(hasError: boolean): string {
    return [
      'relative w-full rounded-lg border border-dashed p-4 transition ml-dropzone',
      hasError ? 'ml-dropzone-error' : '',
      this.isDragging ? 'ml-dropzone-active' : '',
      !this.disabled && !this.loading ? 'cursor-pointer' : 'cursor-not-allowed',
      'focus:outline-none',
    ].filter(Boolean).join(' ');
  }

  private getFileItemClasses(): string {
    return [
      'flex items-center gap-3 rounded-md border p-2 ml-preview-card',
    ].join(' ');
  }

  private getRemoveButtonClasses(): string {
    return [
      'ml-auto inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium transition ml-preview-remove',
      !this.disabled && !this.loading ? '' : 'cursor-not-allowed',
    ].filter(Boolean).join(' ');
  }

  private formatSize(size: number): string {
    if (size < 1024) return `${size} B`;
    const kb = size / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;
    const mb = kb / 1024;
    return `${mb.toFixed(1)} MB`;
  }

  private renderLabel(): TemplateResult {
    if (!this.hasSlot('Label')) return html``;
    return html`
      <div id="${this.uid}-label" class="${cn('mb-2 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
  }

  private renderHelperOrError(): TemplateResult {
    if (this.error) {
      return html`
        <p id="${this.uid}-error" class="mt-2 text-xs ml-error-text">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
    }
    if (this.hasSlot('Helper')) {
      return html`
        <p id="${this.uid}-helper" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
    }
    return html``;
  }

  private renderTriggerContent(): TemplateResult {
    if (this.hasSlot('Trigger') && (!this.value || this.value.length === 0)) {
      return html`${unsafeHTML(this.getSlotContent('Trigger'))}`;
    }

    const title = (this.value?.length || 0) > 0
      ? (this.multiple ? this.msg.addMore : this.msg.replaceFile)
      : this.msg.triggerTitle;

    return html`
      <div class="flex flex-col items-center justify-center gap-1 text-center">
        <div class="text-sm font-medium ml-label">${title}</div>
        <div class="text-xs ml-text-muted">${this.msg.triggerSubtitle}</div>
      </div>
    `;
  }

  private renderLoadingIndicator(): TemplateResult {
    if (!this.loading) return html``;
    return html`
      <div class="absolute inset-0 flex items-center justify-center rounded-lg ml-dropzone-loading-overlay">
        <div class="flex items-center gap-2 text-sm ml-text-muted">
          <span class="inline-block h-4 w-4 animate-spin rounded-full ml-dropzone-spinner"></span>
          ${this.msg.loading}
        </div>
      </div>
    `;
  }

  private renderFileList(): TemplateResult {
    if (!this.value || this.value.length === 0) return html``;

    return html`
      <div class="mt-3 grid gap-2">
        ${this.value.map((file, index) => {
          const previewUrl = this.getPreviewUrl(file);
          return html`
            <div class="${this.getFileItemClasses()}">
              <div class="h-12 w-12 overflow-hidden rounded-md border flex items-center justify-center ml-preview-thumbnail">
                ${previewUrl
                  ? html`<img src="${previewUrl}" alt="${file.name}" class="h-full w-full object-cover" />`
                  : html`<span class="text-[10px] ml-text-muted">${this.msg.noPreview}</span>`
                }
              </div>
              <div class="flex flex-col">
                <span class="text-sm ml-text">${file.name}</span>
                <span class="text-xs ml-text-muted">${this.formatSize(file.size)}</span>
              </div>
              <button
                class="${this.getRemoveButtonClasses()}"
                type="button"
                @click=${() => this.handleRemoveFile(index)}
                ?disabled=${this.disabled || this.loading}
                aria-label="${this.msg.remove}"
              >
                ${svg`
                  <svg viewBox="0 0 24 24" class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 6h18"></path>
                    <path d="M8 6v12"></path>
                    <path d="M16 6v12"></path>
                    <path d="M5 6l1-3h12l1 3"></path>
                  </svg>
                `}
                ${this.msg.remove}
              </button>
            </div>
          `;
        })}
      </div>
    `;
  }

  private getFileInput(): HTMLInputElement | null {
    return this.querySelector('input[type="file"]');
  }

  // ==========================================================================
  // RENDER
  // ==========================================================================
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];

    const hasError = Boolean(this.error);
    const describedBy = hasError
      ? `${this.uid}-error`
      : this.hasSlot('Helper')
        ? `${this.uid}-helper`
        : nothing;
    const labelledBy = this.hasSlot('Label') ? `${this.uid}-label` : nothing;

    return html`
      <div class="${cn(this.getContainerClasses(), this.cssClass)}">
        ${this.renderLabel()}

        <div
          class="${this.getDropZoneClasses(hasError)}"
          role="button"
          tabindex="${this.disabled || this.loading ? -1 : 0}"
          aria-disabled="${this.disabled || this.loading}"
          aria-labelledby=${labelledBy ?? nothing}
          aria-describedby=${describedBy ?? nothing}
          aria-invalid="${hasError}"
          @click=${this.handleTriggerClick}
          @keydown=${this.handleTriggerKeydown}
          @dragover=${this.handleDragOver}
          @dragleave=${this.handleDragLeave}
          @drop=${this.handleDrop}
        >
          ${this.renderTriggerContent()}
          <input
            class="hidden"
            type="file"
            accept="${this.accept}"
            ?multiple=${this.multiple}
            ?disabled=${this.disabled || this.loading}
            aria-labelledby=${labelledBy ?? nothing}
            aria-describedby=${describedBy ?? nothing}
            aria-invalid="${hasError}"
            @change=${this.handleInputChange}
          
          @input="${(e: Event) => e.stopPropagation()}"
/>
          ${this.renderLoadingIndicator()}
        </div>

        ${this.renderFileList()}
        ${this.renderHelperOrError()}
      </div>
    `;
  }
}
