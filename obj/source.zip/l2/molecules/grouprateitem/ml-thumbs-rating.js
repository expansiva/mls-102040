var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var ThumbsRatingMolecule_1;
/// <mls fileReference="_102040_/l2/molecules/grouprateitem/ml-thumbs-rating.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// THUMBS RATING MOLECULE
// =============================================================================
// Skill Group: groupRateItem
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    empty: '—',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let ThumbsRatingMolecule = ThumbsRatingMolecule_1 = class ThumbsRatingMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        this.instanceId = ++ThumbsRatingMolecule_1.instanceCounter;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = 0;
        this.max = 5;
        this.step = 1;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.hoverValue = null;
    }
    // ===========================================================================
    // ACCESSIBILITY IDS
    // ===========================================================================
    get labelId() {
        return `thumbs-label-${this.instanceId}`;
    }
    get helperId() {
        return `thumbs-helper-${this.instanceId}`;
    }
    get errorId() {
        return `thumbs-error-${this.instanceId}`;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    canInteract() {
        return this.isEditing && !this.disabled && !this.readonly;
    }
    getErrorState() {
        return Boolean(this.error) || (this.required && this.value === null && this.isEditing);
    }
    getDescribedBy() {
        if (!this.isEditing)
            return undefined;
        if (this.error)
            return this.errorId;
        if (this.hasSlot('Helper'))
            return this.helperId;
        return undefined;
    }
    getItems() {
        const slotItems = this.getSlots('Item');
        const parsed = slotItems
            .map((el) => {
            const raw = el.getAttribute('value');
            const value = raw !== null ? Number(raw) : NaN;
            const label = el.innerHTML || '';
            return { value, label };
        })
            .filter((item) => !Number.isNaN(item.value));
        if (parsed.length >= 2)
            return parsed.slice(0, 2);
        const fallback = this.generateFallbackItems(parsed);
        return fallback.slice(0, 2);
    }
    generateFallbackItems(existing) {
        if (existing.length === 1) {
            const existingValue = existing[0].value;
            let altValue = existingValue === this.min ? this.max : this.min;
            if (altValue === existingValue) {
                altValue = existingValue + (this.step || 1);
            }
            return [existing[0], { value: altValue, label: '' }];
        }
        let first = this.min;
        let second = this.max;
        if (first === second) {
            second = first + (this.step || 1);
        }
        return [
            { value: first, label: '' },
            { value: second, label: '' },
        ];
    }
    getGroupClasses(errorState) {
        return [
            'flex items-center gap-2 rounded-md border p-1 w-max',
            errorState ? 'ml-border-error' : 'ml-border',
            this.disabled ? 'ml-disabled' : '',
            !this.disabled && this.readonly ? 'opacity-80' : '',
        ].filter(Boolean).join(' ');
    }
    getOptionClasses(isActive, isEditing) {
        return [
            'inline-flex items-center justify-center rounded-md border px-3 py-2 text-xl transition',
            'ml-surface ml-text',
            isActive
                ? 'ml-thumbs-option-selected'
                : 'ml-border',
            isEditing && this.canInteract() && !isActive ? 'ml-thumbs-option' : '',
            isEditing && this.canInteract() ? 'ml-focus-ring' : '',
            this.disabled ? 'ml-disabled' : '',
            !this.disabled && (this.readonly || !isEditing) ? 'cursor-default' : '',
            this.canInteract() ? 'cursor-pointer' : '',
        ].filter(Boolean).join(' ');
    }
    getOptionLabel(item) {
        const label = item.label?.trim();
        return label ? label : String(item.value);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleOptionMouseEnter(value) {
        if (!this.canInteract())
            return;
        this.hoverValue = value;
    }
    handleOptionMouseLeave() {
        if (!this.canInteract())
            return;
        this.hoverValue = null;
    }
    handleOptionClick(value) {
        if (!this.canInteract())
            return;
        this.value = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value },
        }));
    }
    handleOptionFocus() {
        if (!this.canInteract())
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleOptionBlur() {
        if (!this.canInteract())
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleKeydown(e) {
        if (!this.canInteract())
            return;
        const items = this.getItems();
        const options = Array.from(this.querySelectorAll('[data-rating-option]'));
        if (!options.length)
            return;
        const activeElement = this.ownerDocument.activeElement;
        let currentIndex = options.findIndex((el) => el === activeElement);
        if (currentIndex < 0) {
            const selectedIndex = items.findIndex((item) => item.value === this.value);
            currentIndex = selectedIndex >= 0 ? selectedIndex : 0;
            options[currentIndex]?.focus();
        }
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            const nextIndex = (currentIndex + 1) % options.length;
            options[nextIndex]?.focus();
            e.preventDefault();
        }
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            const prevIndex = (currentIndex - 1 + options.length) % options.length;
            options[prevIndex]?.focus();
            e.preventDefault();
        }
        if (e.key === 'Enter' || e.key === ' ') {
            const target = options[currentIndex];
            const raw = target?.getAttribute('data-value');
            const value = raw !== null ? Number(raw) : null;
            if (value !== null && !Number.isNaN(value)) {
                this.handleOptionClick(value);
            }
            e.preventDefault();
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div id=${this.labelId} class="${cn('text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `
        <div id=${this.errorId} class="text-xs ml-error-text">
          ${unsafeHTML(this.error)}
        </div>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <div id=${this.helperId} class="${cn('text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </div>
      `;
        }
        return html ``;
    }
    renderOption(item, index, isEditing) {
        const active = this.hoverValue !== null ? this.hoverValue === item.value : this.value === item.value;
        const label = this.getOptionLabel(item);
        const ariaChecked = active ? 'true' : 'false';
        const tabIndex = this.value === null ? (index === 0 ? 0 : -1) : (this.value === item.value ? 0 : -1);
        if (!isEditing) {
            return html `
        <div
          class=${this.getOptionClasses(active, false)}
          role="radio"
          aria-checked=${ariaChecked}
          aria-label=${String(item.value)}
        >
          <span class="leading-none">${unsafeHTML(label)}</span>
        </div>
      `;
        }
        return html `
      <button
        type="button"
        class=${this.getOptionClasses(active, true)}
        role="radio"
        aria-checked=${ariaChecked}
        aria-label=${String(item.value)}
        tabindex=${tabIndex}
        data-rating-option
        data-value=${String(item.value)}
        @mouseenter=${() => this.handleOptionMouseEnter(item.value)}
        @mouseleave=${this.handleOptionMouseLeave}
        @click=${() => this.handleOptionClick(item.value)}
        @focus=${this.handleOptionFocus}
        @blur=${this.handleOptionBlur}
      >
        <span class="leading-none">${unsafeHTML(label)}</span>
      </button>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const items = this.getItems();
        const errorState = this.getErrorState();
        const describedBy = this.getDescribedBy();
        if (!this.isEditing) {
            const hasValue = this.value !== null;
            return html `
        <div class="${cn('flex flex-col gap-1', this.cssClass)}">
          ${this.renderLabel()}
          <div
            class=${this.getGroupClasses(false)}
            role="radiogroup"
            aria-labelledby=${this.hasSlot('Label') ? this.labelId : undefined}
            aria-readonly="true"
          >
            ${hasValue
                ? items.map((item, index) => this.renderOption(item, index, false))
                : html `<span class="px-3 py-2 ml-text-muted">${this.msg.empty}</span>`}
          </div>
        </div>
      `;
        }
        return html `
      <div class="${cn('flex flex-col gap-1', this.cssClass)}" data-name=${this.name}>
        ${this.renderLabel()}
        <div
          class=${this.getGroupClasses(errorState)}
          role="radiogroup"
          aria-labelledby=${this.hasSlot('Label') ? this.labelId : undefined}
          aria-describedby=${describedBy}
          aria-invalid=${errorState ? 'true' : 'false'}
          aria-required=${this.required ? 'true' : 'false'}
          @keydown=${this.handleKeydown}
        >
          ${items.map((item, index) => this.renderOption(item, index, true))}
        </div>
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
ThumbsRatingMolecule.instanceCounter = 0;
__decorate([
    propertyDataSource({ type: Number })
], ThumbsRatingMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], ThumbsRatingMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], ThumbsRatingMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], ThumbsRatingMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], ThumbsRatingMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], ThumbsRatingMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], ThumbsRatingMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ThumbsRatingMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ThumbsRatingMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ThumbsRatingMolecule.prototype, "required", void 0);
__decorate([
    state()
], ThumbsRatingMolecule.prototype, "hoverValue", void 0);
ThumbsRatingMolecule = ThumbsRatingMolecule_1 = __decorate([
    customElement('grouprateitem--ml-thumbs-rating')
], ThumbsRatingMolecule);
export { ThumbsRatingMolecule };
