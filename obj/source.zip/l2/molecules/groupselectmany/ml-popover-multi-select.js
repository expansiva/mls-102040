var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectmany/ml-popover-multi-select.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML POPOVER MULTI SELECT MOLECULE
// =============================================================================
// Skill Group: groupSelectMany
// This molecule does NOT contain business logic.
import { html, render as litRender, svg, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select options',
    noResults: 'No results found',
    loading: 'Loading...',
    search: 'Search',
    selected: 'selected',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione opções',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        search: 'Buscar',
        selected: 'selecionado',
    },
};
let MlPopoverMultiSelectMolecule = class MlPopoverMultiSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================='
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.minSelection = 0;
        this.maxSelection = 0;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================='
        this.isOpen = false;
        this.searchQuery = '';
        this.activeIndex = -1;
        this.labelId = `ml-popover-multi-select-label-${Math.random().toString(36).slice(2)}`;
        this.errorId = `ml-popover-multi-select-error-${Math.random().toString(36).slice(2)}`;
        this.panelId = `ml-popover-multi-select-panel-${Math.random().toString(36).slice(2)}`;
        this.hasFocus = false;
        this.portalContainer = null;
        this.portalClassName = 'groupselectmany--ml-popover-multi-select';
        this.boundUpdatePosition = () => this.updatePanelPosition();
        this.handleDocumentClick = (e) => {
            if (!this.isOpen)
                return;
            const target = e.target;
            if (!this.contains(target) && !this.portalContainer?.contains(target)) {
                this.closePanel();
            }
        };
        this.handleDocumentKeyDown = (e) => {
            if (!this.isOpen)
                return;
            if (e.key === 'Escape') {
                this.closePanel();
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================='
    disconnectedCallback() {
        super.disconnectedCallback();
        this.destroyPortal();
    }
    updated(changed) {
        if (changed.has('isOpen')) {
            if (this.isOpen) {
                document.addEventListener('click', this.handleDocumentClick, true);
                document.addEventListener('keydown', this.handleDocumentKeyDown);
                this.setInitialActiveIndex();
                this.focusAfterOpen();
            }
            else {
                document.removeEventListener('click', this.handleDocumentClick, true);
                document.removeEventListener('keydown', this.handleDocumentKeyDown);
                this.activeIndex = -1;
            }
        }
        if (changed.has('loading') && this.loading && this.isOpen) {
            this.closePanel();
        }
        if (changed.has('isEditing') && !this.isEditing && this.isOpen) {
            this.closePanel();
        }
        if (this.isOpen && this.portalContainer) {
            this.renderPortalContent();
            this.updatePanelPosition();
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================='
    handleTriggerClick() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.isOpen ? this.closePanel() : this.openPanel();
    }
    handleTriggerFocus() {
        if (!this.isEditing)
            return;
        if (!this.hasFocus) {
            this.hasFocus = true;
            this.dispatchFocusEvent();
        }
    }
    handleTriggerBlur() {
        if (!this.isEditing)
            return;
        if (this.isOpen)
            return;
        this.dispatchBlurIfNeeded();
    }
    handleItemClick(item, isItemDisabled) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (isItemDisabled)
            return;
        const currentValues = this.parseValue(this.value);
        const isSelected = currentValues.includes(item.value);
        let nextValues = [];
        if (isSelected) {
            nextValues = currentValues.filter((val) => val !== item.value);
        }
        else {
            nextValues = [...currentValues, item.value];
        }
        this.value = nextValues.join(',');
        this.dispatchChangeEvent(this.value);
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
        this.activeIndex = -1;
        this.setInitialActiveIndex();
    }
    handlePanelKeyDown(e) {
        if (!this.isOpen)
            return;
        if (e.key === 'Escape') {
            this.closePanel();
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            this.moveActiveIndex(e.key === 'ArrowDown' ? 1 : -1);
            return;
        }
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.toggleActiveItem();
        }
    }
    // ===========================================================================
    // OPEN/CLOSE HELPERS
    // ==========================================================================='
    openPanel() {
        if (this.isOpen)
            return;
        this.isOpen = true;
        this.createPortal();
    }
    closePanel() {
        if (!this.isOpen)
            return;
        this.isOpen = false;
        this.destroyPortal();
        this.dispatchBlurIfNeeded();
    }
    focusAfterOpen() {
        requestAnimationFrame(() => {
            const container = this.portalContainer || this;
            const searchInput = container.querySelector('[data-ml-search]');
            if (this.searchable && searchInput) {
                searchInput.focus();
                return;
            }
            this.focusActiveItem();
        });
    }
    dispatchChangeEvent(value) {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value },
        }));
    }
    dispatchFocusEvent() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    dispatchBlurIfNeeded() {
        if (!this.hasFocus)
            return;
        this.hasFocus = false;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // DATA PREP
    // ==========================================================================='
    parseValue(value) {
        if (!value)
            return [];
        return value.split(',').map((val) => val.trim()).filter(Boolean);
    }
    collectSlotData() {
        const groups = [];
        const allItems = [];
        const groupEls = this.getSlots('Group');
        for (const groupEl of groupEls) {
            const label = groupEl.getAttribute('label') || '';
            const itemEls = Array.from(groupEl.querySelectorAll('Item'));
            const groupItems = itemEls.map((el) => this.createItemData(el, label));
            if (groupItems.length > 0) {
                groups.push({ label, items: groupItems });
                allItems.push(...groupItems);
            }
        }
        const itemEls = this.getSlots('Item').filter((el) => !el.closest('Group'));
        const items = itemEls.map((el) => this.createItemData(el));
        allItems.push(...items);
        return { groups, items, allItems };
    }
    createItemData(el, groupLabel) {
        const value = el.getAttribute('value') || '';
        const labelHtml = el.innerHTML.trim();
        const labelText = (el.textContent || '').trim();
        const disabled = el.hasAttribute('disabled');
        return { value, labelHtml, labelText, disabled, groupLabel };
    }
    filterData(data, query) {
        if (!query)
            return data;
        const q = query.toLowerCase();
        const groups = data.groups.map((group) => {
            const groupMatch = group.label.toLowerCase().includes(q);
            const items = groupMatch
                ? group.items
                : group.items.filter((item) => item.labelText.toLowerCase().includes(q));
            return { label: group.label, items };
        }).filter((group) => group.items.length > 0);
        const items = data.items.filter((item) => item.labelText.toLowerCase().includes(q));
        return { groups, items };
    }
    getSelectionState() {
        const selectedValues = this.parseValue(this.value);
        const selectedSet = new Set(selectedValues);
        const selectedCount = selectedValues.length;
        const selectionFull = this.maxSelection > 0 && selectedCount >= this.maxSelection;
        return { selectedValues, selectedSet, selectedCount, selectionFull };
    }
    getValidationError(selectedCount) {
        if (this.error)
            return this.error;
        if (this.required && selectedCount === 0)
            return ' ';
        if (this.minSelection > 0 && selectedCount < this.minSelection)
            return ' ';
        if (this.maxSelection > 0 && selectedCount > this.maxSelection)
            return ' ';
        return '';
    }
    getItemDisabled(item, selectionFull, selectedSet) {
        if (this.disabled || this.readonly || this.loading)
            return true;
        if (item.disabled)
            return true;
        if (selectionFull && !selectedSet.has(item.value))
            return true;
        return false;
    }
    getSelectedLabelMap(items) {
        const map = new Map();
        for (const item of items) {
            map.set(item.value, item.labelHtml || item.labelText || item.value);
        }
        return map;
    }
    // ===========================================================================
    // KEYBOARD HELPERS
    // ==========================================================================='
    getVisibleItems() {
        const slotData = this.collectSlotData();
        const filtered = this.filterData(slotData, this.searchQuery);
        const { selectedSet, selectionFull } = this.getSelectionState();
        const flatItems = [];
        for (const group of filtered.groups) {
            flatItems.push(...group.items);
        }
        flatItems.push(...filtered.items);
        const visibleItems = flatItems.map((item, index) => ({
            item,
            index,
            disabled: this.getItemDisabled(item, selectionFull, selectedSet),
        }));
        return visibleItems;
    }
    setInitialActiveIndex() {
        if (!this.isOpen)
            return;
        const visibleItems = this.getVisibleItems();
        const firstEnabled = visibleItems.find((entry) => !entry.disabled);
        this.activeIndex = firstEnabled ? firstEnabled.index : -1;
    }
    moveActiveIndex(direction) {
        const visibleItems = this.getVisibleItems();
        if (visibleItems.length === 0)
            return;
        let currentIndex = this.activeIndex;
        let nextIndex = currentIndex;
        const maxIndex = visibleItems.length - 1;
        for (let i = 0; i < visibleItems.length; i++) {
            nextIndex = Math.min(Math.max(currentIndex + direction, 0), maxIndex);
            const nextItem = visibleItems[nextIndex];
            if (!nextItem.disabled) {
                this.activeIndex = nextIndex;
                this.focusActiveItem();
                return;
            }
            currentIndex = nextIndex;
        }
    }
    toggleActiveItem() {
        const visibleItems = this.getVisibleItems();
        const activeEntry = visibleItems[this.activeIndex];
        if (!activeEntry)
            return;
        this.handleItemClick(activeEntry.item, activeEntry.disabled);
    }
    focusActiveItem() {
        const container = this.portalContainer || this;
        const activeButton = container.querySelector(`[data-ml-item][data-index="${this.activeIndex}"]`);
        if (activeButton) {
            activeButton.focus();
        }
    }
    // ===========================================================================
    // PORTAL
    // ===========================================================================
    createPortal() {
        if (this.portalContainer)
            return;
        this.portalContainer = document.createElement('div');
        if (this.portalClassName) {
            this.portalContainer.classList.add(this.portalClassName);
        }
        document.body.appendChild(this.portalContainer);
        this.updatePanelPosition();
        this.renderPortalContent();
        window.addEventListener('scroll', this.boundUpdatePosition, true);
        window.addEventListener('resize', this.boundUpdatePosition);
    }
    destroyPortal() {
        if (!this.portalContainer)
            return;
        window.removeEventListener('scroll', this.boundUpdatePosition, true);
        window.removeEventListener('resize', this.boundUpdatePosition);
        this.portalContainer.remove();
        this.portalContainer = null;
    }
    updatePanelPosition() {
        if (!this.portalContainer)
            return;
        const trigger = this.querySelector('button[role="combobox"]');
        if (!trigger)
            return;
        const rect = trigger.getBoundingClientRect();
        Object.assign(this.portalContainer.style, {
            position: 'fixed',
            top: `${rect.bottom + 8}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            zIndex: '9999',
        });
    }
    renderPortalContent() {
        if (!this.portalContainer)
            return;
        litRender(this.getPortalTemplate(), this.portalContainer, { host: this });
    }
    getPortalTemplate() {
        const slotData = this.collectSlotData();
        const filtered = this.filterData(slotData, this.searchQuery);
        const { selectedSet, selectionFull } = this.getSelectionState();
        const showEmpty = filtered.groups.length === 0 && filtered.items.length === 0;
        return html `
<div
id="${this.panelId}"
class="w-full rounded-lg border ml-select-panel shadow-lg"
role="listbox"
aria-multiselectable="true"
@keydown=${(e) => this.handlePanelKeyDown(e)}
>
${this.searchable
            ? html `
<div class="p-2 border-b ml-select-panel-divider">
<input
class="w-full rounded-md px-3 py-2 text-sm border ml-select-search focus:outline-none focus:ring-2"
.placeholder=${this.msg.search}
value=${this.searchQuery}
@input=${(e) => this.handleSearchInput(e)}
data-ml-search
/>
</div>`
            : nothing}
<div class="max-h-64 overflow-auto p-2">
${showEmpty ? this.renderEmpty() : this.renderItems(filtered.groups, filtered.items, selectedSet, selectionFull)}
</div>
</div>
`;
    }
    // ===========================================================================
    // RENDER HELPERS
    // ==========================================================================='
    getTriggerClasses(hasError) {
        return [
            'w-full min-h-[40px] rounded-lg px-3 py-2 text-sm border transition flex items-center justify-between gap-2',
            'ml-select-trigger',
            hasError
                ? 'ml-select-trigger-error'
                : '',
            'focus:outline-none focus:ring-2 ml-select-trigger-focus',
            (this.disabled || this.readonly || this.loading) ? 'ml-disabled' : 'cursor-pointer',
            this.isOpen ? 'ml-select-trigger-active' : '',
        ].filter(Boolean).join(' ');
    }
    getItemClasses(isSelected, isDisabled) {
        return [
            'w-full rounded-md px-3 py-2 text-sm transition flex items-center justify-between',
            isSelected
                ? 'ml-select-item-selected'
                : 'ml-select-item border border-transparent',
            (!isDisabled && !isSelected) ? 'ml-select-item-hover' : '',
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return nothing;
        return html `<label id="${this.labelId}" class=${cn('text-sm font-medium ml-label', this.getSlotClass('Label'))}>${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    renderHelper(hasError) {
        if (hasError || !this.hasSlot('Helper'))
            return nothing;
        return html `<p class=${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}>${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
    }
    renderError(hasError) {
        if (!hasError)
            return nothing;
        const message = this.error || '';
        return html `<p id="${this.errorId}" class="mt-1 text-xs ml-error-text">${unsafeHTML(message)}</p>`;
    }
    renderSelectedTag(label, isHtml) {
        return html `
<span class="px-2 py-0.5 rounded-full text-xs ml-select-tag">
${isHtml ? unsafeHTML(label) : label}
</span>
`;
    }
    renderTriggerContent(selectedLabels, selectedCount) {
        if (this.loading) {
            return html `<span class="ml-text-muted">${this.msg.loading}</span>`;
        }
        if (this.hasSlot('Trigger')) {
            return html `<span class=${cn('', this.getSlotClass('Trigger'))}>${unsafeHTML(this.getSlotContent('Trigger'))}</span>`;
        }
        if (selectedCount === 0) {
            const placeholder = this.placeholder || this.msg.placeholder;
            return html `<span class="ml-text-muted">${placeholder}</span>`;
        }
        const visible = selectedLabels.slice(0, 2);
        const extraCount = selectedCount - visible.length;
        return html `
<div class="flex flex-wrap items-center gap-1">
${visible.map((item) => this.renderSelectedTag(item.label, item.isHtml))}
${extraCount > 0
            ? html `<span class="text-xs ml-text-muted">+${extraCount}</span>`
            : nothing}
</div>
`;
    }
    renderEmpty() {
        const content = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noResults;
        return html `<div class=${cn('px-3 py-2 text-sm ml-text-muted', this.getSlotClass('Empty'))}>${unsafeHTML(content)}</div>`;
    }
    renderGroup(group, selectedSet, selectionFull, baseIndex) {
        let runningIndex = baseIndex;
        return html `
<div class="mb-2">
${group.label
            ? html `<div class="px-3 py-1 text-xs font-semibold ml-text-muted">${group.label}</div>`
            : nothing}
<div class="flex flex-col gap-1">
${group.items.map((item) => {
            const isSelected = selectedSet.has(item.value);
            const isDisabled = this.getItemDisabled(item, selectionFull, selectedSet);
            const itemIndex = runningIndex++;
            return html `
<button
type="button"
role="option"
aria-selected="${isSelected}"
aria-disabled="${isDisabled}"
class="${this.getItemClasses(isSelected, isDisabled)}"
?disabled=${isDisabled}
@mouseenter=${() => { this.activeIndex = itemIndex; }}
@click=${() => this.handleItemClick(item, isDisabled)}
@keydown=${this.handlePanelKeyDown}
data-ml-item
/data-index="${itemIndex}"
>
<span>${unsafeHTML(item.labelHtml || item.labelText)}</span>
${isSelected
                ? html `<span class="text-xs ml-select-check">✓</span>`
                : nothing}
</button>
`;
        })}
</div>
</div>
`;
    }
    renderItems(groups, items, selectedSet, selectionFull) {
        let indexCounter = 0;
        return html `
${groups.map((group) => {
            const template = this.renderGroup(group, selectedSet, selectionFull, indexCounter);
            indexCounter += group.items.length;
            return template;
        })}
${items.length
            ? html `<div class="flex flex-col gap-1">
${items.map((item) => {
                const isSelected = selectedSet.has(item.value);
                const isDisabled = this.getItemDisabled(item, selectionFull, selectedSet);
                const itemIndex = indexCounter++;
                return html `
<button
type="button"
role="option"
aria-selected="${isSelected}"
aria-disabled="${isDisabled}"
class="${this.getItemClasses(isSelected, isDisabled)}"
?disabled=${isDisabled}
@mouseenter=${() => { this.activeIndex = itemIndex; }}
@click=${() => this.handleItemClick(item, isDisabled)}
@keydown=${this.handlePanelKeyDown}
data-ml-item
/data-index="${itemIndex}"
>
<span>${unsafeHTML(item.labelHtml || item.labelText)}</span>
${isSelected
                    ? html `<span class="text-xs ml-select-check">✓</span>`
                    : nothing}
</button>
`;
            })}
</div>`
            : nothing}
`;
    }
    renderViewMode(selectedLabels) {
        const hasSelection = selectedLabels.length > 0;
        const placeholder = this.placeholder || this.msg.placeholder;
        return html `
<div class=${cn('flex flex-col gap-1', this.cssClass)}>
${this.renderLabel()}
<div class="min-h-[40px] rounded-lg px-3 py-2 text-sm border ml-select-view">
${hasSelection
            ? html `<div class="flex flex-wrap gap-1">
${selectedLabels.map((item) => this.renderSelectedTag(item.label, item.isHtml))}
</div>`
            : html `<span class="ml-text-muted">${placeholder}</span>`}
</div>
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================='
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const slotData = this.collectSlotData();
        const filtered = this.filterData(slotData, this.searchQuery);
        const { selectedValues, selectedSet, selectedCount, selectionFull } = this.getSelectionState();
        const hasError = this.isEditing ? Boolean(this.getValidationError(selectedCount)) : false;
        const labelMap = this.getSelectedLabelMap(slotData.allItems);
        const selectedLabels = selectedValues.map((val) => {
            const label = labelMap.get(val);
            if (label) {
                return { label, isHtml: true };
            }
            return { label: val, isHtml: false };
        });
        if (!this.isEditing) {
            return this.renderViewMode(selectedLabels);
        }
        const triggerClasses = this.getTriggerClasses(hasError);
        return html `
<div class=${cn('w-full', this.cssClass)} role="group">
<div class="flex items-start gap-3">
${this.renderLabel()}
<div class="relative flex-1">
<button
id="${this.name || this.panelId}"
type="button"
class="${triggerClasses}"
role="combobox"
aria-expanded="${this.isOpen}"
aria-haspopup="listbox"
aria-controls="${this.panelId}"
aria-labelledby="${this.hasSlot('Label') ? this.labelId : ''}"
aria-invalid="${hasError}"
aria-required="${this.required}"
?disabled=${this.disabled || this.readonly || this.loading}
@focus=${this.handleTriggerFocus}
@blur=${this.handleTriggerBlur}
@click=${this.handleTriggerClick}
@keydown=${(e) => {
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                this.openPanel();
            }
        }}
>
<div class="flex-1 flex items-center gap-2">
${this.renderTriggerContent(selectedLabels, selectedCount)}
</div>
<span class="ml-text-muted">
<svg viewBox="0 0 20 20" class="w-4 h-4" aria-hidden="true">
${svg `<path d="M5 7l5 5 5-5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>`}
</svg>
</span>
</button>
</div>
</div>
${this.renderError(hasError)}
${this.renderHelper(hasError)}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlPopoverMultiSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlPopoverMultiSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlPopoverMultiSelectMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlPopoverMultiSelectMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPopoverMultiSelectMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-selection' })
], MlPopoverMultiSelectMolecule.prototype, "minSelection", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-selection' })
], MlPopoverMultiSelectMolecule.prototype, "maxSelection", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlPopoverMultiSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPopoverMultiSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPopoverMultiSelectMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPopoverMultiSelectMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPopoverMultiSelectMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlPopoverMultiSelectMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlPopoverMultiSelectMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlPopoverMultiSelectMolecule.prototype, "activeIndex", void 0);
MlPopoverMultiSelectMolecule = __decorate([
    customElement('groupselectmany--ml-popover-multi-select')
], MlPopoverMultiSelectMolecule);
export { MlPopoverMultiSelectMolecule };
