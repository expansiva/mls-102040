/// <mls fileReference="_102040_/l2/molecules/groupnavigatesection/ml-tabs.ts" enhancement="_102020_/l2/enhancementAura" />


// =============================================================================
// GROUP NAVIGATE SECTION — TABS MOLECULE
// =============================================================================
// Skill Group: groupNavigateSection
// This molecule does NOT contain business logic.
import { html, TemplateResult, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';

/// **collab_i18n_start**
const message_en = {
  loading: 'Loading...',
  empty: 'No tabs available',
};
type MessageType = typeof message_en;
const messages: Record<string, MessageType> = {
  en: message_en,
  pt: {
    loading: 'Carregando...',
    empty: 'Nenhuma aba disponível',
  },
};
/// **collab_i18n_end**

interface TabItem {
  value: string;
  title: string;
  icon: string;
  disabled: boolean;
  // The LIVE <Tab> element — its children are projected into the panel, never serialized.
  element: Element;
}

@customElement('groupnavigatesection--ml-tabs')
export class MlTabsMolecule extends MoleculeAuraElement {
  private msg: MessageType = messages.en;

  // ===========================================================================
  // SLOT TAGS
  // ===========================================================================
  slotTags = ['Label', 'Tab'];

  // Tab carries CONTENT and CONTROLS — usually whole sections with their own molecules. Re-emitting
  // it through innerHTML + unsafeHTML handed the panel a COPY: every binding the consumer set inside
  // (@click, @change, .value…) was lost, and the real molecules stayed inert in the hidden Tab.
  // With live slots the active Tab's children are MOVED into the panel; switching tabs parks the
  // previous ones (listeners intact) until they come back.
  protected usesLiveSlots = true;

  // ===========================================================================
  // PROPERTIES — From Contract
  // ===========================================================================
  @propertyDataSource({ type: String })
  value: string | null = null;

  @propertyDataSource({ type: String })
  error: string = '';

  @propertyDataSource({ type: Boolean })
  disabled = false;

  @propertyDataSource({ type: Boolean })
  loading = false;

  // ===========================================================================
  // INTERNAL STATE
  // ===========================================================================
  @state()
  private uid = `tabs-${Math.random().toString(36).slice(2, 10)}`;

  // ===========================================================================
  // EVENT HANDLERS
  // ===========================================================================
  private handleTabClick(tab: TabItem, activeValue: string | null) {
    if (this.disabled || this.loading || tab.disabled) return;
    if (activeValue === tab.value) return;
    this.value = tab.value;
    this.dispatchEvent(new CustomEvent('change', {
      bubbles: true,
      composed: true,
      detail: { value: tab.value, title: tab.title },
    }));
  }

  private handleKeyDown(event: KeyboardEvent) {
    if (this.disabled || this.loading) return;
    const tabs = this.parseTabs();
    if (tabs.length === 0) return;

    const activeValue = this.getActiveValue(tabs);
    const enabledTabs = tabs.filter(t => !t.disabled);
    if (enabledTabs.length === 0) return;

    const buttons = Array.from(this.querySelectorAll('[data-tab-button]')) as HTMLButtonElement[];
    const enabledButtons = buttons.filter(btn => btn.getAttribute('aria-disabled') !== 'true');

    const currentIndexByFocus = enabledButtons.indexOf(document.activeElement as HTMLButtonElement);
    const currentIndexByActive = enabledTabs.findIndex(t => t.value === activeValue);
    const currentIndex = currentIndexByFocus >= 0 ? currentIndexByFocus : currentIndexByActive;

    if (event.key === 'ArrowRight') {
      event.preventDefault();
      const nextIndex = (currentIndex + 1 + enabledButtons.length) % enabledButtons.length;
      enabledButtons[nextIndex]?.focus();
    }

    if (event.key === 'ArrowLeft') {
      event.preventDefault();
      const prevIndex = (currentIndex - 1 + enabledButtons.length) % enabledButtons.length;
      enabledButtons[prevIndex]?.focus();
    }

    if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault();
      const focused = document.activeElement as HTMLButtonElement | null;
      if (!focused) return;
      const tabValue = focused.getAttribute('data-value');
      const tab = tabs.find(t => t.value === tabValue);
      if (tab) this.handleTabClick(tab, activeValue);
    }
  }

  // ===========================================================================
  // HELPERS
  // ===========================================================================
  // Read from the LIVE children, not the snapshot: a projected Tab is empty and a re-snapshot would
  // read it so. Direct children only — a nested tabs molecule inside a panel has Tabs of its own.
  private parseTabs(): TabItem[] {
    return Array.from(this.children).filter(el => el.tagName === 'TAB').map(el => ({
      value: el.getAttribute('value') || '',
      title: el.getAttribute('title') || '',
      icon: el.getAttribute('icon') || '',
      disabled: el.hasAttribute('disabled'),
      element: el,
    }));
  }

  private getActiveValue(tabs: TabItem[]): string | null {
    if (tabs.length === 0) return null;
    const found = tabs.find(t => t.value === this.value);
    if (found && !found.disabled) return found.value;
    const firstEnabled = tabs.find(t => !t.disabled);
    return firstEnabled ? firstEnabled.value : null;
  }

  private toSafeId(value: string): string {
    return value.replace(/[^a-zA-Z0-9_-]/g, '-');
  }

  private getTabClasses(isActive: boolean, isDisabled: boolean): string {
    return [
      'inline-flex items-center gap-2 px-4 py-2 text-sm border-b-2 transition',
      'ml-tab',
      isActive ? 'ml-tab-active' : '',
      isDisabled ? 'ml-disabled' : 'cursor-pointer',
    ].filter(Boolean).join(' ');
  }

  private getTabListClasses(): string {
    return 'flex flex-wrap gap-2 border-b ml-tab-list';
  }

  private getPanelClasses(): string {
    return 'mt-4 rounded-lg border p-4 ml-tab-panel';
  }

  private renderLabel(): TemplateResult {
    if (!this.hasSlot('Label')) return html``;
    return html`
      <div id="${this.uid}-label" class="${cn('mb-2 text-sm font-semibold ml-label', this.getSlotClass('Label'))}">
        ${this.renderLiveSlot('Label')}
      </div>
    `;
  }

  private renderLoading(): TemplateResult {
    return html`
      <div class="rounded-lg border p-4 text-sm ml-tab-container ml-text-muted">
        ${this.msg.loading}
      </div>
    `;
  }

  private renderError(): TemplateResult {
    if (!this.error) return html``;
    return html`
      <p class="mt-2 text-xs ml-error-text">
        ${unsafeHTML(String(this.error))}
      </p>
    `;
  }

  // ===========================================================================
  // RENDER
  // ===========================================================================
  render() {
    const lang = this.getMessageKey(messages);
    this.msg = messages[lang];

    if (this.loading) {
      return html`
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel()}
          ${this.renderLoading()}
        </div>
      `;
    }

    const tabs = this.parseTabs();
    if (tabs.length === 0) {
      return html`
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel()}
          <div class="rounded-lg border p-4 text-sm ml-tab-container ml-text-muted">
            ${this.msg.empty}
          </div>
        </div>
      `;
    }

    const activeValue = this.getActiveValue(tabs);
    const activeTab = tabs.find(t => t.value === activeValue) || null;
    const labelId = this.hasSlot('Label') ? `${this.uid}-label` : undefined;

    return html`
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        <div
          class="${this.getTabListClasses()}"
          role="tablist"
          aria-labelledby="${labelId || nothing}"
          @keydown="${this.handleKeyDown}"
        >
          ${tabs.map(tab => {
      const isActive = tab.value === activeValue;
      const isDisabled = this.disabled || this.loading || tab.disabled;
      const tabId = `${this.uid}-tab-${this.toSafeId(tab.value)}`;
      const panelId = `${this.uid}-panel-${this.toSafeId(tab.value)}`;
      return html`
              <button
                id="${tabId}"
                data-tab-button
                data-value="${tab.value}"
                class="${this.getTabClasses(isActive, isDisabled)}"
                role="tab"
                type="button"
                aria-selected="${isActive ? 'true' : 'false'}"
                aria-disabled="${isDisabled ? 'true' : 'false'}"
                aria-controls="${panelId}"
                tabindex="${isActive ? '0' : '-1'}"
                @click="${() => this.handleTabClick(tab, activeValue)}"
              >
                ${tab.icon ? html`<span class="text-base">${unsafeHTML(tab.icon)}</span>` : nothing}
                <span>${unsafeHTML(tab.title)}</span>
              </button>
            `;
    })}
        </div>

        ${activeTab
        ? html`
              <div
                id="${this.uid}-panel-${this.toSafeId(activeTab.value)}"
                class="${this.getPanelClasses()}"
                role="tabpanel"
                aria-labelledby="${this.uid}-tab-${this.toSafeId(activeTab.value)}"
              >
                ${this.renderLiveSlotFrom(activeTab.element)}
              </div>
            `
        : html``}

        ${this.renderError()}
      </div>
    `;
  }
}
