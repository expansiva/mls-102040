/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-combobox.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML COMBOBOX MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
import { html, render as litRender, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search or select...',
    empty: 'No options found',
    loading: 'Loading...',
    clear: 'Clear value',
    useValue: 'Use',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Pesquisar ou selecionar...',
        empty: 'Nenhuma opção encontrada',
        loading: 'Carregando...',
        clear: 'Limpar valor',
        useValue: 'Usar',
    },
};
let MlComboboxMolecule = class MlComboboxMolecule extends MoleculeAuraElement {
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    constructor() {
        super();
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.placeholder = '';
        this.name = '';
        this.error = '';
        /** When true, any typed text is accepted as the value (not just list items). */
        this.freeText = false;
        /** Show a clear (×) button when the field has a value. */
        this.clearable = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.inputText = '';
        this.isOpen = false;
        this.activeIndex = -1;
        this.uid = `combo-${Math.random().toString(36).slice(2)}`;
        this.lastValueSynced = undefined;
        this.portalContainer = null;
        this.portalWidgetName = 'groupselectone--ml-combobox';
        this.boundUpdatePosition = this.updatePanelPosition.bind(this);
    }
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        this._boundDocClick = this._boundDocClick.bind(this);
        document.addEventListener('click', this._boundDocClick);
    }
    disconnectedCallback() {
        document.removeEventListener('click', this._boundDocClick);
        this.destroyPortal();
        super.disconnectedCallback();
    }
    _boundDocClick(event) {
        if (!this.isOpen)
            return;
        const path = event.composedPath?.() || [];
        if (!this.contains(event.target) && (!this.portalContainer || !path.includes(this.portalContainer)))
            this.closeAndResolve();
    }
    firstUpdated() {
        this.syncInputFromValue();
        this.lastValueSynced = this.value;
    }
    updated(changedProps) {
        if (changedProps.has('value')) {
            this.syncInputFromValue();
            this.lastValueSynced = this.value;
        }
        if (this.isOpen && this.portalContainer) {
            this.renderPortalContent();
            this.updatePanelPosition();
        }
    }
    // ===========================================================================
    // PARSERS
    // ===========================================================================
    toPlainText(rawHtml) {
        return rawHtml.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    }
    parseItems() {
        const standalone = this.getSlots('Item')
            .filter(el => !el.closest('Group'))
            .map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
            labelText: this.toPlainText(el.innerHTML),
            disabled: el.hasAttribute('disabled'),
        }));
        const groups = this.getSlots('Group').map(group => ({
            label: group.getAttribute('label') || '',
            items: Array.from(group.querySelectorAll('Item')).map(el => ({
                value: el.getAttribute('value') || '',
                label: el.innerHTML,
                labelText: this.toPlainText(el.innerHTML),
                disabled: el.hasAttribute('disabled'),
            })),
        }));
        return { standalone, groups };
    }
    getAllItems() {
        const { standalone, groups } = this.parseItems();
        return [...standalone, ...groups.flatMap(g => g.items)];
    }
    filterItems(items, query) {
        if (!query)
            return items;
        const q = query.toLowerCase();
        return items.filter(i => i.labelText.toLowerCase().includes(q));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    syncInputFromValue() {
        if (!this.value) {
            this.inputText = '';
            return;
        }
        const found = this.getAllItems().find(i => i.value === this.value);
        this.inputText = found ? found.labelText : (this.freeText ? this.value : '');
    }
    getFlatVisible(filteredStandalone, filteredGroups) {
        return [...filteredStandalone, ...filteredGroups.flatMap(g => g.items)];
    }
    getNextEnabledIndex(items, start, step) {
        if (!items.length)
            return -1;
        let idx = start;
        for (let i = 0; i < items.length; i++) {
            idx = (idx + step + items.length) % items.length;
            if (!items[idx].disabled)
                return idx;
        }
        return -1;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInputFocus() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = true;
        this.activeIndex = -1;
        this.createPortal();
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleInputInput(event) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.inputText = event.target.value;
        this.isOpen = true;
        this.activeIndex = -1;
        this.createPortal();
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true, composed: true, detail: { value: this.inputText },
        }));
    }
    handleInputBlur() {
        if (!this.isEditing)
            return;
        // Delay so mousedown on an option fires selectItem before blur resolves
        setTimeout(() => {
            if (!this.isOpen) {
                this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            }
        }, 150);
    }
    handleKeyDown(event) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const { standalone, groups } = this.parseItems();
        const q = this.inputText;
        const flatItems = this.getFlatVisible(this.filterItems(standalone, q), groups.map(g => ({ ...g, items: this.filterItems(g.items, q) })).filter(g => g.items.length > 0));
        switch (event.key) {
            case 'Escape':
                this.closeAndResolve();
                this.destroyPortal();
                event.preventDefault();
                break;
            case 'ArrowDown':
                if (!this.isOpen)
                    this.isOpen = true;
                this.activeIndex = this.getNextEnabledIndex(flatItems, this.activeIndex, 1);
                event.preventDefault();
                break;
            case 'ArrowUp':
                if (!this.isOpen)
                    this.isOpen = true;
                this.activeIndex = this.getNextEnabledIndex(flatItems, this.activeIndex, -1);
                event.preventDefault();
                break;
            case 'Enter':
                if (this.isOpen && this.activeIndex >= 0) {
                    const item = flatItems[this.activeIndex];
                    if (item && !item.disabled)
                        this.selectItem(item);
                }
                else if (this.freeText && this.inputText.trim()) {
                    this.commitFreeText();
                }
                event.preventDefault();
                break;
            case 'Tab':
                this.closeAndResolve();
                break;
        }
    }
    selectItem(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.inputText = item.labelText;
        this.lastValueSynced = this.value;
        this.isOpen = false;
        this.activeIndex = -1;
        this.destroyPortal();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true, composed: true, detail: { value: this.value },
        }));
    }
    commitFreeText() {
        const next = this.inputText.trim() || null;
        if (next === this.value) {
            this.isOpen = false;
            this.destroyPortal();
            return;
        }
        this.value = next;
        this.lastValueSynced = this.value;
        this.isOpen = false;
        this.destroyPortal();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true, composed: true, detail: { value: this.value },
        }));
    }
    closeAndResolve() {
        if (this.freeText && this.isOpen) {
            this.commitFreeText();
        }
        else {
            this.syncInputFromValue();
        }
        this.isOpen = false;
        this.activeIndex = -1;
        this.destroyPortal();
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleClear(event) {
        event.stopPropagation();
        this.value = null;
        this.inputText = '';
        this.lastValueSynced = null;
        this.isOpen = false;
        this.destroyPortal();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true, composed: true, detail: { value: null },
        }));
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getInputClasses(hasError) {
        return cn('w-full rounded-lg border px-3 py-2 text-sm ml-text ml-combobox-input', 'ml-select-trigger', 'transition focus:outline-none focus:ring-2', hasError ? 'ml-select-trigger-error' : '', this.isOpen ? 'ml-select-trigger-open' : '', (this.disabled || this.loading) ? 'ml-disabled' : '', this.readonly ? 'cursor-default' : '', this.getSlotClass('Trigger'));
    }
    getOptionClasses(item, flatIndex) {
        const isSelected = item.value === this.value;
        const isActive = flatIndex === this.activeIndex;
        return cn('flex w-full items-center gap-2 px-3 py-2 text-sm cursor-pointer transition select-none ml-select-item', isSelected ? 'ml-select-item-selected' : '', isActive ? 'ml-select-item-highlighted' : '', item.disabled ? 'ml-disabled' : '', this.getSlotClass('Item'));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderCheckmark(item) {
        if (item.value !== this.value)
            return html ``;
        return html `
      <svg class="ml-auto h-4 w-4 flex-shrink-0 ml-select-checkmark" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        <path fill-rule="evenodd" d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z" clip-rule="evenodd"/>
      </svg>
    `;
    }
    renderOption(item, flatIndex, indent = false) {
        return html `
      <li
        id="${this.uid}-opt-${flatIndex}"
        role="option"
        aria-selected=${item.value === this.value ? 'true' : 'false'}
        aria-disabled=${item.disabled ? 'true' : 'false'}
        class=${this.getOptionClasses(item, flatIndex)}
        @mousedown=${(e) => { e.preventDefault(); this.selectItem(item); }}
      >
        <span class="flex-1 truncate ${indent ? 'pl-2' : ''}">${unsafeHTML(item.label)}</span>
        ${this.renderCheckmark(item)}
      </li>
    `;
    }
    renderDropdown(filteredStandalone, filteredGroups, flatItems, listId) {
        const total = filteredStandalone.length + filteredGroups.reduce((n, g) => n + g.items.length, 0);
        return html `
      <ul
        id=${listId}
        role="listbox"
        class="mt-1 max-h-60 w-full overflow-auto rounded-lg border py-1 focus:outline-none ml-select-panel"
      >
        ${this.loading ? html `
          <li class="px-3 py-2 text-sm ml-text-muted">${this.msg.loading}</li>
        ` : total === 0 ? html `
          <li class="px-3 py-2 text-sm ml-select-empty">
            ${this.hasSlot('Empty') ? unsafeHTML(this.getSlotContent('Empty')) : this.msg.empty}
          </li>
        ` : html `
          ${filteredStandalone.map(item => this.renderOption(item, flatItems.indexOf(item)))}
          ${filteredGroups.map(group => html `
            ${group.label ? html `
              <li role="presentation" class="px-3 pt-3 pb-1 text-xs font-semibold uppercase tracking-wider ml-text-muted select-none">
                ${group.label}
              </li>
            ` : nothing}
            ${group.items.map(item => this.renderOption(item, flatItems.indexOf(item), !!group.label))}
          `)}
        `}

        ${this.freeText && this.inputText.trim() && !flatItems.find(i => i.labelText.toLowerCase() === this.inputText.trim().toLowerCase()) ? html `
          <li
            class="flex items-center gap-2 px-3 py-2 text-sm ml-select-item cursor-pointer transition select-none"
            @mousedown=${(e) => { e.preventDefault(); this.commitFreeText(); }}
          >
            <svg class="h-4 w-4 flex-shrink-0 ml-select-checkmark" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2" aria-hidden="true">
              <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"/>
            </svg>
            <span>${this.msg.useValue} "<strong>${this.inputText.trim()}</strong>"</span>
          </li>
        ` : nothing}
      </ul>
    `;
    }
    renderLoading() {
        return html `
      <div class="h-9 w-full animate-pulse rounded-lg ml-select-trigger"></div>
    `;
    }
    // ===========================================================================
    // PORTAL
    // ===========================================================================
    createPortal() {
        if (this.portalContainer)
            return;
        this.portalContainer = document.createElement('div');
        if (this.portalWidgetName)
            this.portalContainer.setAttribute('data-widget', this.portalWidgetName);
        document.body.appendChild(this.portalContainer);
        this.updatePanelPosition();
        this.renderPortalContent();
        window.addEventListener('scroll', this.boundUpdatePosition, true);
        window.addEventListener('resize', this.boundUpdatePosition);
    }
    destroyPortal() {
        if (!this.portalContainer)
            return;
        window.removeEventListener('scroll', this.boundUpdatePosition, true);
        window.removeEventListener('resize', this.boundUpdatePosition);
        this.portalContainer.remove();
        this.portalContainer = null;
    }
    updatePanelPosition() {
        if (!this.portalContainer)
            return;
        const trigger = this.querySelector('[role="combobox"]');
        if (!trigger)
            return;
        const rect = trigger.getBoundingClientRect();
        Object.assign(this.portalContainer.style, {
            position: 'fixed',
            top: `${rect.bottom + 4}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            zIndex: '9999',
        });
    }
    renderPortalContent() {
        if (!this.portalContainer)
            return;
        litRender(this.getPortalTemplate(), this.portalContainer, { host: this });
    }
    getPortalTemplate() {
        const { standalone, groups } = this.parseItems();
        const q = this.inputText;
        const filteredStandalone = this.filterItems(standalone, q);
        const filteredGroups = groups
            .map(g => ({ ...g, items: this.filterItems(g.items, q) }))
            .filter(g => g.items.length > 0);
        const flatItems = this.getFlatVisible(filteredStandalone, filteredGroups);
        const listId = `${this.uid}-list`;
        return this.renderDropdown(filteredStandalone, filteredGroups, flatItems, listId);
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const inputId = `${this.uid}-input`;
        const listId = `${this.uid}-list`;
        const labelId = `${this.uid}-label`;
        const errorId = `${this.uid}-error`;
        const hasError = (!!this.error && this.error.length > 0) || (this.required && !this.value);
        const showClear = this.clearable && !this.disabled && !this.readonly && !this.loading
            && (!!this.value || !!this.inputText);
        // View-only mode
        if (!this.isEditing) {
            const found = this.getAllItems().find(i => i.value === this.value);
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.hasSlot('Label')
                ? html `<div id=${labelId} class="${cn('mb-1 text-sm ml-label', this.getSlotClass('Label'))}">${unsafeHTML(this.getSlotContent('Label'))}</div>`
                : nothing}
          <div class="text-sm ${this.value ? 'ml-text' : 'ml-text-muted'}">
            ${this.value
                ? (found ? unsafeHTML(found.label) : this.value)
                : (this.placeholder || this.msg.placeholder)}
          </div>
          ${this.name ? html `<input type="hidden" name=${this.name} value=${this.value ?? ''} />` : nothing}
        </div>
      `;
        }
        // Trailing icon sizes: chevron always at right; clear button to its left
        const inputPaddingRight = showClear ? '4rem' : '2.5rem';
        return html `
      <div class="${cn('w-full', this.cssClass)}">

        ${this.hasSlot('Label')
            ? html `<label for=${inputId} id=${labelId} class="${cn('mb-1.5 block text-sm font-medium ml-label', this.getSlotClass('Label'))}">${unsafeHTML(this.getSlotContent('Label'))}</label>`
            : nothing}

        <div class="relative">

          <!-- Text input -->
          ${this.loading && !this.isOpen ? this.renderLoading() : html `
            <input
              id=${inputId}
              type="text"
              role="combobox"
              autocomplete="off"
              spellcheck="false"
              aria-expanded=${this.isOpen ? 'true' : 'false'}
              aria-autocomplete="list"
              aria-controls=${listId}
              aria-activedescendant=${ifDefined(this.activeIndex >= 0 ? `${this.uid}-opt-${this.activeIndex}` : undefined)}
              aria-labelledby=${ifDefined(this.hasSlot('Label') ? labelId : undefined)}
              aria-describedby=${ifDefined(hasError ? errorId : undefined)}
              aria-invalid=${hasError ? 'true' : 'false'}
              aria-required=${this.required ? 'true' : 'false'}
              ?disabled=${this.disabled || this.loading}
              ?readonly=${this.readonly}
              placeholder=${this.placeholder || this.msg.placeholder}
              .value=${this.inputText}
              class=${this.getInputClasses(hasError)}
              style="padding-right:${inputPaddingRight}"
              @focus=${this.handleInputFocus}
              @input=${this.handleInputInput}
              @blur=${this.handleInputBlur}
              @keydown=${this.handleKeyDown}
            />

            <!-- Trailing icons -->
            <div class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3 gap-1">

              <!-- Clear button -->
              ${showClear ? html `
                <button
                  type="button"
                  aria-label=${this.msg.clear}
                  class="pointer-events-auto flex h-5 w-5 items-center justify-center rounded-full ml-text-muted transition focus:outline-none focus:ring-2"
                  @click=${this.handleClear}
                >
                  <svg class="h-3.5 w-3.5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"/>
                  </svg>
                </button>
              ` : nothing}

              <!-- Chevron / spinner -->
              <span class="flex h-4 w-4 items-center justify-center ml-text-muted">
                <svg class="h-4 w-4 transition-transform duration-150 ${this.isOpen ? 'rotate-180' : ''}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 10.94l3.71-3.71a.75.75 0 111.06 1.06l-4.24 4.24a.75.75 0 01-1.06 0L5.21 8.27a.75.75 0 01.02-1.06z" clip-rule="evenodd"/>
                </svg>
              </span>
            </div>
          `}
        </div>

        ${this.name ? html `<input type="hidden" name=${this.name} value=${this.value ?? ''} />` : nothing}

        ${hasError && this.error
            ? html `<p id=${errorId} class="mt-1.5 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`
            : !hasError && this.hasSlot('Helper')
                ? html `<p class="${cn('mt-1.5 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`
                : nothing}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlComboboxMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlComboboxMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlComboboxMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlComboboxMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'free-text' })
], MlComboboxMolecule.prototype, "freeText", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlComboboxMolecule.prototype, "clearable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlComboboxMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlComboboxMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlComboboxMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlComboboxMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlComboboxMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlComboboxMolecule.prototype, "inputText", void 0);
__decorate([
    state()
], MlComboboxMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlComboboxMolecule.prototype, "activeIndex", void 0);
MlComboboxMolecule = __decorate([
    customElement('groupselectone--ml-combobox')
], MlComboboxMolecule);
export { MlComboboxMolecule };
