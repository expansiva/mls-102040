/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-segmented-control.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEGMENTED CONTROL MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noOptions: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noOptions: 'Nenhuma opção disponível',
        loading: 'Carregando...',
    },
};
let SegmentedControlMolecule = class SegmentedControlMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedIndex = -1;
        this.parsedItems = [];
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseItems();
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            this.requestUpdate();
        }
    }
    // ===========================================================================
    // ITEM PARSING
    // ===========================================================================
    parseItems() {
        const itemElements = this.getSlots('Item');
        this.parsedItems = itemElements.map((el) => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML.trim(),
            disabled: el.hasAttribute('disabled'),
        }));
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.parsedItems.find((item) => item.value === value);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleKeyDown(e, index) {
        if (this.disabled || this.loading)
            return;
        const enabledItems = this.parsedItems.filter((item) => !item.disabled);
        const currentEnabledIndex = enabledItems.findIndex((item) => item.value === this.parsedItems[index]?.value);
        switch (e.key) {
            case 'ArrowRight':
            case 'ArrowDown':
                e.preventDefault();
                this.focusNextItem(currentEnabledIndex, enabledItems);
                break;
            case 'ArrowLeft':
            case 'ArrowUp':
                e.preventDefault();
                this.focusPreviousItem(currentEnabledIndex, enabledItems);
                break;
            case 'Enter':
            case ' ':
                e.preventDefault();
                if (!this.parsedItems[index]?.disabled) {
                    this.handleSelect(this.parsedItems[index]);
                }
                break;
        }
    }
    focusNextItem(currentIndex, enabledItems) {
        if (enabledItems.length === 0)
            return;
        const nextIndex = (currentIndex + 1) % enabledItems.length;
        const nextItem = enabledItems[nextIndex];
        const globalIndex = this.parsedItems.findIndex((item) => item.value === nextItem.value);
        this.focusedIndex = globalIndex;
        this.focusSegment(globalIndex);
    }
    focusPreviousItem(currentIndex, enabledItems) {
        if (enabledItems.length === 0)
            return;
        const prevIndex = currentIndex <= 0 ? enabledItems.length - 1 : currentIndex - 1;
        const prevItem = enabledItems[prevIndex];
        const globalIndex = this.parsedItems.findIndex((item) => item.value === prevItem.value);
        this.focusedIndex = globalIndex;
        this.focusSegment(globalIndex);
    }
    focusSegment(index) {
        const segments = this.querySelectorAll('[role="option"]');
        const segment = segments[index];
        if (segment) {
            segment.focus();
        }
    }
    handleFocus() {
        if (this.disabled || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.focusedIndex = -1;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getContainerClasses() {
        return cn('flex w-full p-1 gap-1 ml-segmented-track', this.error ? 'ml-segmented-track-error' : '', this.disabled ? 'ml-disabled' : '', this.loading ? 'ml-disabled cursor-wait' : '');
    }
    getSegmentClasses(item, isSelected) {
        return cn('px-4 py-2 text-sm font-medium transition-all duration-200 focus:outline-none ml-segmented-option', isSelected ? 'ml-segmented-option-active' : '', item.disabled ? 'ml-disabled' : '', !item.disabled && !this.disabled && !this.readonly && !this.loading ? 'cursor-pointer' : '', this.readonly && !item.disabled ? 'cursor-default' : '', this.getSlotClass('Item'));
    }
    getLabelClasses() {
        return cn('block text-xs ml-label', this.getSlotClass('Label'));
    }
    getHelperClasses() {
        return cn('mt-1.5 text-xs ml-helper', this.getSlotClass('Helper'));
    }
    getErrorClasses() {
        return 'mt-1.5 text-xs ml-error-text';
    }
    getViewModeClasses() {
        return 'text-sm ml-text';
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.parseItems();
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayText = selectedItem
            ? selectedItem.label
            : this.placeholder || this.getSlotContent('Trigger') || this.msg.placeholder;
        return html `
      <div class=${this.getViewModeClasses()}>
        ${unsafeHTML(displayText)}
      </div>
    `;
    }
    renderEditMode() {
        const labelId = `label-${this.name || Math.random().toString(36).substr(2, 9)}`;
        const errorId = `error-${this.name || Math.random().toString(36).substr(2, 9)}`;
        const hasError = !!this.error;
        return html `
      <div class="${cn('flex flex-col w-full', this.cssClass)}">
        <div class="min-h-[1rem]">
          ${this.renderLabel(labelId)}
        </div>
        ${this.loading ? this.renderLoading() : this.renderSegments(labelId, errorId, hasError)}
        ${this.renderFeedback(errorId, hasError)}
      </div>
    `;
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label')) {
            return html ``;
        }
        return html `
      <label id=${labelId} class=${this.getLabelClasses()}>
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required
            ? html `<span class="ml-error-text ml-0.5">*</span>`
            : html ``}
      </label>
    `;
    }
    renderLoading() {
        return html `
      <div class=${this.getContainerClasses()}>
        <div class="px-4 py-2 text-sm ml-text-muted">
          ${this.msg.loading}
        </div>
      </div>
    `;
    }
    renderSegments(labelId, errorId, hasError) {
        if (this.parsedItems.length === 0) {
            return this.renderEmpty();
        }
        return html `
      <div
        role="listbox"
        aria-labelledby=${this.hasSlot('Label') ? labelId : ''}
        aria-required=${this.required}
        aria-invalid=${hasError}
        aria-describedby=${hasError ? errorId : ''}
        class=${this.getContainerClasses()}
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
      >
        ${this.parsedItems.map((item, index) => this.renderSegment(item, index))}
      </div>
    `;
    }
    renderSegment(item, index) {
        const isSelected = this.value === item.value;
        const tabIndex = this.disabled || this.loading || item.disabled
            ? -1
            : isSelected || (this.value === null && index === 0)
                ? 0
                : -1;
        return html `
      <button
        type="button"
        role="option"
        aria-selected=${isSelected}
        aria-disabled=${item.disabled}
        tabindex=${tabIndex}
        class=${this.getSegmentClasses(item, isSelected)}
        @click=${() => this.handleSelect(item)}
        @keydown=${(e) => this.handleKeyDown(e, index)}
        ?disabled=${this.disabled || this.loading}
      >
        ${unsafeHTML(item.label)}
      </button>
    `;
    }
    renderEmpty() {
        if (this.hasSlot('Empty')) {
            return html `
        <div class="${cn('px-4 py-2 text-sm ml-text-muted', this.getSlotClass('Empty'))}">
          ${unsafeHTML(this.getSlotContent('Empty'))}
        </div>
      `;
        }
        return html `
      <div class="px-4 py-2 text-sm ml-text-muted">
        ${this.msg.noOptions}
      </div>
    `;
    }
    renderFeedback(errorId, hasError) {
        if (hasError) {
            return html `
        <p id=${errorId} class=${this.getErrorClasses()}>
          ${unsafeHTML(this.error)}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class=${this.getHelperClasses()}>
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
};
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedControlMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], SegmentedControlMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SegmentedControlMolecule.prototype, "loading", void 0);
__decorate([
    state()
], SegmentedControlMolecule.prototype, "focusedIndex", void 0);
__decorate([
    state()
], SegmentedControlMolecule.prototype, "parsedItems", void 0);
SegmentedControlMolecule = __decorate([
    customElement('groupselectone--ml-segmented-control')
], SegmentedControlMolecule);
export { SegmentedControlMolecule };
