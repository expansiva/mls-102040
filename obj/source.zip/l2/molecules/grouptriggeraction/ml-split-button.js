var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouptriggeraction/ml-split-button.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SPLIT BUTTON MOLECULE
// =============================================================================
// Skill Group: groupTriggerAction
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    defaultLabel: 'Action',
    moreOptions: 'More options',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
let MlSplitButtonMolecule = class MlSplitButtonMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Icon'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.isOpen = false;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handlePrimaryClick() {
        if (this.disabled || this.loading)
            return;
        const value = this.getPrimaryValue();
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: { value },
        }));
    }
    handleToggleMenu() {
        if (this.disabled || this.loading)
            return;
        this.isOpen = !this.isOpen;
    }
    handleOptionClick(item) {
        if (this.disabled || this.loading || item.disabled)
            return;
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: { value: item.value },
        }));
        this.isOpen = false;
    }
    // ==========================================================================
    // DATA HELPERS
    // ==========================================================================
    getPrimaryValue() {
        const explicit = this.getSlotAttr('Label', 'value');
        if (explicit)
            return explicit;
        const label = this.getPrimaryLabelText();
        return label || this.msg.defaultLabel;
    }
    getPrimaryLabelText() {
        const content = this.getSlotContent('Label');
        if (!content)
            return '';
        const temp = document.createElement('div');
        temp.innerHTML = content;
        return (temp.textContent || '').trim();
    }
    collectSecondaryItems() {
        const children = Array.from(this.children);
        const items = [];
        children.forEach((el) => {
            const tag = el.tagName.toLowerCase();
            if (tag === 'label' || tag === 'icon')
                return;
            const value = el.getAttribute('value');
            if (!value)
                return;
            const disabled = el.hasAttribute('disabled') || el.getAttribute('aria-disabled') === 'true' || el.getAttribute('unavailable') === 'true';
            const label = el.innerHTML || value;
            el.setAttribute('hidden', '');
            items.push({ value, label, disabled });
        });
        return items;
    }
    getAriaLabel() {
        const label = this.getPrimaryLabelText();
        return label || this.msg.defaultLabel;
    }
    // ==========================================================================
    // CLASS HELPERS
    // ==========================================================================
    getPrimaryClasses() {
        const sizeClasses = this.getSizeClasses('primary');
        return [
            'inline-flex items-center justify-center gap-2',
            'ml-split-trigger',
            this.disabled || this.loading ? 'ml-disabled' : 'cursor-pointer',
            sizeClasses,
        ].filter(Boolean).join(' ');
    }
    getChevronClasses() {
        const sizeClasses = this.getSizeClasses('chevron');
        return [
            'inline-flex items-center justify-center',
            'ml-split-dropdown',
            this.disabled || this.loading ? 'ml-disabled' : 'cursor-pointer',
            sizeClasses,
        ].filter(Boolean).join(' ');
    }
    getSizeClasses(region) {
        const sizeMap = {
            xs: { primary: 'px-2.5 py-1 text-xs', chevron: 'px-2 py-1 text-xs', icon: 'h-3.5 w-3.5' },
            sm: { primary: 'px-3 py-1.5 text-sm', chevron: 'px-2.5 py-1.5 text-sm', icon: 'h-4 w-4' },
            md: { primary: 'px-3.5 py-2 text-sm', chevron: 'px-2.5 py-2 text-sm', icon: 'h-4.5 w-4.5' },
            lg: { primary: 'px-4 py-2.5 text-base', chevron: 'px-3 py-2.5 text-base', icon: 'h-5 w-5' },
        };
        const map = sizeMap[this.size] || sizeMap.md;
        return region === 'primary' ? map.primary : map.chevron;
    }
    getOptionClasses(item) {
        return [
            'w-full text-left px-3 py-2 text-sm',
            'ml-split-item',
            item.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    // ==========================================================================
    // RENDER PARTS
    // ==========================================================================
    renderIcon() {
        if (this.loading) {
            return this.renderSpinner();
        }
        if (!this.hasSlot('Icon'))
            return html ``;
        return html `<span class="${cn('inline-flex items-center', this.getSlotClass('Icon'))}">${unsafeHTML(this.getSlotContent('Icon'))}</span>`;
    }
    renderLabel() {
        const label = this.getSlotContent('Label') || this.msg.defaultLabel;
        return html `<span class="${cn('inline-flex items-center', this.getSlotClass('Label'))}">${unsafeHTML(label)}</span>`;
    }
    renderSpinner() {
        const sizeMap = {
            xs: 'h-3.5 w-3.5',
            sm: 'h-4 w-4',
            md: 'h-4.5 w-4.5',
            lg: 'h-5 w-5',
        };
        const sizeClass = sizeMap[this.size] || sizeMap.md;
        return html `
<span class="inline-flex items-center" aria-hidden="true">
<svg class="${sizeClass} animate-spin ml-text-muted" viewBox="0 0 24 24" fill="none">
${svg `<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" opacity="0.25"></circle>`}
${svg `<path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>`}
</svg>
</span>
`;
    }
    renderChevron() {
        return html `
<svg class="h-4 w-4" viewBox="0 0 20 20" fill="none" aria-hidden="true">
${svg `<path d="M5 7l5 5 5-5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>`}
</svg>
`;
    }
    renderMenuOptions(items) {
        if (!this.isOpen || items.length === 0)
            return html ``;
        return html `
<div class="absolute right-0 top-full z-10 mt-1 min-w-full p-2 ml-split-menu">
<div class="flex flex-col gap-1">
${items.map((item) => html `
<button
type="button"
class="${this.getOptionClasses(item)}"
?disabled=${this.disabled || this.loading || item.disabled}
aria-disabled=${this.disabled || this.loading || item.disabled ? 'true' : 'false'}
@click=${() => this.handleOptionClick(item)}
>
${unsafeHTML(item.label)}
</button>
`)}
</div>
</div>
`;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const items = this.collectSecondaryItems();
        const hasLabel = this.hasSlot('Label') || !!this.getPrimaryLabelText();
        const hasIcon = this.hasSlot('Icon') || this.loading;
        const ariaLabel = !hasLabel && hasIcon ? this.getAriaLabel() : undefined;
        return html `
<div class="${cn('relative inline-flex items-stretch', this.cssClass)}" role="group">
<button
type=${this.type}
class="${this.getPrimaryClasses()}"
?disabled=${this.disabled || this.loading}
aria-busy=${this.loading ? 'true' : 'false'}
aria-disabled=${this.disabled || this.loading ? 'true' : 'false'}
aria-label=${ariaLabel || this.msg.defaultLabel}
@click=${this.handlePrimaryClick}
>
${this.iconPosition === 'start' ? this.renderIcon() : html ``}
${this.renderLabel()}
${this.iconPosition === 'end' ? this.renderIcon() : html ``}
</button>
<button
type="button"
class="${this.getChevronClasses()}"
?disabled=${this.disabled || this.loading}
aria-busy=${this.loading ? 'true' : 'false'}
aria-disabled=${this.disabled || this.loading ? 'true' : 'false'}
aria-label=${this.msg.moreOptions}
@click=${this.handleToggleMenu}
>
${this.renderChevron()}
</button>
${this.renderMenuOptions(items)}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSplitButtonMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSplitButtonMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], MlSplitButtonMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSplitButtonMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSplitButtonMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSplitButtonMolecule.prototype, "isOpen", void 0);
MlSplitButtonMolecule = __decorate([
    customElement('grouptriggeraction--ml-split-button')
], MlSplitButtonMolecule);
export { MlSplitButtonMolecule };
