var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouptriggeraction/ml-icon-button.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ICON BUTTON MOLECULE
// =============================================================================
// Skill Group: groupTriggerAction
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    defaultLabel: 'Action',
    loadingLabel: 'Processing',
};
const messages = {
    en: message_en,
    pt: {
        defaultLabel: 'Ação',
        loadingLabel: 'Processando',
    },
};
/// **collab_i18n_end**
let IconButtonMolecule = class IconButtonMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Icon'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleActionClick(event) {
        if (this.disabled || this.loading) {
            event.stopPropagation();
            event.preventDefault();
            return;
        }
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const isDisabled = this.disabled || this.loading;
        const labelContent = this.getSlotContent('Label') || this.msg.defaultLabel;
        const ariaLabel = this.getAccessibleLabel(labelContent);
        return html `
      <button
        type=${this.type}
        class=${cn(this.getButtonClasses(isDisabled), this.cssClass)}
        ?disabled=${isDisabled}
        aria-label=${ariaLabel}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        @click=${this.handleActionClick}
      >
        <span class="sr-only">${unsafeHTML(labelContent)}</span>
        ${this.loading ? this.renderLoadingIcon() : this.renderIcon()}
      </button>
    `;
    }
    // =========================================================================
    // TEMPLATE PARTS
    // =========================================================================
    renderIcon() {
        const iconContent = this.getSlotContent('Icon');
        if (iconContent) {
            return html `
        <span class=${cn(this.getIconClasses(), this.getSlotClass('Icon'))} aria-hidden="true">
          ${unsafeHTML(iconContent)}
        </span>
      `;
        }
        return html `
      <span class=${cn(this.getIconClasses(), this.getSlotClass('Icon'))} aria-hidden="true">
        <svg viewBox="0 0 24 24" class="w-full h-full" fill="currentColor" aria-hidden="true">
          ${svg `<circle cx="12" cy="12" r="4"></circle>`}
        </svg>
      </span>
    `;
    }
    renderLoadingIcon() {
        const label = this.getSlotContent('Label') || this.msg.loadingLabel;
        return html `
      <span class=${this.getIconClasses()} aria-hidden="true">
        <svg viewBox="0 0 24 24" class="w-full h-full animate-spin" fill="none" stroke="currentColor" stroke-width="2">
          ${svg `
            <circle cx="12" cy="12" r="9" opacity="0.25"></circle>
            <path d="M21 12a9 9 0 0 1-9 9"></path>
          `}
        </svg>
      </span>
      <span class="sr-only">${unsafeHTML(label)}</span>
    `;
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    getAccessibleLabel(rawLabel) {
        const clean = rawLabel.replace(/<[^>]*>/g, '').trim();
        return clean || this.msg.defaultLabel;
    }
    getButtonClasses(isDisabled) {
        return [
            'inline-flex items-center justify-center',
            'ml-button',
            'ml-button-secondary',
            this.getSizeClasses(),
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
            this.loading ? 'cursor-wait' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getIconClasses() {
        return [
            'inline-flex items-center justify-center',
            'w-full h-full',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSizeClasses() {
        switch (this.size) {
            case 'xs':
                return 'w-7 h-7 text-xs';
            case 'sm':
                return 'w-8 h-8 text-sm';
            case 'lg':
                return 'w-11 h-11 text-base';
            case 'md':
            default:
                return 'w-9 h-9 text-sm';
        }
    }
};
__decorate([
    propertyDataSource({ type: String })
], IconButtonMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], IconButtonMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], IconButtonMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], IconButtonMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], IconButtonMolecule.prototype, "loading", void 0);
IconButtonMolecule = __decorate([
    customElement('grouptriggeraction--ml-icon-button')
], IconButtonMolecule);
export { IconButtonMolecule };
