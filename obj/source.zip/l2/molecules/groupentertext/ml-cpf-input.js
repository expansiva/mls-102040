var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var CpfInputMolecule_1;
/// <mls fileReference="_102040_/l2/molecules/groupentertext/ml-cpf-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CPF INPUT MOLECULE
// =============================================================================
// Skill Group: groupEnterText
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: '—',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: '—',
    },
};
/// **collab_i18n_end**
let CpfInputMolecule = CpfInputMolecule_1 = class CpfInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.uid = `cpf-input-${CpfInputMolecule_1.idCounter++}`;
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        this.mask = '###.###.###-##';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.displayValue = '';
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ==========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.displayValue = this.formatCpf(String(value ?? ''));
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================
    updated(changedProps) {
        if (changedProps.has('value')) {
            this.displayValue = this.formatCpf(this.value);
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleInputEvent(event) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const target = event.target;
        let raw = target.value;
        if (this.rows <= 1) {
            raw = raw.replace(/\D/g, '');
            raw = raw.slice(0, this.getMaxDigits());
            this.value = raw;
            this.displayValue = this.formatCpf(raw);
        }
        else {
            if (this.maxLength !== null && raw.length > this.maxLength) {
                raw = raw.slice(0, this.maxLength);
            }
            this.value = raw;
            this.displayValue = raw;
        }
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleBlurEvent() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    handleFocusEvent() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // HELPERS
    // ==========================================================================
    getMaxDigits() {
        const base = this.maxLength ?? 11;
        return Math.min(base, 11);
    }
    formatCpf(raw) {
        // Bound props ({{...}}) resolve to undefined before the state is seeded.
        const digits = String(raw ?? '').replace(/\D/g, '').slice(0, 11);
        let formatted = digits;
        if (digits.length > 3) {
            formatted = `${digits.slice(0, 3)}.${digits.slice(3)}`;
        }
        if (digits.length > 6) {
            formatted = `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6)}`;
        }
        if (digits.length > 9) {
            formatted = `${digits.slice(0, 3)}.${digits.slice(3, 6)}.${digits.slice(6, 9)}-${digits.slice(9, 11)}`;
        }
        return formatted;
    }
    getLabelId() {
        return `${this.uid}-label`;
    }
    getErrorId() {
        return `${this.uid}-error`;
    }
    getHelperId() {
        return `${this.uid}-helper`;
    }
    getCounterId() {
        return `${this.uid}-counter`;
    }
    hasError() {
        return String(this.error || '').length > 0;
    }
    getWrapperClasses() {
        const isError = this.hasError();
        const isDisabled = this.disabled || this.loading;
        return [
            'flex items-stretch ml-input-container',
            isError ? 'ml-input-container-error' : '',
            isDisabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses() {
        return [
            'flex-1 bg-transparent px-3 py-2 text-sm outline-none ml-input',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER PARTS
    // ==========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label id="${this.getLabelId()}" class="${cn('mb-1 block text-sm ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `
<div class="${cn('flex items-center px-3 text-sm ml-text-muted', this.getSlotClass('Prefix'))}">
${unsafeHTML(this.getSlotContent('Prefix'))}
</div>
`;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `
<div class="${cn('flex items-center px-3 text-sm ml-text-muted', this.getSlotClass('Suffix'))}">
${unsafeHTML(this.getSlotContent('Suffix'))}
</div>
`;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.hasError()) {
            return html `<p id="${this.getErrorId()}" class="mt-1 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.getHelperId()}" class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderCounter() {
        if (!this.isEditing)
            return html ``;
        if (this.rows <= 1 || this.maxLength === null)
            return html ``;
        return html `
<p id="${this.getCounterId()}" class="mt-1 text-xs ml-text-muted" aria-live="polite">
${String(this.value ?? '').length} / ${this.maxLength}
</p>
`;
    }
    renderViewMode() {
        const formatted = this.formatCpf(this.value);
        const viewValue = this.inputType === 'password'
            ? '••••••••'
            : (this.value ? formatted : this.msg.empty);
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div class="flex items-stretch ml-input-container">
${this.renderPrefix()}
<div class="flex-1 px-3 py-2 text-sm ml-text">
${viewValue}
</div>
${this.renderSuffix()}
</div>
</div>
`;
    }
    renderEditMode() {
        const isDisabled = this.disabled || this.loading;
        const ariaDescribedBy = this.hasError()
            ? this.getErrorId()
            : (this.hasSlot('Helper') ? this.getHelperId() : undefined);
        const inputValue = this.rows <= 1
            ? (this.displayValue || this.formatCpf(this.value))
            : (this.displayValue || this.value);
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div class="${this.getWrapperClasses()}">
${this.renderPrefix()}
${this.rows > 1
            ? html `
<textarea
class="${this.getInputClasses()}"
.name=${this.name}
.placeholder=${this.placeholder}
.rows=${this.rows}
.autocomplete=${this.autocomplete}
?disabled=${isDisabled}
?readonly=${this.readonly}
?required=${this.required}
aria-labelledby=${this.hasSlot('Label') ? this.getLabelId() : ''}
aria-invalid=${this.hasError() ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
aria-describedby=${ariaDescribedBy || ''}
@input=${this.handleInputEvent}
@blur=${this.handleBlurEvent}
@focus=${this.handleFocusEvent}
>${inputValue}</textarea>
`
            : html `
<input
class="${this.getInputClasses()}"
.type=${this.inputType}
.name=${this.name}
.placeholder=${this.placeholder}
.autocomplete=${this.autocomplete}
.value=${inputValue}
?disabled=${isDisabled}
?readonly=${this.readonly}
?required=${this.required}
aria-labelledby=${this.hasSlot('Label') ? this.getLabelId() : ''}
aria-invalid=${this.hasError() ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
aria-describedby=${ariaDescribedBy || ''}
@input=${this.handleInputEvent}
@blur=${this.handleBlurEvent}
@focus=${this.handleFocusEvent}
/>
`}
${this.renderSuffix()}
</div>
${this.loading ? html `<p class="mt-1 text-xs ml-text-muted">${this.msg.loading}</p>` : html ``}
${this.renderCounter()}
${this.renderHelperOrError()}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.isEditing ? this.renderEditMode() : this.renderViewMode();
    }
};
CpfInputMolecule.idCounter = 0;
__decorate([
    propertyDataSource({ type: String })
], CpfInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], CpfInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], CpfInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], CpfInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], CpfInputMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], CpfInputMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'rows' })
], CpfInputMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], CpfInputMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], CpfInputMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], CpfInputMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], CpfInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CpfInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CpfInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CpfInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CpfInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], CpfInputMolecule.prototype, "displayValue", void 0);
CpfInputMolecule = CpfInputMolecule_1 = __decorate([
    customElement('groupentertext--ml-cpf-input')
], CpfInputMolecule);
export { CpfInputMolecule };
