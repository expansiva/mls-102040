declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102040_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102040_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102040_/l2/molecules/groupviewtable/ml-data-table-minimal" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDataTableMinimalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        selectable: boolean;
        isEditing: boolean;
        page: number;
        pageSize: number;
        totalItems: number;
        value: string;
        error: string;
        disabled: boolean;
        loading: boolean;
        private sortKey;
        private sortDirection;
        firstUpdated(): void;
        updated(changedProps: Map<string, any>): void;
        private getHeaderCells;
        private getBodyRows;
        private getFooterRows;
        private getSortedRows;
        private getSelectionSet;
        private updateSelection;
        private getTotalPages;
        private propagateIsEditing;
        private syncSelectAllState;
        private handleSort;
        private handleSortKeydown;
        private handleRowSelection;
        private handleSelectAll;
        private handleRowClick;
        private handleRowKeydown;
        private handlePageChange;
        private renderCaption;
        private renderHeaderCell;
        private renderBodyRow;
        private renderFooter;
        private renderPagination;
        private renderError;
        private renderLoading;
        private renderEmpty;
        render(): any;
    }
}
declare module "_102040_/l2/teste" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102040_/l2/molecules/groupviewtable/ml-data-table-minimal";
    import '/_102033_/l2/molecules/groupentertext/ml-floating-text-input';
    export class Teste102040 extends StateLitElement {
        data: any;
        constructor();
        private mock;
        connectedCallback(): void;
        render(): any;
    }
}
declare module "_102040_/l2/grupoindefinido/ml-toggle-switch.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-toggle-switch\n\n# Objective\nA binary selection control presented as a toggle switch that allows the user to choose between two mutually exclusive options. It provides clear semantics for yes/no, active/inactive, or enabled/disabled decisions.\n\n# Responsibilities\n- Treat only the first two provided items as valid binary options; disregard any additional items.\n- Represent the selected choice as the string value of the chosen item; use null when no choice is made.\n- Display the selected item label inside or next to the toggle so the current state is always visible without opening the options panel.\n- In edit mode, show the selected label in the trigger; when no selection exists, show placeholder text or the provided trigger content using a placeholder visual style.\n- Open and close the options panel when the user activates the trigger.\n- When the panel is open, allow the user to pick an option, which updates the selection, closes the panel, and notifies that the value has changed.\n- In view mode, show only the selected item label as static text; do not show the trigger, options panel, helper text, or error messaging.\n- Block the panel from opening and ignore selection attempts when the control is disabled, readonly, or loading.\n- Show a loading state in the trigger and prevent panel access while loading is active.\n- Display an error message and apply error styling when a non-empty error is provided.\n- Show helper text below the control when no error is present and helper content is available.\n- Apply an error visual state when the control is required and no selection has been made.\n- Allow navigation between the two options using arrow keys, confirm a selection with enter, and close the panel with escape.\n- Notify when the control receives or loses focus.\n\n# Constraints\n- The toggle knob or indicator must reflect the first option in the left or off position, and the second option in the right or on position.\n- The trigger must remain inactive for opening the panel while disabled, readonly, or loading.\n- Selection must be impossible while the control is disabled or readonly.\n- Error display takes precedence over helper text.\n- All visual states, including selected, unselected, hover, disabled, readonly, error, and loading, must use the appropriate semantic color pairings.\n- Colors and contrast must adapt correctly for dark mode.\n\n# Notes\n- This control follows the groupSelectOne contract for structure, properties, and behavioral expectations.\n- Intended for mutually exclusive binary decisions where toggle semantics are clearer than a traditional choice list.";
}
declare module "_102040_/l2/grupoindefinido/ml-toggle-switch" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlToggleSwitchMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private focusedIndex;
        private boundHandleOutsideClick;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private findItem;
        private getSelectedIndex;
        private handleOutsideClick;
        private handleTriggerClick;
        private handleToggleClick;
        private handleItemSelect;
        private handleKeydown;
        private hasError;
        private showRequiredError;
        private getContainerClasses;
        private getTriggerClasses;
        private getToggleTrackClasses;
        private getToggleKnobClasses;
        private getLabelTextClasses;
        private getPlaceholderClasses;
        private getPanelClasses;
        private getItemClasses;
        private getViewModeClasses;
        private renderLabel;
        private renderToggleSwitch;
        private renderSelectedLabel;
        private renderLoadingIndicator;
        private renderDropdownIcon;
        private renderTrigger;
        private renderPanel;
        private renderHelper;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-toast-notification" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    type NotificationType = 'info' | 'success' | 'warning' | 'error';
    type PositionType = 'top' | 'bottom' | 'top-right' | 'bottom-right' | 'top-left' | 'bottom-left';
    export class ToastNotificationMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: NotificationType;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: PositionType | '';
        private isAnimatingOut;
        private autoCloseTimer;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private startAutoCloseTimer;
        private clearAutoCloseTimer;
        private handleDismiss;
        private handleActionClick;
        private getContainerClasses;
        private getTypeClasses;
        private getPositionClasses;
        private getAnimationClasses;
        private getEntryAnimationClass;
        private getExitAnimationClass;
        private getIconColorClasses;
        private getTitleClasses;
        private getMessageClasses;
        private getActionClasses;
        private getActionColorClasses;
        private getCloseButtonClasses;
        private getAriaRole;
        private getAriaLive;
        private renderIcon;
        private renderDefaultIcon;
        private renderTitle;
        private renderMessage;
        private renderAction;
        private renderCloseButton;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/index" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102040_/l2/molecules/groupnotifyuser/ml-toast-notification";
    export class GroupNotifyUserIndex extends StateLitElement {
        visibleInfo: boolean;
        visibleSuccess: boolean;
        visibleWarning: boolean;
        visibleError: boolean;
        private show;
        private getVisible;
        private setVisible;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-toast-notification\n\n# Objective\nProvide ephemeral floating notifications that appear in a screen corner, slide in and out smoothly, indicate different severity levels through color and icon, dismiss automatically after a set time or manually via a close control, optionally offer a secondary action, and stack vertically when multiple instances are active.\n\n# Responsibilities\n- Appear in a configurable screen corner when activated, sliding smoothly from the edge of that corner.\n- Disappear by sliding out smoothly along the same path used for entry.\n- Present four distinct visual identities: information (blue), success (green), warning (yellow), and error (red), each with a default icon.\n- Display a provided message as the primary content.\n- Disappear automatically after a configurable duration unless dismissed earlier.\n- Allow manual dismissal via a close control when manual closing is enabled.\n- Offer an optional action trigger, visually distinct from the message, that can be activated independently of dismissal.\n- Use a custom icon when one is supplied; otherwise, show the default icon for the current notification type.\n- Stack vertically with uniform spacing between simultaneous notifications.\n- Announce urgent interruptions for error and warning types, and polite updates for information and success types to assistive technologies.\n\n# Constraints\n- Must remain hidden when inactive.\n- Must complete its exit and cease to be presented after dismissal.\n- Must cancel pending automatic dismissal if the notification is deactivated externally or dismissed manually before the configured duration elapses.\n- Must not show a manual close control when manual dismissal is disabled.\n- Must not show an action trigger when no action is provided.\n- Must preserve consistent external spacing to support predictable vertical stacking in shared presentation areas.\n- Must apply the appropriate urgency level for assistive announcements based on the notification type.\n\n# Notes\n- The notification is transient and intended only for temporary awareness.\n- Screen corner selection determines both placement and the direction of the slide motion.\n- Activating the action trigger is independent of dismissal; the notification remains visible unless dismissal is separately requested.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-radio-group" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlRadioGroupMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private focusedValue;
        private labelId;
        private errorId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private parseGroups;
        private getAllItems;
        private findItem;
        private getSelectableItems;
        private handleSelect;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private getContainerClasses;
        private getOptionClasses;
        private getRadioClasses;
        private getLabelTextClasses;
        private renderLabel;
        private renderRadioIndicator;
        private renderOption;
        private renderGroup;
        private renderRadioOptions;
        private renderLoading;
        private renderFeedback;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-segmented-control" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class SegmentedControlMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private focusedIndex;
        private parsedItems;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseItems;
        private findItem;
        private handleSelect;
        private handleKeyDown;
        private focusNextItem;
        private focusPreviousItem;
        private focusSegment;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getSegmentClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        render(): TemplateResult;
        private renderViewMode;
        private renderEditMode;
        private renderLabel;
        private renderLoading;
        private renderSegments;
        private renderSegment;
        private renderEmpty;
        private renderFeedback;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-discrete-slider" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDiscreteSliderMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        fillPrevious: boolean;
        private isActive;
        private focusedIndex;
        private isDragging;
        private dragRatio;
        private parsedItems;
        private parsedGroups;
        private boundHandleOutsideClick;
        private boundHandleKeydown;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseSlotContent;
        private updateFocusedIndexFromValue;
        private findItem;
        private handleOutsideClick;
        private handleKeydown;
        private handleTrackClick;
        private handleStopPointerDown;
        private handleDragPointerMove;
        private handleDragPointerUp;
        private selectItem;
        private getContainerClasses;
        private getSliderTrackClasses;
        private getStopClasses;
        private getLabelClasses;
        private getIndicatorClasses;
        private getGroupLabelClasses;
        private calculateStopPosition;
        private getIndexFromPointerX;
        render(): any;
        private renderViewMode;
        private renderEmptyState;
        private renderLabel;
        private renderSlider;
        private renderIndicator;
        private renderFilledTrack;
        private renderDragThumb;
        private renderStop;
        private renderGroupLabels;
        private renderFeedback;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class SelectOneAutocompleteMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        clearable: boolean;
        private isOpen;
        private searchQuery;
        private highlightedIndex;
        private labelId;
        private inputId;
        private listId;
        private errorId;
        private helperId;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleDocumentClick;
        private handleInputFocus;
        private handleFocusOut;
        private handleInput;
        private handleKeyDown;
        private handleItemSelect;
        private handleClear;
        private handleMouseDown;
        private openPanel;
        private closePanel;
        private applySelection;
        private parseItem;
        private getParsedData;
        private getFilteredItems;
        private getLabelByValue;
        private getTriggerText;
        private getInputClasses;
        private getOptionClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/index" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102040_/l2/molecules/groupselectone/ml-radio-group";
    import "_102040_/l2/molecules/groupselectone/ml-segmented-control";
    import "_102040_/l2/molecules/groupselectone/ml-discrete-slider";
    import "_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete";
    export class GroupSelectOneIndexE extends StateLitElement {
        cardToggle: string;
        cardCycle: string;
        cardPlan: string;
        cardSat: string;
        cardCountry: string;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-discrete-slider.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-discrete-slider\n\n# Objective\nA discrete slider that allows selection of exactly one option from a set of mutually exclusive ordinal choices arranged along a horizontal linear scale. It behaves according to the groupSelectOne selection pattern, snapping the selection indicator to fixed stopping points that represent valid options.\n\n# Responsibilities\n- Present options in a linear horizontal order that reflects their natural ordinal relationship\n- Allow the user to select exactly one option at a time by interacting with the scale\n- Display a short text label for each available option, positioned to remain readable\n- Display the currently selected option label in an indicator above the selection position\n- Show placeholder or trigger content when no option is selected\n- Support category labels that span across their associated options without interrupting the linear scale\n- Snap the selection indicator to the chosen option's position upon selection\n- Maintain visibility of all option labels and stopping points regardless of active or inactive state\n- Toggle an active state when the user interacts with the control area\n- Close the active state when the user clicks outside, presses Escape, or selects an option\n- Navigate between enabled options using directional inputs\n- Confirm selection of the focused option using a confirm action\n- Ignore focus and blur state changes when in view mode\n- Display static text showing the selected label in view mode, or a placeholder when nothing is selected\n- Indicate when the selection is invalid due to a missing required value\n- Display an error message when one is provided\n- Display helper text when no error is present\n- Indicate when the component is loading, prevent selection changes during this state, and show a loading state in the indicator\n- Ignore search functionality\n\n# Constraints\n- Must only be used for ordinal data with a natural order of magnitude, intensity, time, or hierarchy\n- Must not be used for nominal data without logical order\n- Must accept no fewer than 2 and no more than 7 options; excess options are ignored, and fewer than 2 results in a non-interactive state\n- Must not change the stored value when the user closes the control without selecting\n- Must not allow selection when disabled, readonly, loading, or when an individual option is disabled\n- Must not display interactive controls in view mode\n- Must not display error text unless an error message is explicitly provided; helper text appears otherwise\n- Must suppress interaction cues when disabled or loading\n- Must allow text selection in readonly mode while preventing value changes\n\n# Notes\n- The linear order of options determines the ordinal scale; grouping labels serve only as visual cues and do not affect selection logic\n- The displayed selected label is derived directly from the selected option content and is not independently stored";
}
declare module "_102040_/l2/molecules/groupselectone/ml-radio-group.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-radio-group\n\n# Objective\nA single-selection option group that displays all available choices at once without hiding them behind a dropdown. It allows the user to pick exactly one option from a small set, making every option visible for quick comparison and selection.\n\n# Responsibilities\n- Present all options simultaneously in a visible list; never hide options behind a dropdown or collapsible panel.\n- Provide distinct areas for Label, Helper, Item, Group, and Empty content. Each Item represents one selectable option and shows its label text.\n- When the user chooses an enabled Item, set the value to that Item's value and indicate that the value has changed.\n- Show disabled Items as visible but unavailable for selection; they cannot change the current value.\n- Block selection changes and suppress change indications while readonly is active.\n- Block selection changes and appear fully inactive while disabled is active.\n- Display an error appearance and indicate invalidity when an error message is present; otherwise show helper text if available.\n- When required is true and no value exists, display an error appearance until a selection is made.\n- Display a loading appearance that prevents selection changes while loading is active.\n- In view mode, render only the selected option's label as static text, or a placeholder when nothing is selected. Hide all interactive controls, error indicators, and helper text.\n- Allow moving focus between options with arrow keys, confirm the focused option with Enter, and report when focus enters or leaves. Escape must not change the selection and may remove focus.\n- When a Group area is present, render its label and include its Items as a labeled subsection while enforcing single-selection across all options.\n- If no Items are provided, render the Empty area content if available.\n\n# Constraints\n- Only one option may be selected at any time, including across subgroups.\n- Selection changes are prohibited during loading, readonly, and disabled states.\n- Disabled options must remain visible and clearly distinguishable from enabled options.\n- Error appearance persists until a valid selection is made when required; provided error messages override helper text.\n- View mode must not expose interactive controls or validation feedback.\n- The component must remain readable and usable when presenting 2 to 6 items at once.\n- Selected, disabled, readonly, error, and loading states must each have a unique, recognizable appearance in any color context.\n\n# Notes\n- Designed for small option sets where immediate visibility of all choices improves decision speed.\n- Group labels are visual separators; they do not allow multiple independent selections within the same component.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-segmented-control.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-segmented-control\n\n# Objective\nA single-selection control that presents multiple options as a connected horizontal group of segments. It allows choosing one option from a compact set, showing the selected label when inactive and displaying all options together when active for editing.\n\n# Responsibilities\n- Integrate with the groupSelectOne contract, supporting Label, Helper, Trigger, Item, Group, and Empty.\n- Render each Item as a selectable segment with a visible label and an associated value.\n- Maintain exactly one selected Item at a time; selecting an Item updates the current value and notifies the system of the change.\n- When not in editing mode, display only the label of the currently selected Item as static text. Do not render segments, error messages, helpers, or emit change notifications.\n- When not in editing mode and no Item is selected, display the configured placeholder or a default fallback if no placeholder is configured.\n- When in editing mode, present all Items simultaneously as a horizontal group without requiring any panel or dropdown to be opened.\n- Render disabled Items visibly but prevent their selection and suppress change notifications when they are activated.\n- Present an error state when the control is required and no value is selected, following the validation rules of the contract.\n- Display an error message and apply an error state when an error is present; otherwise display Helper content when available.\n- Indicate loading and block all interactions, preventing selection and focus.\n- Block all interactions and apply a disabled state to the entire control when disabled.\n- Prevent selection changes while maintaining visible selected content when readonly.\n- Render Empty content when no Items are present; if Empty is not provided, render an explicit empty state.\n- Notify when the control receives and loses focus according to the contract.\n- Support keyboard navigation between segments, confirmation of selection, and dismissal of any open state.\n- Expose accessibility information so assistive technologies can identify the control type, selected option, disabled options, required status, and error conditions.\n\n# Constraints\n- Only one Item may be selected at any time.\n- All options must remain visible simultaneously during editing; they must not be hidden behind an additional interaction layer.\n- Disabled Items must never trigger selection or change notifications.\n- The control must not emit change notifications when not in editing mode.\n- Error display takes precedence over Helper display.\n- Loading state must prevent all user interactions including focus.\n- Designed for compact sets of short labels, typically between 2 and 5 options.\n- When not in editing mode, the display must be non-interactive plain text without borders or backgrounds.\n\n# Notes\n- Trigger content serves as a placeholder only when no Item is selected.\n- The selected Item label always takes precedence over Trigger content when a value is present.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-one-autocomplete\n\n# Objective\nAllow the user to choose exactly one option from a list by typing into a text field to filter results. A list of matching options appears when the field gains focus. The component supports readonly, disabled, and error states, offers an optional way to clear the selection, and allows full keyboard control.\n\n# Responsibilities\n- Filter the list of options by partial case-insensitive text match on their labels as the user types.\n- Show the list of options when the field has focus; hide it when focus is lost.\n- Permit only one selected option at a time; choosing a new option replaces the previous one.\n- Display the label of the currently selected option inside the text field.\n- Allow moving a highlight through the visible options using up and down arrow keys.\n- Confirm the highlighted option as the selection when Enter is pressed.\n- Close the option list without making changes when Escape is pressed.\n- Show a message when typing yields no matching options.\n- Provide an optional clear control that removes the current selection.\n- Prevent all interaction, typing, and list display when in readonly or disabled states.\n- Present an error message and invalid appearance when the field is in an error state.\n- Indicate when data is loading and prevent selection during that time.\n- Update the displayed label if the selected value is changed from outside.\n\n# Constraints\n- The option list must not be visible while the field lacks focus.\n- Highlight navigation must remain within the filtered set of options.\n- Readonly state must show the current selection label but block focus, typing, and list opening.\n- Disabled state must show the current selection label but block all interaction.\n- The clear control must not appear unless explicitly enabled.\n- Error indication must persist until the error state is resolved.\n- Selection must always be singular; multiple simultaneous selections are not allowed.\n\n# Notes\n- The filtering logic must match partial strings regardless of case (for example, typing \"zonas\" matches \"Amazonas\").\n- The component is intended for single-item selection scenarios such as choosing one state from a country list.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-area-chart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlAreaChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private tooltip;
        private parsedSeries;
        private chartTitle;
        private readonly chartWidth;
        private readonly chartHeight;
        private readonly padding;
        private readonly defaultColors;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseData;
        private handlePointClick;
        private handlePointMouseEnter;
        private handlePointMouseLeave;
        private getStackedData;
        private getMaxValue;
        private getLabels;
        private scaleX;
        private scaleY;
        private renderLoading;
        private renderEmpty;
        private renderGrid;
        private renderAreas;
        private renderTooltip;
        private renderLegend;
        private renderAccessibleTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-line-chart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlLineChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private tooltip;
        private readonly chartWidth;
        private readonly chartHeight;
        private readonly padding;
        private parseData;
        private calculateScale;
        private getX;
        private getY;
        private handlePointMouseEnter;
        private handlePointMouseLeave;
        private handlePointClick;
        private renderLoading;
        private renderEmpty;
        private renderGridLines;
        private renderYAxis;
        private renderXAxis;
        private renderLine;
        private renderPoints;
        private renderTooltip;
        private renderLegend;
        private renderAccessibleTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/index" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102040_/l2/molecules/groupviewchart/ml-area-chart";
    import "_102040_/l2/molecules/groupviewchart/ml-line-chart";
    export class GroupViewChartIndex extends StateLitElement {
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-area-chart.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-area-chart\n\n# Objective\nPresent quantitative information as an area chart that highlights volume through filled regions below trend lines. Enable comparison across single or multiple data series, with a default stacked view that shows how individual parts compose a total. Offer interactive discovery, loading feedback, empty state handling, and full accessibility support.\n\n# Responsibilities\n- Render data as lines connecting points, with the area beneath each line filled using the series color at reduced opacity.\n- Accumulate multiple series vertically in a stacked view by default, making each series' contribution to the total visible at every point.\n- Activate a selection behavior when a user interacts with a data point, carrying the point's label, value, and series name when applicable.\n- Reveal a contextual description on hover over any data point, displaying its label, value, and series name when relevant.\n- Display a legend mapping each series name to its corresponding color when enabled; hide the legend entirely when disabled.\n- Replace the chart with a loading placeholder that preserves the final dimensions while data is unavailable.\n- Show an empty state when no data points exist, preferring custom empty content or falling back to a default empty indication.\n- Expose the chart container to assistive technologies as a graphical image named by the chart title.\n- Supply raw data in a structured, non-visual form accessible to assistive technologies.\n- Treat interactive data points as actionable controls described by their label and value.\n- Apply provided title content as the visible chart heading and as the accessible name for the chart container.\n\n# Constraints\n- Must handle both single-series and multi-series data seamlessly.\n- Must default to stacked mode whenever multiple series are present.\n- Tooltip information must always include label and value; series name must appear only when multiple series are present.\n- Legend colors and names must correspond exactly to the rendered areas.\n- The loading placeholder must suggest a chart shape and occupy the same space as the completed chart.\n- All visual elements must maintain adequate contrast in both light and dark presentation modes.\n- The empty state must suppress the chart area and axes.\n- Interactive points must remain operable and perceptible across all display modes.\n\n# Notes\n- Area fill opacity must remain low enough to keep grid lines and overlapping series distinguishable.\n- Tooltip placement must avoid covering the target data point or neighboring content.\n- Dark mode must rely on semantically appropriate color pairings for backgrounds, text, and borders.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-line-chart.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-line-chart\n\n# Objective\nDisplay the evolution of numeric data over time using a multi-series line chart. It must visualize connections between ordered data points, allow comparison across series, and handle loading, empty, and dark-mode states.\n\n# Responsibilities\n- Accept a title, grouped or ungrouped data points, and an empty state as inputs.\n- Position each data point horizontally according to its category label and vertically according to its numeric value.\n- Draw lines connecting sequential points within each series to show progression.\n- Automatically calculate the vertical scale from the minimum and maximum values present in the data.\n- Render subtle horizontal reference lines aligned to the vertical scale.\n- On hover over a data point, display contextual information including the category label, exact value, and series name.\n- On selection of a data point, expose the point's label, value, and series identity for external handling.\n- Differentiate each series by a distinct color.\n- When in a loading state, display an animated placeholder and suppress chart rendering.\n- When no data points are provided, render the empty state or a default empty message.\n- Optionally render a legend mapping each series to its visual representation.\n- Optionally render numeric values next to their corresponding data points.\n- Expose the underlying data in a text format accessible to assistive technologies.\n- Ensure interactive data points are detectable and actionable by assistive technologies.\n- Adapt all visual elements for dark presentation mode.\n\n# Constraints\n- Category labels must appear on the horizontal axis in the order received.\n- The vertical scale must be derived solely from the data values without external configuration.\n- Contextual hover information must appear only while the pointer is over the data point and must disappear on exit.\n- The loading placeholder must fully replace the chart area and block interaction with chart elements.\n- The empty state must render only when no data points exist in any series or root input.\n- The legend must accurately reflect only the series or points currently represented.\n- Visual elements must maintain sufficient contrast for readability in both light and dark modes.\n- Interactive points must present an adequate target area for pointer interaction.\n\n# Notes\n- Lines should visually suggest continuous progression between points.\n- Legend placement should default below the chart.";
}
declare module "_102040_/l2/molecules/groupviewtable/ml-view-table" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ViewTableMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        selectable: boolean;
        isEditing: boolean;
        page: number;
        pageSize: number;
        totalItems: number;
        value: string;
        error: string;
        disabled: boolean;
        loading: boolean;
        private sortKey;
        private sortDirection;
        private parsedHeaders;
        private parsedRows;
        private sortedRowIndices;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseSlotContent;
        private parseHeaders;
        private parseRows;
        private initializeSortedIndices;
        private propagateEditingState;
        private getSelectedIndices;
        private setSelectedIndices;
        private handleSelectAll;
        private handleRowSelect;
        private handleRowClick;
        private handleSort;
        private applySorting;
        private stripHtml;
        private getTotalPages;
        private handlePageChange;
        private getTableClasses;
        private getHeaderCellClasses;
        private getRowClasses;
        private getCellClasses;
        private getCheckboxClasses;
        private renderCaption;
        private renderSortIcon;
        private renderHeader;
        private renderBody;
        private renderFooter;
        private renderEmpty;
        private renderLoading;
        private renderPagination;
        private getPaginationPages;
        private getPaginationButtonClasses;
        private getPageNumberClasses;
        private renderError;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/index" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102040_/l2/molecules/groupviewtable/ml-data-table-minimal";
    import "_102040_/l2/molecules/groupviewtable/ml-view-table";
    export class GroupViewTableIndex extends StateLitElement {
        minimalPage: number;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/ml-data-table-minimal.defs" {
    export const group = "groupViewTable";
    export const skill = "# Metadata\n- TagName: groupviewtable--ml-data-table-minimal\n\n# Objective\nFornecer uma tabela de dados minimalista com ordena\u00E7\u00E3o, sele\u00E7\u00E3o opcional, estados de vazio e carregamento, pagina\u00E7\u00E3o e suporte completo a dark mode.\n\n# Responsibilities\n- Renderizar a hierarquia de slots do grupo (Caption, TableHeader, TableBody, TableRow, TableHead, TableCell, TableFooter, Empty, Loading) conforme o contrato.\n- Exibir o estado de carregamento quando solicitado, substituindo o conte\u00FAdo da tabela pelo conte\u00FAdo de Loading ou pelo padr\u00E3o do contrato.\n- Exibir o estado vazio quando n\u00E3o houver linhas no corpo, usando Empty ou o padr\u00E3o do contrato.\n- Permitir ordena\u00E7\u00E3o nas colunas marcadas como orden\u00E1veis, alternando a dire\u00E7\u00E3o e emitindo o evento de ordena\u00E7\u00E3o com a chave e dire\u00E7\u00E3o.\n- Indicar visualmente a coluna ativa de ordena\u00E7\u00E3o e a dire\u00E7\u00E3o atual.\n- Quando a sele\u00E7\u00E3o estiver habilitada, permitir selecionar/deselecionar todas as linhas e linhas individuais, mantendo o valor de sele\u00E7\u00E3o e emitindo altera\u00E7\u00F5es.\n- Emitir evento de clique em linha quando uma linha for acionada fora do controle de sele\u00E7\u00E3o.\n- Quando houver pagina\u00E7\u00E3o habilitada, permitir a troca de p\u00E1gina e emitir o evento correspondente.\n- Propagar o estado de edi\u00E7\u00E3o para conte\u00FAdos dentro de c\u00E9lulas conforme o contrato.\n- Exibir mensagem de erro abaixo da tabela quando houver erro informado.\n- Renderizar o conte\u00FAdo fornecido pelos slots TableHead, TableCell, Empty e Loading conforme fornecido pelo usu\u00E1rio.\n\n# Constraints\n- Quando loading estiver ativo, o conte\u00FAdo da tabela n\u00E3o deve ser exibido.\n- Quando n\u00E3o houver linhas, o estado vazio deve ser mostrado e nenhuma linha deve ser exibida.\n- A ordena\u00E7\u00E3o s\u00F3 deve estar dispon\u00EDvel para colunas marcadas como orden\u00E1veis.\n- Quando disabled estiver ativo, deve bloquear ordena\u00E7\u00E3o, sele\u00E7\u00E3o e pagina\u00E7\u00E3o, mantendo o estado visual de desabilitado.\n- O valor de sele\u00E7\u00E3o deve refletir os \u00EDndices das linhas selecionadas no formato esperado pelo contrato.\n- O estado de sele\u00E7\u00E3o n\u00E3o deve interferir no disparo do evento de clique em linha fora do controle de sele\u00E7\u00E3o.\n\n# Notes\n- O suporte a dark mode deve cobrir todos os estados visuais e de feedback (normal, selecionado, vazio, carregando, erro e desabilitado).";
}
declare module "_102040_/l2/molecules/groupviewtable/ml-view-table.defs" {
    export const group = "groupViewTable";
    export const skill = "# Metadata\n- TagName: groupviewtable--ml-view-table\n\n# Objective\nPresent data in a clean, minimalist table format that supports ordering, pagination, row selection, and adaptive states for loading and empty data. It must provide clear visual feedback for interactions and maintain full compatibility with dark appearance modes.\n\n# Responsibilities\n- Present data in a structured table with distinguishable header and body areas, plus optional caption and footer regions.\n- Enable column header interaction to sort the displayed data, alternating between ascending and descending order with clear directional indicators.\n- Manage data ordering internally based on the active column and direction.\n- Divide data into pages internally when a page limit is defined, and provide navigation between pages.\n- Offer an optional row selection mode that presents a checkbox at the start of each row and a corresponding master checkbox in the header to select or clear all rows.\n- Maintain and display the current selection state as rows are checked or unchecked individually or collectively.\n- Recognize when a user activates a specific row separately from selection controls.\n- Show an animated loading placeholder that imitates the table layout while data is unavailable, falling back to a default skeleton if no custom loading presentation is supplied.\n- Show a centered empty-state message with an empty-table icon when no data exists, falling back to a default message if no custom empty presentation is supplied.\n- Apply a subdued horizontal rule between rows without vertical dividers between columns for a minimalist appearance.\n- Visually distinguish the header background from the body.\n- Highlight the active sort column header and any selected rows with dedicated color treatments.\n- Adapt all colors\u2014including backgrounds, text, borders, and highlights\u2014for dark mode presentation.\n- Disable all sorting, selection, and pagination interactions when placed in an inactive state.\n\n# Constraints\n- Sort indicators must always match the currently applied column and direction.\n- Page navigation must respect the calculated total pages and current position.\n- The master selection checkbox must accurately reflect whether all, some, or no rows are selected.\n- Loading, empty, and data states must not overlap; only one may be visible at a time.\n- Selected and highlighted states must remain clearly distinguishable in both light and dark appearances.\n- All interactive features must be inoperable when the inactive state is active.\n\n# Notes\n- Custom presentations for empty and loading states take precedence over default representations when provided.\n- Activating a row and toggling its selection are separate, non-conflicting interactions.";
}
declare module "_102040_/l2/testes/ml-radio-group-exemple" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102040_/l2/molecules/groupselectone/ml-radio-group";
    interface Config {
        value: string;
        isEditing: boolean;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        loading: boolean;
        error: string;
    }
    export class MlRadioGroupExemple extends StateLitElement {
        basic: Config;
        grouped: Config;
        private toggle;
        private renderToggle;
        private renderConfig;
        render(): any;
    }
}
declare module "_102040_/l2/testes/select-one" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import "_102040_/l2/molecules/groupselectone/ml-radio-group";
    import "_102040_/l2/molecules/groupselectone/ml-segmented-control";
    export class SelectOne102040 extends StateLitElement {
        radioValue: string;
        radioGroupedValue: string;
        segmentedValue: string;
        segmentedErrorValue: string;
        render(): any;
    }
}
