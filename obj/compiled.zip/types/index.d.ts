declare module "_102027_/l2/collabImport" {
    interface CollabImportOptions {
        project: number;
        shortName: string;
        folder: string;
        extension?: '.defs.ts' | '.ts' | '.test.ts';
    }
    export function collabImport(opts: CollabImportOptions): Promise<any>;
}
declare module "_102027_/l2/utils" {
    export function getPath(widget: string): mls.stor.IFileInfoBase | undefined;
    export function convertTagToFileName(tag: string): {
        shortName: string;
        project: number;
        folder: string;
    } | undefined;
    export function convertFileNameToTag(info: {
        shortName: string;
        project: number;
        folder?: string;
    }): string;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
}
declare module "_102027_/l2/libCompile" {
    export const getDependenciesByHtmlFile: (file: mls.stor.IFileInfo, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByHtml: (models: mls.editor.IModels, html: string, theme: string, withCss?: boolean) => Promise<IJSONDependence>;
    export const getDependenciesByMFile: (models: mls.editor.IModels, withCss?: boolean) => Promise<IJSONDependence>;
    export function getAllWebComponentsInSource(source: string): string[];
    export interface IJSONDependence {
        file: string;
        wcComponents: string[];
        importsMap: string[];
        importsJs: string[];
        importsLinks: {
            ref: string;
            rel: string;
        }[];
        tokens: string | undefined;
        globalCss: string;
        errors: {
            tag: string;
            error: string;
        }[];
    }
}
declare module "_102027_/l2/libCommom" {
    export function getMyKeysBranch(project: number): {
        branch: string;
        owner: string;
        repo: string;
    };
    export function createPath(project: number, shortName: string, folder: string): string;
    export function generateCompactTimestamp(): string;
    export function getDateFormated(dt: string): string;
    export function changeFavIcon(notification: boolean): void;
    export function checkIfHasLocalProject(): boolean;
    export function getLocalProjectName(): string;
    export function setLocalProjectName(prjName: string): void;
    export function isValidProjectName(name: string): boolean;
    export function escapeHTML(str: string): string;
    export function openService(service: string, position: 'left' | 'right', level: number, args?: Record<string, string>): Promise<void>;
    export function selectLevel(level: number): void;
    export function forceServiceInstance(level: number, service: string): Promise<void>;
    export function loadFileHTMLInContainer(el: HTMLElement, shortName: string, project: number): Promise<void>;
    export function convertColorToHex(color: string): string;
    export function getEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string>;
    export function getStyleEnhancementName(file: {
        project: number;
        shortName: string;
        folder: string;
        level: number;
    }): Promise<string | undefined>;
    export function loadPluginProject(project: number, scope: string, onlyEnabled?: boolean): Promise<mls.plugin.MenuAction[]>;
    export function setProjectDetails(project: number): void;
    export function getProjectDetails(): mls.stor.localStor.IRetProjectDetails | undefined;
    export function calculateTotalStringSize(source: string, limitBase: number): ICalculateTotalStringSize;
    export function getListNewFilesToDeleteByFolder(project: number, folder: string, includeDist?: boolean): Promise<mls.stor.IFileInfo[]>;
    export function deleteAllFilesLocal(filesToDelete: mls.stor.IFileInfo[]): AsyncGenerator<string, void, unknown>;
    export function loadModuleFromProjectOrDependency(name: string, folder: string, ext: string): Promise<any>;
    export function findStorFileInProjectsOrDeps(projectActual: number, level: number, fileName: string, folder: string, extension: string): mls.stor.IFileInfo;
    export function saveOpenedFile(project: number, level: number, file: OpenedFile): void;
    export function getLastOpenedFiles(project: number): UserOpenedFiles;
    export function deleteLastOpenedFiles(project: number): void;
    export function getLastModule(): Record<string, string>;
    export function setLastModule(project: number, moduleName: string): void;
    export function getBaseTemplate(file: IInfoFile, enhancement?: string): Promise<string>;
    export function verifyNeedAddTripleslach(info: mls.stor.IFileInfoBase, src: string, extension: string, enhancement?: string): string;
    export function getInstanceByFile(file: mls.stor.IFileInfo): Promise<Object | undefined>;
    export function isNameValid(project: number, shortName: string, folder: string, level: number, extension: string): boolean;
    export function openElementInServiceDetails(el: HTMLElement): Promise<void>;
    export function clearServiceDetails(): Promise<void>;
    export function getProjectConfig(project: number): Promise<IProjectConfig | undefined>;
    export function getProjectModuleConfig(path: string, project: number): Promise<IProjectModuleConfig | undefined>;
    export function getMessageKey(messages: any): string;
    export type OpenedFile = string | OpenedFileL2;
    export type UserOpenedFiles = Record<number, OpenedFile>;
    export type OpenedFileL2 = {
        left?: string;
        right?: string;
    };
    export interface IProjectModuleConfig {
        theme: string;
        initialPage: string;
        menu: IProjectModuleConfigMenu[];
    }
    export interface IProjectModuleConfigMenu {
        pageName: string;
        title: string;
        auth: string;
        icon?: string;
        target?: string;
    }
    export interface IProjectConfigModules {
        name: string;
        path: string;
        pathServer?: string;
        auth: string;
        icon?: string;
    }
    export interface IProjectConfig {
        masterFrontEnd?: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd?: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: IProjectConfigModules[];
    }
    interface ICalculateTotalStringSize {
        totalsize: number;
        exceededLimit: boolean;
        sizeFormatted: string;
    }
    interface IInfoFile {
        project: number;
        folder: string;
        shortName: string;
        extension: string;
    }
}
declare module "_102027_/l2/libMindMap" {
    export const allDefs: Record<string, IdefModule>;
    export function getAllDefs(): Promise<Record<string, IdefModule>>;
    export function getDefsByFile(file: mls.stor.IFileInfo): Promise<mls.defs.AsIs | undefined>;
    export function getMindMapByName(file: string): Promise<MindMapData | undefined>;
    export function getMindMapByStorFile(file: mls.stor.IFileInfo): Promise<MindMapData | undefined>;
    export function setMindMapVariable(bread: MindMapNode[]): void;
    export function getMindMapVariable(): MindMapNode[];
    export type MindMapSelected = MindMapSelectedFile | MindMapSelectedPlugin;
    export interface MindMapSelectedBase {
        plugin: Function;
        args: string;
    }
    export interface MindMapSelectedFile extends MindMapSelectedBase {
        type: "file";
        file: mls.stor.IFileInfo;
        organism?: string;
        widget?: string;
        modelType?: mls.editor.ModelType;
    }
    export interface MindMapSelectedPlugin extends MindMapSelectedBase {
        type: "plugin";
        file: mls.stor.IFileInfo;
    }
    export type MindMapNodeType = 'main' | 'asIs' | 'codeInsights' | 'webcomponent' | 'imports' | 'importedBy' | 'language' | 'attributes' | 'file' | 'file_wc' | 'text' | 'findFile' | 'findFile_item';
    export interface MindMapNode {
        id: string;
        label: string;
        type: MindMapNodeType;
        related: string[];
        meta: Record<string, any>;
        description?: string;
        navigate?: boolean;
    }
    export interface MindMapData {
        current: string;
        nodes: MindMapNode[];
    }
    export interface MindMapNodeStyle {
        fill: string;
        stroke: string;
        text: string;
    }
    export type MindMapNodeStyles = Record<string, MindMapNodeStyle>;
    export interface IdefModule {
        file: mls.stor.IFileInfo;
        defs: mls.defs.AsIs;
    }
}
declare module "_102027_/l2/libModel" {
    export function waitModelIdle(model: mls.editor.IModelBase | undefined): Promise<void>;
    export function readProjectTypescriptAndCompile(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function readProjectTypescriptAndCompileL1(project: number, shortName: string, needCompile?: boolean): Promise<void>;
    export function createAllModels(storFileBase: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean, createStorIfNeed?: boolean): Promise<mls.editor.IModels | undefined>;
    export function createModel(storFile: mls.stor.IFileInfo, needCompile?: boolean, awaitCompile?: boolean): Promise<mls.editor.IModelBase | undefined>;
    export function setErrorOnModel(model: monaco.editor.ITextModel, line: number, startColumn: number, endColumn: number, message: string, severity: monaco.MarkerSeverity): void;
    export function createModelAnyFile(storFile: mls.stor.IFileInfo): Promise<mls.editor.IModelBase>;
    export function setModelEventAny(model: mls.editor.IModelBase, storFile: mls.stor.IFileInfo): void;
    export function _MarkCompileNeed(storFile: mls.stor.IFileInfo): Promise<void>;
    export interface IModelProcessing {
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export class ModelProcessing implements IModelProcessing {
        private running;
        private idlePromise;
        private idleResolve;
        begin(): void;
        end(): void;
        whenIdle(): Promise<void>;
        isProcessing(): boolean;
    }
    export interface IModelBase extends mls.editor.IModelBase {
        changeTimeout?: number;
        processing?: IModelProcessing;
    }
}
declare module "_102027_/l2/designSystemBase" {
    export function getTokens(project: number): Promise<IDesignSystemTokens[]>;
    export function getTokensLess(project: number, theme: string): Promise<string>;
    export function getTokensLessByTokensArray(tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function getTokensCss(project: number, theme: string): Promise<string>;
    export function getGlobalCss(project: number, theme: string): Promise<string>;
    export function getGlobalLess(project: number): Promise<string>;
    export function compileLess(str: string): Promise<string>;
    export function preCompileLess(project: number, less: string, theme: string): Promise<string>;
    export function preCompileLessAction(lessSource: string, tokens: IDesignSystemTokens[], theme: string): Promise<string>;
    export function preCompileLessByThemeOrDefault(project: number, less: string, theme: string): Promise<string>;
    export function removeTokensFromSource(src: string): string;
    export function removeTokensTheme(project: number, themeName: string): Promise<void>;
    export function replaceTokensBlock(code: string, newContent: string): string;
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102040_/l2/designSystem" {
    import { IDesignSystemTokens } from "_102027_/l2/designSystemBase";
    export const tokens: IDesignSystemTokens[];
}
declare module "_102040_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102040_/l2/teste" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102033_/l2/molecules/groupentertext/ml-floating-text-input';
    export class Teste102040 extends StateLitElement {
        data: any;
        constructor();
        private mock;
        connectedCallback(): void;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/summary.defs" {
    export const group = "molecules";
    export const skill = "# Metadata\n- TagName: summary\n\n# Objective\nA summary page that presents an overview of all molecule component groups implemented in mls-102040. It displays each group organized by functional category, showing the group name and the list of components it contains.\n\n# Responsibilities\n- Display all 27 component groups organized into 5 functional categories: Enter, Select, View, Navigate, and Other\n- Show the component count for each group\n- List the component names within each group\n- Present global totals (groups and components) in the page header\n";
}
declare module "_102027_/l2/collabState" {
    /**
     * Returns the value for a given state key.
     * @param key State key in dot notation.
     * @returns The value stored at the specified key, or undefined if not set.
     */
    export function getState(key: string): any;
    /**
     * Updates the value for a given state key.
     * @param key State key in dot notation.
     * @param value Value to be stored.
     * @param systemChange Optional. If true, marks as a system-initiated change.
     */
    export function setState(key: string, value: any, systemChange?: boolean): void;
    /**
     * Subscribes a component to one or more state keys.
     * @param keyOrKeys - The state key or keys. Example: 'name/0;ui.name'.
     * Use a key starting with '*' (e.g. '*myKey;ui.xxx') to ensure only one active subscription with that key.
     * @param component - The subscribing component or callback function.
     */
    export function subscribe(keyOrKeys: string | string[], component: Object): void;
    /**
     * Unsubscribe a component from a state key or keys.
     * @param keyOrKeys - The state key or keys.
     * @param component - The unsubscribing component.
     */
    export function unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
    /**
     * Notify subscribed components about a state change.
     * @param key - The state key that changed.
     */
    export function notify(key: string): void;
    /**
     * Initializes a nested property in the global state object if it doesn't already exist.
     * If the property exists, it retains its current value without being overwritten.
     *
     * @param {string} path - The dot-separated path specifying the property to initialize (e.g., "globalState.users").
     * @param {*} value - The value to set if the property at the given path does not exist.
     */
    export function initState(path: string, value: string | Object | Array<unknown>): void;
    export interface GlobalState {
        [key: string]: any;
    }
    export const globalState: {
        _ica: GlobalState;
        globalStateManagment: CollabState;
        globalVariation: number;
    };
    export interface CollabState {
        getState(key: string): any;
        setState(key: string, value: any, systemChange?: boolean): void;
        getHistory(): Array<{
            timestamp: number;
            system: boolean;
            key: string;
            value: any;
        }>;
        clearHistory(): void;
        subscribe(keyOrKeys: string | string[], component: Object): void;
        unsubscribe(keyOrKeys: string | string[], component: Object | "*"): void;
        notify(key: string): void;
    }
    export function getCollabStateInstance(): CollabState;
}
declare module "_102027_/l2/collabLitElement" {
    import { LitElement } from 'lit';
    /**
     * Class extending LitElement with CollabState functionality.
     */
    export class CollabLitElement extends LitElement {
        globalVariation: number;
        createRenderRoot(): this;
        protected updated(changedProperties: Map<string | number | symbol, unknown>): void;
        getMessageKey(messages: any): string;
        loadStyle(css: string): void;
    }
    export function getMessageKey(messages: any): string;
    export interface IScenaryDetails {
        description: string;
        html: HTMLElement;
    }
}
declare module "_102040_/l2/molecules/summary" {
    import { CollabLitElement } from "_102027_/l2/collabLitElement";
    export class MoleculesSummary extends CollabLitElement {
        render(): any;
        private renderSection;
        private renderCard;
    }
}
declare module "_102040_/l2/molecules/groupenterboolean/index" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    export class GroupEnterBooleanIndex extends StateLitElement {
        cardCheckbox: boolean;
        cardToggle: boolean;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-boolean-segmented.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-boolean-segmented\n\n# Objective\nEnable the user to choose between two mutually exclusive boolean states through a pair of side-by-side options. The molecule must clearly identify the current selection, inform the system of changes, and adapt its interactivity and presentation according to editing, viewing, disabled, and error conditions.\n\n# Responsibilities\n- Display a provided label above the control.\n- Present two selectable options side by side during editing, representing affirmative and negative boolean states.\n- Visually distinguish the option that matches the current value from the unselected option.\n- Set the value to affirmative when that option is chosen.\n- Set the value to negative when that option is chosen.\n- Immediately inform the system when the user changes the selection, reporting the new boolean value.\n- Honor an initially configured boolean value.\n- Prevent user interaction and suppress system notifications while disabled.\n- Show the current value as static text during viewing mode, without interactive elements or system notifications.\n- Display helper text beneath the control during editing when available and no error is present.\n- Display error text and apply an error presentation when an error is present, replacing helper text.\n- Keep the distinguished option synchronized with the current value at all times.\n- Signal when the control receives or loses focus during editing.\n- Support keyboard selection during editing, allowing the user to toggle the value using the Space key and inform the system of the change.\n- Communicate disabled, selected, and invalid states to assistive technologies.\n- Associate the control with its visible label for accessibility.\n\n# Constraints\n- Only native boolean values (true or false) are valid selections.\n- The control must not send notifications to the system while disabled.\n- Error text and helper text must not appear in viewing mode.\n- Interactive options must not be rendered in viewing mode.\n- The visually distinguished option must always reflect the current value.\n- Keyboard interaction must only be available during editing and when not disabled.\n- The label must appear above the control; helper or error text must appear below the control during editing.\n- User interaction must be ignored while the control is disabled.\n\n# Notes\n- The affirmative option represents true; the negative option represents false.\n- The presentation must remain effective across light and dark environments.\n- Error state takes precedence over helper text display.";
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-boolean-segmented" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class BooleanSegmentedMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private labelId;
        private helperId;
        private handleSelect;
        private handleKeyDown;
        private handleFocus;
        private handleBlur;
        private renderLabel;
        private renderHelperOrError;
        private getSegmentClasses;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-checkbox-preference\n\n# Objective\nProvide a boolean preference control that allows users to mark or unmark an option. It must support an interactive editing mode for changing the value and a read-only view mode for displaying the current state, while clearly communicating validation issues.\n\n# Responsibilities\n- Present an interactive toggle in editing mode that switches the value between true and false.\n- Display static text \"Yes\" when the value is true and \"No\" when the value is false in view mode, without allowing interaction.\n- Update the value and notify the system when the user activates the toggle in editing mode.\n- Support keyboard activation to toggle the value when the control has focus in editing mode.\n- Prevent user interaction and value changes when disabled.\n- Display provided label content next to the control and associate it for accessibility.\n- Show error messages and apply an error state when an error exists in editing mode.\n- Show helper text below the control when no error is present and helper content is available in editing mode.\n- Report when the control gains focus and when it loses focus, only in editing mode.\n- Keep the visual checked appearance consistent with the current boolean value.\n\n# Constraints\n- Must conform to the groupEnterBoolean group behavior definitions.\n- Must not allow interaction or value changes in view mode.\n- Must not allow interaction or value changes when disabled.\n- Must suppress change notifications in view mode and when disabled.\n- Must prioritize error display over helper content in editing mode.\n- Must present only static text without interactive elements when in view mode.\n- Must provide equivalent visual treatments for light and dark modes, preserving contrast for all states including focus and error.\n\n# Notes\n- The editing layout should display the toggle indicator adjacent to the preference description, such as \"[x] Utilizar biometria\".\n- Visual spacing between the toggle, label, and auxiliary text must remain clear and readable for preference lists.";
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CheckboxPreferenceMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private inputId;
        private labelId;
        private helperId;
        private errorId;
        private static nextId;
        private handleToggle;
        private handleFocus;
        private handleBlur;
        private renderLabel;
        private renderHelperOrError;
        private getCheckboxClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-toggle-icon.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-icon\n\n# Objective\nA boolean input component that behaves as a toggle switch with distinct icons for on and off states. It supports editing and viewing modes, optional labeling, helper text, error display, and disabled state, emitting events on user-driven state changes.\n\n# Responsibilities\n- Maintain a boolean `value` as the source of truth for the on/off state, defaulting to `false` when not provided.\n- Display a distinct icon for the on state and a distinct icon for the off state, showing only the icon matching the current value.\n- Perform a visible transition when switching between on and off states.\n- In editing mode, toggle the boolean value upon user activation via click or Space key.\n- Emit a `change` event with the current boolean value in `detail.value` after each state change in editing mode.\n- Emit `focus` when receiving focus and `blur` when losing focus in editing mode.\n- Render an associated label when provided, semantically linking it to the control.\n- Display helper content below the control in editing mode when helper content is available and no error is present.\n- Display an error message and expose an invalid state via `aria-invalid` when error text is provided in editing mode.\n- In viewing mode, render static text \u201CYes\u201D when the value is `true` and \u201CNo\u201D when `false`.\n- Present a visible focus indicator when the control has focus.\n- Reduce opacity and remove interactive affordances when disabled.\n- Apply emphasized visual treatment for the on state and neutral treatment for the off state.\n- Apply error-specific visual highlighting and display the error message when invalid.\n- Adapt colors for dark mode using semantic pairs.\n\n# Constraints\n- Do not respond to interaction, change the value, or emit events when disabled.\n- Do not display helper text or error messages in viewing mode.\n- Do not emit `change`, `focus`, or `blur` events in viewing mode.\n- Only display helper content when no error is present and the component is in editing mode.\n- Only toggle the value in response to click or Space key while in editing mode and not disabled.\n- Error messaging and invalid state must only appear when error text is provided and the component is in editing mode.\n\n# Notes\n- The icons representing the on and off states are configurable.";
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-toggle-icon" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlToggleIconMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        iconOn: string;
        iconOff: string;
        private hasFocus;
        private labelId;
        private helperId;
        private errorId;
        private handleToggle;
        private handleKeyDown;
        private handleFocus;
        private handleBlur;
        private getTrackClasses;
        private getThumbClasses;
        private getButtonClasses;
        private renderIcon;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderEditMode;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.defs" {
    export const group = "groupEnterBoolean";
    export const skill = "# Metadata\n- TagName: groupenterboolean--ml-toggle-switch\n\n# Objective\nA boolean input molecule that enables users to switch between two mutually exclusive states. It provides an interactive toggle during editing mode and displays the current selection as static text during read-only mode. It reports value changes, focus, and blur to the surrounding system, and presents labels, contextual guidance, and validation errors according to its current state.\n\n# Responsibilities\n- Present an interactive binary toggle when in editing mode\n- Display static text representing the current value when not in editing mode, showing \"Yes\" for true and \"No\" for false\n- Accept and display label content through the contract-defined label region\n- Accept and display helper content through the contract-defined helper region when no validation error is present and in editing mode\n- Display validation error messages when provided and in editing mode\n- Change the boolean value upon user activation when in editing mode\n- Report value changes to the system, including the new boolean state\n- Report when the control receives focus\n- Report when the control loses focus\n- Prevent user activation and suppress value change reports when disabled\n- Prevent all interaction and suppress reports when not in editing mode\n- Initialize with a default value of false when no prior value exists\n- Support keyboard activation to change the value when enabled and in editing mode\n- Communicate the current boolean state to accessibility tools\n- Communicate the disabled condition to accessibility tools when applicable\n- Communicate the invalid condition to accessibility tools when a validation error is present\n- Maintain programmatic associations between the control and its label, helper text, and error messages\n\n# Constraints\n- Must exclusively use the Label and Helper content regions defined in the contract\n- Must treat the value strictly as a boolean type without intermediate states\n- Must not permit value changes while disabled\n- Must not report value changes while disabled\n- Must not permit interaction or report focus, blur, or value changes when not in editing mode\n- Must suppress helper text display when a validation error message is present\n- Must not display helper text or error messages when not in editing mode\n- Must ensure value change reports are detectable outside the component\n- Must display \"Yes\" only when the value is true in read-only mode\n- Must display \"No\" only when the value is false in read-only mode\n\n# Notes\n- The control maintains a strict binary state; null or indeterminate values are not supported\n- Keyboard activation should follow conventional toggle interaction patterns";
}
declare module "_102040_/l2/molecules/groupenterboolean/ml-toggle-switch" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ToggleSwitchMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: boolean;
        error: string;
        name: string;
        isEditing: boolean;
        disabled: boolean;
        private handleToggle;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        private renderLabel;
        private renderHelper;
        private renderError;
        private getToggleButtonClasses;
        private getThumbClasses;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdate/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-shortcut-picker';
    import '/_102040_/l2/molecules/groupenterdate/ml-inline-calendar';
    export class GroupEnterDateIndex extends StateLitElement {
        private cardCompactCalendar;
        private cardDatePicker;
        private cardDateShortcutPicker;
        private cardInlineCalendar;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupenterdate/ml-compact-calendar.defs" {
    export const group = "groupEnterDate";
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-compact-calendar\n\n# Objective\nAllow the user to select a single date from an always-visible inline calendar grid. The calendar renders directly inside the page layout without a popover, shows the current month with navigation controls, highlights today and the selected date, optionally displays week numbers, and respects min/max date bounds. It also has a view-only mode that shows the selected value as plain text.\n\n# Responsibilities\n- Render a full inline calendar grid for the current view month, showing all days in a 7-column layout.\n- Navigate to the previous or next month when the corresponding buttons are clicked.\n- Highlight the currently selected day and today's date visually.\n- Emit a \"change\" custom event with the selected ISO date string when the user clicks a selectable day.\n- Emit a \"monthChange\" custom event when the user navigates to a different month.\n- Emit \"focus\" and \"blur\" custom events when focus enters or leaves the component.\n- Provide a clear button in the header that removes the current selection and emits a \"change\" event with null.\n- Display the selected date in a locale-aware human-readable format in the header; show a placeholder when nothing is selected.\n- Disable navigation buttons when the target month would go outside the min/max date bounds.\n- Disable individual day cells that fall outside the current month or outside the min/max date range.\n- Support optional display of ISO week numbers as an additional column when \"show-week-numbers\" is true.\n- Respect a configurable first-day-of-week so the weekday header row and grid alignment start on the correct day.\n- Update the view month automatically when the \"value\", \"min-date\", or \"max-date\" properties change via external state binding.\n- Render in view-only mode (non-editable static text) when \"is-editing\" is false.\n- Display a label slot above the calendar and a helper/error slot below.\n- Show a required indicator next to the label when \"required\" is true.\n- Show an error message and apply error border styling to the container when \"error\" is non-empty.\n- Show a loading message and prevent day selection and navigation when \"loading\" is true.\n- Apply disabled styling and block all interaction when \"disabled\" is true.\n- Apply readonly styling and block day selection and clearing when \"readonly\" is true.\n\n# Constraints\n- Day cells outside the current month must be rendered as disabled and must not be selectable.\n- The clear button must not appear when there is no selection or when the component is in disabled, readonly, or loading state.\n- Navigation to previous or next month must be blocked when it would move outside the allowed min/max range.\n- Selection must always be a single date; the component does not support multi-selection.\n- In disabled or readonly state all interaction including month navigation must be blocked.\n- The calendar must always be visible; it does not collapse into a dropdown.\n- The \"change\" event must only fire when a valid, selectable date is chosen or when the selection is explicitly cleared.";
}
declare module "_102040_/l2/molecules/groupenterdate/ml-compact-calendar" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlCompactCalendarMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private viewMonth;
        private viewYear;
        private hasFocus;
        private static idCounter;
        private instanceId;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private handleDayClick;
        private handleClear;
        private handlePrevMonth;
        private handleNextMonth;
        private handleFocusIn;
        private handleFocusOut;
        render(): TemplateResult;
        private renderViewMode;
        private renderLabel;
        private renderHeader;
        private renderCalendar;
        private renderDayCell;
        private renderFeedback;
        private setViewToToday;
        private parseIsoDate;
        private formatIsoDate;
        private formatDisplayValue;
        private getMonthTitle;
        private getWeekdayNames;
        private getCalendarDays;
        private isDateSelectable;
        private isSameDay;
        private isSameIsoDate;
        private getWeekNumber;
        private ensureViewWithinBounds;
        private canNavigatePrev;
        private canNavigateNext;
        private navigateToMonth;
        private getContainerClasses;
        private getNavButtonClasses;
        private getDayClasses;
    }
}
declare module "_102040_/l2/molecules/groupenterdate/ml-date-picker.defs" {
    export const group = "groupEnterDate";
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-date-picker\n\n# Objective\nAllow the user to choose a single date by clicking a trigger button that opens a calendar dropdown. The selected date is displayed on the trigger in a locale-aware format, and a clear action inside the panel resets the selection. The component supports disabled, readonly, required, loading, and error states, and has a view-only mode that shows the value as static text.\n\n# Responsibilities\n- Render a trigger button that shows the currently selected date or a placeholder when nothing is selected.\n- Open a calendar dropdown panel when the trigger is clicked and close it when a date is selected, cleared, or the user clicks outside.\n- Display a monthly calendar grid inside the panel with previous/next month navigation arrows.\n- Emit a \"change\" custom event with the selected ISO date string when the user picks a day.\n- Emit a \"monthChange\" custom event when the user navigates to a different month.\n- Emit \"focus\" and \"blur\" custom events when the trigger button gains or loses focus.\n- Provide a clear button inside the calendar panel that removes the current selection and closes the panel.\n- Disable individual day cells that fall outside the min/max date bounds.\n- Disable the previous/next navigation buttons when the target month would go outside the allowed range.\n- Optionally display week numbers as an extra column when \"show-week-numbers\" is true.\n- Respect a configurable first-day-of-week for weekday header row alignment.\n- Synchronise the calendar view to the current value, or to today if no value is set, each time the panel is opened.\n- Update the view month when \"min-date\" or \"max-date\" properties change via external state binding.\n- Close the calendar panel when \"is-editing\" is set to false via external state binding.\n- Render in view-only mode (static formatted text) when \"is-editing\" is false.\n- Show a label slot above the trigger and a helper/error slot below.\n- Show a required indicator next to the label when \"required\" is true.\n- Show an error message and apply error border styling when \"error\" is non-empty.\n- Show a loading indicator below the trigger and prevent opening the calendar when \"loading\" is true.\n- Include a hidden input element with the component name and current value for form submission.\n\n# Constraints\n- The calendar panel must not open when the component is in disabled, readonly, or loading state.\n- Day cells outside the min/max range must be disabled and must not be selectable.\n- Only one date can be selected at a time; multi-selection is not supported.\n- The calendar must close automatically after a date is selected or cleared.\n- Clicking outside the component must close the calendar panel without changing the selection.\n- The clear button must not reset the selection when the component is disabled, readonly, or loading.";
}
declare module "_102040_/l2/molecules/groupenterdate/ml-date-picker" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDatePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private viewMonth;
        private viewYear;
        private fieldId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleToggleOpen;
        private handleFocus;
        private handleBlur;
        private handleOutsideClick;
        private handlePrevMonth;
        private handleNextMonth;
        private handleSelectDay;
        private handleClear;
        private syncViewToValue;
        private ensureViewWithinRange;
        private parseIsoDate;
        private toIsoDate;
        private toDateKey;
        private formatDisplay;
        private formatTriggerValue;
        private getWeekdayLabels;
        private getDaysInMonth;
        private addMonths;
        private isDateDisabled;
        private canNavigatePrev;
        private canNavigateNext;
        private getISOWeekNumber;
        private getContainerClasses;
        private getTriggerClasses;
        private getDayClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderCalendar;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdate/ml-date-shortcut-picker.defs" {
    export const group = "groupEnterDate";
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-date-shortcut-picker\n\n# Objective\nProvide a date selection interface that offers configurable shortcut options for common dates alongside a manual date entry field. It allows users to quickly select predefined dates or enter a date manually, maintaining compliance with the groupEnterDate contract.\n\n# Responsibilities\n- Display configurable shortcut options labeled \"Hoje\", \"Ontem\", \"Esta semana\", \"Este m\u00EAs\", and \"\u00DAltimos 30 dias\" above the manual entry field, arranged horizontally and wrapping when space is insufficient\n- Present each shortcut as a pill-shaped element with consistent internal spacing and visual feedback for hover, focus, and selection states\n- Highlight the shortcut that corresponds to the current value using accent colors, including dark mode variants\n- When \"Hoje\" is selected, set the value to the current date in ISO format and emit the change event\n- When \"Ontem\" is selected, set the value to the previous day's date in ISO format and emit the change event\n- When \"Esta semana\" is selected, set the value to the first day of the current week based on the configured firstDayOfWeek, in ISO format, and emit the change event\n- When \"Este m\u00EAs\" is selected, set the value to the first day of the current month in ISO format and emit the change event\n- When \"\u00DAltimos 30 dias\" is selected, set the value to the date from 30 days before today in ISO format and emit the change event\n- Update the manual entry field to reflect the value when a shortcut is selected\n- Provide a manual date entry field with standard surface, border, and text styling, supporting dark mode and showing placeholder text when empty\n- Allow users to type a valid date or clear the manual entry field\n- When a valid date is entered manually, update the value in ISO format and emit the change event\n- When the manual entry is cleared, set the value to null and emit the change event with null\n- Disable any shortcut whose calculated date falls outside the minDate and maxDate boundaries, showing it with reduced opacity and no hover states\n- Prevent disabled shortcuts from changing the value if activated\n- When disabled, prevent all shortcuts and the manual field from being interactive\n- When readonly, prevent shortcuts from changing the value and prevent the manual field from being edited\n- During loading, display a loading indicator with contrast appropriate for light and dark modes, replacing the interactive area and blocking all interactions\n- In display mode, show only the formatted date text according to locale, or a long dash when no value exists; hide shortcuts, manual entry, error messages, and helper text\n- When the error property is a non-empty string, display the error message below the field, apply error border styling to the manual entry with colors supporting dark mode, and apply the error visual state\n- When no error is present and helper text is provided, display the helper text below the field in a secondary style\n- Emit a blur event when the manual entry field loses focus\n- Emit a focus event when the manual entry field receives focus\n- Apply accessibility attributes: associate the label via aria-labelledby, associate error text via aria-describedby, set aria-invalid when an error exists, and set aria-required when required\n\n# Constraints\n- Must use only the properties, events, and slot tags defined in the groupEnterDate contract\n- All date values emitted must follow the ISO \"YYYY-MM-DD\" format\n- Shortcuts must not update the value if their resulting date is outside the minDate/maxDate range\n- Error display takes precedence over helper text display\n- The manual entry field must support a null state when cleared\n- In display mode, no interactive elements or supporting text may be visible\n\n# Notes\n- The available shortcut set is configurable\n- Date display formatting follows the current locale settings\n- The firstDayOfWeek configuration affects only the \"Esta semana\" shortcut calculation";
}
declare module "_102040_/l2/molecules/groupenterdate/ml-date-shortcut-picker" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class DateShortcutPickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private inputValue;
        private isFocused;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private syncInputValue;
        private getLocale;
        private formatDateForDisplay;
        private parseDisplayToIso;
        private getTodayIso;
        private dateToIso;
        private getYesterdayIso;
        private getThisWeekStartIso;
        private getThisMonthStartIso;
        private getLast30DaysIso;
        private isDateInRange;
        private getShortcuts;
        private isShortcutSelected;
        private handleShortcutClick;
        private handleInputChange;
        private handleInputFocus;
        private handleInputBlur;
        private getContainerClasses;
        private getShortcutsContainerClasses;
        private getShortcutClasses;
        private getInputClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        private getLoadingClasses;
        private renderLabel;
        private renderShortcuts;
        private renderShortcut;
        private renderInput;
        private renderFeedback;
        private renderLoading;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdate/ml-inline-calendar.defs" {
    export const group = "groupEnterDate";
    export const skill = "# Metadata\n- TagName: groupenterdate--ml-inline-calendar\n\n# Objective\nAn inline calendar molecule for selecting a single date, always visible during editing, with monthly navigation. It follows the groupEnterDate contract for data entry and display states.\n\n# Responsibilities\n- Display a single-month calendar inline during editing mode, without popovers or overlays.\n- Provide month navigation controls to move between previous and next months.\n- Update the visible month and year upon navigation, and report the new view to the system.\n- Allow selection of exactly one date at a time; a new selection replaces the previous one.\n- Report the selected date in ISO format (YYYY-MM-DD) and notify the system of value changes.\n- Visually distinguish the current day from other days, and combine this distinction with the selection highlight when today is chosen.\n- Present week numbers as a column when enabled.\n- Arrange days starting from the configured first day of the week.\n- Show only the formatted date text when not in editing mode, with no calendar grid, navigation, error message, or helper text.\n- Present a loading state that prevents access to the calendar.\n- Display an error message and indicate an invalid state when error content is provided.\n- Show helper text below the calendar when no error is present.\n- Show a label above the calendar when provided.\n- Adapt to dark mode using the semantic color definitions from the group contract.\n\n# Constraints\n- Must expose only the properties, events, and slots defined in the groupEnterDate contract.\n- Days before the minimum date or after the maximum date must be disabled and unselectable.\n- Navigation must be prevented for months entirely outside the minimum and maximum date range.\n- When no date is selected, no day may appear selected.\n- In the disabled state, the calendar must not respond to navigation or selection.\n- In the read-only state, the calendar must remain visible but must not allow date selection; the displayed text must remain selectable.\n- Hover feedback must appear only on enabled, unselected days.\n- Focus indicators must be visible on navigation controls and day cells per the contract.\n- Disabled days must appear with reduced opacity and must not provide hover feedback.\n- The error state must apply visual error styling to the calendar and display the error message beneath it.\n- The selected day must have a visual highlight clearly distinct from unselected days.\n- The calendar must follow the group accessibility contract, including modal dialog behavior for the panel, structured day presentation, communication of selected and disabled states, and polite announcements for month title changes.\n- The label must be programmatically associated with the field.\n- Error content must communicate the invalid state and link the error description.\n- The required state must be communicated programmatically.\n- Disabling dates via arbitrary arrays is not supported; only minimum and maximum date boundaries control availability.\n\n# Notes\n- The molecule is rendered directly in the page flow and does not use a popover.\n- Date availability is controlled exclusively by the minimum and maximum date boundaries.";
}
declare module "_102040_/l2/molecules/groupenterdate/ml-inline-calendar" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class InlineCalendarMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        private focusWithin;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        placeholder: string;
        firstDayOfWeek: number;
        showWeekNumbers: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private viewMonth;
        private viewYear;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handlePrevMonth;
        private handleNextMonth;
        private handleDaySelect;
        private handleFocusIn;
        private handleFocusOut;
        private dispatchMonthChange;
        private syncViewToValue;
        private ensureViewWithinRange;
        private getAdjacentMonth;
        private getMonthTitle;
        private getWeekdayLabels;
        private buildCalendarDays;
        private getStartOffset;
        private normalizeFirstDay;
        private parseISODate;
        private formatISODate;
        private formatDisplayValue;
        private isOutsideRange;
        private canNavigateTo;
        private isToday;
        private isSelected;
        private getDayButtonClasses;
        private getContainerClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderHiddenInput;
        private renderViewMode;
        private renderCalendar;
        private getWeekNumber;
        private calculateISOWeek;
        createRenderRoot(): this;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdateinterval/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-month-year-range';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-presets';
    export class GroupEnterDateIntervalIndex extends StateLitElement {
        private cardOne;
        private cardTwo;
        private cardThree;
        private cardFour;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag.defs" {
    export const group = "groupEnterDateInterval";
    export const skill = "# Metadata\n- TagName: groupenterdateinterval--ml-date-interval-drag\n\n# Objective\nAllow the user to select a date range by pressing and dragging across an always-visible single-month calendar grid. Pressing down on any selectable day anchors the start date, and releasing the pointer on another day confirms the end date. The component shows a live preview of the range as the user drags and highlights invalid end-date candidates in red. It supports min/max date bounds, configurable minimum and maximum range lengths, optional same-day selection, and disabled, readonly, loading, and error states.\n\n# Responsibilities\n- Render a full inline calendar grid for the current month with 42 cells (6 weeks \u00D7 7 days).\n- Start a drag gesture on pointerdown on a selectable start day, setting that day as the tentative start and clearing any previous end date.\n- Update the hover preview as the pointer moves over other day cells during the drag.\n- Finish the drag on pointerup (including a window-level fallback) and commit the ordered start and end dates.\n- Swap start and end if the user drags backwards so the earlier date always becomes the start.\n- Emit \"startChange\", \"endChange\", and \"change\" custom events with the confirmed start and end ISO date strings when a range is committed.\n- Emit \"focus\" and \"blur\" custom events when focus enters or leaves the component.\n- Highlight days in the confirmed range with a range background and mark start and end endpoints with a distinct fill.\n- Highlight hovered days during drag with a red background when the candidate end date violates the range constraints.\n- Navigate to the previous or next month when the corresponding header buttons are clicked.\n- Disable navigation buttons when the target month would go outside the min/max date bounds.\n- Enforce minRangeDays and maxRangeDays constraints when validating candidate end dates.\n- Reject same-day ranges when \"allow-same-day\" is false.\n- Display a summary of the current start and end dates in the header.\n- Display a loading overlay that blocks the calendar when \"loading\" is true.\n- Show an overall label slot, separate start and end label slots, and a helper/error slot.\n- Apply error border styling and show an error message when \"error\" is non-empty.\n- Apply disabled styling and block all pointer interaction when \"disabled\" is true.\n- Apply readonly background styling and block pointer interaction when \"readonly\" is true.\n\n# Constraints\n- The calendar is always visible; it does not collapse into a dropdown.\n- Day cells outside the min/max global date bounds must not be selectable as either start or end.\n- End date candidates that violate minRangeDays, maxRangeDays, or allowSameDay must be rejected and visually flagged as invalid during drag.\n- When the drag finishes on an invalid end candidate the end date must remain null and the component must stay in the selecting-end state.\n- All pointer interaction must be blocked when disabled, readonly, or loading.\n- The \"change\" event must only fire after a complete valid range has been committed, not during the drag preview.";
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class DateIntervalDragMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDate: string | null;
        endDate: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        minRangeDays: number;
        maxRangeDays: number;
        firstDayOfWeek: number;
        allowSameDay: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private selectingEnd;
        private hoverDate;
        private isDragging;
        private hoverValid;
        private currentMonth;
        private hasFocus;
        private labelId;
        private errorId;
        private helperId;
        connectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private handleDayPointerDown;
        private handleDayPointerEnter;
        private handleDayPointerUp;
        private handleWindowPointerUp;
        private finishDrag;
        private handlePrevMonth;
        private handleNextMonth;
        private handleFocusIn;
        private handleFocusOut;
        private getLocale;
        private syncCurrentMonth;
        private parseIsoDate;
        private formatIsoDate;
        private formatDisplayDate;
        private diffInDays;
        private compareIso;
        private getOrderedRange;
        private isWithinMinMax;
        private isDateSelectableForStart;
        private isDateSelectableForEnd;
        private getWeekdayLabels;
        private getCalendarDays;
        private getActiveRange;
        private isInRange;
        private getMonthLabel;
        private canNavigatePrev;
        private canNavigateNext;
        private getRangeSummary;
        private getDayClasses;
        render(): any;
        private renderOverallLabel;
        private renderHeader;
        private renderCalendar;
        private renderFeedback;
        private renderLoading;
    }
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-presets.defs" {
    export const group = "groupEnterDateInterval";
    export const skill = "# Metadata\n- TagName: groupenterdateinterval--ml-date-interval-presets\n\n# Objective\nEnable users to select a date range through predefined period shortcuts or custom start and end dates, conforming to the groupEnterDateInterval contract. The component presents the range differently depending on whether the user is editing or viewing the value.\n\n# Responsibilities\n- Render in editing mode when isEditing is true, displaying interactive date range controls; render in viewing mode when isEditing is false, showing only the formatted date range text without inputs, calendar, helper text, or error messages.\n- Display predefined date range options above the custom date inputs when option content is provided; omit the options entirely when no such content is supplied.\n- Highlight the predefined option whose start and end dates match the currently selected values.\n- Apply the start and end dates defined by a predefined option when that option is activated, then emit the standard start change, end change, and change notifications defined by the group contract.\n- Maintain the standard change event detail structure containing start and end dates regardless of whether the change originated from a predefined option or manual input.\n- Finalize any active date selection and close the calendar panel when a predefined option is chosen.\n- Provide separate entry fields for start and end dates during editing, enforcing minimum date, maximum date, minimum range days, maximum range days, same-day allowance, and first day of the week as specified by the contract.\n- Automatically correct the range if the chosen end date precedes the start date.\n- Reject same-day ranges when same-day selection is not permitted.\n- Disable dates that fall outside the allowed minimum or maximum bounds or exceed the permitted range duration.\n- Display the general field label when label content is provided; display start and end field labels when their respective content is provided.\n- Show helper text below the inputs when no validation error exists; display the error message in place of the helper text when an error is present.\n- Present a loading state that blocks interaction when loading is true.\n- Block all interaction with options, date fields, and calendar panels when disabled.\n- Allow text selection of displayed values while preventing value changes when read-only.\n- Emit focus and blur notifications according to the group contract when the field gains or loses focus.\n- Format the displayed date range in view mode according to the current locale, applying the contract's rules for handling null or incomplete ranges.\n\n# Constraints\n- Must operate exclusively within the properties, events, and content regions defined by the groupEnterDateInterval contract.\n- The change event detail must remain consistent with the group contract structure containing start and end dates, even when triggered by predefined option selection.\n- Predefined option selection must not introduce alternative event payloads or naming.\n- Active option state must be determined strictly by comparing the current start and end dates against each option's defined values.\n- The option list must not render if no option content is configured.\n- Date validation rules must be applied to both manual input and preset selection.\n- Error feedback must replace helper text entirely rather than appearing simultaneously.\n- Loading, disabled, and read-only states must override normal interactive behavior.\n\n# Notes\n- View mode should gracefully handle null or partial ranges using the contract's defined display conventions.\n- Predefined options serve as shortcuts that immediately commit a valid range without requiring additional confirmation.";
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-presets" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDateIntervalPresetsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDate: string | null;
        endDate: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        minRangeDays: number;
        maxRangeDays: number;
        firstDayOfWeek: number;
        allowSameDay: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private selectingEnd;
        private hoverDate;
        private viewingMonth;
        private viewingYear;
        private focusedField;
        private parsedPresets;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parsePresets;
        private initializeViewingMonth;
        private parseDate;
        private formatDateISO;
        private formatDateDisplay;
        private formatRangeDisplay;
        private getDaysBetween;
        private isDateDisabled;
        private isDateInRange;
        private isRangeStart;
        private isRangeEnd;
        private getCalendarDays;
        private getOrderedDayNames;
        private handleTriggerClick;
        private handleDateSelect;
        private handleDateHover;
        private handleDateHoverEnd;
        private handlePresetSelect;
        private handlePrevMonth;
        private handleNextMonth;
        private handleOutsideClick;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private isPresetActive;
        private getTriggerClasses;
        private getPresetClasses;
        private getDayClasses;
        render(): TemplateResult;
        private renderLoading;
        private renderSpinner;
        private renderViewMode;
        private renderEditMode;
        private renderLabel;
        private renderTrigger;
        private renderCalendarIcon;
        private renderChevronIcon;
        private renderDropdown;
        private renderPresets;
        private renderCalendar;
        private renderCalendarHeader;
        private renderSelectionHint;
        private renderFeedback;
    }
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar.defs" {
    export const group = "groupEnterDateInterval";
    export const skill = "# Metadata\n- TagName: groupenterdateinterval--ml-date-range-dual-calendar\n\n# Objective\nAllow the user to select a date range through two separate trigger buttons \u2014 one for the start date and one for the end date \u2014 that open a panel showing two side-by-side monthly calendars. Clicking the start trigger opens the calendars in start-selection mode; clicking the end trigger enters end-selection mode directly when a start date is already set. A hover preview highlights the tentative range as the user moves over day cells. The component enforces min/max date bounds, optional minimum and maximum range lengths, same-day restrictions, and supports disabled, readonly, required, loading, and error states.\n\n# Responsibilities\n- Render two trigger buttons (start date and end date) that display the current selection or a placeholder.\n- Open a dual-calendar panel when either trigger is clicked, positioning the left calendar at the start date's month (or today if unset).\n- Enter end-selection mode automatically when the end-date trigger is clicked and a start date is already set.\n- Render two adjacent month calendars; the right calendar always shows the month after the left.\n- Navigate both calendars together by one month when the previous or next arrow is clicked.\n- Highlight the selected range across both calendar grids with distinct border styling on start and end endpoints.\n- Show a live range preview as the mouse hovers over valid day cells while in end-selection mode.\n- Confirm the range when the user clicks a day in end-selection mode, swapping dates if needed so start <= end.\n- Close the calendar panel automatically after a valid range is confirmed.\n- Close the calendar panel when the user clicks outside the component.\n- Emit \"startChange\", \"endChange\", and \"change\" custom events when the range changes.\n- Emit \"focus\" and \"blur\" custom events when focus enters or leaves the component.\n- Provide a clear button inside the panel that resets both dates and emits the corresponding change events.\n- Display optional hint text for min/max range day constraints inside the panel footer.\n- Disable individual day cells that fall outside the global min/max date bounds or violate range constraints in end-selection mode.\n- Disable the previous/next navigation buttons when the target month would fall outside the allowed bounds.\n- Enforce minRangeDays, maxRangeDays, and allowSameDay when validating the candidate end date.\n- Render in view-only mode (static formatted text showing start \u2013 end) when \"is-editing\" is false.\n- Show overall, start, and end label slots as well as a helper/error slot.\n- Show a required indicator when \"required\" is true.\n- Show an error message and apply error border styling when \"error\" is non-empty.\n- Show a loading indicator and disable the triggers when \"loading\" is true.\n- Include hidden form inputs for the start and end dates when \"name\" is provided.\n\n# Constraints\n- The calendar panel must not open when the component is disabled, readonly, or loading.\n- Day cells outside the global min/max bounds must be disabled and not selectable.\n- End-date selections that violate minRangeDays, maxRangeDays, or allowSameDay constraints must be silently rejected without closing the panel.\n- The right calendar must always display exactly one month ahead of the left calendar.\n- The \"change\" event must only fire after a complete valid range is committed.\n- Clicking outside the component must close the panel without modifying the current selection.\n- The clear action must be blocked when the component is disabled, readonly, or loading.";
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class DateRangeDualCalendarMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        private onDocumentClick;
        private isFocused;
        slotTags: string[];
        startDate: string | null;
        endDate: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        minRangeDays: number;
        maxRangeDays: number;
        firstDayOfWeek: number;
        allowSameDay: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private selectingEnd;
        private hoverDate;
        private currentMonthLeft;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private handleFocusIn;
        private handleFocusOut;
        private handleOpenCalendar;
        private handleOutsideClick;
        private closeCalendar;
        private handleDayHover;
        private handleDayClick;
        private handlePrevMonth;
        private handleNextMonth;
        private handleClear;
        private emitStartChange;
        private emitEndChange;
        private emitChange;
        private getToday;
        private parseISO;
        private formatISO;
        private formatDisplay;
        private getLocale;
        private compareDates;
        private toUtcDay;
        private addDays;
        private addMonths;
        private daysBetween;
        private adjustMonthToBounds;
        private canNavigateToMonth;
        private canSelectRange;
        private isDateDisabled;
        private isInRange;
        private getWeekdayLabels;
        private renderLabel;
        private renderStartLabel;
        private renderEndLabel;
        private renderHelperOrError;
        private renderCalendarIcon;
        private renderMonth;
        private renderCalendarPanel;
        private renderViewMode;
        private renderEditMode;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-month-year-range.defs" {
    export const group = "groupEnterDateInterval";
    export const skill = "# Metadata\n- TagName: groupenterdateinterval--ml-month-year-range\n\n# Objective\nEnable users to select a date range limited to month and year granularity. The molecule presents two independent year-navigable month grids, highlights the chosen interval, and communicates the selection through the groupEnterDateInterval contract.\n\n# Responsibilities\n- Display two month grids, each tied to a navigable year, allowing independent year traversal.\n- Present months in a uniform layout with abbreviated names based on the current locale.\n- Permit selection of a start month from the first grid and an end month from the second grid.\n- Visually mark the selected start and end months with a distinct selection style.\n- Highlight all months between the start and end selections with an interval style.\n- While awaiting the end selection, keep the start month marked and allow interval preview by interacting with the end grid.\n- Map selected months to startDate and endDate values representing the first day of each chosen month, adhering to the groupEnterDateInterval contract.\n- After start month selection, store the startDate, clear any previous endDate, enter end-selection mode, and signal the start change.\n- After end month selection, store the endDate; if the end precedes the start, automatically swap the values to maintain chronological order, then signal the end change and the final interval change.\n- Disable months that fall outside the minDate and maxDate boundaries.\n- Disable end months that would violate the minimum or maximum allowed range duration, converting day-based limits to month-level constraints.\n- Block selection of the same month for both start and end when same-month selection is forbidden, remaining in end-selection mode until a distinct month is chosen.\n- In non-editing mode, render only the formatted interval text according to the locale and contract display format, with no month grids visible.\n- In loading state, show a loading indicator and prevent all interaction.\n- In disabled state, block all interaction and prevent opening or selecting values.\n- In readonly state, allow viewing and text selection but block value changes.\n- Signal when the field gains focus and when it loses focus.\n- In view mode, suppress all event emissions and hide error messages and helper text.\n- Show a general field label, individual labels for the start and end grids, and helper text when no error is present.\n- Show error messages with an error style when validation fails, replacing the helper text.\n- Adapt all colors for dark mode across backgrounds, text, borders, hover states, selections, and errors using semantic pairs.\n- Exhibit the visual states Normal, Selecting, Complete, Disabled, Readonly, Error, Loading, and View Mode.\n\n# Constraints\n- Day-level selection must never be exposed or permitted.\n- Emitted values must always represent the first day of the selected month to satisfy the contract format.\n- Change notifications must use only the contract-defined startDate and endDate properties, never custom month-only fields.\n- Disabled months must not respond to interaction or show hover effects.\n- Interval selections must respect configured minimum and maximum range limits.\n- Visual feedback must accurately reflect the current selection and preview states.\n- Grids and interactive elements must not appear in view mode or during loading.\n- Error and helper text must not appear simultaneously; error takes precedence.\n\n# Notes\n- Independent year navigation in each grid supports selections that span multiple years.\n- Interval preview during end-selection gives immediate visual feedback before confirmation.";
}
declare module "_102040_/l2/molecules/groupenterdateinterval/ml-month-year-range" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlMonthYearRangeMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDate: string | null;
        endDate: string | null;
        error: string;
        name: string;
        locale: string;
        minDate: string;
        maxDate: string;
        minRangeDays: number;
        maxRangeDays: number;
        allowSameDay: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private startYear;
        private endYear;
        private selectingEnd;
        private hoverMonth;
        private isFocused;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private initializeYears;
        private initializeYearsFromDate;
        private parseDate;
        private formatDateISO;
        private formatDisplayDate;
        private getMonthDiff;
        private getDaysInRange;
        private isMonthDisabled;
        private isEndMonthDisabled;
        private generateMonthData;
        private handleStartYearPrev;
        private handleStartYearNext;
        private handleEndYearPrev;
        private handleEndYearNext;
        private handleStartMonthSelect;
        private handleEndMonthSelect;
        private handleEndMonthHover;
        private handleEndMonthLeave;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getGridContainerClasses;
        private getGridPanelClasses;
        private getYearNavClasses;
        private getNavButtonClasses;
        private getYearLabelClasses;
        private getMonthGridClasses;
        private getMonthButtonClasses;
        private getLabelClasses;
        private getGridLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        private getLoadingClasses;
        private renderLabel;
        private renderGridLabel;
        private renderYearNav;
        private renderMonthGrid;
        private renderMonthButton;
        private renderStartGrid;
        private renderEndGrid;
        private renderFeedback;
        private renderViewMode;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker.defs" {
    export const group = "groupEnterDatetime";
    export const skill = "# Metadata\n- TagName: groupenterdatetime--ml-datetime-picker\n\n# Objective\nAllow the user to select a combined date and time through a trigger button that opens a panel containing a monthly calendar grid on the left and scrollable hour and minute selectors on the right. The selection is confirmed explicitly with a Confirm button. The component supports min/max datetime bounds, configurable minute step intervals, timezone-aware display, and disabled, readonly, required, loading, and error states.\n\n# Responsibilities\n- Render a trigger button that displays the currently selected datetime in a locale- and timezone-aware format, or a placeholder when nothing is selected.\n- Open a picker panel when the trigger is clicked and close it on outside clicks or after confirmation or clearing.\n- Render a monthly calendar grid inside the panel with previous/next month navigation.\n- Render scrollable hour (0\u201323) and minute selectors side by side; generate minute options according to the configured minuteStep.\n- When the user selects a day, automatically move the time selection to the first valid hour/minute within the min/max datetime bounds if the current time would become invalid.\n- When the user selects an hour, automatically advance the minute selection to the first valid minute for that hour.\n- Emit a \"change\" custom event with the confirmed ISO datetime string (YYYY-MM-DDTHH:MM:00) when the user clicks Confirm.\n- Emit a \"change\" event with null when the user clicks Clear, and close the panel.\n- Emit \"focus\" and \"blur\" custom events when the trigger button gains or loses focus.\n- Disable individual day cells that fall outside the date portion of the min/max datetime bounds.\n- Disable individual hour and minute buttons that would produce a datetime outside the min/max bounds.\n- Prevent Confirm from executing when no date is selected or when the selected time is invalid.\n- Update the display value when \"value\", \"locale\", or \"timezone\" properties change via external state binding.\n- Render in view-only mode (static formatted text) when \"is-editing\" is false.\n- Show a label slot above the trigger and a helper/error slot below.\n- Show a required indicator next to the label when \"required\" is true.\n- Show an error message and apply error border styling when \"error\" is non-empty.\n- Show a loading spinner on the trigger and prevent opening the panel when \"loading\" is true.\n- Include a hidden input element for form submission when \"name\" is provided.\n\n# Constraints\n- The panel must not open when the component is disabled, readonly, or loading.\n- The Confirm button must be inert until a valid date and a valid time within min/max bounds are both selected.\n- Minute options must be strictly limited to multiples of minuteStep; intermediate values must not appear.\n- Hour and minute options that violate the min/max datetime constraint for the currently selected date must be disabled and unselectable.\n- The panel must close on any outside click without altering the committed value.\n- The \"change\" event must only fire on explicit Confirm or Clear actions, never during intermediate calendar or time navigation.";
}
declare module "_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDatetimePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minuteStep: number;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private isFocused;
        private displayValue;
        private selectedDate;
        private selectedHour;
        private selectedMinute;
        private currentMonth;
        private labelId;
        private helperId;
        private errorId;
        private documentClickBound;
        createRenderRoot(): this;
        handleIcaStateChange(key: string, value: any): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleFocus;
        private handleBlur;
        private handleDaySelect;
        private handleHourSelect;
        private handleMinuteSelect;
        private handleConfirm;
        private handleClear;
        private handlePrevMonth;
        private handleNextMonth;
        private openPicker;
        private closePicker;
        private addDocumentListener;
        private removeDocumentListener;
        private handleDocumentClick;
        private prepareOpenState;
        private updateFromValue;
        private updateDisplay;
        private formatDisplay;
        private parseIso;
        private pad;
        private getMinuteOptions;
        private parseMinMax;
        private getMinDate;
        private getMaxDate;
        private isDateDisabled;
        private isTimeDisabled;
        private getFirstValidTime;
        private getFirstValidMinute;
        private getTriggerClasses;
        private getLabelClasses;
        private getPanelClasses;
        private getDayButtonClasses;
        private getTimeButtonClasses;
        private getAriaDescribedBy;
        private getWeekdays;
        private renderLabel;
        private renderHiddenInput;
        private renderHelperOrError;
        private renderTrigger;
        private renderCalendar;
        private renderTime;
        private renderPanel;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdatetime/ml-enter-datetime-masked-input.defs" {
    export const group = "groupEnterDatetime";
    export const skill = "# Metadata\n- TagName: groupenterdatetime--ml-enter-datetime-masked-input\n\n# Objective\nAllow the user to type a date and time directly into a masked text field. As the user types, the component formats the raw digits into a locale-appropriate date/time pattern (e.g. MM/DD/YYYY HH:MM for en-US, DD/MM/AAAA HH:MM for pt, TT.MM.JJJJ HH:MM for de). When focus leaves the field or Enter is pressed, the typed value is parsed and committed as an ISO datetime string if it is valid; otherwise the field reverts to the last committed value. The component supports min/max datetime bounds, configurable minute step, timezone-aware display, and disabled, readonly, required, loading, and error states.\n\n# Responsibilities\n- Render a text input field with a calendar icon decoration on the right.\n- Apply a live mask to the raw typed characters, formatting them into the locale-appropriate date/time pattern as the user types.\n- Derive the correct date segment order (M/D/Y vs D/M/Y), date separator (/ vs .), and 12/24-hour mode from the configured locale.\n- Commit the typed value on blur or when Enter is pressed, converting the masked text to an ISO datetime string (YYYY-MM-DDTHH:MM:00).\n- Revert the input display to the last valid committed value when the typed text cannot be parsed into a valid datetime.\n- Emit a \"change\" custom event with the ISO datetime string when a valid value is committed.\n- Emit a \"change\" event with null when the field is cleared to empty and committed.\n- Emit \"focus\" and \"blur\" custom events when the input gains or loses focus.\n- Validate that the parsed datetime satisfies the minDatetime and maxDatetime bounds before committing.\n- Validate that the minute component is a multiple of minuteStep before committing.\n- Validate that the date components represent a real calendar date (year 1000\u20139999, valid month and day for that month).\n- Synchronise the displayed input value when the \"value\", \"locale\", or \"timezone\" properties change externally.\n- Format the displayed value using Intl.DateTimeFormat with the configured locale and timezone for correct presentation.\n- Render in view-only mode (static formatted text) when \"is-editing\" is false.\n- Show a label slot above the input and a helper/error slot below.\n- Show a required indicator next to the label when \"required\" is true.\n- Show an error message and apply error border styling when \"error\" is non-empty.\n- Show an animated loading spinner in place of the calendar icon and prevent input when \"loading\" is true.\n- Apply disabled styling and block all input interaction when \"disabled\" is true.\n- Apply readonly styling and block text entry when \"readonly\" is true.\n\n# Constraints\n- The mask must only accept digit characters; all non-digit input is stripped before formatting.\n- A value must not be committed unless all 12 required digit positions (two each for day, month, four-digit year, hour, minute) are present and form a valid datetime.\n- If the typed text is empty, committing must store null and emit \"change\" with null.\n- If the typed text is non-empty but invalid, committing must silently revert the field to the last committed display value without emitting \"change\".\n- The minute value must be a multiple of minuteStep; a datetime with a non-conforming minute must be rejected.\n- The parsed datetime must fall within the minDatetime\u2013maxDatetime range; out-of-range values must be rejected.\n- Interaction (typing, focus, blur) must be blocked when disabled or loading.\n- Readonly state must render the current value but prevent text modification.";
}
declare module "_102040_/l2/molecules/groupenterdatetime/ml-enter-datetime-masked-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class EnterDatetimeMaskedInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minuteStep: number;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private isFocused;
        private inputValue;
        private static idCounter;
        private inputId;
        private labelId;
        private helperId;
        private errorId;
        firstUpdated(): void;
        updated(changedProps: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleKeydown;
        render(): any;
        private renderViewMode;
        private renderLabel;
        private renderFeedback;
        private renderLoading;
        private renderIcon;
        private applyMask;
        private commitInputValue;
        private parseInputToIso;
        private updateInputValueFromValue;
        private formatValueForDisplay;
        private getIs12HourLocale;
        private getFormatConfig;
        private getSegmentsFromDigits;
        private joinDateParts;
        private joinTimeParts;
        private isValidDateParts;
        private pad;
        private getInputClasses;
    }
}
declare module "_102040_/l2/molecules/groupenterdatetimeinterval/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-datetime-interval-timeline';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-event-duration-interval';
    export class GroupEnterDateTimeIntervalIndex extends StateLitElement {
        private cardTimeline;
        private cardEnter;
        private cardEvent;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupenterdatetimeinterval/ml-datetime-interval-timeline.defs" {
    export const group = "groupEnterDatetimeInterval";
    export const skill = "# Metadata\n- TagName: groupenterdatetimeinterval--ml-datetime-interval-timeline\n\n# Objective\nAllow the user to view and edit a datetime interval through a visual timeline track that renders two draggable markers representing the start and end datetimes, together with two datetime-local inputs arranged in a two-column grid. In view mode the component collapses to a single formatted range string. When editing, the timeline visually fills the segment between the two selected instants.\n\n# Responsibilities\n- Render a horizontal timeline track showing a progress segment between the start and end markers proportional to the configured min/max datetime boundaries.\n- Display two clickable circular markers on the timeline, one for start and one for end, highlighting the active field.\n- Render two datetime-local inputs (start and end) in a responsive two-column grid when in editing mode.\n- Apply the minuteStep property as the step attribute of both inputs, converting minutes to seconds.\n- Validate each input value against the configured minDatetime and maxDatetime boundaries before accepting it.\n- Reject an end datetime that would create an invalid range with the already-confirmed start datetime.\n- Enforce minimum and maximum interval duration in minutes when both start and end are present.\n- Block equal start and end instants unless allowSameInstant is true.\n- Dispatch a startChange event when the start value changes and an endChange event when the end value changes, each carrying the new ISO value.\n- Dispatch a change event carrying both startDatetime and endDatetime when both fields hold a valid range.\n- Dispatch focus and blur events as fields gain and lose focus.\n- Show a loading indicator text when the loading property is true.\n- Render an error message below the timeline when the error property is non-empty.\n- Render a helper message from the Helper slot when no error is present and the field is in editing mode.\n- Render an optional top label from the Label slot.\n- Collapse to a plain formatted range string when isEditing is false.\n- Format displayed datetimes using Intl.DateTimeFormat with the configured locale and timezone, collapsing same-day ranges to show the shared date once.\n- Support English and Portuguese UI strings via the locale property.\n\n# Constraints\n- Input interaction must be blocked when disabled, readonly, or loading is true.\n- Values that fall outside minDatetime or maxDatetime must be silently rejected without updating the property.\n- The change event must only fire when both startDatetime and endDatetime are set and form a valid range.\n- The edit inputs are only shown in editing mode; the timeline track and markers are present in both modes.\n- Helper text must not be shown when an error is active.\n- The component must not contain business logic; it is a pure presentation molecule.";
}
declare module "_102040_/l2/molecules/groupenterdatetimeinterval/ml-datetime-interval-timeline" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class DatetimeIntervalTimelineMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDatetime: string | null;
        endDatetime: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        minuteStep: number;
        allowSameInstant: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        activeField: 'start' | 'end' | null;
        private uid;
        private onStartFocus;
        private onEndFocus;
        private onFieldBlur;
        private onStartInput;
        private onEndInput;
        private toInputValue;
        private fromInputValue;
        private toDate;
        private isWithinMinMax;
        private isValidRange;
        private formatDateTime;
        private formatRange;
        private getContainerClasses;
        private getInputClasses;
        private getMarkerClasses;
        private getTimelineProgressClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private renderTimeline;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval.defs" {
    export const group = "groupEnterDatetimeInterval";
    export const skill = "# Metadata\n- TagName: groupenterdatetimeinterval--ml-enter-datetime-interval\n\n# Objective\nAllow the user to select a datetime interval by clicking separate start and end trigger buttons that each expand an inline picker panel. The component shows a live formatted preview of the selected range above the trigger buttons and supports individual confirmation and clearing of each field. In view mode the range is displayed as plain text without any interactive controls.\n\n# Responsibilities\n- Render one trigger button per field (start and end) that toggles an inline picker panel open or closed when clicked.\n- Display the formatted datetime of the selected value on each trigger button, or a placeholder text when no value is set.\n- Open the picker panel for a field when its trigger button is clicked, and close the panel if the same button is clicked again.\n- Render a datetime-local input inside each picker panel, initialized to a draft value that the user can freely edit before confirming.\n- Apply configurable min, max, and step constraints to the picker input so the browser native controls respect the interval rules.\n- Require the user to click a Confirm button to commit the draft; reject the confirmation if the draft fails validation.\n- Validate the start draft against minDatetime and maxDatetime.\n- Validate the end draft against a computed minimum (derived from startDatetime, minDurationMinutes, minuteStep, and allowSameInstant) and a computed maximum (derived from startDatetime, maxDurationMinutes, and maxDatetime).\n- After confirming the start field, automatically open the end picker if no end value is set yet.\n- Provide a Clear button inside each picker panel to remove the current value and close the panel.\n- Show a formatted range preview (start \u2013 end) above the trigger buttons at all times when values are present.\n- Collapse to a plain formatted range string when isEditing is false.\n- Dispatch startChange when the committed start value changes, endChange when the committed end value changes, and change when the end is committed alongside a confirmed start.\n- Dispatch focus when any picker panel first opens and blur when the last open panel closes.\n- Show a loading indicator text when the loading property is true.\n- Render an error message when error is non-empty, or a helper message from the Helper slot when no error is present.\n- Render an optional label from the Label slot, with LabelStart and LabelEnd slot overrides for each field's label.\n- Synchronize draft values with external property changes via handleIcaStateChange.\n- Support English and Portuguese UI strings via the locale property.\n\n# Constraints\n- Opening the picker panel must be blocked when disabled, readonly, or loading is true.\n- Confirmation of a draft must be rejected unless the draft passes all validation constraints.\n- The change event must only fire when a confirmed end value is set together with a confirmed start value.\n- Helper text must not be shown when an error is active.\n- The component must not contain business logic; it is a pure presentation molecule.";
}
declare module "_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class EnterDatetimeIntervalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startDatetime: string | null;
        endDatetime: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        minuteStep: number;
        allowSameInstant: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private startDraft;
        private endDraft;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        private dispatchFocus;
        private dispatchBlur;
        private dispatchStartChange;
        private dispatchEndChange;
        private dispatchChange;
        private handleOpenField;
        private setActiveField;
        private handleStartDraftInput;
        private handleEndDraftInput;
        private handleConfirmStart;
        private handleConfirmEnd;
        private handleClearStart;
        private handleClearEnd;
        private isStartDraftValid;
        private isEndDraftValid;
        private isWithinRange;
        private getMinEndIso;
        private getMaxEndIso;
        private getDisplayRange;
        private formatDateTime;
        private formatDate;
        private formatTime;
        private getDateKey;
        private parseIso;
        private parseIsoToTime;
        private toInputValueFromIso;
        private formatInputValue;
        private toIsoFromInput;
        private addMinutes;
        private toIsoString;
        private maxIso;
        private minIso;
        private pad;
        private renderLabel;
        private renderPreview;
        private renderInputBlock;
        private renderPickerPanel;
        private renderFeedback;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenterdatetimeinterval/ml-event-duration-interval.defs" {
    export const group = "groupEnterDateTimeInterval";
    export const skill = "# Metadata\n- TagName: groupenterdatetimeinterval--ml-event-duration-interval\n\n# Objective\nEnable users to define an event time interval by providing a start and end date and time. The molecule automatically calculates the duration between the two points and presents it to the user. It supports defining the interval by directly setting the end, or by providing a duration in minutes or hours that the molecule converts into an end time. The molecule handles validation, boundary restrictions, and distinct presentation modes for editing and viewing.\n\n# Responsibilities\n- Present two date-time fields for start and end when the user is allowed to edit.\n- Accept and confirm a start date and time from the user.\n- Accept a duration expressed in minutes or hours and derive the corresponding end time automatically.\n- If the end is not yet defined when the start is confirmed, guide the user to provide the end next.\n- Accept and confirm an end date and time from the user.\n- Communicate the confirmed start and end values, including the calculated duration, to the consuming system according to the groupEnterDateTimeInterval contract.\n- Calculate the elapsed duration in minutes whenever both start and end are available, and present this value to the user.\n- Block confirmation of an end that occurs before or at the same instant as the start, unless the configuration explicitly permits same-instant selection.\n- Visually distinguish which field is currently active for input.\n- Visually indicate when the interval is completely defined.\n- Show a group label when provided, and individual field labels when provided.\n- Show supporting text alongside the calculated duration when custom guidance is provided.\n- Show validation failure messages and alter the visual presentation to reflect an error condition.\n- Indicate a busy state and prevent user action while processing.\n- Ignore user attempts to change values when interaction is disabled.\n- Allow text selection but prevent opening of date-time choosers and prevent value modification when in a read-only state.\n- Enforce mandatory field semantics when the interval is marked as required.\n- Limit available dates and times to a defined minimum and maximum range.\n- Limit end choices to those that respect configured minimum and maximum duration boundaries.\n- Advance minute selections in configured increments rather than continuously.\n- When the user is not allowed to edit, present the interval as formatted text without any input controls.\n- When not editing, display a placeholder dash for missing values, a partial interval when only the start exists, and the full formatted range when both exist.\n- Signal when the user enters or leaves the component boundary according to the contract.\n- Adjust visual presentation for dark environments using the contract's semantic color system.\n\n# Constraints\n- Must adhere strictly to the properties and events defined in the groupEnterDateTimeInterval contract.\n- Must not permit an end datetime earlier than or equal to the start datetime unless same-instant selection is explicitly allowed.\n- Must visually suppress end options that violate minimum or maximum duration constraints.\n- Must not present input fields, helper text, error messages, or communicate changes when in the viewing state.\n- Must not respond to user input or communicate state changes while disabled or busy.\n- Must not present interactive controls for value selection in read-only state.\n- Error indicators and messages must appear only during editing.\n- Calculated duration must not appear in the helper area while an error is present.\n- Must support dark mode presentation using semantic color pairs for surfaces, borders, typography, hover, and focus.\n\n# Notes\n- The molecule supports two ways to establish the end: by direct entry of the end datetime, or by specifying a duration that is added to the start.\n- The duration is displayed as auxiliary information unless an error condition overrides it.\n- Text presentation in the non-editing state follows contract rules for empty, partial, and complete intervals.";
}
declare module "_102040_/l2/molecules/groupenterdatetimeinterval/ml-event-duration-interval" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class EventDurationIntervalMolecule extends MoleculeAuraElement {
        private msg;
        private componentId;
        slotTags: string[];
        startDatetime: string | null;
        endDatetime: string | null;
        error: string;
        name: string;
        locale: string;
        timezone: string;
        minDatetime: string;
        maxDatetime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        minuteStep: number;
        allowSameInstant: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private durationValue;
        private durationUnit;
        handleIcaStateChange(key: string, value: any): void;
        private handleFocus;
        private handleBlur;
        private handleStartInput;
        private handleEndInput;
        private handleDurationValueInput;
        private handleDurationUnitChange;
        private emitChangeIfComplete;
        private updateDurationFromRange;
        private applyDurationToEnd;
        private getDurationMinutes;
        private isEndValidAgainstStart;
        private parseIsoToDate;
        private formatToInput;
        private parseInputToIso;
        private formatRangeDisplay;
        private addMinutesToIso;
        private getStartMinMax;
        private getEndMinMax;
        render(): any;
        private renderLabel;
        private renderFieldLabel;
        private renderHelper;
        private getLabelId;
        private getInputClasses;
        private getSelectClasses;
    }
    export default EventDurationIntervalMolecule;
}
declare module "_102040_/l2/molecules/groupentermoney/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-display';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-minimal';
    import '/_102040_/l2/molecules/groupentermoney/ml-currency-input';
    export class GroupEnterMoneyIndex extends StateLitElement {
        private cardBr;
        private cardDisplay;
        private cardMinimal;
        private cardCurrency;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupentermoney/ml-currency-input.defs" {
    export const group = "groupEnterMoney";
    export const skill = "# Metadata\n- TagName: groupentermoney--ml-currency-input\n\n# Objective\nPermitir ao usu\u00E1rio inserir e visualizar valores monet\u00E1rios em USD, com formata\u00E7\u00E3o e valida\u00E7\u00E3o conforme padr\u00E3o en-US, aceitando at\u00E9 20 d\u00EDgitos num\u00E9ricos.\n\n# Responsibilities\n- Aceitar entrada de valores monet\u00E1rios em USD.\n- Permitir digita\u00E7\u00E3o de n\u00FAmeros e ponto decimal (.) da esquerda para a direita.\n- Ignorar e impedir caracteres n\u00E3o num\u00E9ricos, exceto o ponto decimal.\n- Permitir entrada de pelo menos 20 d\u00EDgitos num\u00E9ricos (excluindo o ponto decimal).\n- Formatar e exibir o valor conforme padr\u00E3o en-US, sempre com duas casas decimais.\n- Emitir eventos de input a cada altera\u00E7\u00E3o e de change/blur ao perder o foco.\n- Atualizar e emitir o valor como n\u00FAmero com duas casas decimais.\n- Definir o valor como null se a entrada estiver vazia ou inv\u00E1lida.\n- Suportar modos de edi\u00E7\u00E3o (input) e visualiza\u00E7\u00E3o (string formatada como moeda USD).\n- Impedir edi\u00E7\u00E3o quando disabled ou readonly estiverem ativos.\n- Exibir indicador de carregamento e bloquear entrada quando loading for true.\n- Indicar visualmente campos obrigat\u00F3rios, estados de erro e exibir mensagens de erro.\n- Exibir texto de ajuda quando n\u00E3o houver erro.\n- Renderizar slots de label e helper em suas posi\u00E7\u00F5es respectivas, se fornecidos.\n- Indicar visualmente os estados disabled e readonly.\n- Garantir conformidade de acessibilidade conforme o contrato do grupo.\n\n# Constraints\n- N\u00E3o permitir entrada de caracteres n\u00E3o num\u00E9ricos, exceto o ponto decimal.\n- Limitar a entrada a pelo menos 20 d\u00EDgitos num\u00E9ricos (excluindo o ponto decimal).\n- O campo deve exibir o placeholder \"0.00\" quando vazio.\n- O valor exibido deve seguir a formata\u00E7\u00E3o en-US, com separador de milhar e duas casas decimais.\n- O valor deve ser null se a entrada estiver vazia ou inv\u00E1lida.\n- O campo n\u00E3o pode ser editado quando disabled ou readonly estiverem ativos.\n- O campo deve ser visualmente distinto nos estados disabled (opacidade reduzida) e readonly (texto selecion\u00E1vel).\n- Slots de label e helper devem ser renderizados apenas se fornecidos.\n- Texto de ajuda n\u00E3o deve ser exibido quando houver erro.\n- O indicador de carregamento deve bloquear a entrada quando loading for true.\n\n# Notes\n- Exemplo de formata\u00E7\u00E3o: ao digitar 123, exibir \"1.23\"; ao digitar 123456, exibir \"1,234.56\".\n- O campo deve garantir acessibilidade conforme o contrato do grupo.";
}
declare module "_102040_/l2/molecules/groupentermoney/ml-currency-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class GroupEnterMoneyMlCurrencyInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        currency: string;
        locale: string;
        decimals: number;
        min: number | null;
        max: number | null;
        showSymbol: boolean;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        handleIcaStateChange(key: string, value: any): void;
        private getEffectiveLocale;
        private formatNumber;
        private formatToRaw;
        /**
         * Parses the raw string entered by the user, interpreting it as an integer of cents
         * (or the appropriate fraction based on `decimals`). Returns a number or null.
         * Supports up to 20 digits by using BigInt for the intermediate integer value.
         */
        private parseRawToNumber;
        private clampValue;
        private onFocus;
        private onInput;
        private onBlur;
        private getInputClasses;
        private getContainerClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderInput;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentermoney/ml-enter-money-br.defs" {
    export const group = "groupEnterMoney";
    export const skill = "# Metadata\n- TagName: groupentermoney--ml-enter-money-br\n\n# Objective\nA monetary input field that accepts numeric typing and automatically formats values according to Brazilian currency conventions. As the user types digits, the value fills from right to left, applying thousand and decimal separators without displaying the currency symbol.\n\n# Responsibilities\n- Accept only numeric characters during editing; ignore any letters, symbols, or signs without changing the field's value.\n- Format the displayed value using Brazilian locale conventions: period as thousands separator and comma as decimal separator.\n- Omit the currency symbol from display, showing only the formatted numeric value.\n- Fill entered digits from right to left, so that typing \"123456\" displays as \"1.234,56\".\n- Emit an input event containing the parsed numeric value during typing, following the group's contract rules.\n- On focus loss, set the value to null if the field is empty; otherwise normalize the value, apply minimum and maximum bounds if defined, reformat the display, and emit change followed by blur events.\n- In read-only mode, display the formatted value or an em dash when null, without presenting an input field or emitting events.\n- Respect disabled and read-only states by blocking interaction as defined by the contract.\n- Display an error state when a non-empty error string is provided; otherwise display helper text when a Helper slot is present.\n- Support Label and Helper slots exactly as defined by the contract.\n- Present the label above or beside the field when provided, and helper text below when no error exists.\n- Show error styling and error message below the field when in error state.\n- Present reduced opacity and no visual interaction cues when disabled.\n- Support dark mode color variants for background, text, border, hover, focus, and error states as defined by the contract.\n\n# Constraints\n- Must expose properties and events exactly as defined by the groupEnterMoney contract.\n- Default configuration must use Brazilian locale (pt-BR), BRL currency, and 2 decimal places.\n- Must never accept non-numeric input during editing.\n- Must not display the currency symbol under any editing or viewing state.\n- Must not emit input, change, or blur events in read-only mode.\n- Empty content on blur must result in a null value.\n- Must apply min/max constraints only when explicitly defined.\n- Error state takes precedence over helper text display.\n\n# Notes\n- The component operates in two distinct modes: editing (interactive input) and viewing (static display).\n- Right-to-left filling means each new digit shifts the decimal place accordingly.";
}
declare module "_102040_/l2/molecules/groupentermoney/ml-enter-money-br" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class EnterMoneyBrMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        currency: string;
        locale: string;
        decimals: number;
        min: number | null;
        max: number | null;
        showSymbol: boolean;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        handleIcaStateChange(key: string, value: any): void;
        private handleFocus;
        private handleInput;
        private handleBlur;
        private getLocale;
        private getDecimals;
        private extractDigits;
        private parseDigitsToNumber;
        private formatNumberToRaw;
        private formatNumberToView;
        private applyMinMax;
        private getInputClasses;
        private renderLabel;
        private renderHelper;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenternumber/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupenternumber/ml-range-slider';
    export class GroupEnterNumberIndex extends StateLitElement {
        private cardInputValue;
        private cardStepperValue;
        private cardSliderValue;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupenternumber/ml-floating-number-input.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-floating-number-input\n\n# Objective\nPermitir ao usu\u00E1rio inserir ou visualizar n\u00FAmeros inteiros e decimais em um campo com label flutuante, seguindo regras de acessibilidade, formata\u00E7\u00E3o e estados visuais definidos pelo contrato groupEnterNumber.\n\n# Responsibilities\n- Aceitar entrada de valores inteiros e decimais conforme as propriedades de configura\u00E7\u00E3o.\n- Exibir e atualizar o valor atual, podendo ser um n\u00FAmero ou nulo.\n- Emitir evento de altera\u00E7\u00E3o de valor a cada modifica\u00E7\u00E3o.\n- Emitir evento de confirma\u00E7\u00E3o de valor ao perder foco ou ao usar controles de incremento/decremento.\n- Emitir eventos ao receber e ao perder foco.\n- Alternar entre modo de edi\u00E7\u00E3o (input) e visualiza\u00E7\u00E3o (texto formatado) conforme configura\u00E7\u00E3o.\n- Impedir intera\u00E7\u00E3o quando desabilitado e refletir visualmente esse estado.\n- Impedir edi\u00E7\u00E3o, mas permitir sele\u00E7\u00E3o de texto quando somente leitura.\n- Indicar obrigatoriedade visual e semanticamente quando requerido.\n- Exibir mensagem de erro e refletir estado de erro quando configurado.\n- Exibir indicador de carregamento e bloquear intera\u00E7\u00E3o quando em carregamento.\n- Respeitar limites m\u00EDnimos, m\u00E1ximos e passos definidos para o valor.\n- Renderizar r\u00F3tulo flutuante, prefixo, sufixo e mensagem auxiliar conforme slots e propriedades.\n- Aplicar regras de acessibilidade para r\u00F3tulo, erro, obrigatoriedade e estado inv\u00E1lido.\n- Formatar o valor exibido conforme localidade e quantidade de decimais.\n- Exibir valor formatado como texto quando em modo de visualiza\u00E7\u00E3o, sem input, erro ou helper.\n- Exibir tra\u00E7o (\u2014) quando o valor for nulo em modo de visualiza\u00E7\u00E3o.\n\n# Constraints\n- O campo s\u00F3 aceita n\u00FAmeros v\u00E1lidos conforme as propriedades de decimais, localidade, m\u00EDnimo, m\u00E1ximo e passo.\n- N\u00E3o permite intera\u00E7\u00E3o ou edi\u00E7\u00E3o quando desabilitado ou em carregamento.\n- N\u00E3o permite edi\u00E7\u00E3o quando somente leitura, mas permite sele\u00E7\u00E3o do texto.\n- O campo deve indicar obrigatoriedade e erro de forma visual e acess\u00EDvel.\n- O label deve flutuar para fora do campo ao receber foco ou quando houver valor; caso contr\u00E1rio, permanece dentro do campo.\n- O helper s\u00F3 \u00E9 exibido quando n\u00E3o h\u00E1 erro e o slot correspondente est\u00E1 presente.\n- Em modo de visualiza\u00E7\u00E3o, n\u00E3o exibe input, erro ou helper, apenas o valor formatado, prefixo e sufixo.\n- Quando o valor for nulo em modo de visualiza\u00E7\u00E3o, exibe tra\u00E7o (\u2014).\n- O componente deve garantir espa\u00E7amento e alinhamento adequados entre todos os elementos visuais.\n- O componente deve aplicar estilos visuais e de acessibilidade conforme o estado atual (normal, focado, preenchido, desabilitado, somente leitura, erro, carregando).\n\n# Notes\n- O componente deve garantir que todos os estados e transi\u00E7\u00F5es sejam percept\u00EDveis e acess\u00EDveis ao usu\u00E1rio.\n- O label flutuante deve ter transi\u00E7\u00E3o suave entre os estados.\n- O componente deve suportar dark mode conforme padr\u00E3o do contrato.";
}
declare module "_102040_/l2/molecules/groupenternumber/ml-floating-number-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlFloatingNumberInputMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        private isFocused;
        updated(changedProps: Map<string, unknown>): void;
        handleIcaStateChange(key: string, _value: any): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private getSeparators;
        private parseRawValue;
        private roundToDecimals;
        private formatToDisplay;
        private getContainerClasses;
        private getInputClasses;
        private renderFloatingLabel;
        private renderInlineLabel;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenternumber/ml-number-input.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-number-input\n\n# Objective\nAllow the user to type a numeric value into a text field that accepts locale-aware decimal input with optional prefix and suffix slot adornments. On blur the component rounds the value to the configured decimal places, clamps it to min/max bounds, and reformats the display text. In view mode it shows the formatted number alongside any prefix or suffix without an editable field.\n\n# Responsibilities\n- Render a text input with inputmode=\"decimal\" for entering a number.\n- Parse the typed text on each input event using locale-aware group and decimal separators, updating the numeric value property immediately and emitting an input event.\n- On blur, parse the raw text, round the result to the configured decimals, clamp to min/max bounds, reformat the display text using locale-aware formatting, and emit a change event; emit a blur event regardless of whether the value changed.\n- Emit a focus event when the input gains focus.\n- Support optional Prefix and Suffix slot adornments rendered to the left and right of the input respectively.\n- Apply the configured locale and decimals to all number formatting via toLocaleString / Intl.NumberFormat.\n- Synchronize the internal raw display value when value, locale, or decimals are changed externally via handleIcaStateChange.\n- In view mode, display the formatted value (or \"\u2014\" when null) flanked by any Prefix and Suffix slot content; omit the input element entirely.\n- Show a loading indicator text when loading is true.\n- Render an error message when error is non-empty, or a helper message from the Helper slot otherwise.\n- Render an optional label from the Label slot.\n\n# Constraints\n- Input, typing, and value updates must be blocked when readonly, disabled, or loading is true.\n- Rounding and clamping must only occur on blur, not during live typing.\n- Error indication must persist until the error property is cleared.\n- The component must not contain business logic; it is a pure presentation molecule.";
}
declare module "_102040_/l2/molecules/groupenternumber/ml-number-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlNumberInputMolecule extends MoleculeAuraElement {
        private msg;
        private componentId;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private emitInput;
        private emitChange;
        private emitBlur;
        private emitFocus;
        private getSeparators;
        private parseRawValue;
        private roundToDecimals;
        private formatToDisplay;
        private getInputClasses;
        private getContainerClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderPrefix;
        private renderSuffix;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupenternumber/ml-number-stepper.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-number-stepper\n\n# Objective\nAllow the user to enter or adjust a numeric value through a text input flanked by decrement and increment buttons. Each button click changes the value by the configured step, respecting min/max bounds, and the typed input is normalised and clamped on blur. In view mode the component renders the formatted value with optional prefix and suffix adornments but no interactive controls.\n\n# Responsibilities\n- Render a text input for direct numeric entry together with a decrement button (\u2212) and an increment button (+).\n- Increment the value by the step amount when the + button is clicked, silently ignoring the action if it would exceed max.\n- Decrement the value by the step amount when the \u2212 button is clicked, silently ignoring the action if it would fall below min.\n- Parse the typed text on each input event using locale-aware group and decimal separators, updating the numeric value property immediately and emitting an input event.\n- On blur, parse the raw text, round the result to the configured decimals, clamp to min/max bounds, reformat the display text, and emit change and blur events.\n- Emit a focus event when the input gains focus.\n- Support optional Prefix and Suffix slot adornments rendered around the input.\n- Apply the configured locale and decimals to all Intl.NumberFormat calls.\n- Synchronize the internal raw display value when value, decimals, or locale are changed externally via handleIcaStateChange.\n- In view mode, display the formatted value (or \"\u2014\" when null) flanked by any Prefix and Suffix slot content; omit all interactive controls.\n- When loading is true, show a loading indicator and suppress helper/error text in its favour.\n- Derive an effective error from the explicit error property, or from the required constraint when the value is null; render a helper message from the Helper slot when no effective error is active.\n- Render an optional label from the Label slot.\n- Support English and Portuguese UI strings (loading indicator, required message, increment/decrement aria labels) via the locale property.\n\n# Constraints\n- Increment, decrement, and direct input must be blocked when disabled, readonly, or loading is true, and also when isEditing is false.\n- Increment must be silently blocked when the resulting value would exceed max; decrement must be silently blocked when it would fall below min.\n- Rounding and clamping must only occur on blur or after a stepper button click, not during live typing.\n- The required error must only surface when required is true and value is null; it must be suppressed when the explicit error property is set.\n- The component must not contain business logic; it is a pure presentation molecule.";
}
declare module "_102040_/l2/molecules/groupenternumber/ml-number-stepper" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class NumberStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValue;
        private inputId;
        private labelId;
        private helperId;
        private errorId;
        connectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private increment;
        private decrement;
        private emitInput;
        private emitChange;
        private formatToDisplay;
        private parseRawToNumber;
        private normalizeValue;
        private roundToDecimals;
        private getNumberSeparators;
        private getInputClasses;
        private getButtonClasses;
        private getContainerClasses;
        private getRowClasses;
        render(): any;
        private renderViewMode;
        private renderLabel;
        private renderHelperOrError;
        private renderPrefix;
        private renderSuffix;
    }
}
declare module "_102040_/l2/molecules/groupenternumber/ml-range-slider.defs" {
    export const group = "groupEnterNumber";
    export const skill = "# Metadata\n- TagName: groupenternumber--ml-range-slider\n\n# Objective\nAllows users to select a numeric interval by adjusting two controls that define the lowest and highest acceptable values. It presents the formatted bounds above their respective controls and alternates between an interactive state for editing and a plain text state for viewing, following the groupEnterNumber contract. It notifies the system of range changes as they happen and when they settle, suitable for filtering data such as age brackets or price bands.\n\n# Responsibilities\n- Present two adjustable controls for setting the lower and upper limits of a numeric interval during editing\n- Display formatted values for both limits above their respective controls\n- Respect absolute floor, ceiling, and increment settings that apply to both limits\n- Keep the lower limit from surpassing the upper limit and the upper limit from dropping below the lower limit\n- Notify the system with the current interval values continuously while either control is being adjusted\n- Notify the system with the final interval values once adjustment ends or focus moves away\n- Restrict interval values to stay within the absolute floor and ceiling\n- Present values rounded or truncated to the configured precision\n- Apply locale and unit formatting to displayed values; fall back to the browser's default when no locale is specified\n- Show placeholder text when no interval has been chosen\n- In viewing mode, display only the formatted interval or an absence marker, with no interactive controls, guidance text, or validation messages\n- Show validation messages and distinct error styling exclusively during editing when the value is invalid\n- Block all adjustment and suppress change notifications when disabled\n- Allow focus and selection but block value changes when readonly\n- Show a busy state indicator and block interaction while loading\n- Associate the controls with their visible label, any visible validation message, and states for required and invalid through accessibility properties\n\n# Constraints\n- Must use only the Label, Helper, Prefix, and Suffix slots from the groupEnterNumber contract\n- The lower limit must not exceed the upper limit at any time\n- Both controls must stay within the configured minimum, maximum, and step boundaries\n- Validation messages must not appear in viewing mode\n- Viewing mode must not present guidance text, interactive controls, or editing affordances\n- Placeholder must only appear when the interval is unset\n- Disabled and loading states must prevent all control adjustment and system notifications\n- Readonly state must lock the controls in place while preserving focus capability\n- Accessibility properties must reference the Label slot when available\n- Accessibility properties must reference validation messages when they are shown\n- Required and invalid conditions must be exposed through accessibility properties\n\n# Notes\n- The molecule follows the groupEnterNumber contract for editing, viewing, validation, and state management\n- Continuous notifications during adjustment enable live filtering without requiring the user to finish interacting";
}
declare module "_102040_/l2/molecules/groupenternumber/ml-range-slider" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class RangeSliderMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: number | null;
        valueHigh: number | null;
        error: string;
        name: string;
        min: number | null;
        max: number | null;
        step: number;
        decimals: number;
        locale: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawValueLow;
        private rawValueHigh;
        handleIcaStateChange(key: string, value: any): void;
        private getLabelId;
        private getErrorId;
        private getHelperId;
        private getDisplayPlaceholder;
        private isIntervalUnset;
        private getBounds;
        private normalizeValue;
        private roundToDecimals;
        private formatToDisplay;
        private clampPair;
        private emitInput;
        private emitChange;
        private emitFocus;
        private emitBlur;
        private handleLowInput;
        private handleHighInput;
        private handleLowChange;
        private handleHighChange;
        private handleFocus;
        private handleBlur;
        private renderLabel;
        private renderPrefixSuffix;
        private renderHelperOrError;
        private getInputClasses;
        private getValueDisplay;
        private renderLoading;
        private renderEditMode;
        private renderViewMode;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupentertext/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentertext/ml-address-field';
    import '/_102040_/l2/molecules/groupentertext/ml-password-strength-input';
    import '/_102040_/l2/molecules/groupentertext/ml-phone-input';
    import '/_102040_/l2/molecules/groupentertext/ml-tag-input';
    export class GroupEnterTextIndex extends StateLitElement {
        private cardCpf;
        private cardFloating;
        private cardMultiline;
        private cardAddress;
        private cardPassword;
        private cardPhone;
        private cardTag;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupentertext/ml-address-field.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-address-field\n\n# Objective\nProvide a complete address entry interface that allows users to input a postal code and automatically retrieves corresponding address details from an external service. The molecule populates street, neighborhood, city, and state fields automatically while keeping them manually editable afterward. It includes fields for number and complement, validates the postal code before searching, and notifies the system when a complete address is confirmed.\n\n# Responsibilities\n- Display input fields for postal code, street, neighborhood, city, state, number, and complement.\n- Accept user input in all fields and reflect changes immediately.\n- When the postal code reaches its required valid length, automatically query an external address service.\n- Populate street, neighborhood, city, and state fields with data returned from the service.\n- Allow manual editing of any auto-populated field after the lookup completes.\n- Prevent entry beyond the defined maximum length for any field.\n- Render single-line inputs by default and multi-line inputs when configured; multi-line fields must not apply format patterns or input type restrictions.\n- Display a character counter below multi-line fields when a maximum length is defined, updating as the user types.\n- Present field values as static text without error messages or helper text when in view mode.\n- Show an em dash when a view-mode field contains no value.\n- Hide sensitive values behind a fixed bullet sequence in view mode when configured for secure content.\n- Remain editable after external value updates unless the field is marked as read-only or disabled.\n- Emit a notification containing the full address object when the address entry is confirmed.\n- Emit a notification with the current field value on every user input.\n- Emit a notification with the current value and a blur indication when a field loses focus.\n- Emit a focus indication when a field gains focus.\n- Present a visual error state only when an external error message is provided.\n- Support visual error states for empty required fields when indicated externally.\n- Block user interaction while remaining visible during loading states.\n- Display a loading indicator during loading states.\n- Show helper text below fields when no error exists and the field is in editing mode.\n- Hide helper text and display error messages below fields when errors are present.\n- Render prefix and suffix elements aligned horizontally with the input area.\n- Provide distinct visual treatments for normal, focus, filled, disabled, read-only, error, loading, and view modes.\n- Highlight field borders with focus colors when active.\n- Use semantic error colors for borders and messages when an error is present.\n- Reduce opacity and remove interaction affordances when disabled.\n- Allow text selection without editing affordances when read-only.\n- Support dark mode variants for all background, text, border, focus, hover, and placeholder colors.\n- Announce character count changes politely to assistive technologies.\n- Associate labels with inputs and link error messages and counters using assistive attributes.\n- Mark fields as invalid and required for accessibility when applicable.\n\n# Constraints\n- The postal code must be validated for correct length before triggering any external lookup.\n- The molecule must not generate its own error messages; all errors come from external sources.\n- Format patterns must apply to visible text while the stored value contains only raw characters without literal pattern symbols.\n- Multi-line fields must ignore format pattern and input type configurations.\n- Loading states must prevent user interaction without hiding the component.\n- Empty values must always be represented as empty strings.\n\n# Notes\n- The molecule adheres to the groupEnterText contract boundaries.\n- The external address lookup occurs only when the postal code field is valid and complete.";
}
declare module "_102040_/l2/molecules/groupentertext/ml-address-field" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlAddressFieldMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        postalCode: string;
        street: string;
        number: string;
        complement: string;
        neighborhood: string;
        city: string;
        stateCode: string;
        postalCodeError: string;
        streetError: string;
        numberError: string;
        complementError: string;
        neighborhoodError: string;
        cityError: string;
        stateError: string;
        name: string;
        postalCodeMask: string;
        postalCodeLength: number;
        streetMaxLength: number | null;
        numberMaxLength: number | null;
        complementMaxLength: number | null;
        neighborhoodMaxLength: number | null;
        cityMaxLength: number | null;
        complementRows: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        loading: boolean;
        postalCodeRequired: boolean;
        streetRequired: boolean;
        numberRequired: boolean;
        neighborhoodRequired: boolean;
        cityRequired: boolean;
        stateRequired: boolean;
        private postalCodeDisplay;
        private isSearching;
        private focusedField;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private applyMask;
        private extractRaw;
        private handlePostalCodeInput;
        private handleFieldInput;
        private handleFieldBlur;
        private handleFieldFocus;
        private triggerAddressLookup;
        private confirmAddress;
        private getInputClasses;
        private getLabelClasses;
        private getErrorClasses;
        private getHelperClasses;
        private getViewValueClasses;
        private getCounterClasses;
        private getContainerClasses;
        private renderLabel;
        private renderViewValue;
        private renderError;
        private renderCounter;
        private renderInput;
        private renderTextarea;
        private renderPostalCodeField;
        private renderLoadingOverlay;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertext/ml-cpf-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-cpf-input\n# Objective\nPermitir a entrada e exibi\u00E7\u00E3o de CPF com formata\u00E7\u00E3o padr\u00E3o, mantendo o valor armazenado como apenas n\u00FAmeros.\n# Responsibilities\n- Aceitar a digita\u00E7\u00E3o de at\u00E9 11 d\u00EDgitos num\u00E9ricos para CPF.\n- Exibir o CPF formatado como 000.000.000-00 quando houver 11 d\u00EDgitos.\n- Manter e disponibilizar o valor armazenado apenas como sequ\u00EAncia num\u00E9rica, sem pontos e h\u00EDfen.\n- Em modo de edi\u00E7\u00E3o, permitir entrada em uma \u00FAnica linha com formata\u00E7\u00E3o aplicada na exibi\u00E7\u00E3o.\n- Disparar atualiza\u00E7\u00E3o a cada digita\u00E7\u00E3o com o valor bruto num\u00E9rico.\n- Ao perder o foco, emitir eventos de altera\u00E7\u00E3o e de perda de foco com o valor bruto num\u00E9rico.\n- Em modo de visualiza\u00E7\u00E3o, exibir o valor formatado quando existir; caso contr\u00E1rio, exibir \u201C\u2014\u201D.\n- Exibir r\u00F3tulo, ajuda, prefixo e sufixo quando fornecidos.\n- Exibir mensagem de erro quando fornecida e aplicar o estado de erro.\n# Constraints\n- Quando desabilitado, n\u00E3o permitir intera\u00E7\u00E3o nem emitir eventos de entrada.\n- Quando somente leitura, bloquear edi\u00E7\u00E3o e permitir sele\u00E7\u00E3o de texto, sem emitir eventos de entrada.\n- Se obrigat\u00F3rio e o valor estiver vazio, entrar em estado de erro quando a mensagem de erro for fornecida.\n- Deve apresentar os estados visuais: normal, focado, preenchido, desabilitado, somente leitura, erro e carregando.\n- A exibi\u00E7\u00E3o deve sempre seguir o formato de CPF com pontos e h\u00EDfen quando houver valor.\n# Notes\n- O valor armazenado \u00E9 sempre num\u00E9rico e sem formata\u00E7\u00E3o.";
}
declare module "_102040_/l2/molecules/groupentertext/ml-cpf-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CpfInputMolecule extends MoleculeAuraElement {
        static idCounter: number;
        private uid;
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private displayValue;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, any>): void;
        private handleInputEvent;
        private handleBlurEvent;
        private handleFocusEvent;
        private getMaxDigits;
        private formatCpf;
        private getLabelId;
        private getErrorId;
        private getHelperId;
        private getCounterId;
        private hasError;
        private getWrapperClasses;
        private getInputClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderHelperOrError;
        private renderCounter;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertext/ml-floating-text-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-floating-text-input\n\n# Objective\nAllow the user to enter a single line of text through an input field that features a floating label \u2014 the label starts in the placeholder position and animates upward when the field is focused or has a value. The component supports optional input masking, prefix and suffix slots, character length limits, multiple input types, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Display a floating label that animates to a smaller position above the input when the field is focused or has a value.\n- Accept and expose typed text as the component's value, dispatching an \"input\" event on each keystroke and a \"change\" event on blur.\n- Apply an optional input mask: insert literal separator characters automatically, strip non-matching characters, and store only the raw (unmasked) digits or letters as the value.\n- Enforce optional maximum and minimum character length limits on the raw value.\n- Support multiple input types (text, password, email, etc.) via the input-type property; never apply masking when the type is \"password\".\n- Render a read-only view mode (isEditing = false) that shows the label and value as plain text, displaying \"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\" for password type and \"\u2014\" when the value is empty.\n- Show an inline error message styled in red when the error property is set.\n- Show a helper text below the field when a Helper slot is provided and there is no error.\n- Render optional prefix and suffix content inside the input container via named slots.\n- Show a spinning indicator inside the suffix area when the loading state is active.\n- Dispatch \"focus\" and \"blur\" custom events when the underlying input gains or loses focus.\n- Synchronize the displayed masked value when the bound value, mask, or input-type changes externally.\n\n# Constraints\n- Input, typing, focus, and all interaction must be blocked when disabled, readonly, loading, or isEditing is false.\n- Masking must never be applied to password-type inputs.\n- The raw (unmasked) value must be stored in the value property; masked characters are display-only.\n- The clear action and option list are not part of this component; it is a plain text input, not a select.\n- Error styling must persist until the error property is cleared externally.\n- The loading state must prevent interaction and display a spinner in place of or alongside the suffix slot.\n- Multiple simultaneous selections or multi-line input are not supported by this component.";
}
declare module "_102040_/l2/molecules/groupentertext/ml-floating-text-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlFloatingTextInputMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private isFocused;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        updated(changedProps: Map<string, unknown>): void;
        private handleInput;
        private handleBlur;
        private handleFocus;
        private shouldUseMask;
        private getMaskedDisplayValue;
        private applyMaskToRaw;
        private extractRawFromInput;
        private isMaskToken;
        private isCharValidForToken;
        private getLabelText;
        private getInputPlaceholder;
        private getViewValue;
        private renderPrefix;
        private renderSuffix;
        private renderFeedback;
        private renderInlineLabel;
        private renderFloatingLabel;
        private getContainerClasses;
        private getInputClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertext/ml-multiline-text.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-multiline-text\n\n# Objective\nAllow the user to enter either a single line of text or a multiline paragraph, switching automatically between an <input> and a <textarea> based on the rows property. The component supports optional input masking for single-line mode, character length limits, prefix and suffix slots, a live character counter for multiline mode, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Render a <textarea> when rows > 1 and an <input> when rows = 1, using the same property contract for both.\n- Accept and expose typed text as the component's value, dispatching an \"input\" event on each keystroke and a \"change\" event on blur.\n- Apply an optional input mask in single-line mode (rows = 1) only: insert literal separators automatically, strip non-matching characters, and store only the raw value.\n- Enforce optional maximum and minimum character length limits; truncate input that exceeds maxLength.\n- Display a live character counter (current / max) below the textarea when rows > 1 and maxLength is set.\n- Support multiple input types via the input-type property; never apply masking when the type is \"password\".\n- Render a view mode (isEditing = false) showing the label and current value as plain text, displaying \"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\" for password type and \"\u2014\" when the value is empty.\n- Show an inline error message styled in red when the error property is set.\n- Show helper text below the field when a Helper slot is provided and there is no error.\n- Render optional prefix and suffix content inside the input wrapper via named slots.\n- Show a spinning loading indicator when the loading state is active.\n- Dispatch \"focus\" and \"blur\" custom events when the underlying input or textarea gains or loses focus.\n- Synchronize the raw display value when the bound value, mask, rows, or input-type changes externally.\n\n# Constraints\n- Input and all interaction must be blocked when disabled, readonly, loading, or isEditing is false.\n- Masking applies only to single-line mode (rows = 1) and never to password-type inputs.\n- The raw (unmasked) value must be stored in the value property; masked characters are display-only.\n- The character counter must only be shown in multiline mode when maxLength is explicitly set.\n- Error styling must persist until the error property is cleared externally.\n- The component must not implement selection, autocomplete dropdown, or calendar-style pickers.";
}
declare module "_102040_/l2/molecules/groupentertext/ml-multiline-text" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MultilineTextMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private rawDisplay;
        private labelId;
        private inputId;
        private helperId;
        private errorId;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private isMaskActive;
        private shouldRenderTextarea;
        private normalizeValue;
        private syncRawDisplay;
        private applyMaxLength;
        private getRawFromInput;
        private matchToken;
        private applyMaskToRaw;
        private getDisplayValue;
        private getWrapperClasses;
        private getInputClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderLoading;
        private renderHelperOrError;
        private renderCounter;
        private handleInput;
        private handleBlur;
        private handleFocus;
        render(): any;
        private renderViewMode;
        private renderEditMode;
    }
}
declare module "_102040_/l2/molecules/groupentertext/ml-password-strength-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-password-strength-input\n\n# Objective\nProvide a password entry field that allows switching between hidden and visible text, combined with a real-time strength indicator based on configurable validation criteria. It operates within the groupEnterText contract.\n\n# Responsibilities\n- Present a password entry field during editing when configured for a single row.\n- Offer a control to alternate between masked and plain text visibility during editing, without changing the stored value.\n- Show a static placeholder for empty values and a masked representation for filled values when not in editing mode, while hiding all editing controls, strength indicators, and helper or error information.\n- Assess password strength using configurable criteria: minimum length (when specified), uppercase letters, numbers, and symbols.\n- Consider the length requirement satisfied when no minimum length is configured.\n- Classify strength into four levels based on how many criteria are met: zero to one as weak, two as medium, three as strong, and four as very strong.\n- Refresh the strength bar and criteria checklist immediately upon any change to the entered value.\n- Honor configured input masking for display while basing strength calculations on the underlying unmasked value.\n- Refuse input beyond a configured maximum length; show a character counter when multiple rows are allowed together with a maximum length limit.\n- Disable editing and prevent interaction with the visibility control when the field is marked as disabled, read-only, or loading.\n- Notify changes only through the contract-specified interactions (input, change, blur, focus), providing the current value.\n- Position label content above the field when supplied.\n- Position prefix content before the entry area and suffix content after it; the visibility control must coexist with suffix content.\n- Place the strength indicator below the entry area and above any helper or error message during editing.\n- Display a horizontal strength bar and adjacent text label that correspond to the current strength level.\n- Present each validation criterion beneath the strength bar with a visual marker indicating whether it is met.\n- Apply distinct visual treatments to distinguish satisfied criteria from unsatisfied ones.\n- Present error indicators and messaging when validation fails, while maintaining the strength indicator visible during editing.\n- Reduce opacity and remove interactive capabilities from the entire field set when disabled.\n- Allow text selection but block visibility toggle interaction when read-only.\n- Present a loading state that blocks entry and conceals the strength indicator.\n- Adapt all semantic colors for dark appearance, including backgrounds, borders, text, errors, and accents.\n\n# Constraints\n- Must only use the contract-defined content areas: Label, Helper, Prefix, and Suffix.\n- The visibility control must only appear when editing a single-row password field.\n- Strength evaluation must always reference the underlying value, never a masked representation.\n- No interactions other than those defined in the contract may be used to communicate changes.\n- When not in editing mode, no entry field, visibility control, strength indicator, helper text, or error message may appear.\n- The visibility control must not displace or suppress suffix content.\n- During loading, the strength indicator must remain hidden.\n\n# Notes\n- Strength assessment reflects the current state continuously as the user enters text.\n- Masking and character counting behaviors adhere to the groupEnterText contract.";
}
declare module "_102040_/l2/molecules/groupentertext/ml-password-strength-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class PasswordStrengthInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        mask: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isPasswordVisible;
        private isFocused;
        private rawDisplay;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private applyMask;
        private extractRawValue;
        private getCriteriaStatus;
        private getStrengthLevel;
        private getStrengthLabel;
        private getStrengthBarClasses;
        private getStrengthTextClasses;
        private handleInput;
        private handleChange;
        private handleFocus;
        private handleBlur;
        private togglePasswordVisibility;
        private getContainerClasses;
        private getInputWrapperClasses;
        private getInputClasses;
        private getToggleButtonClasses;
        private getCriteriaItemClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderToggleButton;
        private renderInput;
        private renderStrengthIndicator;
        private renderCriteriaItem;
        private renderHelper;
        private renderError;
        private renderLoading;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertext/ml-phone-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-phone-input\n\n# Objective\nProvide a Brazilian phone number entry field that formats numbers as they are entered, accepts supplementary content before and after the input area, and participates in standard form workflows.\n\n# Responsibilities\n- Display entered numbers in the Brazilian format \"(XX) XXXXX-XXXX\" while handling the underlying content as digits only.\n- Communicate the digit-only content on every change and when editing is completed.\n- Signal when the field loses focus, carrying the final digit-only content.\n- Accommodate a prefix region for DDD or international country code selection, and a suffix region for additional actions.\n- Show formatted text as read-only content when editing is disabled, displaying an em dash when empty.\n- Present externally provided error messages below the field, and suppress any helper guidance while an error is shown.\n- Limit entry to a configurable minimum and maximum number of digits, refusing characters beyond the maximum.\n- Exhibit clear visual differences for normal, focused, filled, disabled, read-only, error, and loading states.\n- Render appropriately in dark mode with matching visual treatments.\n\n# Constraints\n- Must operate within the groupEnterText boundaries without introducing new controls or signals.\n- Must remain a single-line entry area.\n- Must prevent user input during loading while keeping surrounding regions visible.\n- Must remain silent and hide error or helper information when in view mode.\n- Must depend on external sources to define validation failures.\n- Must support configurable autocomplete assistance.\n- Must respect required, disabled, and read-only rules as established by the group.\n\n# Notes\n- DDD lists and international country code selectors with flags are provided by the surrounding context into the prefix region; the field does not maintain these catalogs.\n- Validation occurs outside the component; the field only displays the error state it is given.";
}
declare module "_102040_/l2/molecules/groupentertext/ml-phone-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class PhoneInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        autocomplete: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isFocused;
        private rawDisplay;
        private labelId;
        private errorId;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private extractDigits;
        private formatPhoneNumber;
        private handleInput;
        private handleChange;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getInputWrapperClasses;
        private getInputClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        private getPrefixSuffixClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderLoadingIndicator;
        private renderFeedback;
        private renderViewMode;
        private renderEditMode;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupentertext/ml-tag-input.defs" {
    export const group = "groupEnterText";
    export const skill = "# Metadata\n- TagName: groupentertext--ml-tag-input\n\n# Objective\nProvide a tag entry field that allows users to create multiple tags from typed text, display each tag as a removable chip, and manage the collection as a single comma-separated value. It must support constraints on tag count and length, prevent duplicates, offer suggestion areas, and adapt behavior between single-line tag entry and standard multi-line text entry.\n\n# Responsibilities\n- Accept text entry and convert delimited tokens into tags when in single-line edit mode.\n- Present each committed tag as a removable chip inside the field before the text entry region, keeping the entry region visible for additional input.\n- Present on each chip the tag text and a visible removal control with clear interaction affordance.\n- Maintain the current tag collection as a single comma-separated string, ignoring empty tokens.\n- Emit the updated comma-separated value immediately after tags are added or removed.\n- Prevent addition of duplicate tags using case-insensitive comparison.\n- Enforce configured maximum and minimum length limits on individual tags.\n- Block further character entry when the current token reaches the maximum length.\n- Block tag creation and removal when the field is disabled, loading, or readonly.\n- Present label, helper, prefix, and suffix content according to the groupEnterText contract.\n- Display error text and apply error visual treatment when an error is present.\n- Provide a helper area during edit mode for external suggestion content.\n- Switch to plain text display without chips or interaction when in view mode, showing an em dash when the value is empty.\n- Adopt standard multi-line text entry behavior when configured for multiple rows, including length limits and character counting.\n- Visually indicate focus by highlighting the field border during active input in edit mode.\n- Visually indicate disabled and loading states as non-interactive without focus styling that suggests editability.\n- Visually indicate readonly state as non-editable while keeping text selectable.\n- Emit focus and blur events when the field gains or loses attention in edit mode.\n- Emit change events when the field loses focus in edit mode.\n- Support dark-mode color semantics for all visual states.\n\n# Constraints\n- Must only present content in the Label, Helper, Prefix, and Suffix areas defined by the groupEnterText contract.\n- The stored and emitted value must always be a comma-separated string.\n- In single-line edit mode, Enter and comma must commit the current token as a tag only if the token is not empty.\n- After committing a tag in single-line edit mode, the entry area must clear to accept the next token.\n- Duplicate tags must not be added, and no value update or event may occur for duplicate attempts.\n- Tags exceeding the maximum length or below the minimum length must not be added.\n- Chips must flow to the next line when they exceed the available field width.\n- Removing a chip must update the comma-separated value and emit the new value immediately.\n- No input or change events may result from user interaction while disabled, loading, or readonly.\n- No tag creation or removal interactions may be available while disabled, loading, or readonly.\n- In view mode, interactive controls must not appear, input/change/focus/blur events must not emit, error and helper content must be hidden.\n- In multi-line mode, tag chips, delimiters, and tag-specific parsing must not be active.\n- The molecule must not filter or manage suggestion data; it must only render the helper area for external suggestion content.\n- All color applications must include dark-mode variants.\n\n# Notes\n- Consumers are responsible for splitting the comma-separated string into an array if needed.\n- The helper area serves as the visual container for autocomplete suggestions supplied by the parent.";
}
declare module "_102040_/l2/molecules/groupentertext/ml-tag-input" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlTagInputMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        maxLength: number | null;
        minLength: number | null;
        rows: number;
        autocomplete: string;
        inputType: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private currentInput;
        private isFocused;
        private get tags();
        private get isInteractive();
        private get isMultiLine();
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleKeyDown;
        private addTag;
        private removeTagByIndex;
        private handleFocus;
        private handleBlur;
        private handleContainerClick;
        private getContainerClasses;
        private getInputClasses;
        private getTagClasses;
        private getRemoveButtonClasses;
        private renderLabel;
        private renderPrefix;
        private renderSuffix;
        private renderTag;
        private renderTags;
        private renderInput;
        private renderTextarea;
        private renderEditMode;
        private renderViewMode;
        private renderHelper;
        private renderLoadingIndicator;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertime/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    import '/_102040_/l2/molecules/groupentertime/ml-time-scroll-picker';
    import '/_102040_/l2/molecules/groupentertime/ml-enter-time-duration';
    export class GroupEnterTimeIndex extends StateLitElement {
        private card1;
        private card2;
        private card3;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupentertime/ml-clock-time-picker.defs" {
    export const group = "groupEnterTime";
    export const skill = "# Metadata\n- TagName: groupentertime--ml-clock-time-picker\n\n# Objective\nAllow the user to pick a time of day through a step-by-step clock panel. The user clicks a read-only text input to open a panel, then selects the hour, then the minute, and optionally the second, each on a separate stage. Confirming the selection stores the time in HH:MM or HH:MM:SS format and closes the panel. The component supports 12-hour and 24-hour modes, a configurable minute step, min/max time bounds, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Display a read-only text input showing the currently selected time formatted with Intl.DateTimeFormat, or a configurable placeholder when no time is selected.\n- Open a clock selection panel when the input or the clock icon button is clicked, provided the component can interact.\n- Guide the user through three sequential stages \u2014 hour, then minute, then (optionally) second \u2014 automatically advancing to the next stage after each selection.\n- Show 12 hour buttons (1\u201312) in 12-hour mode and 24 hour buttons (0\u201323) in 24-hour mode.\n- Show AM/PM toggle buttons when hour12 is enabled and update the internally stored 24-hour value accordingly.\n- Show minute buttons respecting the minuteStep interval; default step is 1.\n- Show second buttons (0\u201359) only when show-seconds is enabled.\n- Disable individual hour, minute, and second buttons that fall outside the minTime\u2013maxTime range.\n- Allow the user to clear the selection, setting value to null and closing the panel.\n- Allow the user to confirm the selection only when all required stages are complete; dispatch a \"change\" event with the formatted value string.\n- Close the panel when a click is detected outside the component.\n- Render a view mode (isEditing = false) showing the label and formatted time as plain text.\n- Show an inline error message or helper text below the input as appropriate.\n- Support i18n for labels (hour, minute, second, AM, PM, clear, confirm, placeholder) in English and Portuguese.\n- Dispatch \"focus\" and \"blur\" custom events on input focus and blur.\n- Synchronize internal selection state when the value property changes externally.\n\n# Constraints\n- The panel must not open when disabled, readonly, loading, or isEditing is false.\n- Hour, minute, and second options outside the min/max time range must be rendered as disabled and must not be selectable.\n- The confirm button must be inactive until all required stages (hour, minute, and second if show-seconds is true) have a selection.\n- The panel input is always readonly; the user cannot type a time directly.\n- AM/PM conversion must correctly map 12-hour display values to 24-hour storage values (12 AM = 00:xx, 12 PM = 12:xx).\n- The value is always stored in 24-hour HH:MM or HH:MM:SS format regardless of the display mode.";
}
declare module "_102040_/l2/molecules/groupentertime/ml-clock-time-picker" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ClockTimePickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private stage;
        private selectedHour;
        private selectedMinute;
        private selectedSecond;
        private amPm;
        handleIcaStateChange(key: string, value: any): void;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private onToggleOpen;
        private onOutsideClick;
        private onInputFocus;
        private onInputBlur;
        private onSelectHour;
        private onSelectMinute;
        private onSelectSecond;
        private onConfirm;
        private onClear;
        private onToggleAmPm;
        private canInteract;
        private syncSelectionFromValue;
        private parseTime;
        private formatTime;
        private buildValueString;
        private isSelectionComplete;
        private convertTo24Hour;
        private convertTo12Hour;
        private attachOutsideClick;
        private detachOutsideClick;
        private isHourDisabled;
        private isMinuteDisabled;
        private isSecondDisabled;
        private getHourOptions;
        private getMinuteOptions;
        private getSecondOptions;
        private getInputClasses;
        private getOptionClasses;
        private getPanelClasses;
        private getLabelClasses;
        private getStepLabel;
        private renderLabel;
        private renderHelperOrError;
        private renderClockOptions;
        private renderAmPm;
        private getLabelId;
        private getHelperId;
        private getErrorId;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertime/ml-enter-time-duration.defs" {
    export const group = "groupEnterTime";
    export const skill = "# Metadata\n- TagName: groupentertime--ml-enter-time-duration\n\n# Objective\nEnable entry and display of time duration in hours and minutes, optionally including seconds, ensuring values conform to valid ranges, boundary limits, and formatting rules. It communicates all changes exclusively through a standardized string-based value contract.\n\n# Responsibilities\n- Accept and retain a time value as a formatted string or null when no value is present.\n- Automatically format user entries to preserve the correct time structure during editing.\n- Validate each time unit independently, permitting hours from 00 to 23, minutes from 00 to 59, and seconds from 00 to 59 when enabled.\n- Enforce minimum and maximum time boundaries, preventing confirmation or retention of values outside the permitted range.\n- Allow incremental adjustment of individual time units during editing, respecting the configured step interval for minutes.\n- Present the value as static text when editing is inactive, showing a formatted representation or a clear empty indicator.\n- Communicate confirmed changes using only a payload containing the formatted time string or null.\n- Signal when the element becomes active and when it becomes inactive.\n- Indicate an invalid state and display the associated message when an error condition exists; otherwise, present auxiliary guidance when available.\n- Display a label when label content is provided.\n- Prevent modification and interaction when disabled or restricted to read-only.\n- Indicate when data is being loaded.\n\n# Constraints\n- Must not emit any payload containing total seconds, numeric timestamps, or unformatted values.\n- Must not permit values that exceed unit limits or violate configured boundaries.\n- Must completely omit the seconds unit when seconds are disabled, and must not store or communicate values containing seconds in that configuration.\n- Must not allow incremental adjustment of time units when editing is inactive, disabled, or restricted.\n- Must not present editing affordances, guidance text, or error messages when in non-editing display mode.\n- Must suppress change communication when in non-editing display mode.\n- Minute values and adjustments must align with the configured step; unsupported intermediate values must be rejected or normalized.\n\n# Notes\n- The empty state must be immediately recognizable and distinct from a zero value.\n- Error messages take precedence over auxiliary guidance text.\n- Time values must follow 24-hour conventions.";
}
declare module "_102040_/l2/molecules/groupentertime/ml-enter-time-duration" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class EnterTimeDurationMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private rawValue;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private handleFocus;
        private handleBlur;
        private handleInput;
        private handleKeyDown;
        private commitValue;
        private dispatchChange;
        private formatStoredValue;
        private parseTime;
        private normalizeTime;
        private formatTime;
        private timeToSeconds;
        private isWithinRange;
        private getDisplayValue;
        private getInputClasses;
        private renderLabel;
        private renderFeedback;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertime/ml-time-scroll-picker.defs" {
    export const group = "groupEnterTime";
    export const skill = "# Metadata\n- TagName: groupentertime--ml-time-scroll-picker\n\n# Objective\nAllow the user to pick a time of day by scrolling through independent columns \u2014 one for hours, one for minutes, optionally one for seconds, and optionally one for AM/PM \u2014 displayed in a dropdown panel that opens below a read-only text input. Confirming the selection stores the time in HH:MM or HH:MM:SS format. The component supports 12-hour and 24-hour modes, a configurable minute step, min/max time bounds, keyboard Escape to dismiss, and disabled, readonly, error, loading, and view-only states.\n\n# Responsibilities\n- Display a read-only text input showing the currently selected time formatted with Intl.DateTimeFormat, or a configurable placeholder when no time is selected.\n- Open a picker panel containing scrollable columns when the input or clock-icon button is clicked, provided the component can interact.\n- Render an hour column (1\u201312 in 12-hour mode, 0\u201323 in 24-hour mode), a minute column (respecting the minuteStep interval), an optional seconds column (0\u201359), and an optional AM/PM column when hour12 is enabled.\n- Disable individual column items that would produce a time outside the minTime\u2013maxTime range when combined with the currently selected values.\n- Allow the user to independently scroll and select any value in each column without a forced step-by-step progression.\n- Provide a Confirm button that commits the selection, dispatches a \"change\" event with the formatted value, and closes the panel; the button is disabled when the selected combination is outside the allowed range.\n- Provide a Clear button that sets value to null, dispatches a \"change\" event with null, and closes the panel.\n- Close the panel when a click is detected outside the component or when the Escape key is pressed.\n- Render a view mode (isEditing = false) showing the label and formatted time as plain text.\n- Show a loading indicator text when the loading state is active.\n- Show an inline error message or helper text below the input as appropriate.\n- Support i18n for labels (confirm, clear, placeholder, loading) in English and Portuguese.\n- Dispatch \"focus\" and \"blur\" custom events on input focus and blur.\n- Synchronize internal column selection state when the value, hour12, or show-seconds properties change externally.\n\n# Constraints\n- The panel must not open when disabled, readonly, loading, or isEditing is false.\n- The Confirm button must be disabled when the currently selected time combination falls outside the minTime\u2013maxTime range.\n- The panel input is always readonly; the user cannot type a time directly.\n- AM/PM conversion must correctly map 12-hour display values to 24-hour storage values.\n- Individual column items outside the allowed time range must be rendered as disabled and must reject click events.\n- The panel must close on outside click and on Escape key, without committing unsaved changes.\n- The value is always stored in 24-hour HH:MM or HH:MM:SS format regardless of the display mode.";
}
declare module "_102040_/l2/molecules/groupentertime/ml-time-scroll-picker" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlTimeScrollPickerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private selectedHour;
        private selectedMinute;
        private selectedSecond;
        private selectedPeriod;
        private componentId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string): void;
        private handleToggleOpen;
        private handleOutsideClick;
        private handleFocus;
        private handleBlur;
        private handleConfirm;
        private handleClear;
        private handleHourSelect;
        private handleMinuteSelect;
        private handleSecondSelect;
        private handlePeriodSelect;
        private handleKeyDown;
        private syncFromValue;
        private parseTimeValue;
        private formatValueFromSelection;
        private formatDisplay;
        private to12Hour;
        private to24Hour;
        private getMinSeconds;
        private getMaxSeconds;
        private isTimeAllowed;
        private isSelectedTimeValid;
        private getMinutesList;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private renderInput;
        private renderClockIcon;
        private renderPicker;
        private renderHourColumn;
        private renderMinuteColumn;
        private renderSecondColumn;
        private renderPeriodColumn;
        private isPeriodAllowed;
        private getInputClasses;
        private getIconButtonClasses;
        private getItemClasses;
        private getActionButtonClasses;
        private getPrimaryButtonClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertimeinterval/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-slider';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-work-shift-interval';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-range';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-enter-time-interval';
    export class GroupEnterTimeIntervalIndex extends StateLitElement {
        private card1Value;
        private card2Value;
        private card3Value;
        private card4Value;
        private card5Value;
        private card6Value;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-enter-time-interval.defs" {
    export const group = "groupEnterTimeInterval";
    export const skill = "# Metadata\n- TagName: groupentertimeinterval--ml-enter-time-interval\n\n# Objective\nDefinir e apresentar um intervalo de hor\u00E1rio individual, com hora de in\u00EDcio e hora de fim, permitindo altern\u00E2ncia entre edi\u00E7\u00E3o e visualiza\u00E7\u00E3o, aplicando valida\u00E7\u00F5es e refletindo estados de intera\u00E7\u00E3o conforme o contrato do grupo.\n\n# Responsibilities\n- Apresentar um par de hor\u00E1rios no formato 24 horas, com op\u00E7\u00E3o de incluir segundos\n- Disponibilizar campos para edi\u00E7\u00E3o do hor\u00E1rio de in\u00EDcio e do hor\u00E1rio de fim quando em modo de edi\u00E7\u00E3o\n- Exibir apenas o texto formatado do intervalo quando em modo de visualiza\u00E7\u00E3o, sem campos edit\u00E1veis, mensagens de erro ou conte\u00FAdo auxiliar\n- Identificar e sinalizar intervalos que ultrapassem a meia-noite quando essa op\u00E7\u00E3o estiver habilitada\n- Notificar quando o intervalo completo for confirmado, quando cada hor\u00E1rio for modificado individualmente, e quando os campos receberem ou perderem foco\n- Aplicar restri\u00E7\u00F5es de sele\u00E7\u00E3o baseadas em limites de hor\u00E1rio, passo de minutos, dura\u00E7\u00E3o m\u00EDnima e m\u00E1xima, permiss\u00E3o de hor\u00E1rios id\u00EAnticos e permiss\u00E3o de intervalo overnight\n- Exibir mensagem de erro quando fornecida, ou apresentar conte\u00FAdo auxiliar quando dispon\u00EDvel e n\u00E3o houver erro\n- Responder ao estado de carregamento impedindo intera\u00E7\u00F5es e exibindo indicador visual apropriado\n- Responder ao estado desabilitado impedindo intera\u00E7\u00F5es em ambos os campos e aplicando apar\u00EAncia de inatividade\n- Responder ao estado somente leitura impedindo altera\u00E7\u00F5es enquanto mant\u00E9m o texto leg\u00EDvel e selecion\u00E1vel\n- Permitir a associa\u00E7\u00E3o de r\u00F3tulos distintos para o campo geral, para o hor\u00E1rio de in\u00EDcio e para o hor\u00E1rio de fim, fornecidos externamente\n- Diferenciar visualmente qual campo de hor\u00E1rio est\u00E1 ativo no momento\n- Diferenciar visualmente quando ambos os hor\u00E1rios estiverem definidos\n\n# Constraints\n- Em modo de visualiza\u00E7\u00E3o, o layout deve conter apenas o intervalo formatado, ocultando qualquer elemento de entrada ou suporte\n- O indicador de pr\u00F3ximo dia deve ser exibido somente quando o intervalo overnight estiver permitido e o hor\u00E1rio de fim for anterior ao de in\u00EDcio\n- Quando ambos os hor\u00E1rios estiverem ausentes, a apresenta\u00E7\u00E3o deve seguir o padr\u00E3o definido pelo contrato do grupo\n- A mensagem de erro tem prioridade sobre o conte\u00FAdo auxiliar; o conte\u00FAdo auxiliar s\u00F3 deve aparecer na aus\u00EAncia de erro\n- As regras de valida\u00E7\u00E3o devem restringir as sele\u00E7\u00F5es inv\u00E1lidas antes da confirma\u00E7\u00E3o do intervalo\n- A dura\u00E7\u00E3o entre in\u00EDcio e fim deve respeitar os limites m\u00EDnimo e m\u00E1ximo estabelecidos, quando definidos\n- O formato de exibi\u00E7\u00E3o deve manter consist\u00EAncia com o padr\u00E3o 24 horas e incluir segundos apenas quando configurado para tal\n- Cada ocorr\u00EAncia deste elemento gerencia exclusivamente um \u00FAnico par de hor\u00E1rios; o agrupamento de m\u00FAltiplos intervalos deve ser tratado externamente\n\n# Notes\n- O texto descritivo de recorr\u00EAncia, incluindo dias da semana, deve ser fornecido externamente atrav\u00E9s do r\u00F3tulo geral, n\u00E3o sendo gerado internamente\n- A composi\u00E7\u00E3o de m\u00FAltiplos intervalos de hor\u00E1rio deve ser tratada externamente, agrupando v\u00E1rias ocorr\u00EAncias deste elemento conforme necess\u00E1rio";
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-enter-time-interval" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class EnterTimeIntervalMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private handleStartInput;
        private handleEndInput;
        private emitCombinedChangeIfValid;
        private handleFocus;
        private handleBlur;
        private isIntervalValid;
        private isWithinBounds;
        private toMinutes;
        private isOvernightInterval;
        private formatTimeDisplay;
        private getDisplayRange;
        private getContainerClasses;
        private getInputClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-range.defs" {
    export const group = "groupEnterTimeInterval";
    export const skill = "# Metadata\n- TagName: groupentertimeinterval--ml-time-interval-range\n\n# Objective\nEnable users to define a time interval by providing a start time and an end time, ensure the interval is logically valid, display the resulting duration in minutes, and report the interval to the system according to the groupEnterTimeInterval specification.\n\n# Responsibilities\n- Present two adjacent time fields labeled \"In\u00EDcio\" and \"Fim\"\n- Receive time values in 24-hour format without seconds\n- Restrict minute selection to increments defined by a configurable step\n- Validate that the end time is later than the start time when same-time and overnight intervals are disallowed\n- Show a clear visual error state when the selected end time does not come after the start time\n- Calculate and visibly present the duration in minutes between the start and end times\n- Report to the system when the start value changes, when the end value changes, and when the complete interval is confirmed or modified\n- Visually reflect active, complete, disabled, read-only, loading, and required states\n- In view mode, display the formatted time range as static text without controls, guidance text, or error messaging\n\n# Constraints\n- Duration calculation must assume the same calendar day unless overnight intervals are explicitly permitted\n- The duration must be shown to the user but must not be included in interval reports to the system\n- When an error is present, helper text must be hidden and the error indication must be shown\n- Overnight intervals must display a \"+1\" day indicator in view mode only when overnight intervals are enabled\n- Read-only and disabled states must prevent modification of the time values\n- The required state must ensure both start and end values are provided\n- All visual states must support dark mode appearance\n\n# Notes\n- The visual duration readout must update immediately whenever either time value changes\n- Error validation must apply to the interval as a whole rather than individual fields alone";
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-range" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class TimeIntervalRangeMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private uid;
        private handleStartInput;
        private handleEndInput;
        private handleFocus;
        private handleBlur;
        private toMinutes;
        private calcDurationMinutes;
        private isOvernight;
        private hasRangeError;
        private hasDurationLimitError;
        private hasRequiredError;
        private getValidationError;
        private formatTimeDisplay;
        private getInputClasses;
        private getWrapperClasses;
        render(): any;
        private renderMainLabel;
        private renderLabelStart;
        private renderLabelEnd;
        private renderViewMode;
    }
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector.defs" {
    export const group = "groupEnterTimeInterval";
    export const skill = "# Metadata\n- TagName: groupentertimeinterval--ml-time-interval-selector\n\n# Objective\nAllow the user to define a time interval by selecting both a start time and an end time through dropdown pickers with select-based hour, minute, optional second, and optional AM/PM fields. After the start time is confirmed the picker automatically advances to the end time. The component validates interval constraints (min/max duration, overnight spans, same-time rules) and stores both times independently as HH:MM or HH:MM:SS strings.\n\n# Responsibilities\n- Render two clickable time buttons side by side \u2014 one for the start time and one for the end time \u2014 each showing the currently selected time formatted with Intl.DateTimeFormat or a placeholder when unset.\n- Open a select-based picker panel below the buttons when a field is clicked, provided the component can interact.\n- Populate the picker with a <select> for hour (12 or 24-hour mode), minute (respecting minuteStep), optional second, and optional AM/PM.\n- Pre-fill the picker with the field's current time when it has a value, or with the minimum allowed time when it does not.\n- Validate the tentative time against minTime, maxTime, minDurationMinutes, maxDurationMinutes, allowOvernight, and allowSameTime before allowing confirmation; disable the confirm button when invalid.\n- On start-time confirmation: store the start time, dispatch a \"startChange\" event, then automatically open the end-time picker if no end time is set, or close and dispatch \"change\" if the end time is already set.\n- On end-time confirmation: store the end time, dispatch \"endChange\" and \"change\" events, and close the picker.\n- Allow clearing the currently active field's time independently, dispatching the corresponding \"startChange\" or \"endChange\" event.\n- Display a \"(+1)\" overnight badge on the end-time button when allowOvernight is true and the end time is earlier than the start time.\n- Render a view mode (isEditing = false) showing the label and a formatted \"start \u2013 end\" range string, including the overnight suffix when applicable.\n- Show an inline error message or helper text below the buttons as appropriate.\n- Support i18n for labels (confirm, clear, placeholders, loading, nextDay) in English and Portuguese.\n- Dispatch \"focus\" and \"blur\" custom events when a field is opened or closed.\n\n# Constraints\n- All interaction must be blocked when disabled, readonly, or loading.\n- The end time must be strictly after the start time unless allowOvernight or allowSameTime is explicitly enabled.\n- Duration between start and end must satisfy minDurationMinutes and maxDurationMinutes when those are greater than zero.\n- Each time must fall within the minTime\u2013maxTime bounds.\n- The confirm button must remain disabled while the current selection violates any constraint.\n- The component must not implement a visual clock face or scrollable column picker; it uses <select> elements only.\n- Start and end times are stored as separate properties (startTime, endTime) and dispatched via separate events; a combined \"change\" event is also dispatched only when both times are set.";
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlTimeIntervalSelectorMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private tempHour;
        private tempMinute;
        private tempSecond;
        private tempAmPm;
        handleIcaStateChange(key: string, value: any): void;
        private handleOpen;
        private handleClose;
        private handleConfirm;
        private handleClear;
        private handleHourChange;
        private handleMinuteChange;
        private handleSecondChange;
        private handleAmPmChange;
        private parseTime;
        private formatToStorage;
        private formatForDisplay;
        private initTempFromTime;
        private toHour12;
        private toHour24;
        private getTimeFromTemp;
        private toSeconds;
        private isTimeWithinLimits;
        private isOvernight;
        private calcDurationMinutes;
        private isEndTimeValid;
        private isTimeValidForField;
        private getRangeDisplay;
        private getInputClasses;
        private getPickerClasses;
        private getSelectClasses;
        render(): TemplateResult;
        private renderViewMode;
        private renderEditMode;
        private renderPicker;
        private renderHourOptions;
        private renderMinuteOptions;
        private renderSecondOptions;
        private renderFeedback;
        private renderClockIcon;
    }
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-slider.defs" {
    export const group = "groupEnterTimeInterval";
    export const skill = "# Metadata\n- TagName: groupentertimeinterval--ml-time-interval-slider\n\n# Objective\nAllow the user to define a time interval by dragging two overlapping range sliders \u2014 one for the start time and one for the end time \u2014 over a shared track. The selected segment is highlighted on the track. Both times are displayed as formatted labels above the sliders and validated against min/max time bounds, duration constraints, overnight rules, and same-time rules before being committed.\n\n# Responsibilities\n- Render two stacked <input type=\"range\"> elements sharing the same track, one controlling the start time and one controlling the end time.\n- Convert the raw slider value (seconds since midnight) to a formatted time string using Intl.DateTimeFormat for display.\n- Show a highlighted segment on the track between the start and end positions; in overnight mode, render two segments (start-to-midnight and midnight-to-end).\n- Display formatted start and end times in labeled boxes above the slider track, updating in real time as the thumb is dragged (draft mode).\n- Commit the start or end time only when the slider's change event fires and the new value passes all validation rules; revert the draft on invalid change.\n- Validate each committed value against minTime, maxTime, allowOvernight, allowSameTime, minDurationMinutes, and maxDurationMinutes.\n- Dispatch a \"startChange\" event when the start time is committed; dispatch an \"endChange\" event when the end time is committed; dispatch a combined \"change\" event when both times are set.\n- Display a \"(+1)\" overnight label on the end-time box when allowOvernight is true and the end time is before the start time.\n- Respect the minuteStep property as the slider step (converted to seconds); use 1-second steps when show-seconds is enabled.\n- Clamp slider min/max to the minTime\u2013maxTime bounds (defaulting to 00:00\u201323:59:59).\n- Render a view mode (isEditing = false) showing the label and a formatted \"start \u2013 end\" range string, including the overnight suffix when applicable.\n- Show an inline error message or helper text below the track as appropriate.\n- Support i18n for fallback labels (Start, End, loading, nextDay) in English and Portuguese.\n- Dispatch \"focus\" and \"blur\" custom events when a slider thumb gains or loses focus.\n\n# Constraints\n- All slider interaction must be blocked when disabled, loading, or isEditing is false; readonly permits visual display but blocks dragging.\n- An invalid slider change (violating any duration, overnight, same-time, or bounds constraint) must be silently rejected and the draft cleared; the committed value must not change.\n- The slider step must be at least 1 second and must respect minuteStep when show-seconds is false.\n- The component must not render a clock face, dropdown panel, or select-based picker; time entry is through range sliders only.\n- The overnight highlight must only appear when allowOvernight is explicitly true.\n- Start and end times are stored as separate properties (startTime, endTime) and the combined \"change\" event fires only when both are non-null.";
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-slider" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class TimeIntervalSliderMolecule extends MoleculeAuraElement {
        private msg;
        private baseId;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private draftStartSeconds;
        private draftEndSeconds;
        handleIcaStateChange(key: string, value: any): void;
        updated(changed: Map<string, unknown>): void;
        private syncDraftFromValues;
        private handleFocus;
        private handleBlur;
        private handleStartInput;
        private handleEndInput;
        private handleStartChange;
        private handleEndChange;
        private canInteract;
        private toSeconds;
        private secondsToTime;
        private formatDisplay;
        private getMinMaxSeconds;
        private getStepSeconds;
        private getCurrentStartSeconds;
        private getCurrentEndSeconds;
        private isOvernight;
        private durationMinutes;
        private isValidInterval;
        private isValidStart;
        private isValidEnd;
        private getTrackSegmentStyles;
        private getContainerClasses;
        private getInputBoxClasses;
        private getRangeClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval.defs" {
    export const group = "groupEnterTimeInterval";
    export const skill = "# Metadata\n- TagName: groupentertimeinterval--ml-time-interval\n\n# Objective\nA molecule that allows a user to view and edit a single time interval within a day, with support for 12-hour and 24-hour formats, optional seconds, overnight intervals, and various validation and visual states. It represents exactly one interval; multiple intervals in the same day are managed by orchestrating multiple instances.\n\n# Responsibilities\n- Display a single time interval composed of a start time and an end time\n- In editing mode, present fields for start and end times in a single row, separated by a visual delimiter, with associated labels for each\n- In viewing mode, display only the formatted interval text without editable controls, helper text, error messages, or time selectors\n- Accept and display a general label above the field group when provided\n- Display helper content only when no error is present and editing is active\n- Format displayed times according to 12-hour (AM/PM) or 24-hour preferences, and include seconds when configured\n- Indicate visually when the start time selector is open and when the end time selector is open\n- Apply a distinct visual state when both start and end times are filled\n- Show an overnight indicator alongside the end time when the interval crosses midnight and overnight intervals are permitted\n- Show a placeholder em dash when both times are null in viewing mode, and show the start time followed by a placeholder when only the start time is set\n- Respect minimum and maximum time boundaries, minute step increments, minimum and maximum duration limits, overnight allowance, and same-time allowance to permit or reject selections\n- Signal when the start time is modified\n- Signal when the end time is modified\n- Signal when both start and end times are confirmed together\n- Signal when the component receives focus and when it loses focus\n- Present a loading state that blocks interaction and indicates activity\n- Present a disabled state that blocks interaction and prevents value changes\n- Present a readonly state that prevents editing while allowing text selection\n- Treat both start and end times as mandatory when required\n- Enter an error state and display the provided error message when an error is supplied\n- Adapt visual presentation for dark mode environments\n\n# Constraints\n- Must not display input fields, selectors, helper text, error messages, or signal changes when not in editing mode\n- Time values must be handled in 24-hour format, with display formatting applied according to user preferences\n- Must display the overnight indicator only when overnight intervals are allowed and the end time is earlier than the start time\n- Must suppress helper content whenever an error message is present\n- Must not manage a collection of intervals or validate overlap between multiple intervals; overlap handling belongs to the consumer\n- Must block all user actions when disabled or loading\n- Must prevent value changes when disabled\n- Must allow text selection but disable editing controls in readonly mode\n- Must apply error styling and show the error message when an error is provided\n\n# Notes\n- This component manages exactly one time interval; supporting multiple intervals in a single day requires using multiple instances managed externally\n- The consumer is responsible for calculating total daily hours and supplying that information as helper content if desired\n- Validation of overlapping intervals across multiple instances is explicitly outside the scope of this component";
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-time-interval" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlTimeIntervalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private startHour;
        private startMinute;
        private startSecond;
        private startPeriod;
        private endHour;
        private endMinute;
        private endSecond;
        private endPeriod;
        firstUpdated(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private syncFromStartTime;
        private syncFromEndTime;
        private parseTime;
        private toMinutes;
        private formatTime24;
        private formatTimeDisplay;
        private isOvernight;
        private calcDuration;
        private convert12To24;
        private isTimeDisabled;
        private handleDocumentClick;
        private handleFieldClick;
        private handleHourSelect;
        private handleMinuteSelect;
        private handleSecondSelect;
        private handlePeriodSelect;
        private updateStartTime;
        private updateEndTime;
        private emitChangeIfComplete;
        private handleBlur;
        private getContainerClasses;
        private getFieldClasses;
        private getPickerClasses;
        private getColumnClasses;
        private getOptionClasses;
        render(): TemplateResult;
        private renderLoading;
        private renderViewMode;
        private renderEditMode;
        private renderPicker;
        private renderFeedback;
    }
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-work-shift-interval.defs" {
    export const group = "groupEnterTimeInterval";
    export const skill = "# Metadata\n- TagName: groupentertimeinterval--ml-work-shift-interval\n\n# Objective\nEnable users to define a single work shift interval with a start time and an end time. The component supports overnight shifts, enforces time constraints, communicates changes to the system, and clearly indicates its current state.\n\n# Responsibilities\n- Represent a single work shift interval defined by a start time and an end time.\n- Enable users to provide a start time and an end time through direct input or selection controls.\n- Support overnight intervals that extend into the following day when enabled.\n- Notify the system when a complete interval has been defined or confirmed.\n- Notify the system whenever the start time or end time is modified.\n- Notify the system when the component gains or loses focus.\n- Restrict selectable and enterable times based on configured minimum and maximum bounds, step increments, duration limits, and whether identical start and end times are allowed.\n- Indicate when data is loading by blocking interaction and displaying a loading indicator.\n- Block all user interaction when disabled.\n- Prevent modification while allowing text selection when in a read-only state.\n- Require both the start and end times to be provided when marked as mandatory.\n- Display error indicators and messages when the interval is invalid or an error condition is present.\n- In display mode, present only the formatted interval text without controls or auxiliary information.\n- Display preset descriptions as auxiliary text only; selecting a preset must be handled outside the component.\n- Manage exactly one time interval; supporting multiple shifts simultaneously must be handled by external orchestration.\n- Display an overall label describing the interval when provided.\n- Display separate labels for the start and end fields when provided.\n- Present the start and end fields as a unified group.\n- Indicate which field is currently being edited.\n- Indicate when both start and end times have been provided.\n- Identify overnight intervals with an indicator showing the end time occurs on the following day.\n- Format displayed times according to the system convention and indicate missing values with a placeholder.\n- Display auxiliary text when no error exists, and replace it with error text when validation fails.\n- Adapt colors and contrast for dark mode environments.\n\n# Constraints\n- Must block interaction while loading or disabled.\n- Must not present input controls or auxiliary text in display mode.\n- Must require both times when mandatory; partial intervals are not acceptable.\n- Must not perform preset selection internally.\n- Must manage only one interval at a time.\n- Must communicate error states accessibly.\n- Must represent times in 24-hour format and support optional seconds precision.\n- Must only permit overnight intervals when explicitly enabled.\n\n# Notes\n- Preset selection and multiple shift management are handled by parent components.\n- Auxiliary text may describe available presets, but does not trigger selection.";
}
declare module "_102040_/l2/molecules/groupentertimeinterval/ml-work-shift-interval" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class WorkShiftIntervalMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        startTime: string | null;
        endTime: string | null;
        error: string;
        name: string;
        locale: string;
        hour12: boolean;
        showSeconds: boolean;
        minuteStep: number;
        minTime: string;
        maxTime: string;
        minDurationMinutes: number;
        maxDurationMinutes: number;
        allowOvernight: boolean;
        allowSameTime: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private activeField;
        private handleStartInput;
        private handleEndInput;
        private handleFocus;
        private handleBlur;
        private dispatchChangeIfComplete;
        private normalizeValueForInput;
        private normalizeValueForStorage;
        private parseToSeconds;
        private formatFromSeconds;
        private formatDisplay;
        private isOvernightInterval;
        private getInputStep;
        private getEndConstraints;
        private maxTimeValue;
        private minTimeValue;
        private getWrapperClasses;
        private getInputClasses;
        private getIndicatorClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupexpandcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay';
    export class GroupExpandContentIndex extends StateLitElement {
        private cardAccordion;
        private cardReadmore;
        private cardSingle;
        private cardPanel;
        private cardOverlay;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-accordion.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-accordion\n\n# Objective\nAllow the user to expand and collapse individually labeled content sections arranged vertically. The component can operate in single-expand mode (only one section open at a time) or multi-expand mode (any number of sections open simultaneously), and supports disabled, loading, and per-section disabled states with full keyboard navigation.\n\n# Responsibilities\n- Render each Section slot as a collapsible panel with a clickable header showing its title attribute.\n- Track which sections are open and toggle them when their header is clicked or activated via keyboard.\n- In single-expand mode, close any currently open section before opening a new one.\n- In multi-expand mode, allow any number of sections to be open simultaneously.\n- Initialize open sections from the expanded attribute present on Section elements at first render.\n- Dispatch a toggle custom event (bubbling, composed) with index, title, and expanded when a section is toggled.\n- Allow moving keyboard focus between section headers using ArrowDown and ArrowUp keys, skipping disabled headers.\n- Activate a focused header with Enter or Space.\n- Render an optional Label slot above the accordion panels.\n- Display a loading skeleton with an animated pulse when the loading property is true.\n- Show an empty-state message when no Section slots are provided.\n- Apply disabled styling and block interaction on individual sections that carry the disabled attribute.\n- Block all interaction when the component-level disabled or loading property is true.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- A section must not open or close while the component-level disabled or loading state is active.\n- A per-section disabled header must receive tabindex=\"-1\" and must not be reachable or togglable.\n- In single-expand mode, at most one section may be open at any time.\n- Keyboard navigation must skip disabled headers and wrap around the list.\n- The component must not contain business logic; it only manages visual expand/collapse state.\n- Section content is rendered via unsafeHTML from the Section slot's inner template or innerHTML and must not be sanitized by this component.";
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-accordion" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlAccordionMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private findNextEnabledHeader;
        private getSectionContent;
        private getHeaderClasses;
        private getContentClasses;
        private getChevronClasses;
        render(): any;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private renderSection;
    }
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-collapsible-panel\n\n# Objective\nProvide an expandable and collapsible panel interface that allows users to reveal or hide content by interacting with section headers. Supports multiple independent sections, optional subtitles, icons, and controlled expansion behavior.\n\n# Responsibilities\n- Render multiple independent collapsible sections when provided.\n- Each section header must be clickable to toggle its expanded or collapsed state.\n- Display an optional label as a component title above the sections.\n- Display a left-aligned icon and optional subtitle within each section header.\n- Indicate expanded state through a right-aligned chevron that changes orientation.\n- Animate the expansion and collapse of section content smoothly.\n- Support an initial expanded state for individual sections.\n- Support a mode where only one section may be expanded at a time.\n- Support a mode where multiple sections may be expanded simultaneously.\n- Emit events when a section is opened or closed, including the section index, title, and current state.\n- Support keyboard navigation between headers and toggling via Enter and Space.\n- Render a loading placeholder when content is not yet ready, preventing section interaction.\n- Visually indicate when the entire component or individual sections are disabled and prevent interaction.\n\n# Constraints\n- Section headers must not be interactive while the component is in a loading state.\n- Disabled sections must not respond to click or keyboard interactions.\n- When configured for single expansion, expanding one section must collapse any other expanded section.\n- Section content must remain hidden when collapsed and visible when expanded.\n- The loading state must suppress all section interactions and display placeholder content instead.\n- Keyboard navigation must cycle through headers without activating them unless explicitly triggered.\n- Multiple instances must maintain independent expansion states without interfering with each other.\n- Visual states must respect semantic color pairing rules including dark mode variants.\n\n# Notes\n- The subtitle is only rendered when explicitly provided for a section.\n- Events are dispatched for both open and close actions under a unified toggle contract.";
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlCollapsiblePanelMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleHeaderClick;
        private handleHeaderKeydown;
        private focusAdjacentHeader;
        render(): any;
        private renderLabel;
        private renderLoading;
        private renderSections;
        private getSectionContent;
        private getHeaderClasses;
        private getChevronClasses;
        private getContentClasses;
    }
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-readmore-expand\n\n# Objective\nDisplays content sections that users can expand to view fully or collapse to hide. Supports both accordion-style single expansion and multiple simultaneous expansions. Provides clear visual states and accessibility for interactive content disclosure.\n\n# Responsibilities\n- Render content sections with an interactive trigger and an expandable content area\n- Expand a section to reveal its full content when the user activates its trigger\n- Collapse an expanded section to hide its content when the user activates its trigger again\n- Support a configuration where expanding one section automatically collapses any other open section\n- Support a configuration where multiple sections may remain expanded at the same time\n- Initialize sections in their designated expanded or collapsed state when first displayed\n- Ignore all expansion interactions when the entire component is disabled\n- Ignore expansion interactions only for sections individually marked as disabled\n- Announce when a section changes state by providing the section identifier and whether it is now expanded or collapsed\n- Display an optional text label above the group of sections\n- Show a loading indicator and suppress section content while loading data\n- Allow users to navigate between section triggers using directional keys\n- Allow users to activate the focused section trigger using standard activation keys\n- Expose expanded state and disabled state to assistive technologies on each trigger\n- Associate each expandable content region with its corresponding trigger for assistive technologies\n\n# Constraints\n- Must not apply height restrictions, clipping, or fade gradients to simulate truncated content\n- Must not use custom text labels for expand or collapse actions beyond the standard section trigger\n- Must not emit state change notifications that lack the section identifier or expanded status\n- Must not allow disabled sections to change state through any interaction method\n- Must not allow any section to change state when the entire component is disabled\n- Must maintain visual distinction between expanded and collapsed sections\n- Must maintain visual distinction for disabled states at both component and section levels\n- Must ensure keyboard navigation cycles only through interactive triggers, skipping disabled ones appropriately\n\n# Notes\n- The trigger area acts as the primary control for revealing or hiding content\n- Visual design should support both light and dark presentation modes\n- Animation between expanded and collapsed states should provide clear visual feedback without impeding accessibility";
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlReadmoreExpandMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleKeyDown;
        private focusNextHeader;
        private getHeaderElements;
        private getSectionInfo;
        private getTriggerClasses;
        private getPanelClasses;
        private getPanelInnerClasses;
        private renderLabel;
        private renderLoading;
        private renderChevron;
        private renderSection;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-reveal-overlay\n\n# Objective\nConceal sensitive or surprise content behind a visual overlay until the user explicitly chooses to reveal it. Provide a configurable warning before disclosure, allow the user to toggle between hidden and visible states, and inform the system whenever the content is revealed or concealed.\n\n# Responsibilities\n- Display a configurable warning message above each revealable content block.\n- Keep sensitive content fully hidden behind a visual overlay until the user interacts with the reveal control.\n- Provide a central control over the overlay that offers to reveal the content when hidden and to hide it when shown.\n- Remove the overlay with a smooth visual transition when the user chooses to reveal the content.\n- Allow the user to restore the hidden state by activating the same control again.\n- Inform the system of any state change by identifying the affected section, its title, and whether it is now revealed or hidden.\n- Prevent toggling and system notifications when the molecule or a specific section is inactive.\n- Show a loading state instead of sections when content is not yet ready.\n- Support keeping multiple sections open at once or only one at a time, according to the group behavior contract.\n\n# Constraints\n- Must use only the predefined content areas of the group contract for the warning text and the sensitive content blocks; no additional content areas, controls, or notification mechanisms may be introduced.\n- The warning text must be provided through the designated warning content area.\n- Each sensitive content block must reside in its designated content area, and the central control label must come from the title associated with that area.\n- The control label must indicate the current action: offering to reveal when content is hidden and to hide when content is visible.\n- The overlay must completely obscure the underlying content while hidden, preventing any visual access to the information beneath.\n- The overlay must cover the full content area without disturbing the surrounding layout or flow.\n- When inactive, the entire block\u2014including overlay, control, and content\u2014must appear visually dimmed or disabled.\n- Colors for backgrounds, text, borders, and hover states must follow the semantic pairs defined for both standard and dark presentations.\n- The reveal and hide actions must remain reversible; the user must never be locked into a single state.\n\n# Notes\n- The overlay may employ blur or solid color treatments as long as the content remains unreadable prior to revelation.\n- Transitions between hidden and revealed states should be noticeable but not distracting.\n- All structural behavior, accessibility, and notification semantics are governed by the groupExpandContent contract.";
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class RevealOverlayMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        private openSections;
        firstUpdated(): void;
        private handleToggle;
        private handleHeaderKeydown;
        private renderLoading;
        private getHeaderClasses;
        private getContainerClasses;
        private getOverlayClasses;
        private getActionButtonClasses;
        private renderSectionContent;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content.defs" {
    export const group = "groupExpandContent";
    export const skill = "# Metadata\n- TagName: groupexpandcontent--ml-single-expand-content\n\n# Objective\nManage a single expandable section with a clickable header and collapsible body. It must display a title above the section when provided, open and close smoothly, report state changes, and prevent interaction when disabled or loading.\n\n# Responsibilities\n- Present exactly one Section slot; ignore any additional Section slots beyond the first.\n- Display the section header text from the mandatory title attribute of the Section slot.\n- Display the expandable body from the inner content of the Section slot.\n- Start in an expanded or collapsed state based on the expanded attribute of the Section slot.\n- Reflect the current expanded state through a dedicated property and allow external update.\n- Notify when the expanded state changes by emitting an event that includes the new state.\n- Prevent toggling when the component or the Section slot is marked as disabled.\n- Replace all section content with a loading placeholder and block all interaction while loading.\n- Display the Label slot, when present, as a title above the section without interfering with expansion.\n- Apply accordion behavior when multiple Section slots are provided and the multiple property is false.\n- Support configurable animation for expand and collapse transitions.\n- Make the header focusable and indicate its current expanded state to assistive technologies.\n- Associate the expandable body with its header for accessibility.\n- Allow toggling via Enter and Space keys, and navigate between headers with Arrow Up and Arrow Down when multiple sections are present.\n\n# Constraints\n- The Section slot must supply a title attribute to define the header text.\n- Only the first Section slot is effective; extras are disregarded.\n- Disabled state must visually attenuate the section and block toggling.\n- Loading state must hide actual content and show only a placeholder.\n- State change events must carry the exact expanded value and, for toggle events, include index and title.\n- Focus indicators must be visible when navigating by keyboard.\n- Colors and borders must support dark mode through semantic pairing.\n\n# Notes\n- The Label slot is purely presentational and does not trigger or prevent expansion.\n- Although optimized for one section, accidental provision of multiple Section slots is handled via the multiple property rule set.";
}
declare module "_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class SingleExpandContentMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        disabled: boolean;
        loading: boolean;
        expanded: boolean;
        private openSections;
        private parsedSections;
        private initialized;
        firstUpdated(): void;
        handleIcaStateChange(key: string, value: any): void;
        private parseSections;
        private initializeExpandedState;
        private handleToggle;
        private handleKeyDown;
        private getHeaderClasses;
        private getContentClasses;
        private getContentInnerClasses;
        private getChevronClasses;
        private renderChevron;
        private renderLabel;
        private renderLoadingPlaceholder;
        private renderSection;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/grouplocateposition/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/grouplocateposition/ml-address-autocomplete';
    import '/_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger';
    import '/_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker';
    import '/_102040_/l2/molecules/grouplocateposition/ml-locate-nearby';
    export class GroupLocatePositionIndex extends StateLitElement {
        private cardAddressAutocomplete;
        private cardGeolocationTrigger;
        private cardLocateMapPicker;
        private cardLocateNearby;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-address-autocomplete.defs" {
    export const group = "groupLocatePosition";
    export const skill = "# Metadata\n- TagName: grouplocateposition--ml-address-autocomplete\n\n# Objective\nAn address input field that suggests locations as the user types, allowing selection of a geographic position represented by coordinates. It relies on external sources to provide address suggestions and translates user selections into a definitive location value.\n\n# Responsibilities\n- Accept supplementary content such as labels, helper text, trigger controls, suggestion items, and empty state messages from external sources\n- Accept user text input and request external address suggestions after typing pauses\n- Present externally provided address suggestions, each associated with a geographic coordinate and a human-readable label\n- Update the selected value to the coordinate of the chosen address upon selection\n- Display the human-readable label of the selected address in the input field after selection\n- Clear the selected value and notify the system when the user removes all search text\n- Indicate when suggestions are being loaded and prevent selection during this period\n- Validate that a value is present when required and signal an error state if missing during editing\n- Display the selected address as static text when not in editing mode, showing the human-readable label when available or falling back to coordinates or an empty state\n- Offer a way to capture the current geographic position when enabled, updating the selected value accordingly\n- Signal when the field gains or loses focus\n- Respect disabled and read-only states by blocking edits and selections while maintaining coherent visual presentation\n- Display a map preview of the selected location when enabled and a valid position exists\n- Communicate all state changes and selections to the containing system\n\n# Constraints\n- Must not store or manage its own suggestion list; suggestions must come from external sources\n- Must only request suggestions after the user pauses typing, not continuously\n- Must close suggestions upon selection and show the selected address label\n- Must reset the value to empty and notify the system when search text is cleared\n- Must remain visually inactive and non-interactive during loading states\n- Must not display error states when in view mode\n- Must not request suggestions or allow editing when in view mode\n- Must not display a map preview when no valid position is selected\n- Must block all editing and selection interactions when disabled or read-only\n- Must expose its expanded state, selected option, invalid state, required status, and descriptive labels to assistive technologies\n- Must support both light and dark presentation modes\n\n# Notes\n- The geographic value is represented as a coordinate pair (latitude and longitude)\n- Address labels and coordinates are provided together for each suggestion\n- Corporate applications include delivery address entry, employee residential registration, logistics waypoint definition, prospect headquarters logging, and field service dispatch location selection";
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-address-autocomplete" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class AddressAutocompleteMolecule extends MoleculeAuraElement {
        private msg;
        private inputId;
        private labelId;
        private helperId;
        private errorId;
        private debounceTimer;
        private mutationObserver;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        showMap: boolean;
        allowGeolocation: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        firstUpdated(): void;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: any): void;
        private parseValue;
        private getSuggestions;
        private findLabelForValue;
        private syncSearchQueryFromValue;
        private emitChange;
        private emitSearch;
        private emitBlur;
        private emitFocus;
        private handleInput;
        private handleItemSelect;
        private handleInputFocus;
        private handleInputBlur;
        private handleGeoLocation;
        private getInputClasses;
        private getSuggestionPanelClasses;
        private getSuggestionItemClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderEmptyState;
        private renderSuggestionsPanel;
        private renderGeolocationButton;
        private renderMapPreview;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger.defs" {
    export const group = "groupLocatePosition";
    export const skill = "# Metadata\n- TagName: grouplocateposition--ml-geolocation-trigger\n\n# Objective\nCapture the device's current geographic position for the groupLocatePosition group. Provide a trigger control that requests a single position reading, presents the result as a coordinate pair, supports suggestion selection, and displays a map preview when configured. Operate in editing and viewing modes while respecting all group contract parameters.\n\n# Responsibilities\n- Render distinct regions for label, helper text, trigger action, suggestions list, individual suggestion items, and empty state messaging\n- Honor the group contract parameters: value, error, name, placeholder, showMap, allowGeolocation, isEditing, disabled, readonly, required, and loading\n- When geolocation is allowed and the molecule is in editing mode, activating the trigger requests the device's current geographic position\n- While awaiting a position reading, enter a loading state and block additional position requests\n- Upon successful capture, update the value to a comma-separated latitude and longitude pair and notify that the value changed, including the new coordinate pair\n- Upon successful capture, also notify a search request using the coordinate pair so the surrounding page can resolve and populate suggestions\n- If capture fails, exit the loading state, preserve the existing value, and notify the failure with a code and message\n- Perform only a single position request per activation; do not support continuous tracking\n- When disabled, prevent all user interactions including position requests and suggestion selection\n- When readonly, prevent editing while preserving the ability to select and read text\n- In view mode, display the resolved address or raw coordinates for the current value; do not show input controls, suggestion panels, or issue search requests\n- In view mode, if no value exists, display empty state content or a default placeholder indicator\n- Present suggestion items when available; each item must hold a coordinate value and be selectable\n- Selecting a suggestion item updates the value, notifies the change, closes the suggestions, and sets the search text to the selected item's label\n- When no suggestions are available, display empty state content or a default no-results message\n- When required and no value is set, display an error visual state until a location is chosen\n- Notify when the field receives and loses focus according to the group contract\n- Use the error state to display error messaging below the field; suppress error messaging in view mode\n\n# Constraints\n- The value must always be represented as a comma-separated latitude and longitude pair when set\n- Error messages must never appear in view mode\n- Helper text must be hidden when an error message is present\n- The suggestions panel must only appear when editing and actively open\n- Selected suggestion items must be visually distinguishable from unselected items\n- The loading state must visually disable the trigger and suggestion interactions\n- The error state must apply visual styling to the interactive field and show error text below it\n- Disabled state must reduce visual opacity and indicate non-interactive behavior\n- Readonly state must appear non-editable while maintaining readable text contrast\n- All visual colors must include dark mode variants using semantic pairings\n- If map display is enabled and a valid value exists, show a map preview with a location indicator in both edit and view modes\n\n# Notes\n- The trigger region supplies the primary action control and must contain any icon or label required by the use case\n- Intended for corporate scenarios including field service, logistics, mobile human resources, asset security, and delivery fleet management";
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlGeolocationTriggerMolecule extends MoleculeAuraElement {
        private static instanceCount;
        private msg;
        private baseId;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        showMap: boolean;
        allowGeolocation: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        private geoLoading;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private parseValue;
        private getSuggestions;
        private resolveLabelByValue;
        private htmlToText;
        private getInputClasses;
        private getItemClasses;
        private getPanelClasses;
        private getMapClasses;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleSelect;
        private handleGeolocation;
        private renderLabel;
        private renderHelperOrError;
        private renderTrigger;
        private renderSuggestions;
        private renderViewMode;
        private renderMapPreview;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker.defs" {
    export const group = "groupLocatePosition";
    export const skill = "# Metadata\n- TagName: grouplocateposition--ml-locate-map-picker\n\n# Objective\nA location selection interface that combines map visualization with search and geolocation capabilities. It enables users to identify, adjust, and confirm geographic coordinates either by searching for a place, dragging a map marker, or using their current position.\n\n# Responsibilities\n- Accept and maintain location value as a coordinate string or null\n- Display a search field with a suggestion panel when in editing mode\n- Show a map with a position marker when map display is enabled\n- Allow the marker to be dragged to update coordinates during active editing\n- Emit change events containing the coordinate value when selection occurs\n- Emit search events to request external address resolution when coordinates change\n- Provide a control to capture the user's current geographic position when allowed\n- Render selectable suggestion items with labels and coordinate values\n- Present an empty state when no suggestions are available\n- Display labels, helper text, and error messages according to the current state\n- Support a view-only mode that shows static location text and a non-interactive map\n- Indicate loading state and disable interactions during processing\n- Track and emit focus and blur events on the search field\n- Apply distinct visual treatments for disabled, readonly, error, and focused states\n\n# Constraints\n- Must reject or ignore JSON object formats for value, accepting only coordinate strings or null\n- Must prevent marker dragging when the component is readonly, disabled, or not in editing mode\n- Must close the suggestion panel immediately upon selecting an item\n- Must block all user interactions when disabled, including search, suggestions, geolocation, and map manipulation\n- Must suppress search event emissions and hide helper and error text in view mode\n- Must enter error state only when required is true and value is null\n- Must interpret labels, helpers, triggers, suggestions, items, and empty states strictly according to the group contract without introducing new elements or properties\n- Must support both light and dark presentation modes\n\n# Notes\n- Coordinate updates from map dragging should emit both change and search events to enable parent-level address lookup\n- The search event acts as a request for external address resolution rather than performing internal geocoding";
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class LocateMapPickerMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        showMap: boolean;
        allowGeolocation: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        private isFocused;
        private isDragging;
        handleIcaStateChange(key: string, _value: any): void;
        private parseValue;
        private getSuggestions;
        private getLabelForValue;
        private updateSearchQueryFromValue;
        private getEffectiveQuery;
        private isInteractionBlocked;
        private getInputClasses;
        private getPanelClasses;
        private getItemClasses;
        private getMapContainerClasses;
        private getMapMarkerStyle;
        private getErrorMessage;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleSelect;
        private handleGeolocation;
        private handleMapPointerDown;
        private handleMapPointerMove;
        private handleMapPointerUp;
        private updateValueFromPointer;
        private renderLabel;
        private renderHelperOrError;
        private renderSuggestions;
        private renderMap;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-locate-nearby.defs" {
    export const group = "groupLocatePosition";
    export const skill = "# Metadata\n- TagName: grouplocateposition--ml-locate-nearby\n\n# Objective\nAllow users to find and select nearby locations centered on a specific coordinate. The molecule supports searching for places, selecting from suggestions, viewing the selected location, and optionally using the device's geolocation to set the center point. It can also display a map preview of the selected coordinate.\n\n# Responsibilities\n- Accept a central coordinate value or no coordinate.\n- Offer a geolocation option when enabled, which obtains the user's current position and sets it as the central coordinate.\n- Display a search field during editing that lets users type to find nearby locations.\n- Show available nearby locations as selectable suggestions, each identified by a coordinate.\n- Update the selected value when the user clicks a suggestion.\n- Show an empty state when no suggestions are available.\n- During viewing, display the label of the selected location if it matches a known suggestion; otherwise show the raw coordinate or an empty state.\n- Hide the suggestions panel and disable search emission during viewing.\n- Block selection changes when disabled or readonly.\n- Show error messages and error styling during editing when an error exists; otherwise show helper text if provided.\n- Open and close the suggestions panel based on user focus and interaction during editing.\n- Show a map with a location pin when map display is enabled and a valid coordinate is selected.\n\n# Constraints\n- Must use the groupLocatePosition contract slots: Label, Helper, Trigger, Suggestions, Item, and Empty.\n- Must not accept nearby locations as a structured data array; locations must be provided as Item elements inside the Suggestions slot.\n- Must emit a change event when the central coordinate changes through geolocation or when a suggestion is selected.\n- Must emit a search event with the coordinate when geolocation succeeds, allowing the page to resolve location labels.\n- Must emit a search event only when the user types in the search field during editing.\n- Must not render the suggestions panel during view mode.\n- Must not emit change events from user interaction when disabled or readonly.\n- Sorting and filtering of suggestions must be handled externally by the order and presence of provided Item elements.\n- Must support the visual states defined by the contract: normal, focused, open, disabled, readonly, error, and loading.\n- Must provide dark mode variants for all colors including backgrounds, text, borders, focus indicators, and hover states.\n\n# Notes\n- The page is responsible for calculating distances, ordering results, and filtering categories by providing Item elements in the desired sequence.\n- The content of each suggestion, including name, address, distance, and category icon, is defined entirely by the page through the Item slot content.";
}
declare module "_102040_/l2/molecules/grouplocateposition/ml-locate-nearby" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class LocateNearbyMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        showMap: boolean;
        allowGeolocation: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        private geoLoading;
        private static idCount;
        private inputId;
        private labelId;
        private listboxId;
        private helperId;
        private errorId;
        private blurTimeout;
        handleIcaStateChange(key: string, value: any): void;
        private getSuggestions;
        private parseValue;
        private getSelectedLabel;
        private syncSearchQueryWithValue;
        private getInputClasses;
        private getPanelClasses;
        private getItemClasses;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleSuggestionSelect;
        private handleGeolocation;
        private renderLabel;
        private renderHelper;
        private renderSuggestions;
        private renderMap;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav.defs" {
    export const group = "groupNavigateMain";
    export const skill = "# Metadata\n- TagName: groupnavigatemain--ml-sidebar-nav\n\n# Objective\nProvide a vertical sidebar navigation panel that organises application destinations into top-level items, labelled groups, and a footer section. The sidebar can be collapsed to an icon-only rail and supports an active selection, disabled items, badge indicators, collapsible groups, and a loading skeleton.\n\n# Responsibilities\n- Render top-level Item slots, Group slots (each containing Item children), and a Footer slot containing Item children as distinct navigation regions.\n- Highlight the item whose value matches the value property as the active (current) page.\n- Dispatch a change custom event (bubbling, composed) with value, label, and badge when a non-disabled item is clicked.\n- Toggle the sidebar between full-width (w-64) and collapsed icon-rail (w-16) modes when the collapse button is activated, and dispatch a collapse event with the new collapsed state.\n- When collapsed, hide item labels and badge text, replacing full badges with a small dot indicator on the icon.\n- Show item initials as a fallback icon when no icon HTML is provided.\n- Allow named groups to be expanded or collapsed individually by clicking the group label; groups without a label are always expanded.\n- When collapsed, render group items without a group label header and separated by a horizontal divider.\n- Display a loading skeleton with animated pulse items when the loading property is true.\n- Render an optional Label slot as the sidebar header title when the sidebar is not collapsed.\n- Block item selection and dispatch when the component-level disabled property or an individual item's disabled attribute is set.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- Only one item may be active at a time; setting a new value replaces the previous active item.\n- Disabled items must render with reduced opacity, a not-allowed cursor, and must not dispatch change events.\n- The collapse toggle button must always remain visible regardless of collapsed state.\n- The component must not contain business logic; it only manages navigation selection and layout state.\n- Item badges and icons are rendered via unsafeHTML and must not be sanitized by this component.";
}
declare module "_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSidebarNavMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        collapsed: boolean;
        disabled: boolean;
        loading: boolean;
        private collapsedGroups;
        private parseItem;
        private parseTopItems;
        private parseGroups;
        private parseFooterItems;
        private handleItemClick;
        private handleToggleCollapse;
        private handleToggleGroup;
        private getItemClasses;
        private getIconClasses;
        private renderItemIcon;
        private renderNavItem;
        private renderGroup;
        private renderCollapseToggle;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesection/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-side-nav-scrollspy';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-tabs';
    export class GroupNavigateSectionIndex extends StateLitElement {
        private cardBreadcrumbTrail;
        private cardNavigatePills;
        private cardTabs;
        private cardSideNavScrollspy;
        private cardNavigateTabs;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-breadcrumb-trail\n\n# Objective\nDisplay a hierarchical navigation trail that indicates the user's current position within a nested structure. It enables users to understand the path taken to reach the current level and to navigate back to any previous interactive level.\n\n# Responsibilities\n- Consist of an overall descriptive label and a series of hierarchical navigation levels presented in a single horizontal sequence with visual delimiters between consecutive levels.\n- Display each level with a visible text label and an optional icon.\n- Distinguish each level by an identity that is communicated upon selection.\n- Maintain an active state that identifies the currently selected level; if no level is externally designated as active, the first interactive level must be treated as active by default.\n- Allow users to select any interactive level, which updates the active state and communicates the selected level's identity and label to the system.\n- Render the final level as plain text without a selection action, making it non-interactive by default.\n- Support non-interactive states for any level, preventing selection and suppressing hover or focus indications.\n- Show only the content associated with the active level while hiding content from all other levels.\n- Display a loading indicator and suppress all interactions when in a loading state.\n- Block all selection interactions when the component is in a disabled state.\n- On small viewports, collapse intermediate levels into an overflow control represented by \"...\"; opening this control must reveal hidden levels and permit selection, updating the active state accordingly.\n- Display an error message below the navigation trail when an error state is provided.\n\n# Constraints\n- The default visual delimiter between levels must be the \"/\" character.\n- Non-interactive levels must appear visually inactive and must not respond to selection attempts.\n- The overflow control must align with the collapsed position and must be non-interactive when the component is disabled or loading.\n- The component must remain on a single horizontal line without wrapping.\n- All visual states\u2014including active, inactive, non-interactive, hover, focus, and error\u2014must adapt to dark mode using the system's semantic color pairs.\n- The trail must maintain compact spacing and prioritize clarity of the hierarchical path.\n\n# Notes\n- The overflow behavior is triggered specifically by limited horizontal space.\n- The error message is independent of the navigation levels and appears only when explicitly provided.";
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class BreadcrumbTrailMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private isOverflowOpen;
        firstUpdated(): void;
        private getTabs;
        private getActiveValue;
        private getTabClasses;
        private getDelimiterClasses;
        private getOverflowButtonClasses;
        private getPanelClasses;
        private getLabelClasses;
        private getErrorClasses;
        private renderTab;
        private renderOverflowMenu;
        private renderTrail;
        private handleTabClick;
        private handleOverflowToggle;
        private handleKeyDown;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-navigate-pills\n\n# Objective\nA horizontal navigation component that presents selectable sections as pills in a scrollable row. It allows users to choose one section at a time, revealing only the content associated with that section. It supports disabled sections, a loading state, and keyboard navigation.\n\n# Responsibilities\n- Display a horizontally scrollable row of selectable pills, each representing a distinct section.\n- Maintain exactly one active selection at any time.\n- Visually distinguish the active pill from inactive pills.\n- If no external active section is specified, automatically select the first available non-disabled section.\n- Prevent disabled pills from being selected and ensure they do not trigger selection changes.\n- Notify the consuming system whenever the user changes the active selection.\n- Render only the content of the active section; keep all other section contents hidden.\n- When the component is entirely disabled, make all pills non-interactive and prevent any selection changes.\n- When loading, indicate that the component is processing and block user interaction until loading completes.\n- Allow keyboard users to move focus between pills and confirm a selection.\n- Expose the relationship between each pill and its corresponding content panel for accessibility purposes.\n- Depend on external sources for section labels, identifiers, and inner content.\n\n# Constraints\n- Only one pill may be active at a time.\n- A disabled pill cannot be selected by user action or automatic fallback.\n- Content from inactive sections must not be visible or accessible while another section is active.\n- Keyboard navigation must skip disabled pills.\n- The row of pills must remain usable through horizontal scrolling when the total width exceeds the available space.\n- Business-specific labels and categories must be provided by the consumer; the component must remain generic.\n\n# Notes\n- Designed for corporate filtering and selection scenarios such as deal status, service request types, product categories, support queues, and project assignments.\n- The consumer controls all text and content rendered inside the pills and their associated panels.";
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class NavigatePillsMolecule extends MoleculeAuraElement {
        private msg;
        private instanceId;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private lastActiveIndex;
        private handleTabClick;
        private handleKeyDown;
        private focusTabButton;
        private dispatchChange;
        private getTabs;
        private getActiveIndex;
        private getTabClasses;
        private renderLabel;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-navigate-tabs.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-navigate-tabs\n\n# Objective\nA tab navigation molecule that allows users to switch between content sections. It supports touch gestures, keyboard navigation, and indicates the active section while keeping inactive sections hidden.\n\n# Responsibilities\n- Display only the content associated with the currently active tab; keep all other sections hidden.\n- When initialized without a preselected tab, automatically activate the first enabled tab.\n- Upon user selection of an enabled tab, update the active state and communicate the new identifier and title to the system.\n- Support horizontal swipe gestures to navigate sequentially to the previous or next enabled tab.\n- Reject any attempt to activate a disabled tab through any interaction method.\n- Support keyboard navigation to move focus between tabs and to confirm selection of the focused tab.\n- Block all tab changes while the component is disabled.\n- Display a loading state and prevent all user interaction while loading.\n- Expose an accessible label for the tab group when provided.\n- Maintain a visual indicator that tracks the active tab and moves smoothly between selections.\n- Ensure all tabs remain reachable through horizontal scrolling when they exceed the available width.\n- Visually distinguish the active tab from inactive tabs.\n- Visually indicate disabled tabs as non-interactive.\n- Display the active tab's content below the tab list, occupying the full available width.\n- Adjust visual presentation appropriately for dark mode settings.\n\n# Constraints\n- Disabled tabs cannot be activated by any interaction method.\n- The component must not allow tab changes while disabled or loading.\n- Swipe navigation must follow tab sequence and bypass disabled tabs.\n- Notifications of selection changes must include both the active tab's identifier and its title.\n- Keyboard interaction must conform to accessibility standards for tab navigation.\n\n# Notes\n- The active tab's identifier may represent its positional index depending on how the author defines the tab values.";
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-navigate-tabs" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlNavigateTabsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private parsedTabs;
        private focusedIndex;
        private indicatorStyle;
        private touchStartX;
        private touchEndX;
        private tabListRef;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private parseTabs;
        private initializeActiveTab;
        private updateFocusedIndex;
        private getActiveTab;
        private updateIndicator;
        private handleTabClick;
        private selectTab;
        private handleKeyDown;
        private moveFocus;
        private focusTab;
        private handleTouchStart;
        private handleTouchMove;
        private handleTouchEnd;
        private getContainerClasses;
        private getTabListClasses;
        private getTabClasses;
        private getIndicatorClasses;
        private getPanelClasses;
        private getLoadingClasses;
        private getErrorClasses;
        private getLabelClasses;
        render(): TemplateResult;
        private renderLoading;
        private renderLabel;
        private renderTabList;
        private renderTab;
        private renderPanel;
        private renderError;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-side-nav-scrollspy.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-side-nav-scrollspy\n\n# Objective\nFornecer navega\u00E7\u00E3o lateral que vincule a se\u00E7\u00F5es da p\u00E1gina, destacando automaticamente a se\u00E7\u00E3o vis\u00EDvel conforme o usu\u00E1rio rola, e permitindo navega\u00E7\u00E3o suave at\u00E9 a se\u00E7\u00E3o selecionada.\n\n# Responsibilities\n- Exibir uma lista vertical de itens de navega\u00E7\u00E3o, cada um representando uma se\u00E7\u00E3o distinta da p\u00E1gina com um identificador \u00FAnico e um r\u00F3tulo textual.\n- Distinguir visualmente o item de navega\u00E7\u00E3o atualmente ativo dos demais.\n- Quando nenhuma sele\u00E7\u00E3o inicial for fornecida, definir como padr\u00E3o o primeiro item dispon\u00EDvel.\n- Atualizar a sele\u00E7\u00E3o ativa quando o usu\u00E1rio ativar um item de navega\u00E7\u00E3o dispon\u00EDvel.\n- Notificar o sistema sobre mudan\u00E7as de sele\u00E7\u00E3o, fornecendo o identificador e o r\u00F3tulo da se\u00E7\u00E3o.\n- Solicitar rolagem suave at\u00E9 a se\u00E7\u00E3o da p\u00E1gina correspondente quando um item for ativado, desde que a se\u00E7\u00E3o alvo exista.\n- Detectar automaticamente qual se\u00E7\u00E3o da p\u00E1gina est\u00E1 vis\u00EDvel na \u00E1rea de visualiza\u00E7\u00E3o durante a rolagem e sincronizar o item de navega\u00E7\u00E3o ativo para corresponder a essa se\u00E7\u00E3o.\n- Desabilitar todas as intera\u00E7\u00F5es e impedir mudan\u00E7as de sele\u00E7\u00E3o quando o componente estiver em estado desabilitado.\n- Impedir que itens de navega\u00E7\u00E3o desabilitados sejam selecionados manualmente ou automaticamente via detec\u00E7\u00E3o de rolagem.\n- Renderizar vis\u00EDvel apenas o conte\u00FAdo associado ao item ativo; ocultar o conte\u00FAdo dos itens inativos.\n- Exibir um estado de carregamento que substitua a lista de navega\u00E7\u00E3o e o conte\u00FAdo at\u00E9 que o carregamento seja conclu\u00EDdo.\n- Apresentar qualquer t\u00EDtulo fornecido acima da lista de itens e utiliz\u00E1-lo como nome acess\u00EDvel para a regi\u00E3o de navega\u00E7\u00E3o.\n- Permitir navega\u00E7\u00E3o por teclado entre os itens e ativa\u00E7\u00E3o do item focado.\n\n# Constraints\n- A ativa\u00E7\u00E3o de um item cuja se\u00E7\u00E3o alvo n\u00E3o exista n\u00E3o deve produzir erros e deve ignorar a a\u00E7\u00E3o de rolagem.\n- Itens desabilitados n\u00E3o podem ser ativados por nenhum meio.\n- O destaque autom\u00E1tico baseado em rolagem deve refletir com precis\u00E3o a se\u00E7\u00E3o mais proeminente na \u00E1rea de visualiza\u00E7\u00E3o.\n- Durante o carregamento, o componente n\u00E3o deve exibir itens de navega\u00E7\u00E3o ou conte\u00FAdo, nem permitir intera\u00E7\u00E3o.\n- O estado ativo deve permanecer consistente entre sele\u00E7\u00F5es do usu\u00E1rio e atualiza\u00E7\u00F5es autom\u00E1ticas de rolagem.\n- O componente deve suportar um r\u00F3tulo acess\u00EDvel para a regi\u00E3o de navega\u00E7\u00E3o quando um t\u00EDtulo for fornecido.\n\n# Notes\n- A navega\u00E7\u00E3o \u00E9 destinada ao uso como barra lateral fixa ao lado de conte\u00FAdo de p\u00E1gina rol\u00E1vel.";
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-side-nav-scrollspy" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSideNavScrollspyMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private parsedTabs;
        private activeValue;
        private isScrolling;
        private scrollTimeout;
        private observer;
        private sectionVisibility;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private parseTabs;
        private initializeActiveValue;
        private syncActiveValue;
        private setupIntersectionObserver;
        private cleanupObserver;
        private updateActiveFromVisibility;
        private handleScroll;
        private handleTabClick;
        private handleKeyDown;
        private focusTab;
        private scrollToSection;
        private emitChange;
        private getNavClasses;
        private getTabClasses;
        private getContainerClasses;
        private getSidebarClasses;
        private getContentClasses;
        private getLabelClasses;
        render(): TemplateResult;
        private renderTab;
        private renderLoading;
        private renderError;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-tabs.defs" {
    export const group = "groupNavigateSection";
    export const skill = "# Metadata\n- TagName: groupnavigatesection--ml-tabs\n\n# Objective\nAllow the user to switch between multiple named content panels within a section by clicking labelled tab buttons arranged in a horizontal tab bar. The component tracks which tab is active, renders the corresponding panel below the tab bar, and supports icons, disabled tabs, an error message, a loading state, and full keyboard navigation.\n\n# Responsibilities\n- Render each Tab slot as a button in the tab bar with its title and optional icon.\n- Display the content panel of the active tab below the tab bar.\n- Activate the tab whose value matches the value property; fall back to the first enabled tab when the stored value is absent or refers to a disabled tab.\n- Dispatch a change custom event (bubbling, composed) with value and title when a non-disabled tab is clicked or activated via keyboard.\n- Allow moving keyboard focus between enabled tab buttons using ArrowLeft and ArrowRight keys with wrapping.\n- Activate the focused tab with Enter or Space.\n- Apply ARIA roles (tablist, tab, tabpanel) and aria-selected, aria-disabled, aria-controls, and aria-labelledby attributes for accessibility.\n- Render an optional Label slot above the tab bar as the tab list label.\n- Display a loading message when the loading property is true.\n- Show an empty-state message when no Tab slots are provided.\n- Render an error message below the tab panel when the error property is non-empty.\n- Block tab switching when the component-level disabled or loading property is true.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- Only one tab panel may be visible at a time.\n- Keyboard navigation must skip disabled tabs.\n- Disabled tabs must render with reduced opacity, a not-allowed cursor, and must not dispatch change events.\n- The active tab must receive tabindex=\"0\"; all other tabs must receive tabindex=\"-1\".\n- Tab content is rendered via unsafeHTML from each Tab slot's innerHTML and must not be sanitized by this component.\n- The component must not contain business logic; it only manages tab selection state.\n- Error indication must persist until the error property is cleared externally.";
}
declare module "_102040_/l2/molecules/groupnavigatesection/ml-tabs" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlTabsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        disabled: boolean;
        loading: boolean;
        private uid;
        private handleTabClick;
        private handleKeyDown;
        private parseTabs;
        private getActiveValue;
        private toSafeId;
        private getTabClasses;
        private getTabListClasses;
        private getPanelClasses;
        private renderLabel;
        private renderLoading;
        private renderError;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesteps/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-compact-step-indicator';
    export class GroupNavigateStepsIndex extends StateLitElement {
        private cardHorizontal;
        private cardVertical;
        private cardWizard;
        private cardCompact;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-compact-step-indicator.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-compact-step-indicator\n\n# Objective\nProvide a compact visual indicator for multi-step workflows that displays progress through numbered steps or completion marks without visible text labels, optimized for narrow spaces such as form headers.\n\n# Responsibilities\n- Display a series of step indicators in a compact format suitable for limited horizontal space\n- Indicate which step is currently active through visual emphasis\n- Show completed steps with a completion mark instead of a number\n- Present pending steps with a numeric indicator\n- Support a loading state that replaces the step indicators when active\n- Allow step selection when navigation is enabled\n- Communicate the selected step's identity and title to the system upon selection\n- Provide accessibility labels using each step's title and description even though they are not visually displayed\n\n# Constraints\n- Must not display step titles or descriptions as visible text within the indicator area\n- When navigation is globally blocked, no step may be selected\n- When a step is marked as disabled, it must not be selectable under any condition\n- In linear mode, only previously completed steps and the single next step immediately following the current completed step may be selected; future steps beyond that are not selectable\n- In non-linear mode, any step that is not disabled may be selected regardless of completion status\n- Must support distinct visual treatments for pending, active, completed, disabled, and loading states\n- Must adapt color semantics for both light and dark environments\n- Must arrange indicators in a single horizontal row with even spacing for header layouts\n- Must support configurable sizing to accommodate different container constraints\n\n# Notes\n- The optional label associated with the indicator is not rendered as part of the compact step visualization\n- Step descriptions contribute to accessibility context but remain visually hidden";
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-compact-step-indicator" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CompactStepIndicatorMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number;
        linear: boolean;
        disabled: boolean;
        loading: boolean;
        private handleStepClick;
        private handleStepKeyDown;
        private getSteps;
        private canSelectStep;
        private focusNextSelectable;
        private getIndicatorSizeClasses;
        private getIndicatorClasses;
        private getStepAriaLabel;
        private getLabelText;
        private stripHtml;
        private renderLoading;
        private renderStepItem;
        private renderSteps;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-horizontal-stepper\n\n# Objective\nA horizontal stepper that presents a sequence of steps from left to right. Each step shows an icon and a title. Users can navigate between steps by clicking or using keyboard controls. The component visually communicates which steps are completed, active, pending, or unavailable, and can enforce sequential progression or allow free navigation.\n\n# Responsibilities\n- Display an optional title above the step sequence.\n- Arrange all steps in a single horizontal row with equal spacing and a clear left-to-right flow.\n- Render each step as an indicator containing an icon, with the step title shown directly below the indicator.\n- Visually highlight the active step.\n- Visually distinguish completed steps from pending steps.\n- Visually dim steps that are unavailable and show them as non-interactive.\n- Support a progression mode that restricts navigation to previously completed steps and the immediate next step only.\n- Support a progression mode that allows navigation to any step that is not unavailable, regardless of completion order.\n- Update the current step when the user selects an allowed step by clicking or by keyboard.\n- Announce the current step and its title whenever the active step changes.\n- Maintain synchronization so the visual state always reflects the current step.\n- Automatically mark all steps preceding the active step as completed when the active step changes.\n- Block interaction on steps marked as unavailable.\n- Block all navigation when the entire component is marked as unavailable.\n- Show a loading state that disables interaction and visually indicates activity.\n- Allow users to move focus between steps using left and right directional controls.\n- Allow users to select the focused step using a confirmation control.\n- Ensure keyboard navigation follows the same restrictions as click navigation.\n- Expose accessibility information so assistive technologies can identify the step list, each step, the active selection, unavailable steps, and completed steps.\n\n# Constraints\n- Unavailable steps must not respond to click or keyboard selection.\n- In restricted progression mode, future steps beyond the immediate next allowed step must not be selectable.\n- In free progression mode, completion state must not prevent navigation unless a step is unavailable.\n- The loading state must suppress normal step visuals or dim them to emphasize that activity is in progress.\n- When navigating to a step, all preceding steps must be implicitly treated as completed, regardless of whether they were individually visited.\n- Completed steps must not appear identical to pending or active steps.\n- The left-to-right progression sense must remain clear regardless of step state.\n\n# Notes\n- The title above the stepper is optional.\n- Each step supplies its own icon content individually.\n- The component can operate in either strict sequential order or free-form navigation.";
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlHorizontalStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number;
        linear: boolean;
        disabled: boolean;
        loading: boolean;
        private focusedIndex;
        handleIcaStateChange(key: string, value: any): void;
        firstUpdated(): void;
        private getSteps;
        private getLabelText;
        private isStepCompleted;
        private canNavigateTo;
        private getNextFocusableIndex;
        private handleStepClick;
        private handleKeyDown;
        private handleFocus;
        private getIndicatorClasses;
        private getTitleClasses;
        private getDescriptionClasses;
        private getContainerClasses;
        private renderLoading;
        private renderStep;
        private renderConnector;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-vertical-stepper\n\n# Objective\nGuide the user through an ordered sequence of steps displayed in a vertical list, indicating which step is currently active, which steps have been completed, and which are still pending. The component supports linear and non-linear navigation modes, per-step disabled and completed states, an optional description per step, and full keyboard navigation.\n\n# Responsibilities\n- Render each Step slot as a vertically stacked list item showing a numbered indicator, a title, and an optional description.\n- Mark the step whose index matches the value property as active.\n- Replace the number indicator with a checkmark icon for steps that carry the completed attribute.\n- Connect adjacent steps with a vertical connector line, coloured to indicate completion or activity of the next step.\n- Dispatch a change custom event (bubbling, composed) with value (index) and title when a navigable step is selected.\n- In linear mode, allow navigation only to steps at or before the current step, or to the immediately following step if the current step is completed, or to any already-completed step.\n- In non-linear mode, allow navigation to any non-disabled step regardless of order.\n- Support keyboard navigation: ArrowDown/ArrowRight moves to the next navigable step; ArrowUp/ArrowLeft moves to the previous; Home jumps to the first navigable step; End jumps to the last; Enter/Space selects the focused step.\n- Move focus programmatically to the newly selected step button after keyboard navigation.\n- Render an optional Label slot as a heading above the step list.\n- Display a loading message when the loading property is true.\n- Show an empty-state message when no Step slots with a title are provided.\n- Apply ARIA roles (tablist, tab) and aria-selected, aria-disabled, and aria-label attributes for accessibility.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- Steps without a title attribute must be silently skipped and not rendered.\n- Navigation to a disabled step must be blocked regardless of linear mode setting.\n- The active step button must receive tabindex=\"0\"; all other step buttons must receive tabindex=\"-1\".\n- In linear mode, forward navigation beyond the next step is blocked unless intermediate steps are completed.\n- The component must not contain business logic; it only manages step selection and completion display.\n- The component-level disabled property must block all step interaction and navigation.";
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlVerticalStepperMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number;
        linear: boolean;
        disabled: boolean;
        loading: boolean;
        private handleStepClick;
        private handleKeydown;
        private parseSteps;
        private getLabelText;
        private canNavigateTo;
        private selectStep;
        private findNextNavigableIndex;
        private focusStep;
        private getStepButtonClasses;
        private getIndicatorClasses;
        private getTitleClasses;
        private getDescriptionClasses;
        private getConnectorClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps.defs" {
    export const group = "groupNavigateSteps";
    export const skill = "# Metadata\n- TagName: groupnavigatesteps--ml-wizard-steps\n\n# Objective\nA step navigation component that displays a horizontal sequence of workflow steps and manages user progression through them. It indicates active, completed, pending, and disabled states, and enforces either sequential or free-form navigation based on step completion.\n\n# Responsibilities\n- Render a horizontal step indicator strip ordered from left to right matching the sequence of provided step definitions.\n- Display each step's required title and optional description.\n- Visually highlight the active step.\n- Show a completion mark on steps marked as finished.\n- Apply a subdued appearance to disabled steps and remove their interactivity.\n- Present an optional label above the step sequence.\n- Update the active step upon valid user selection and notify the system of the change, including the step's identity and title.\n- Honor an externally controlled value to determine which step is active.\n- Disable all navigation when the component is in a disabled state.\n- In linear mode, restrict forward navigation to the next step only when the current step is completed; allow return to prior completed steps.\n- In non-linear mode, permit navigation to any step that is not disabled, without completion prerequisites.\n- Prevent advancement when linearity or completion requirements are unmet.\n- Consider optional steps non-blocking for progression when marked complete.\n- Display a loading state that replaces the normal step indicator when loading is active.\n- Enable keyboard navigation to move between steps and select the focused step.\n- Expose accessibility information so assistive technologies can identify the active step, disabled steps, and completed steps.\n\n# Constraints\n- Must operate exclusively within the groupNavigateSteps contract properties, events, and content areas.\n- Must not provide internal footer buttons for step navigation; external controls are the consumer's responsibility.\n- Step definitions must include a title; description, completion status, and disabled state are optional.\n- Validation must rely only on the completion status of steps and the linear mode setting; no external validation callbacks or additional events may be used.\n- The loading state must override the standard visual presentation entirely.\n- Must maintain accessible navigation semantics for the step container and each step.\n- Must remain visually usable in both light and dark presentation modes.\n\n# Notes\n- The consumer manages step completion state and any external navigation buttons.\n- This component governs only the step indicator strip; step body content is handled separately by the consumer.";
}
declare module "_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlWizardStepsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number;
        linear: boolean;
        disabled: boolean;
        loading: boolean;
        private focusedIndex;
        private handleStepClick;
        private handleContainerKeyDown;
        private parseSteps;
        private canNavigateTo;
        private getInitialFocusIndex;
        private findNextFocusableIndex;
        private getStepClasses;
        private getLabelText;
        private renderLoading;
        private renderLabel;
        private renderStep;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-alert-modal';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback';
    export class GroupNotifyUserIndex extends StateLitElement {
        private cardBanner;
        private cardToast;
        private cardAlertModal;
        private cardContextual;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-alert-modal\n\n# Objective\nPresent a blocking modal alert for critical or destructive actions that demands user attention and an explicit choice before proceeding. Communicate severity through visual cues and provide clear options to confirm or cancel the action.\n\n# Responsibilities\n- Appear as a centered overlay with a backdrop that blocks interaction with the underlying screen when activated\n- Display a severity-appropriate icon by default, while allowing replacement with a custom icon when provided\n- Show a title when one is supplied\n- Always display the descriptive message content when the alert is active\n- Present externally supplied action buttons, including confirmation and cancellation options, arranged side by side\n- Notify the system when the user selects an action button\n- Notify the system when the user dismisses the alert through an available dismiss mechanism\n- Remain open when the user interacts with the backdrop or clicks outside the alert boundaries\n- Disappear completely without leaving reserved space when in an inactive state\n- Automatically close after a configured duration when specified, transitioning to an inactive state and signaling dismissal\n- Support distinct severity levels: danger treated as error, warning as warning, and info as info\n- Disable user-initiated dismissal mechanisms when configured as non-dismissible\n- Adjust presentation to modal overlay behavior when positioned for centered display\n- Announce its presence and severity to assistive technologies using appropriate roles and live regions\n- Adapt its visual presentation for dark environments\n\n# Constraints\n- The backdrop must be purely visual and must not respond to clicks or taps by closing the alert\n- Action buttons must be supplied externally; the alert must not generate default buttons\n- No output may be displayed when the alert is inactive\n- When non-dismissible, no close button or dismiss gesture may be available to the user\n- The message area must not be empty when the alert is visible\n- Default icons must match the severity level when no custom icon is supplied\n- Auto-dismiss must only occur when a positive duration is configured and the alert is active\n- Severity mapping must remain consistent: danger corresponds to error behavior\n- Modal positioning must cover the full screen with an overlay backdrop\n- Accessibility announcements must reflect the current alert type\n\n# Notes\n- The caller is responsible for defining the labels and appearance of the action buttons placed inside the action area\n- Dismissal via the dedicated dismiss mechanism is equivalent to cancellation from the system's perspective";
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-alert-modal" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlAlertModalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: string;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: string;
        private autoDismissId;
        handleIcaStateChange(key: string): void;
        updated(changedProps: Map<string, unknown>): void;
        private manageAutoDismiss;
        private clearAutoDismiss;
        private handleDismiss;
        private handleActionClick;
        private getNormalizedType;
        private getRole;
        private getAriaLive;
        private getPositionClasses;
        private getContainerClasses;
        private getIconWrapperClasses;
        private renderDefaultIcon;
        private renderIcon;
        private renderTitle;
        private renderMessage;
        private renderActions;
        private renderDismiss;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-contextual-feedback\n\n# Objective\nProvide contextual feedback messages inside forms, positioned near related fields or sections. Communicates success, error, warning, or info states through text, optional icon, and optional action. Supports dismissible and persistent modes, automatic dismissal timing, and accessibility announcements.\n\n# Responsibilities\n- Display only when visible; remain completely hidden otherwise\n- Present a primary message as contextual feedback near form fields or sections\n- Support four semantic variants: success, error, warning, and info\n- Display an optional icon when provided alongside the message\n- Display an optional title with clear visual hierarchy relative to the message\n- Display an optional action control and report when it is activated\n- Provide a manual dismissal control when configured as dismissible\n- Automatically dismiss after a specified duration when visible, if duration is configured\n- Cancel automatic dismissal if the user manually dismisses first\n- Report whenever the message is dismissed, whether by user action or automatic timeout\n- Announce error and warning messages immediately to assistive technologies\n- Announce info and success messages to assistive technologies without interrupting\n- Support inline placement within form layouts without overlaying adjacent content\n- Animate entry with a combined fade and slight slide when becoming visible\n\n# Constraints\n- Must not render any content when hidden\n- Must not show a dismissal control when not configured as dismissible\n- Must remain visible until externally changed when persistent and no duration is set\n- Must always report dismissal when it occurs\n- Must prioritize manual dismissal over automatic timeout\n- Must align horizontally when an icon is present; otherwise the message must use the full available width\n- Must maintain a compact, inline appearance appropriate to form contexts\n\n# Notes\n- Designed for localized form feedback rather than global notifications\n- Entry animation applies only on transition to visible";
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-contextual-feedback" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ContextualFeedbackMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: string;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: string;
        private isAnimatingOut;
        private isAnimatingIn;
        private autoHideTimer;
        private previousVisible;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private handleBecomeVisible;
        private startAutoHideTimer;
        private clearAutoHideTimer;
        private handleDismiss;
        private handleActionClick;
        private getContainerClasses;
        private getTypeStyles;
        private getAriaRole;
        private getAriaLive;
        private renderDefaultIcon;
        private renderIcon;
        private renderTitle;
        private renderMessage;
        private renderAction;
        private renderDismissButton;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-notify-banner.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-notify-banner\n\n# Objective\nDisplay a contextual inline or floating notification banner that communicates a status message to the user. The banner supports four semantic types (info, success, warning, error), an optional title, an optional action link, an optional custom icon, a dismiss button, automatic timed dismissal, and configurable screen positioning.\n\n# Responsibilities\n- Render the banner only when the visible property is true; render nothing when visible is false.\n- Apply type-specific colors and a default icon matching the type (info, success, warning, error).\n- Render a custom icon from the Icon slot when provided, replacing the default icon.\n- Render an optional Title slot as a bold heading above the message.\n- Render the Message slot content as the notification body; show a fallback warning text when the Message slot is absent.\n- Render an optional Action slot as a clickable inline element and dispatch an action custom event (bubbling, composed) when it is clicked.\n- Render a dismiss button when the dismissible property is true; clicking it sets visible to false and dispatches a dismiss custom event (bubbling, composed).\n- Start an auto-dismiss timer when both visible is true and duration is greater than zero; cancel the timer when visible becomes false or duration changes to zero.\n- Cancel the auto-dismiss timer when the component is disconnected from the DOM.\n- Apply fixed-position placement classes derived from the position property (top-right, top-left, bottom-right, bottom-left, top, bottom); use relative positioning when position is empty.\n- Set role=\"alert\" and aria-live=\"assertive\" for error type; set role=\"status\" and aria-live=\"polite\" for all other types.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- The banner must render no DOM output while visible is false.\n- The dismiss button must not appear unless dismissible is true.\n- Auto-dismiss must not fire if visible has already been set to false before the timer expires.\n- The component must not contain business logic; it only manages notification visibility and appearance.\n- Slot content (Title, Message, Action, Icon) is rendered via unsafeHTML and must not be sanitized by this component.\n- Only one auto-dismiss timer may be active at a time; a new timer must cancel the previous one.";
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-notify-banner" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class NotifyBannerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: 'info' | 'success' | 'warning' | 'error' | string;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: string;
        private dismissTimer;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, unknown>): void;
        private startAutoDismiss;
        private clearAutoDismiss;
        private handleDismiss;
        private handleActionClick;
        private getRole;
        private getAriaLive;
        private getPositionClasses;
        private getContainerClasses;
        private getTypeClasses;
        private getIconClasses;
        private renderDefaultIcon;
        private renderIcon;
        private renderTitle;
        private renderMessage;
        private renderAction;
        private renderDismissButton;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.defs" {
    export const group = "groupNotifyUser";
    export const skill = "# Metadata\n- TagName: groupnotifyuser--ml-toast-notification\n\n# Objective\nProvide ephemeral floating notifications that appear in a screen corner, slide in and out smoothly, indicate different severity levels through color and icon, dismiss automatically after a set time or manually via a close control, optionally offer a secondary action, and stack vertically when multiple instances are active.\n\n# Responsibilities\n- Appear in a configurable screen corner when activated, sliding smoothly from the edge of that corner.\n- Disappear by sliding out smoothly along the same path used for entry.\n- Present four distinct visual identities: information (blue), success (green), warning (yellow), and error (red), each with a default icon.\n- Display a provided message as the primary content.\n- Disappear automatically after a configurable duration unless dismissed earlier.\n- Allow manual dismissal via a close control when manual closing is enabled.\n- Offer an optional action trigger, visually distinct from the message, that can be activated independently of dismissal.\n- Use a custom icon when one is supplied; otherwise, show the default icon for the current notification type.\n- Stack vertically with uniform spacing between simultaneous notifications.\n- Announce urgent interruptions for error and warning types, and polite updates for information and success types to assistive technologies.\n\n# Constraints\n- Must remain hidden when inactive.\n- Must complete its exit and cease to be presented after dismissal.\n- Must cancel pending automatic dismissal if the notification is deactivated externally or dismissed manually before the configured duration elapses.\n- Must not show a manual close control when manual dismissal is disabled.\n- Must not show an action trigger when no action is provided.\n- Must preserve consistent external spacing to support predictable vertical stacking in shared presentation areas.\n- Must apply the appropriate urgency level for assistive announcements based on the notification type.\n\n# Notes\n- The notification is transient and intended only for temporary awareness.\n- Screen corner selection determines both placement and the direction of the slide motion.\n- Activating the action trigger is independent of dismissal; the notification remains visible unless dismissal is separately requested.";
}
declare module "_102040_/l2/molecules/groupnotifyuser/ml-toast-notification" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    type NotificationType = 'info' | 'success' | 'warning' | 'error';
    type PositionType = 'top' | 'bottom' | 'top-right' | 'bottom-right' | 'top-left' | 'bottom-left';
    export class ToastNotificationMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        type: NotificationType;
        visible: boolean;
        dismissible: boolean;
        duration: number;
        position: PositionType | '';
        private isAnimatingOut;
        private autoCloseTimer;
        disconnectedCallback(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private startAutoCloseTimer;
        private clearAutoCloseTimer;
        private handleDismiss;
        private handleActionClick;
        private getContainerClasses;
        private getTypeClasses;
        private getPositionClasses;
        private getAnimationClasses;
        private getEntryAnimationClass;
        private getExitAnimationClass;
        private getIconColorClasses;
        private getTitleClasses;
        private getMessageClasses;
        private getActionClasses;
        private getActionColorClasses;
        private getCloseButtonClasses;
        private getAriaRole;
        private getAriaLive;
        private renderIcon;
        private renderDefaultIcon;
        private renderTitle;
        private renderMessage;
        private renderAction;
        private renderCloseButton;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupplaymedia/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupplaymedia/ml-audio-player';
    import '/_102040_/l2/molecules/groupplaymedia/ml-video-player';
    import '/_102040_/l2/molecules/groupplaymedia/ml-pdf-viewer';
    import '/_102040_/l2/molecules/groupplaymedia/ml-image-gallery';
    export class GroupPlayMediaIndex extends StateLitElement {
        private card1;
        private card2;
        private card3;
        private card4;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-audio-player.defs" {
    export const group = "groupPlayMedia";
    export const skill = "# Metadata\n- TagName: groupplaymedia--ml-audio-player\n\n# Objective\nProvide an audio player that enables users to play, pause, seek, adjust volume, and mute media. It manages the playback lifecycle, surfaces timing information, and adheres to the groupPlayMedia contract for events, accessibility, error handling, and content sourcing.\n\n# Responsibilities\n- Accept one or more audio sources with associated types through designated source content areas, using them in fallback order.\n- Respect autoplay, loop, and muted settings to determine initial playback behavior.\n- Toggle between playing and paused states when the user activates the corresponding control.\n- Provide a seek control that reflects the current playback position and total duration, and allows the user to change position within the media timeline.\n- Display the current playback time and total duration.\n- Provide a volume control that adjusts output across the full range from silent to maximum.\n- Provide a mute toggle that silences and restores audio output.\n- Emit a play event with empty detail that propagates when playback starts.\n- Emit a pause event with empty detail that propagates when playback stops.\n- Emit an ended event with empty detail that propagates when playback reaches the end.\n- Emit timeUpdate events that include the current time and total duration whenever the playback position changes.\n- Disable all controls and prevent playback manipulation through the interface when in a disabled state.\n- Enter a buffering state and display a loading indicator while media is loading.\n- Enter an error state and emit an error event containing a message when media playback fails.\n- Use provided label content as the accessible name for the player.\n- Support keyboard controls for toggling play/pause, seeking backward and forward, and increasing or decreasing volume.\n- Restrict content areas to Label, Source, and Track as defined by the group contract.\n\n# Constraints\n- Controls must remain non-interactive and playback must not be controllable via the interface while disabled.\n- Only Label, Source, and Track content areas may be accepted; no additional content areas are permitted.\n- Volume must remain within the valid range from silent to maximum.\n- Events must carry the specified detail structure and must propagate according to the group contract.\n- Playback must not start automatically unless the autoplay setting is active.\n- Error states must suppress standard playback controls and present error information.\n\n# Notes\n- Intended for corporate use cases including training podcasts, call recordings, legal depositions, candidate interviews, and internal voice communications.\n- Time values must reflect the actual media timeline and update as the user seeks or playback progresses.";
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-audio-player" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class AudioPlayerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        poster: string;
        autoplay: boolean;
        loop: boolean;
        muted: boolean;
        preload: 'none' | 'metadata' | 'auto';
        disabled: boolean;
        loading: boolean;
        private isPlaying;
        private currentTime;
        private duration;
        private volume;
        private isMuted;
        private isBuffering;
        private errorMessage;
        private audioEl;
        firstUpdated(): void;
        updated(): void;
        playMedia(): void;
        pauseMedia(): void;
        togglePlay(): void;
        seekTo(time: number): void;
        setVolume(level: number): void;
        toggleMute(): void;
        private handlePlay;
        private handlePause;
        private handleEnded;
        private handleTimeUpdate;
        private handleLoadedMetadata;
        private handleWaiting;
        private handleCanPlay;
        private handleMediaError;
        private handleSeekInput;
        private handleVolumeInput;
        private handleKeyboard;
        private syncInitialState;
        private getLabelText;
        private formatTime;
        private getButtonClasses;
        private getRangeClasses;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-image-gallery.defs" {
    export const group = "groupPlayMedia";
    export const skill = "# Metadata\n- TagName: groupplaymedia--ml-image-gallery\n\n# Objective\nAn image gallery that presents a sequence of images through a main viewing area, a thumbnail strip, and an expanded overlay view. It supports directional navigation, keyboard control, and communicates state changes through the groupPlayMedia contract.\n\n# Responsibilities\n- Render each gallery image from an ordered set of source slots.\n- Accept optional track slots associated by index to each source, using the track label as the image caption and alternative text.\n- Display the currently selected image in the main viewing area.\n- Present thumbnails in a horizontal strip below the main image, with the active thumbnail visually distinguished.\n- Provide previous and next controls to move through the image sequence.\n- Disable the previous control at the first image and the next control at the last image.\n- Update the main image immediately when a thumbnail is selected.\n- Notify with the current index and total image count whenever the active image changes.\n- Support keyboard navigation with left and right arrow keys when the component has focus.\n- Open an expanded lightbox view when the main image is activated.\n- Close the expanded view when activated again or when the space key is pressed.\n- Signal start of expanded view when opening and end of expanded view when closing.\n- Report a descriptive failure when no image sources are provided.\n- Use the label slot content as the component's accessible label.\n- Block all interactions when disabled.\n- Show a loading indicator over the main area and block interactions when loading.\n- Hide controls and thumbnails and display only an error message when in error.\n\n# Constraints\n- The main image must always match the currently selected source.\n- Thumbnail interaction must immediately update the selection.\n- Navigation controls must not loop; boundaries must disable the relevant control.\n- Keyboard navigation must only respond while the component is focused.\n- The expanded view must display a dark overlay covering the component and center the enlarged image.\n- Captions must appear below the main image.\n- The label content must appear near the top as a title or description.\n- In disabled state, controls and thumbnails must appear visually inactive.\n- In loading state, the indicator must appear over the main image area.\n- In error state, the message must use error styling and occupy the main gallery area.\n- All colors must have semantic light and dark mode variations.\n\n# Notes\n- Track slots are optional and linked to sources by position.\n- The component adheres to the groupPlayMedia contract for slots, events, and accessibility.";
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-image-gallery" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ImageGalleryMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        disabled: boolean;
        loading: boolean;
        error: string;
        private activeIndex;
        private isExpanded;
        private lastErrorMessage;
        private notifyIndexChange;
        private dispatchPlayEvent;
        private dispatchPauseEvent;
        private dispatchErrorEvent;
        private getSources;
        private getTracks;
        private getCaption;
        private getAltText;
        private getLabelText;
        private getComputedError;
        private syncActiveIndex;
        private trackError;
        private handlePrev;
        private handleNext;
        private handleThumbnailSelect;
        private handleToggleExpanded;
        private handleKeyDown;
        private getControlButtonClasses;
        private getThumbnailClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-pdf-viewer.defs" {
    export const group = "groupPlayMedia";
    export const skill = "# Metadata\n- TagName: groupplaymedia--ml-pdf-viewer\n\n# Objective\nAn embedded document viewer that presents paginated content from a source URL, allowing users to navigate between pages, adjust the viewing scale, and track their position within the document.\n\n# Responsibilities\n- Accept content exclusively through the Label, Source, and Track slots defined by the groupPlayMedia contract\n- Treat each Source slot as a potential document source using its source address; adopt the first valid Source as the active document\n- Enter an Error state and dispatch an error event if no Source is provided or if none contain a valid source address\n- Use the Label slot content as the accessible label and display it as a visible title or description alongside the viewer\n- Render the document page by page, maintaining the current page index and the total page count\n- Provide controls to navigate to the previous page, the next page, and to jump directly to a specific page within the total\n- Provide controls to increase viewing scale, decrease viewing scale, and toggle a fit-to-width mode\n- Enter a Buffering state when the loading property is true, display a loading indicator, and disable navigation and scale controls\n- Enter a Disabled state when the disabled property is true, render all controls non-interactive and visually inactive, and block all navigation and scale actions\n- Dispatch a timeUpdate event on every page change, indicating the current page number and the total page count\n- Dispatch a play event when increasing the viewing scale and a pause event when decreasing the viewing scale\n- Dispatch an ended event when toggling the fit-to-width mode\n- Dispatch an error event and hide all controls if the document fails to load or render\n- Respond to keyboard inputs: left and right directional inputs navigate pages, up and down directional inputs adjust scale, and space toggles between scale increase and decrease\n- Present the progress control as a slider that communicates the current page position and the total number of pages\n\n# Constraints\n- Navigation must be constrained to the bounds of the document; previous page is unavailable at the first page and next page is unavailable at the last page\n- Controls must remain inactive and non-interactive while loading or disabled\n- All controls must be hidden when the Error state is active\n- Page position and total count must remain accurate and synchronized with the displayed content\n- Event notifications must only dispatch in response to their corresponding user actions or state changes\n- The viewer must not process navigation or scale actions when loading or disabled\n\n# Notes\n- Page navigation and viewing scale are independent behaviors\n- The progress slider represents discrete page positions across the document sequence\n- Fit-to-width is a distinct viewing mode separate from incremental scale adjustments";
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-pdf-viewer" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlPdfViewerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        disabled: boolean;
        loading: boolean;
        autoplay: boolean;
        loop: boolean;
        muted: boolean;
        preload: string;
        poster: string;
        private currentPage;
        private totalPages;
        private scale;
        private fitToWidth;
        private hasError;
        private errorMessage;
        private documentSrc;
        private isScaleIncreasing;
        firstUpdated(): void;
        disconnectedCallback(): void;
        private initializeDocument;
        private keyboardHandler;
        private setupKeyboardListeners;
        private removeKeyboardListeners;
        private goToPreviousPage;
        private goToNextPage;
        private goToPage;
        private handleSliderChange;
        private handlePageInputChange;
        private increaseScale;
        private decreaseScale;
        private toggleFitToWidth;
        private toggleScaleDirection;
        private dispatchTimeUpdateEvent;
        private dispatchPlayEvent;
        private dispatchPauseEvent;
        private dispatchEndedEvent;
        private dispatchErrorEvent;
        private getContainerClasses;
        private getToolbarClasses;
        private getButtonClasses;
        private getActiveButtonClasses;
        private getViewerClasses;
        private getPageInputClasses;
        private getSliderClasses;
        private getLoadingOverlayClasses;
        private getErrorClasses;
        private renderLabel;
        private renderNavigationControls;
        private renderPageIndicator;
        private renderScaleControls;
        private renderToolbar;
        private renderProgressBar;
        private renderDocumentViewer;
        private renderLoading;
        private renderError;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-video-player.defs" {
    export const group = "groupPlayMedia";
    export const skill = "# Metadata\n- TagName: groupplaymedia--ml-video-player\n\n# Objective\nProvide a fully accessible video player that renders a native HTML video element from declarative Source and Track slots and exposes custom playback controls for play/pause, seeking, volume, mute, captions, and fullscreen. The component tracks playback state internally and dispatches events on play, pause, end, and time update.\n\n# Responsibilities\n- Render a native <video> element populated with <source> elements from Source slots and <track> elements from Track slots.\n- Display a poster image when the poster property is set.\n- Support autoplay, loop, muted, and preload attributes passed through to the native video element.\n- Show play, pause, and replay button labels according to the current playback state (playing, paused, ended).\n- Render a seek range input that reflects currentTime and allows the user to scrub to any position within the video duration.\n- Display the current time and total duration in mm:ss format next to the seek bar.\n- Render a mute/unmute toggle button and a volume range input for audio level control; muting via the volume slider (reaching 0) must also set the muted state.\n- Show a captions toggle button only when Track slots are present; toggling it enables or disables all text tracks on the video element.\n- Render a fullscreen button that calls requestFullscreen on the video element.\n- Track and expose isPlaying, currentTime, duration, volume, isMuted, and hasEnded as reactive internal state.\n- Dispatch play, pause, ended, timeUpdate, and error custom events (bubbling, composed) in response to the corresponding native media events.\n- Expose public methods: playMedia, pauseMedia, togglePlay, seekTo, setVolume, toggleMute, enterFullscreen, toggleCaptions.\n- Allow keyboard shortcuts on the player container: Space toggles play/pause; ArrowLeft seeks back 5 seconds; ArrowRight seeks forward 5 seconds; ArrowUp increases volume by 0.05; ArrowDown decreases volume by 0.05.\n- Display a loading placeholder when the loading property is true.\n- Show a no-source error message when no Source slots with a src attribute are provided.\n- Render an optional Label slot as a caption above the player.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- All playback controls and keyboard shortcuts must be blocked when disabled or loading is true.\n- Seek position must be clamped to the range [0, duration].\n- Volume must be clamped to the range [0, 1].\n- The captions button must not appear when no Track slots are present.\n- The component must not contain business logic; it only manages playback UI state.\n- Source and Track data are read from slot attributes (src, type, kind, lang, label) and must not alter the slot elements.";
}
declare module "_102040_/l2/molecules/groupplaymedia/ml-video-player" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class VideoPlayerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        poster: string;
        autoplay: boolean;
        loop: boolean;
        muted: boolean;
        preload: string;
        disabled: boolean;
        loading: boolean;
        private isPlaying;
        private currentTime;
        private duration;
        private volume;
        private isMuted;
        private hasEnded;
        private captionsEnabled;
        handleIcaStateChange(key: string, value: any): void;
        playMedia(): void;
        pauseMedia(): void;
        togglePlay(): void;
        seekTo(seconds: number): void;
        setVolume(value: number): void;
        toggleMute(): void;
        enterFullscreen(): void;
        toggleCaptions(): void;
        private handlePlay;
        private handlePause;
        private handleEnded;
        private handleTimeUpdate;
        private handleLoadedMetadata;
        private handleVolumeChange;
        private handleMediaError;
        private handleSeekInput;
        private handleVolumeInput;
        private handleKeyDown;
        render(): any;
        private renderLabel;
        private renderControls;
        private readSources;
        private readTracks;
        private hasSources;
        private getMediaElement;
        private formatTime;
        private emitError;
        private isBlocked;
        private getButtonClasses;
        private getRangeClasses;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale';
    import '/_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps';
    import '/_102040_/l2/molecules/grouprateitem/ml-qualitative-feedback-tags';
    import '/_102040_/l2/molecules/grouprateitem/ml-rating-slider';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-thumbs-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-csat-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-ces-scale';
    export class GroupRateItemIndex extends StateLitElement {
        private card1;
        private card2;
        private card3;
        private card4;
        private card5;
        private card6;
        private card7;
        private card8;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-ces-scale.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-ces-scale\n\n# Objective\nA molecule that presents a 1-to-7 Customer Effort Score rating scale, allowing users to select a numeric value representing their perceived level of effort. It displays options in a horizontal arrangement with a color gradient from low to high effort, supports configurable text labels at the extremes, and adapts its density based on the presence of label and helper content.\n\n# Responsibilities\n- Accept only Label, Helper, and Item slots as defined by the groupRateItem contract.\n- When Item slots are provided, present only those items as selectable rating options, ignoring min, max, and step.\n- Use the numeric value declared in each Item slot's value attribute as that option's selection value.\n- When no Item slots are provided, generate rating options automatically from 1 to 7 in increments of 1.\n- In edit mode, set the value to the selected option's number upon user selection and emit a change event with detail `{ value: number | null }`.\n- In edit mode, when interaction is allowed, provide a visual preview of an option when it is hovered.\n- Clear the hover preview when the user stops hovering, returning the visual state to reflect the current value.\n- Emit focus and blur events according to the groupRateItem contract when the field receives or loses focus.\n- In view mode, display the selected value statically without hover behavior or interactive affordances.\n- Show the error visual state specified by the contract when the field is required and no value is selected.\n- Display the error message below the control and apply the error visual state when an error is provided; hide error indicators in view mode.\n- Prevent all selection, hover, and related event emission when disabled.\n- Prevent value changes and hover effects when readonly, while continuing to show the current value.\n- Automatically adopt a compact layout when both Label and Helper slots are absent, reducing spacing and control size while preserving full functionality.\n- Present rating options horizontally as selectable items identified by their numeric values.\n- Apply a left-to-right color gradient across options, associating the lowest value with minimal effort and the highest value with maximal effort.\n- Visually emphasize selected and hovered options without altering their underlying gradient color identity.\n- In view mode, present the selected value using the same effort-based color mapping, without interactive cues.\n- Render the content of Item slots inside their respective options, allowing the first and last options to carry configurable extreme labels.\n- When options are auto-generated, display numeric labels only and visually emphasize the first and last values to imply the scale extremes.\n- Place the Label slot near the control as the field label.\n- Place the Helper slot beneath the control when no error is present.\n- Place the error message beneath the control and apply the error visual state when an error is active.\n- Support dark-mode equivalents for all background, border, text, and gradient colors.\n- In compact variant, reduce spacing between options, item padding, and text size while keeping labels readable.\n\n# Constraints\n- Must not use slot tags outside of Label, Helper, and Item.\n- Item slots must declare a numeric value attribute to be treated as valid selection options.\n- Auto-generated options are constrained to the 1\u20137 range.\n- Change events must only fire in edit mode as a result of user selection.\n- Hover preview must not activate in view mode, disabled state, or readonly state.\n- Error messages and error visual states must be hidden in view mode.\n- Focus and blur behavior must align strictly with the groupRateItem contract.\n- Compact layout must be determined solely by the absence of both Label and Helper slots.\n- The color gradient must consistently map the lowest available value to the low-effort end and the highest available value to the high-effort end, independent of how many options are rendered.\n\n# Notes\n- Configurable extreme labels depend on authors supplying Item slots at the first and last positions with the desired text.\n- The gradient provides a fixed semantic reference for effort level and must remain distinguishable across all visual states.";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-ces-scale" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CesScaleMolecule extends MoleculeAuraElement {
        private msg;
        private baseId;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private isFocused;
        private handleItemClick;
        private handleItemMouseEnter;
        private handleMouseLeave;
        private handleKeyDown;
        private focusRateItem;
        private handleFocusIn;
        private handleFocusOut;
        private getItems;
        private getCompact;
        private getGradientClasses;
        private getItemClasses;
        private renderLabel;
        private renderHelper;
        private renderItems;
        private renderView;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-csat-rating.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-csat-rating\n\n# Objective\nA customer satisfaction score rating tool that presents five selectable satisfaction levels. Each level displays a distinct icon and a configurable descriptive label. The component highlights the active choice and reveals the associated numeric score.\n\n# Responsibilities\n- Present five rating options in a horizontal row ordered from 1 to 5\n- Allow each option to show a unique icon and configurable descriptive label\n- Enable selection of a single numeric value in the 1-to-5 range\n- Visually emphasize the selected option\n- Show the selected numeric score next to the option group when a value is active\n- Show a static dash placeholder when no value is selected and the component is in view mode\n- Apply hover highlighting during editing and clear it when the pointer exits\n- Present a static, non-interactive view in non-editing mode without hover effects, error indicators, or helper text\n- Enter an error state when a value is required but none is selected\n- Show error messages and error styling during editing when an error is supplied\n- Prevent all interaction and state changes when disabled\n- Prevent interaction while keeping the current value visible when readonly\n- Notify when the selected value changes\n- Notify when the component gains or loses focus\n- Support keyboard navigation between options and keyboard confirmation of selection\n\n# Constraints\n- Must adhere to the Rate Item group behavior contract for states, properties, and notifications\n- Must maintain a fixed scale of five numeric levels from 1 to 5\n- Must use explicitly provided option definitions when available, ignoring generic scale settings\n- Change notifications must include only the numeric value, not labels or other metadata\n- Must suppress interaction and notifications in disabled and readonly states\n- Must suppress hover effects and interaction outside of editing mode\n- Must suppress error and helper presentation outside of editing mode\n- Keyboard control must follow the group behavior contract for directional movement and selection\n\n# Notes\n- Each rating level is defined by its own declared content\n- Color presentation must respect light and dark mode contracts\n- Labels and helper text are visible only during editing and only under their defined conditions";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-csat-rating" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CsatRatingMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private focusedIndex;
        private labelId;
        private errorId;
        private getItems;
        private handleSelect;
        private handleMouseEnter;
        private handleMouseLeave;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private focusOption;
        private getContainerClasses;
        private getOptionsContainerClasses;
        private getOptionClasses;
        private getIconClasses;
        private getLabelTextClasses;
        private getScoreClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderScore;
        private renderOption;
        private renderViewMode;
        private renderEditMode;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-emoji-mood-scale\n\n# Objective\nProvide a visual mood scale using expressive emoji faces to capture user sentiment quickly. It allows selecting a satisfaction level from very unsatisfied to very satisfied using custom-defined options within the groupRateItem contract.\n\n# Responsibilities\n- Behave as a member of the groupRateItem group, respecting all contract properties, events, states, and validation rules.\n- Accept rating options exclusively through declared item slots with numeric values; when items are declared, automatic range generation must be ignored.\n- Render five mood options arranged horizontally from very unsatisfied to very satisfied, using the visual content provided for each slot.\n- In editing mode, enable selection of a single option and signal when the value changes.\n- In viewing mode, render only the selected option statically; display a placeholder when no value is present.\n- Visually highlight the option under pointer focus; remove the highlight when the pointer leaves.\n- Update the current value and signal change when the user selects an option.\n- Signal when an option receives focus and when it loses focus.\n- Present an error state when required and no value is selected.\n- Display an error message when one is provided; if no error exists, display helper text when available.\n- Block interaction and show disabled visuals when disabled; block interaction while preserving selection visuals when read-only.\n- Allow navigation between options and selection of the focused option using keyboard input.\n- Communicate selection state, required status, and validity to assistive technologies; ensure labels and error messages are programmatically associated with the control group.\n\n# Constraints\n- Must define exactly five mood options through item slots.\n- Must not use automatic range values when custom items are declared.\n- Must remain non-interactive in view mode, when disabled, or when read-only.\n- Must clear pointer highlight when the cursor exits the component.\n- Must only signal change in response to user action.\n- Error messages take precedence over helper text.\n- Must adapt visual presentation for both light and dark modes.\n\n# Notes\n- The visual representation of each option is determined entirely by the content supplied in its item slot.";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class EmojiMoodScaleMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private focusedIndex;
        private handleOptionClick;
        private handleOptionFocus;
        private handleOptionBlur;
        private handleMouseEnter;
        private handleMouseLeave;
        private handleKeydown;
        private focusItem;
        private getSelectedIndex;
        private getItems;
        private getActiveValue;
        private getHasError;
        private getErrorMessage;
        private renderLabel;
        private renderHelperOrError;
        private getContainerClasses;
        private getOptionClasses;
        private renderOption;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-numeric-rating-nps\n\n# Objective\nA numeric rating selector that presents a scale of numbers for expressing satisfaction levels, commonly used for Net Promoter Score, customer satisfaction, and corporate evaluations. It allows choosing a value from a defined numeric range or from custom-provided options.\n\n# Responsibilities\n- Present options as a horizontal numeric scale.\n- Render custom items exactly as provided through the Item content area when available, disregarding any configured numeric range.\n- Automatically generate numeric options from a minimum to a maximum value using defined increments when no custom items are provided.\n- Allow selection of a single numeric value and communicate changes to the system.\n- Support clearing the selection to an empty state.\n- Enable interaction with options in edit mode unless the component is disabled or readonly.\n- In view mode, display the selected value as static text; when empty, show a placeholder dash and disable all interaction, hover effects, and supplementary text.\n- Preview the hovered option distinctly and clear the preview when focus or pointer leaves.\n- Keep the selected option visually distinct from unselected options.\n- Display a label when content is provided.\n- Display helper text beneath the options when no error is present.\n- Display error messages beneath the options when validation fails, replacing helper text.\n- Indicate invalid and required states when the field is mandatory and empty.\n- Notify the system when an option gains or loses focus in edit mode.\n- Adapt appearance for both light and dark presentation contexts.\n\n# Constraints\n- Must conform to the groupRateItem contract, using only the Label, Helper, and Item content areas.\n- Must not permit interaction or hover effects in view mode.\n- Must suppress helper text while an error message is shown in edit mode.\n- Must highlight only the individual hovered option during preview, never a cumulative range.\n- Must mute the appearance of disabled and readonly options and prevent active or hover styling on them.\n- Must ignore configured range and step values when custom items are present.\n\n# Notes\n- Common scales include 0\u201310 for NPS and 1\u20135 for CSAT, though the range remains configurable.\n- Designed for post-service feedback, training evaluations, vendor assessments, organizational climate surveys, and onboarding feedback.";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class NumericRatingNpsMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private focusedIndex;
        private handleOptionClick;
        private handleOptionFocus;
        private handleOptionBlur;
        private handleOptionMouseEnter;
        private handleOptionMouseLeave;
        private handleKeyDown;
        private focusOption;
        private getItems;
        private getSelectedIndex;
        private getGroupClasses;
        private getOptionClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderOptionLabel;
        private renderViewMode;
        private getViewDisplayValue;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-qualitative-feedback-tags.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-qualitative-feedback-tags\n\n# Objective\nProvide a qualitative feedback selection mechanism that allows users to choose predefined tags to explain their rating. It works alongside a numeric or emoji scale to contextualize the given score. Tags are configurable and support single selection only.\n\n# Responsibilities\n- Expose all properties defined by the groupRateItem contract: value, error, name, min, max, step, isEditing, disabled, readonly, and required.\n- Accept feedback options through configurable items, each carrying a mandatory numeric identifier and a visual label.\n- When custom options are provided, render exclusively those options and disregard any numeric range configuration.\n- When no custom options are provided, automatically generate options across the configured numeric range using the defined increment.\n- In editing mode, allow the user to select one option at a time, updating the current value and notifying the system of the change.\n- In editing mode, notify the system when the component or its options receive or lose focus.\n- In editing mode, update the preview state when the user points to an option, reverting when the pointer leaves.\n- In viewing mode, display the currently selected value as static text; show an em dash when no value exists. Disable all interaction, hover effects, helper text, and error messaging.\n- Prevent user interaction and value changes when disabled or readonly, and suppress change notifications.\n- Present an error state when the field is required but no value is selected; display any provided error message.\n- Expose the correct accessibility semantics for the container and each option, including selection status, requirement status, invalidity, and descriptive error references.\n- Support keyboard navigation between options using horizontal arrow keys and selection using confirmation keys.\n- Support only single selection at a time, where each new choice replaces the previous one.\n- Allow visual labels to consist of text, emojis, or icons as provided by the item configuration.\n\n# Constraints\n- The component must render options in a single horizontal row.\n- Custom options always take precedence over auto-generated numeric ranges.\n- Only one option may be selected at any given moment.\n- Interaction, hover effects, and informational messages must be completely suppressed in viewing mode.\n- Disabled and readonly states must block all user-driven changes and events.\n- Error messaging must appear below the options when applicable; helper text must appear only when no error is present.\n- A label, when provided, must appear above the options.\n- Visual states must distinguish clearly between normal, hovered, selected, disabled, readonly, and error conditions.\n- The component must support both light and dark appearance modes through semantic color application.\n\n# Notes\n- The visual representation of each option is determined entirely by the provided item content, enabling flexible use of numbers, emojis, or textual tags.\n- Although the original use case mentions multiple selection, this molecule adheres to the groupRateItem contract by enforcing single selection only.";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-qualitative-feedback-tags" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class QualitativeFeedbackTagsMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private labelId;
        private errorId;
        private hasFocus;
        private handleSelect;
        private handleFocusIn;
        private handleFocusOut;
        private handleKeydown;
        private handleOptionEnter;
        private handleOptionLeave;
        private handleOptionFocus;
        private handleOptionBlur;
        private getItems;
        private getActiveIndex;
        private getDisplayValue;
        private getOptionClasses;
        private renderLabel;
        private renderFeedback;
        private renderViewMode;
        private renderEditMode;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-rating-slider.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-rating-slider\n\n# Objective\nProvide a precision rating control that lets users express intensity, confidence, or preference along a continuous or discrete scale. It offers finer granularity than star ratings or NPS, supporting both auto-generated numeric ranges and custom-defined options for self-assessment or research contexts.\n\n# Responsibilities\n- Accept and emit the selected value as a number, or null when no selection exists\n- Render custom options when provided, using each option's declared numeric value as the selectable value\n- Generate a linear numeric scale from a minimum to a maximum using a defined step when custom options are not provided\n- Allow interaction for selection while in editing mode, including hover preview and click to confirm selection\n- Display the selected value statically in view mode, showing a dash indicator when no value is selected\n- Prevent value changes and interaction when disabled or readonly, while preserving the visible selection in readonly mode\n- Emit focus events when an option receives focus and blur events when focus leaves\n- Enter an error state when required and no value is selected\n- Display external error messages when provided; otherwise display helper content when available\n- Support keyboard navigation between adjacent options and keyboard confirmation of the current option\n- Communicate selection state, required status, and error conditions to assistive technologies\n- Present options in a linear horizontal arrangement that visually suggests a slider scale\n\n# Constraints\n- Must belong to the groupRateItem group and support Label, Helper, and Item content areas\n- Custom items must take precedence over min/max/step configuration\n- Must not show helper text or error indicators in view mode\n- Must not permit interaction or value changes while disabled or readonly\n- Must indicate invalid state only when required is true and value is null\n- Hover preview must not alter the committed selected value\n- Must maintain distinct visual treatments for normal, hovered, selected, disabled, readonly, and error states\n- Must respect dark mode visual semantics\n\n# Notes\n- Intended for self-assessment of skill level, confidence ratings, or preference surveys\n- Hover preview provides temporary visual feedback without committing a value until confirmed";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-rating-slider" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlRatingSliderMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private uid;
        private handleOptionClick;
        private handleOptionMouseEnter;
        private handleOptionMouseLeave;
        private handleGroupMouseLeave;
        private handleOptionFocus;
        private handleOptionBlur;
        private handleKeyDown;
        private previewHoverFromOption;
        private selectValueFromOption;
        private getOptionValue;
        private getIndexFromValue;
        private getItems;
        private getActiveValue;
        private isHighlighted;
        private getGroupClasses;
        private getOptionButtonClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderRatingOptions;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-star-rating.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-star-rating\n\n# Objective\nProvide a numeric rating selection mechanism that allows users to choose a value from 1 to 5. It serves corporate platforms such as training systems, internal product evaluation, supplier portals, and marketplaces. Typical uses include rating courses, suppliers, service interactions, and documents.\n\n# Responsibilities\n- Allow selection of a numeric rating from 1 through 5 when operating with default options\n- Render exclusively custom items when provided, honoring their individual numeric values and supplied visual representations\n- Display the provided label content in association with the rating field\n- In edit mode, enable interaction where hovering over an option temporarily highlights that option and all preceding options\n- Remove temporary highlight on mouse leave, restoring visual emphasis to the currently selected rating\n- Update the current rating to the chosen numeric value upon selection and report the change to the system\n- Report when the component receives or loses focus\n- In view mode, present the selected rating as static content without permitting interaction, hover feedback, error indication, or helper text\n- Show an em-dash symbol when no rating exists in view mode\n- Present error messaging and assume an error appearance in edit mode when an error condition is active\n- Present helper text in edit mode when no error condition exists and helper content is supplied\n- Block all interaction and assume a disabled appearance when disabled\n- Block value changes while preserving rating visibility when readonly\n- Expose the current selection, required status, and error condition to assistive technologies in a meaningful way\n- Permit navigation through options via keyboard and allow the focused option to be selected via keyboard action\n- Treat absence of selection as unset rather than zero\n\n# Constraints\n- Must conform to the groupRateItem group contract for properties, events, and slot definitions\n- Default rating scale is bounded to the defined minimum and maximum values\n- Presence of custom item slots disables default option generation\n- Hover and selection behaviors are suppressed while disabled or readonly\n- Error and helper presentations are restricted to edit mode\n- View mode hides interactive affordances and auxiliary text regardless of state\n- A required field without a selection must trigger the defined error validation behavior\n- Only numeric values are valid; unset represents no choice\n\n# Notes\n- Suitable for corporate training platforms, internal product reviews, supplier portals, and marketplace systems\n- When custom items are used, their slot content defines the visual representation entirely";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-star-rating" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlStarRatingMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private uid;
        private handleOptionClick;
        private handleOptionMouseEnter;
        private handleOptionMouseLeave;
        private handleOptionFocus;
        private handleOptionBlur;
        private handleOptionKeydown;
        private focusOption;
        private getRatingItems;
        private getActiveValue;
        private isItemActive;
        private getLabelId;
        private getHelpId;
        private getIsInvalid;
        private renderLabel;
        private renderHelperOrError;
        private renderHiddenInput;
        private renderStarIcon;
        private renderOption;
        private renderEditMode;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouprateitem/ml-thumbs-rating.defs" {
    export const group = "groupRateItem";
    export const skill = "# Metadata\n- TagName: grouprateitem--ml-thumbs-rating\n\n# Objective\nA binary rating molecule that allows users to choose between two opposing options, typically represented as positive and negative ratings. It follows the groupRateItem contract to provide a compact horizontal choice control that supports editing, viewing, and accessibility needs.\n\n# Responsibilities\n- Present exactly two selectable options defined by provided content items, each associated with a numeric rating value, arranged horizontally in a compact row.\n- Disregard minimum, maximum, and step settings when content items are present.\n- Display label content above the option row when provided.\n- In editing state: set the rating value when an option is chosen and announce the change.\n- In editing state: temporarily highlight an option while it is being hovered, and remove the highlight when hover ends.\n- In viewing state: show the chosen rating as a static display; show an empty indicator when no rating exists; prevent all interaction and change announcements.\n- Announce focus and blur interactions only during editing state.\n- Allow keyboard movement between options and confirmation of a selection using standard navigation keys, restricted to editing state.\n- Visually indicate and block interaction when disabled.\n- Visually indicate non-editable status while keeping the current selection visible when readonly.\n- Signal an invalid state to assistive technologies when a value is required but missing during editing.\n- Display an error message below the options when an error is provided during editing; display helper content instead when no error exists and helper content is available.\n- Conceal helper and error messages in viewing state.\n- Expose the container as a grouped set of selectable choices and each option as an individual choice with its selection state available to assistive technologies.\n\n# Constraints\n- Must always present exactly two options.\n- Must adhere strictly to the groupRateItem contract without adding new properties or behaviors.\n- Must not display scale boundaries or stepped values.\n- Must not permit value changes in viewing state, disabled state, or readonly state.\n- Must not show hover highlights, change announcements, or focus/blur communications in viewing state.\n- Must not display helper or error text in viewing state.\n- Must apply error visual treatment when required and unselected during editing, or when an explicit error is present.\n- Highlighting must affect only the specific hovered or selected option, never both options together as a range.\n- Must support rich text content within option labels.\n\n# Notes\n- The two options are typically visualized as opposing icons or labels such as thumbs up and thumbs down.\n- Dark mode color schemes must be respected for all visual states including default, hover, selected, error, disabled, and readonly.";
}
declare module "_102040_/l2/molecules/grouprateitem/ml-thumbs-rating" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ThumbsRatingMolecule extends MoleculeAuraElement {
        private msg;
        private static instanceCounter;
        private instanceId;
        slotTags: string[];
        value: number | null;
        error: string;
        name: string;
        min: number;
        max: number;
        step: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        private hoverValue;
        private get labelId();
        private get helperId();
        private get errorId();
        private canInteract;
        private getErrorState;
        private getDescribedBy;
        private getItems;
        private generateFallbackItems;
        private getGroupClasses;
        private getOptionClasses;
        private getOptionLabel;
        private handleOptionMouseEnter;
        private handleOptionMouseLeave;
        private handleOptionClick;
        private handleOptionFocus;
        private handleOptionBlur;
        private handleKeydown;
        private renderLabel;
        private renderHelperOrError;
        private renderOption;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupscancode/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code-1d';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-ocr';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-document';
    export class GroupScanCodeIndex extends StateLitElement {
        private cardScanCode1d;
        private cardScanCode;
        private cardScanOcr;
        private cardScanDocument;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-code-1d.defs" {
    export const group = "groupScanCode";
    export const skill = "# Metadata\n- TagName: groupscancode--ml-scan-code-1d\n\n# Objective\nA scanner specialized for reading linear 1D barcodes, including EAN-13, EAN-8, UPC-A, Code 128, and Code 39. It operates within the groupScanCode group, periodically emitting captured frames for external decoding while also attempting local decoding when available. Upon successful detection, it emits the barcode format and value. It supports camera selection, adjustable capture frequency, and manages distinct visual states for idle, open, capturing, loading, result, error, and disabled conditions.\n\n# Responsibilities\n- Adhere to the groupScanCode contract for properties, events, and slots.\n- Allow selection between rear and front cameras.\n- Adjust the frequency of frame capture when automatic capture is active.\n- Open the camera only upon user action via the Trigger or through the group's defined open flow, signaling when the camera becomes active.\n- Close the camera upon user action or through the group's defined close flow, signaling when the camera becomes inactive.\n- Periodically capture and emit frames for external decoding while the camera is open and automatic capture is enabled.\n- Attempt local decoding of 1D barcodes when a local decoding capability is available.\n- Emit the detected barcode format and value when a code is successfully read.\n- Emit a change notification when the decoded value is updated.\n- Transition to the Result state and present the decoded value through the Result slot or a default display when a value is available.\n- Display a processing indicator when loading is active, maintaining visual consistency with the capture state.\n- Block opening and capture interactions and show a disabled visual state when disabled.\n- Enter an Error state and display the error message when an error is provided.\n- Support custom labeling, helper text, trigger content, and result presentation through dedicated slots.\n\n# Constraints\n- Must only target linear 1D barcode formats as specified.\n- Must not emit detection events without both format and value.\n- Must cease frame capture when the camera closes or when disabled.\n- Must not access the camera before an explicit open action.\n- Must reflect the current operational state visually according to the group contract states: Idle, Open, Capturing, Loading, Result, Disabled, and Error.\n- Must remain visually consistent across light and dark themes.\n- Must present decoded values clearly for enterprise use cases including inventory, retail point-of-sale, logistics, pharmacy, and asset management.\n\n# Notes\n- Local decoding serves as a performance optimization; the component continues to support external decoding for all frames.\n- The molecule is optimized for corporate scanning scenarios requiring fast and reliable 1D barcode recognition.";
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-code-1d" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlScanCode1dMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        facing: string;
        autoCapture: boolean;
        captureInterval: number;
        disabled: boolean;
        loading: boolean;
        private isOpen;
        private isCapturing;
        private hasSupport;
        private lastEmittedValue;
        private videoEl;
        private stream;
        private autoCaptureTimer;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: any): void;
        private emitValueChange;
        private emitCapture;
        private emitDetect;
        private emitOpen;
        private emitClose;
        private openCamera;
        private closeCamera;
        private stopCamera;
        private handleAutoCaptureState;
        private stopAutoCapture;
        private captureFrame;
        private flashCapture;
        private tryLocalDecode;
        private handleTriggerClick;
        private handleTriggerKeydown;
        private handleCloseKeydown;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderResult;
        private renderTriggerContent;
        private getFrameClasses;
        private getVideoWrapperClasses;
        private getTriggerClasses;
        private getCaptureButtonClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-code.defs" {
    export const group = "groupScanCode";
    export const skill = "# Metadata\n- TagName: groupscancode--ml-scan-code\n\n# Objective\nAllow the user to capture a video frame from the device camera for code scanning purposes. The component manages the camera lifecycle (open, capture, close), supports front and rear camera selection, optional automatic periodic frame capture, and transitions between trigger, viewfinder, and result states based on whether a scan value has been obtained.\n\n# Responsibilities\n- Show a trigger button (from the Trigger slot or a default label) when the camera is closed and no value has been captured yet.\n- Open the device camera using getUserMedia with the facing constraint when the trigger button is clicked or openCamera is called.\n- Render a live video viewfinder while the camera is open.\n- Capture the current video frame to a PNG data URL and dispatch a capture custom event (bubbling, composed) with the image when the capture button is clicked.\n- In auto-capture mode, fire the capture event on a repeating interval defined by captureInterval.\n- Close the camera and stop all media tracks automatically when a non-null value is set.\n- Close the camera and dispatch a close custom event (bubbling, composed) when the close button is clicked or Escape is pressed.\n- Display the captured value (or custom Result slot content) and a \"scan again\" button after a successful capture.\n- Dispatch a change custom event (bubbling, composed) with the new value whenever the value property changes.\n- Dispatch an open custom event (bubbling, composed) when the camera stream becomes ready.\n- Show appropriate error messages for permission-denied, camera-not-found, and unknown camera errors.\n- Render an optional Label slot as a descriptive heading above the component.\n- Render an optional Helper slot as secondary hint text below the component; the Helper text is replaced by the error message when an error is present.\n- Stop all media tracks and cancel auto-capture timers when the component is disconnected from the DOM.\n- Block camera opening, capture, and scan-again actions when the disabled property is true.\n- Show a loading overlay on the viewfinder when the loading property is true.\n- Support light and dark color schemes through conditional class application.\n\n# Constraints\n- The camera must not open while disabled is true or while the camera is already open.\n- Frame capture must not occur when disabled, loading, the camera is not ready, or a capture is already in progress.\n- Auto-capture timer must be cleared before a new one is started to avoid duplicate intervals.\n- The component must not perform any code decoding or recognition; it only captures frames and emits them for external processing.\n- Setting value to null (via scan again) must reopen the camera; the component itself does not interpret the scanned data.\n- Media stream tracks must always be stopped when the camera is closed to release the hardware resource.";
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-code" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlScanCodeMolecule extends MoleculeAuraElement {
        private msg;
        private stream;
        private autoTimer;
        private errorId;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        facing: 'environment' | 'user';
        autoCapture: boolean;
        captureInterval: number;
        disabled: boolean;
        loading: boolean;
        private isOpen;
        private isCapturing;
        private cameraReady;
        disconnectedCallback(): void;
        updated(changedProps: Map<string, unknown>): void;
        private openCamera;
        private closeCamera;
        private startCamera;
        private stopCamera;
        private setupAutoCapture;
        private captureFrame;
        private getVideoElement;
        private handleTriggerClick;
        private handleCaptureClick;
        private handleScanAgain;
        private handleKeydown;
        private getRootClasses;
        private getActionButtonClasses;
        private getCaptureButtonClasses;
        private getViewfinderClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderTrigger;
        private renderResult;
        private renderViewfinder;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-document.defs" {
    export const group = "groupScanCode";
    export const skill = "# Metadata\n- TagName: groupscancode--ml-scan-document\n\n# Objective\nA scanner molecule that uses the device camera to detect document boundaries, allows manual refinement of detection corners, and produces a rectified cropped image of the document. It follows the groupScanCode contract for scanning workflows.\n\n# Responsibilities\n- Render the Label slot content above the scanner area when provided.\n- Render the Helper slot content below the scanner area when provided.\n- Render the Trigger slot as the control to open the camera while in the Idle state.\n- Open and close the camera according to the isOpen state, signaling open and close events at the appropriate times.\n- While the camera is active, continuously detect the document's four corners within the frame and maintain them as the active capture region.\n- Display the camera viewfinder with an overlay showing the document contour lines and four corner markers positioned at the active corners when in the Open state.\n- Provide visually distinct corner markers that indicate they can be manually adjusted.\n- Allow the user to manually reposition each of the four corners to redefine the capture region.\n- Provide visual feedback, such as a flash or pulse effect over the viewfinder, during capture.\n- Upon capture, generate a rectified and cropped image using the active corners and notify via the capture event with the processed image data.\n- When autoCapture is enabled, perform captures periodically according to the configured interval and notify via the capture event with the processed image data for each occurrence.\n- Display a loading indicator over the scanner area while processing or decoding results.\n- Block camera opening, capture, and manual adjustments when in a disabled state, and present the Trigger and scanner area as visually attenuated.\n- Enter a Result state when a value is provided externally, hiding the viewfinder and presenting the result.\n- Present the result using the Result slot when available; otherwise, display the value text as the default result.\n- Announce result updates using polite live region behavior.\n- Display error messages when provided, styled as an error, positioned below the scanner area, and associate them with accessibility attributes per the contract.\n- Open the camera when the trigger is activated with Enter or Space keys, and close the camera when the Escape key is pressed.\n- Maintain contract compatibility by keeping value as a string and emitting a change event when value is modified externally.\n- Apply dark mode semantic pairing for surfaces, borders, text, error states, and highlights per the contract.\n\n# Constraints\n- The camera must only open when the component is not disabled.\n- Corner detection must remain active only while the camera is open.\n- Manual corner adjustments must override automatic detection for the active capture region.\n- Capture must not occur if the component is disabled or loading.\n- The processed image data must correspond to the region defined by the active corners at the moment of capture.\n- Auto-capture must respect the specified interval and must not occur when disabled.\n- Error messages must be presented only through the error property.\n- The viewfinder must remain a visual element without keyboard focus.\n- Visual states for idle, open, capturing, loading, result, error, and disabled must not overlap in presentation.\n\n# Notes\n- The component operates within the groupScanCode contract expectations for scanning molecules.\n- Dark mode presentation must follow semantic pairing defined by the contract.";
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-document" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlScanDocumentMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        facing: string;
        autoCapture: boolean;
        captureInterval: number;
        disabled: boolean;
        loading: boolean;
        private isOpen;
        private corners;
        private manualOverride;
        private isCapturing;
        private videoReady;
        private videoEl?;
        private overlayEl?;
        private stream;
        private detectionTimer;
        private autoCaptureTimer;
        private draggingIndex;
        private errorId;
        private boundPointerMove;
        private boundPointerUp;
        private boundEscape;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private openCamera;
        private closeCamera;
        private handleEscapeKey;
        private bindEscapeListener;
        private unbindEscapeListener;
        private startDetectionLoop;
        private stopDetectionLoop;
        private setDefaultCorners;
        private captureFrame;
        private getCornerBounds;
        private setupAutoCapture;
        private clearAutoCapture;
        private handleCornerPointerDown;
        private handlePointerMove;
        private handlePointerUp;
        private getWrapperClasses;
        private getViewfinderClasses;
        private getTriggerClasses;
        private getCaptureClasses;
        private getCornerHandleClasses;
        private hasResult;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderTrigger;
        private renderResult;
        private renderViewfinder;
        private handleTriggerClick;
        private handleTriggerKeydown;
        private handleCaptureClick;
        private handleCloseClick;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-ocr.defs" {
    export const group = "groupScanCode";
    export const skill = "# Metadata\n- TagName: groupscancode--ml-scan-ocr\n\n# Objective\nEnable users to capture printed text using the device camera and optical character recognition, providing a live preview with a defined capture area, and presenting recognized text for review or correction before confirmation.\n\n# Responsibilities\n- Present an activation element that opens the camera interface; use custom content when provided, otherwise show a default activation element.\n- Open the camera preview when activated and signal that the interface is now active.\n- Display the live camera feed while the interface remains open.\n- Provide a capture control during live preview that is identifiable to assistive technologies.\n- Emit the captured image when the user triggers a capture.\n- Support continuous automatic capture at configured intervals while the camera interface is active, if enabled.\n- Transition to a result state when recognized text is supplied externally, replacing the live preview with the text outcome.\n- Notify when the text value changes due to external updates.\n- Display a customizable result region for text editing when provided; otherwise present the text in a non-editable format.\n- Display optional supplementary information above and below the scanner area.\n- Block camera activation and visually indicate unusability when the component is disabled.\n- Display a processing state that prevents additional captures until processing completes.\n- Close the camera interface and signal closure when dismissed manually or after presenting a result.\n- Handle camera permission denials or hardware unavailability by entering an error state and presenting a clear message.\n- Announce result changes to assistive technologies in a non-intrusive manner.\n- Support standard keyboard patterns for activating the trigger and dismissing the interface.\n\n# Constraints\n- The activation element must support keyboard interaction following established accessibility conventions.\n- The capture control must be clearly identifiable to users of assistive technologies.\n- Camera interaction must be blocked during processing or when the component is disabled.\n- Result updates must be communicated to assistive technologies without demanding immediate attention.\n- Visual presentation must adapt to both light and dark themes.\n- Distinct visual treatment must separate idle, loading, error, and result states.\n- Disabled state must reduce visual prominence and remove interactive affordances from the trigger.\n- The live preview must only appear while the camera interface is deliberately active.\n- A visual indicator defining the capture zone must overlay the live preview.\n- The result display must fully replace the camera preview when text is available.\n\n# Notes\n- The component depends on external systems to supply recognized text to enter the result state.\n- Continuous capture is optional and controlled by external configuration.\n- Custom content for activation and result regions is supplied through designated content areas.";
}
declare module "_102040_/l2/molecules/groupscancode/ml-scan-ocr" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlScanOcrMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        facing: string;
        autoCapture: boolean;
        captureInterval: number;
        disabled: boolean;
        loading: boolean;
        private isOpen;
        private localError;
        private isCapturing;
        private videoEl;
        private canvasEl;
        private stream;
        private captureTimer;
        disconnectedCallback(): void;
        updated(changed: Map<string, unknown>): void;
        private openCamera;
        private attachStream;
        private closeCamera;
        private stopCamera;
        private startAutoCapture;
        private stopAutoCapture;
        private captureFrame;
        private handleTriggerClick;
        private handleTriggerKey;
        private handleCaptureClick;
        private handleRootKey;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderTrigger;
        private renderResult;
        private renderCamera;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupsearchcontent/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-history';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-faceted-search';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-filters';
    export class GroupSearchContentIndex extends StateLitElement {
        private cardSearchBar;
        private cardSearchHistory;
        private cardFacetedSearch;
        private cardSearchFilters;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-faceted-search.defs" {
    export const group = "groupSearchContent";
    export const skill = "# Metadata\n- TagName: groupsearchcontent--ml-faceted-search\n\n# Objective\nA faceted search component that presents filter options grouped by facets, allows searching within facet options, displays selected filters as breadcrumbs above the search field, and communicates user selections to the containing page through events.\n\n# Responsibilities\n- Use only the group slot tags: Label, Helper, Suggestion, and Empty.\n- Render the Label slot content above the search field to display breadcrumbs of selected filters provided by the page.\n- Represent each facet option through a Suggestion slot, where the slot's value attribute carries the selection value and the slot content carries the display text including result counts.\n- Update the search query as the user types and emit a search event carrying the current query after a configured debounce period.\n- Upon selecting a suggestion, set the component value to the suggestion's value, update the query to the suggestion's label, emit a change event with the selected value, and close the suggestions panel.\n- Upon pressing Enter without an active suggestion selection, confirm the raw query text as the value and emit a change event with that value.\n- Upon clearing the field, reset the value to null, clear the query, and emit a clear event.\n- Emit a focus event when the search field gains focus and a blur event when it loses focus.\n- Block user interaction and suppress change and search events when the component is disabled.\n- Keep the suggestions panel open and indicate a loading state while loading is active.\n- Render the Empty slot content inside the suggestions panel when no options are available.\n- Support keyboard navigation to move through suggestions, confirm a selection, and close the panel.\n- Expose selected facet filters through the change event value for the page to interpret, since the component exposes only a single value.\n- Communicate the panel's open or closed state, the list structure, and the highlighted option to assistive technologies.\n- Indicate an invalid state and link the field to its error description when an error is present.\n\n# Constraints\n- Must not use slot tags outside the defined group set: Label, Helper, Suggestion, and Empty.\n- The page is responsible for providing breadcrumb content via the Label slot; the component only renders it in the designated position.\n- Debounce timing must be configurable but always applied before emitting search events.\n- The change event must always carry the current value, whether from suggestion selection or free-text confirmation.\n- When disabled, the component must block interaction and must not emit change or search events.\n- The suggestions panel must remain open during loading even if the option list is empty.\n- Keyboard navigation must allow traversal of available suggestions without losing focus.\n- The value emitted in change represents the serialized or structured filter state for all facets, managed by the consuming page.\n- An error state must only trigger invalid marking and error association when the error value is non-empty.\n\n# Notes\n- The component acts as a controlled input where the page manages the meaning of value across multiple facets.\n- The count displayed with each option is part of the provided Suggestion content and is not computed or altered by the component.\n- Selected filters are visually represented through the Label slot content, not maintained as internal component state.";
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-faceted-search" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class FacetedSearchMolecule extends MoleculeAuraElement {
        private msg;
        private instanceId;
        private searchTimer;
        private isPointerDown;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        debounce: number;
        disabled: boolean;
        loading: boolean;
        private query;
        private isOpen;
        private highlightedIndex;
        updated(changed: Map<string, unknown>): void;
        private handleInput;
        private handleKeyDown;
        private handleFocus;
        private handleBlur;
        private handleClear;
        private handleSuggestionClick;
        private handlePanelPointerDown;
        private handlePanelPointerUp;
        private scheduleSearch;
        private confirmSelection;
        private confirmFreeText;
        private clearValue;
        private updateQueryFromValue;
        private getSuggestionItems;
        render(): any;
        private renderLabel;
        private renderSuggestions;
        private renderFeedback;
        private getInputClasses;
        private getClearButtonClasses;
        private getPanelClasses;
        private getItemClasses;
    }
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-search-bar.defs" {
    export const group = "groupSearchContent";
    export const skill = "# Metadata\n- TagName: groupsearchcontent--ml-search-bar\n\n# Objective\nProvide a search field that accepts text entry, presents inline suggestions, allows clearing the entry, and communicates loading and empty states. It confirms user selections and notifies when text changes, selections are made, or the field is cleared.\n\n# Responsibilities\n- Use Label, Helper, Suggestion, and Empty content areas as defined by the groupSearchContent contract.\n- Display a search field with a leading magnifying glass icon.\n- Provide a clear action that appears when text is present and the field is active.\n- Update the current search text as the user types, wait for a brief pause, then notify that a search should be performed with the current text.\n- Confirm the current text as the chosen value when the user submits, and notify that the value has changed.\n- When a suggestion is chosen, set the chosen value to that suggestion's value, update the displayed text to match the suggestion's label, and notify that the value has changed.\n- When cleared, remove all text, reset the chosen value, and notify that the field has been cleared.\n- Present a loading indicator within the suggestions area when loading is active, while still allowing text entry unless the field is inactive.\n- Show empty-state content as a no-results message when no suggestions are available and loading is not active.\n- Open the suggestions area when the user is typing or when suggestions exist.\n- Notify when the input receives focus and when it loses focus.\n- When inactive, prevent interaction with the input and clear action, and suppress search, change, and clear notifications.\n- Expose accessibility semantics so assistive technologies recognize the input controls a list of options, know whether the list is shown, and understand that autocomplete offers choices from that list.\n- Identify the suggestions container and each item within it with appropriate accessibility roles, indicating which item is selected or highlighted.\n- When an error is present, mark the input as invalid and link the error message as its description.\n\n# Constraints\n- The clear action must only appear when text is present and the field is active.\n- Label content must appear above the input when provided.\n- Helper content must appear below the input when provided and no error is present.\n- An error message must appear below the input when present, and must take precedence over helper content.\n- The suggestions area must appear inline below the input without complex dropdown behavior.\n- The inactive state must appear visually dimmed and must suppress hover or focus styling on interactive elements.\n- The error state must apply an error appearance to the input border and error text color, with appropriate dark-mode presentation.\n- The field must not perform search notifications while inactive.\n- The field must not perform change or clear notifications while inactive.\n\n# Notes\n- Suggestions are rendered inline and require only simple panel behavior.";
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-search-bar" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSearchBarMolecule extends MoleculeAuraElement {
        private msg;
        private debounceTimer;
        private componentId;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        debounce: number;
        disabled: boolean;
        loading: boolean;
        private query;
        private isOpen;
        private highlightIndex;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private handleClearClick;
        private handleSuggestionClick;
        private scheduleSearch;
        private confirmQuery;
        private confirmSuggestion;
        private getSuggestions;
        private getInputClasses;
        private getPanelClasses;
        private getSuggestionClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderSuggestions;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-search-filters.defs" {
    export const group = "groupSearchContent";
    export const skill = "# Metadata\n- TagName: groupsearchcontent--ml-search-filters\n\n# Objective\nProvide a search interface with a text field, an expandable panel of selectable options, and removable active selection chips. It allows users to search by typing, choose from available options, manage active selections, and communicate all changes to the surrounding system.\n\n# Responsibilities\n- Display a text input that reflects the user's current typing\n- Communicate the current search text to the system after the user pauses typing for a configurable duration\n- Confirm the typed text as the active selection and communicate it to the system when the user submits without choosing from the panel\n- When the user picks an option from the panel, set it as the active selection, update the input to show the option's label, communicate the selection to the system, and close the panel\n- Toggle the options panel open and closed via a dedicated control labeled \"Filters\"\n- Present available options in the panel from the contract-defined suggestion content\n- Show the designated empty content when no options are available\n- Arrange elements vertically: label above, search field and filter control in a row, active chips below the field, and the options panel below the chips when open\n- Display active selections as removable chips below the search bar\n- Active chips must appear as pills showing the confirmed label with a visible removal control\n- When a chip is removed, clear the active selection and input text, communicate the removal to the system, and communicate an empty selection\n- Show the count of active selections on the \"Filters\" control\n- Display a loading indicator in the panel while options are being fetched\n- Each option in the panel must display hover styles and a visual selection state\n- Notify the system when the input receives focus and when it loses focus\n- Prevent all interaction when the component is disabled, including typing, toggling the panel, selecting options, and removing chips\n- Show the contract-defined label above the input\n- Show the contract-defined helper text below the component when provided and no error exists\n- Show an error indicator with error text and a contrasting border on the input when an error is present\n\n# Constraints\n- Must exclusively use the contract content areas: Label, Helper, Suggestion, and Empty\n- Search communications must contain only the current text being typed\n- Selection change communications must contain the confirmed choice, which is empty when cleared\n- Removal communications must only occur when the user dismisses an active chip\n- The active selection count must read as zero when nothing is confirmed, and one when a selection exists\n- The panel must only open or close via the \"Filters\" control, or close upon option selection\n- All interactive elements must be inactive when the component is disabled\n- Error display takes precedence over helper text display\n- Visual presentation must adapt to both light and dark modes\n\n# Notes\n- The pause duration before communicating typing changes is configurable\n- Available options are provided through the contract's Suggestion content area\n- The panel should visually appear as an elevated surface with a border and overlay background";
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-search-filters" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class SearchFiltersMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        debounce: number;
        disabled: boolean;
        loading: boolean;
        private query;
        private isOpen;
        private selectedLabel;
        private highlightedIndex;
        private debounceTimer;
        private inputId;
        private listboxId;
        private labelId;
        private errorId;
        disconnectedCallback(): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private getSuggestions;
        private getActiveSelectionCount;
        private handleInput;
        private handleKeyDown;
        private confirmQuery;
        private selectSuggestion;
        private stripHtml;
        private handleClear;
        private handleRemoveChip;
        private handleTogglePanel;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getLabelClasses;
        private getInputRowClasses;
        private getInputWrapperClasses;
        private getInputClasses;
        private getClearButtonClasses;
        private getFilterButtonClasses;
        private getBadgeClasses;
        private getChipsContainerClasses;
        private getChipClasses;
        private getChipRemoveClasses;
        private getPanelClasses;
        private getPanelContentClasses;
        private getSuggestionClasses;
        private getEmptyClasses;
        private getLoadingClasses;
        private getHelperClasses;
        private getErrorClasses;
        private renderLabel;
        private renderClearButton;
        private renderFilterButton;
        private renderChips;
        private renderPanel;
        private renderPanelContent;
        private renderSuggestion;
        private renderFeedback;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-search-history.defs" {
    export const group = "groupSearchContent";
    export const skill = "# Metadata\n- TagName: groupsearchcontent--ml-search-history\n\n# Objective\nProvide a search input that reveals a dropdown panel of recent and saved searches when focused and empty, and switches to live search suggestions as the user types. Users may select a suggestion or confirm their query to set the field value, with support for loading states, clearing, and disabled states.\n\n# Responsibilities\n- Display a search input accompanied by label content above it and helper content below it.\n- When the input is focused and contains no text, open a panel below the input showing grouped recent searches and saved searches.\n- As the user types, update the visible query and transition the panel to show live result suggestions.\n- Notify the host of the current query after the user pauses typing for the configured debounce duration.\n- When the user selects a suggestion, populate the input with the suggestion's value and label, notify the host that the value has changed, and close the panel.\n- When the user presses Enter without selecting a suggestion, confirm the current query as the input value, notify the host of the change, and close the panel.\n- When the user clears the input, reset the value and query, notify the host of the clear action, and restore the recent/saved searches panel if the input remains focused.\n- Show a loading indicator inside the suggestions panel while results are being fetched, keeping the panel open.\n- Prevent focus, typing, selection, and all host notifications when the component is in a disabled state.\n- Notify the host when the input gains or loses focus.\n- Allow navigation through suggestions using arrow keys, confirmation with Enter, and panel closure with Escape.\n- Show empty-state content when no suggestions are available for the current query state.\n- Ensure the input is described by its label and any provided error message for accessibility purposes.\n- Accept recent searches and saved searches as two distinct groups of suggestion items without requiring separate configuration for each group.\n\n# Constraints\n- The suggestions panel must only open when the input is focused.\n- The panel must close after a selection or Enter confirmation and remain closed until the input is refocused.\n- Query notifications to the host must not occur during active typing; they must only happen after the debounce pause.\n- The input must be empty to show recent and saved searches; any non-empty query must show live result suggestions.\n- No suggestions may be selected, typed, or notified while disabled.\n- Keyboard navigation must not move focus away from the input.\n- Error indicators must only appear when an error is explicitly provided.\n\n# Notes\n- Recent searches and saved searches are provided as two distinct groups of suggestion items.\n- The debounce duration determines how long the user must pause typing before the host is notified.";
}
declare module "_102040_/l2/molecules/groupsearchcontent/ml-search-history" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSearchHistoryMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        debounce: number;
        disabled: boolean;
        loading: boolean;
        private query;
        private isOpen;
        private focusedSuggestion;
        private debounceTimer;
        private inputId;
        private labelId;
        private errorId;
        handleIcaStateChange(key: string, value: any): void;
        private handleInput;
        private handleFocus;
        private handleBlur;
        private handleClear;
        private handleKeyDown;
        private handleSuggestionClick;
        private selectSuggestion;
        private scrollFocusedIntoView;
        private getInputClasses;
        private getSuggestionClasses;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderClearButton;
        private renderSuggestions;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectfileforupload/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-preview';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-upload-file-list';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-metadata-uploader';
    export class GroupSelectFileForUploadIndex extends StateLitElement {
        private cardDropzone;
        private cardPreview;
        private cardUserPhoto;
        private cardFileList;
        private cardMetadata;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-file-metadata-uploader.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: groupselectfileforupload--ml-file-metadata-uploader\n\n# Objective\nEnable users to select files via click or drag-and-drop within a designated area, while accommodating supplementary metadata inputs in an integrated customizable region. The molecule manages file validation, maintains the active selection, communicates rejections, and respects disabled and loading states.\n\n# Responsibilities\n- Display an associated label when one is provided.\n- Present a clickable and droppable area for file selection.\n- Provide a customizable region where additional content, such as metadata fields, can be placed.\n- Maintain the current set of selected files and update it only when incoming files pass validation.\n- Validate incoming files against permitted types, size limits, and quantity limits before accepting them.\n- Notify the external system when files are rejected, specifying the reason and identifying the rejected files.\n- Preserve the existing selection unchanged when all incoming files are invalid.\n- Visually indicate when files are being dragged over the selection area.\n- Prevent all user interaction and ignore dragged files when disabled, keeping the selection unchanged.\n- Prevent all user interaction and indicate an active loading state when loading is in effect.\n- Accept document type options as content within the customizable region rather than through separate settings.\n- Allow metadata field validation to be controlled externally, showing a visual error indication only when instructed.\n- Display assistance text below the selection area when it is provided and no error is active.\n- Communicate only file rejection scenarios internally; the external system must compose and submit the final file and metadata object.\n\n# Constraints\n- The current selection must not change if incoming files fail validation.\n- All interaction and file updates must be blocked while the molecule is disabled or loading.\n- Assistance text must be hidden when an error state is active.\n- The molecule must not include built-in inputs or storage for metadata fields; these must reside within the customizable region.\n- The molecule must not trigger final submission actions; assembly of the complete file and metadata payload is handled externally.\n- Visual errors on metadata fields must appear only when instructed by the external system, not by internal logic.\n\n# Notes\n- The customizable region is intended to host metadata inputs, but the molecule does not track or validate the values entered there.\n- Distinct visual treatments for dragging, disabled, loading, and error states must be clearly distinguishable.";
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-file-metadata-uploader" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlFileMetadataUploaderMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        name: string;
        private isDragging;
        private inputId;
        private labelId;
        private errorId;
        private validateFiles;
        private isFileTypeAccepted;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleFileInputChange;
        private processFiles;
        private handleRemoveFile;
        private handleDropZoneClick;
        private handleDropZoneKeyDown;
        private formatFileSize;
        private getDropZoneClasses;
        private getFileItemClasses;
        private getRemoveButtonClasses;
        private renderLabel;
        private renderDropZone;
        private renderDefaultTrigger;
        private renderDragActiveState;
        private renderLoadingState;
        private renderSelectedFiles;
        private renderFileItem;
        private renderMetadataSlot;
        private renderFeedback;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: groupselectfileforupload--ml-file-upload-dropzone\n\n# Objective\nAllow the user to select one or more files for upload by clicking a drop zone area or dragging and dropping files onto it. The component validates selected files against type, size, and count constraints before accepting them, maintains the accumulated list of accepted files, and gives visual feedback for drag, error, loading, and disabled states.\n\n# Responsibilities\n- Open the native file picker when the drop zone is clicked or activated with Enter or Space.\n- Accept files dragged and dropped onto the zone and process them the same way as picker-selected files.\n- Validate each incoming file against the accept pattern (extension or MIME type), the maxSizeKb limit, and the maxFiles count limit before adding it to the value.\n- Dispatch a \"reject\" custom event for each batch of files that fail validation, including the files and the rejection reason (\"type\", \"size\", or \"count\").\n- In single-file mode (multiple = false), replace any existing file with the first valid incoming file.\n- In multi-file mode (multiple = true), append valid incoming files up to the maxFiles limit.\n- Display the list of accepted files with their names and formatted sizes, and provide a remove button for each entry.\n- Render a loading indicator and suppress all interaction while loading = true.\n- Render an error message from the error property, replacing the helper text when both are present.\n- Apply a highlighted drag-over appearance while files are being dragged over the zone.\n- Render an optional Label slot above the zone and an optional Helper slot below it.\n- Support a Trigger slot to replace the default icon-and-text drop zone content.\n\n# Constraints\n- All interaction (click, keyboard, drag-and-drop, remove) must be blocked when disabled = true or loading = true.\n- Files that fail type, size, or count validation must never be added to value.\n- In single-file mode, value must never contain more than one file.\n- The drop zone must not be focusable (tabindex = -1) when disabled or loading.\n- The error message must take precedence over the helper text; both must not be shown simultaneously.\n- The hidden file input value must be cleared after each selection so the same file can be re-selected.\n- File size rejection is based on the file's byte size divided by 1024 compared against maxSizeKb; a maxSizeKb of 0 means no size limit.\n- A maxFiles of 0 means no file count limit in multi-file mode.";
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlFileUploadDropzoneMolecule extends MoleculeAuraElement {
        private msg;
        private inputId;
        private labelId;
        private errorId;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private handleZoneClick;
        private handleZoneKeydown;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleInputChange;
        private handleRemoveFile;
        private processFiles;
        private validateFiles;
        private getAvailableSlots;
        private isFileTypeAccepted;
        private formatFileSize;
        private getInputElement;
        render(): any;
        private renderTriggerContent;
        private renderFileList;
    }
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-preview.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: groupselectfileforupload--ml-file-upload-preview\n\n# Objective\nAllow the user to select one or more files for upload through a clickable drop zone or drag-and-drop, then display a visual preview grid of the accepted files. Image files are shown as thumbnail previews; non-image files display a \"no preview\" placeholder. The component validates files against type, size, and count constraints and manages object URLs for image thumbnails.\n\n# Responsibilities\n- Open the native file picker when the trigger zone is clicked or activated with Enter or Space.\n- Accept files dragged and dropped onto the zone and process them identically to picker-selected files.\n- Validate each incoming file against the accept pattern, the maxSizeKb limit, and the maxFiles count limit before accepting it.\n- Dispatch a \"reject\" custom event for each group of rejected files, including the files and the rejection reason (\"type\", \"size\", or \"count\").\n- In single-file mode (multiple = false), keep only the first valid incoming file; in multi-file mode append valid files up to the maxFiles limit.\n- Create and cache an object URL for each accepted image file and display it as a thumbnail; revoke the URL when the corresponding file is removed or the component is disconnected.\n- Display accepted files in a grid with a thumbnail (or \"no preview\" text), file name, formatted file size, and a remove button per entry.\n- Show the trigger zone label as \"Add more files\" in multi-file mode or \"Replace file\" in single-file mode once at least one file has been accepted.\n- Render an overlay loading spinner on the trigger zone while loading = true.\n- Show an error message from the error property or a helper text from the Helper slot below the zone.\n- Support Label, Helper, and Trigger slots for custom labelling, hints, and trigger zone content.\n\n# Constraints\n- All interaction (click, keyboard, drag-and-drop, remove) must be blocked when disabled = true or loading = true.\n- Files that fail type, size, or count validation must never be added to value.\n- Object URLs must be revoked for any file that is removed from value and for all files when the component is disconnected from the DOM.\n- In single-file mode, value must never contain more than one file.\n- The error message takes precedence over the helper text; both must not appear simultaneously.\n- The custom Trigger slot content is only shown when value is empty; once files are present the default trigger label is used instead.\n- File size comparison uses the raw byte size against maxSizeKb * 1024; a maxSizeKb of 0 means no size limit.\n- A maxFiles of 0 means no file count limit in multi-file mode.";
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-preview" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlFileUploadPreviewMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private previewUrls;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleTriggerKeydown;
        private handleInputChange;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleRemoveFile;
        private processFiles;
        private isAcceptedType;
        private syncPreviewUrls;
        private revokeAllPreviews;
        private getFileKey;
        private getPreviewUrl;
        private getContainerClasses;
        private getDropZoneClasses;
        private getFileItemClasses;
        private getRemoveButtonClasses;
        private formatSize;
        private renderLabel;
        private renderHelperOrError;
        private renderTriggerContent;
        private renderLoadingIndicator;
        private renderFileList;
        private getFileInput;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-upload-file-list.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: groupselectfileforupload--ml-upload-file-list\n\n# Objective\nPresent a list of files intended for upload, enabling users to inspect file details, monitor upload progress, discard unwanted files, and add files through browsing or drag-and-drop, while enforcing validation rules and responding to states that prevent interaction, restrict editing, indicate loading, or signal errors.\n\n# Responsibilities\n- Display a label when one is provided.\n- Display helper text when available and no error is active.\n- Offer a target area for file selection and drag-and-drop operations, with visual feedback during drag interactions.\n- List every file currently in the selection.\n- For each file, show its name and size in a human-readable format.\n- For each file, show an indicator representing its file type.\n- For each file, show a progress indicator that reflects whether the upload is ongoing or finished.\n- Allow users to remove individual files when interaction is permitted and the component is not restricted to read-only.\n- Update the displayed list to exclude any removed file.\n- Prevent file removal and ignore drag-and-drop input when interaction is blocked.\n- Show an error message and apply an error appearance when an error condition is supplied.\n- Show helper text instead of the error message when no error condition exists.\n- Evaluate newly selected or dropped files against acceptance criteria for type, size limit, and quantity limit.\n- Communicate the reason when files are rejected based on validation criteria.\n- Visually emphasize the drop target while files are being dragged over it.\n\n# Constraints\n- Behavior must remain within the defined functional contract.\n- Progress indicators must collectively reflect the global upload state.\n- Removal must not affect the list when interaction is blocked.\n- Error messages must override helper text.\n- File type indicators must derive from the file's format or extension.\n- File sizes must be presented in readable units.\n- Read-only restriction must suppress removal options without altering the list content.\n\n# Notes\n- The component maintains synchronization between the displayed list and the underlying file collection.\n- Validation and drag-and-drop behavior follow the standards of the group contract.";
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-upload-file-list" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class UploadFileListMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private fileInput?;
        private uid;
        private handleTriggerClick;
        private handleTriggerKeydown;
        private handleInputChange;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleRemoveFile;
        private validateAndMergeFiles;
        private dispatchRejectEvents;
        private matchesAccept;
        private formatSize;
        private getFileExtension;
        private getDropZoneClasses;
        private getFileRowClasses;
        private getTypeBadgeClasses;
        private getRemoveButtonClasses;
        private renderLabel;
        private renderHelperOrError;
        private renderTriggerContent;
        private renderFileList;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload.defs" {
    export const group = "groupSelectFileForUpload";
    export const skill = "# Metadata\n- TagName: groupselectfileforupload--ml-user-photo-upload\n\n# Objective\nEnable users to select a profile photo through click or drag-and-drop, enforce image-only validation and size/quantity limits, and present a thumbnail preview of the accepted image.\n\n# Responsibilities\n- Provide an interactive trigger area that initiates file selection when activated by click, touch, or keyboard.\n- Support dragging files over the trigger area and visually signal when a drop is possible.\n- Accept only image files; reject any non-image selections.\n- Validate every dropped or selected file against the group contract limits for file size and total count.\n- Hold the set of valid selected files as the current value.\n- Notify when files are rejected, specifying whether the failure was due to file type, size, or count, without retaining the invalid files in the value.\n- Generate and display a thumbnail preview representing the content of the accepted image file.\n- When single-file mode is active, preview only the first valid file.\n- Allow the user to remove a file from the current selection, updating the value accordingly.\n- Ignore all selection attempts and drag-and-drop actions while disabled.\n- Ignore all selection attempts and indicate a loading state while processing.\n- Show an error message and treat the field as invalid whenever an error condition is present.\n- Show helper information when no error is present and helper content is provided.\n- Ensure the trigger area is reachable and operable via keyboard.\n\n# Constraints\n- Only image files may be accepted; all other file types must be rejected.\n- Invalid files must never appear in the current value.\n- The preview must represent the actual accepted image, not a generic placeholder.\n- Selection and drag-and-drop must be non-interactive during disabled or loading states.\n- Error messages must be presented instead of helper content when both are applicable.\n- Keyboard interaction must open the file picker without breaking standard focus navigation.\n- Drag state signaling must activate when files are dragged over the area and deactivate when they leave or are dropped.\n\n# Notes\n- Thumbnail generation depends on the successfully validated file content.\n- Behavior and validation rules align with the groupSelectFileForUpload contract.";
}
declare module "_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlUserPhotoUploadMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: File[];
        error: string;
        multiple: boolean;
        accept: string;
        maxSizeKb: number;
        maxFiles: number;
        disabled: boolean;
        loading: boolean;
        private isDragging;
        private previewUrl;
        private previewFile;
        private uid;
        handleIcaStateChange(key: string, value: any): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleTriggerKeyDown;
        private handleInputChange;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleRemove;
        private processFiles;
        private dispatchRejects;
        private isImageFile;
        private isAcceptedType;
        private updatePreview;
        private revokePreview;
        private isBusy;
        private openFilePicker;
        private formatSize;
        private getTriggerClasses;
        private getRemoveButtonClasses;
        render(): any;
        private renderLabel;
        private renderTriggerContent;
        private renderPreview;
        private renderFileList;
        private renderFeedback;
    }
}
declare module "_102040_/l2/molecules/groupselectmany/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectmany/ml-dual-list-select';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-popover-multi-select';
    import '/_102040_/l2/molecules/groupselectmany/ml-tree-multi-select';
    export class GroupSelectManyIndex extends StateLitElement {
        private cardDualList;
        private cardCheckboxes;
        private cardDropdown;
        private cardPopover;
        private cardTree;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupselectmany/ml-dual-list-select.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-dual-list-select\n\n# Objective\nAllow the user to select multiple items from a side-by-side two-panel layout. The left panel shows available (unselected) items and the right panel shows selected items. Users transfer items between panels using per-item Add/Remove buttons or bulk \"Add all\" / \"Remove all\" actions. The component supports optional search filtering, grouping, min/max selection limits, and a read-only view mode.\n\n# Responsibilities\n- Render two panels side by side: one for available items and one for selected items, each showing their item count.\n- Move a single item from the available panel to the selected panel when its Add button is clicked, and back when its Remove button is clicked.\n- Move all transferable available items to the selected panel when \"Add all\" is clicked, respecting the maxSelection limit.\n- Move all removable selected items back to the available panel when \"Remove all\" is clicked, respecting the minSelection limit.\n- Derive the available list as all items not present in value, and the selected list as all items present in value.\n- Filter both panels simultaneously by the search query when searchable = true and the user types in the search field.\n- Render items inside named group sections with a group label header when items belong to a Group slot.\n- Store the multi-selection as a comma-separated string in value and dispatch a \"change\" custom event on every mutation.\n- Prevent adding an item when maxSelection is set and the selection is already at the limit.\n- Prevent removing an item when minSelection (or required = true) would be violated.\n- Disable per-item buttons and bulk action buttons when the corresponding action is not permitted.\n- Display a loading indicator and suppress all interaction when loading = true.\n- Show an error message or helper text below the component when in editing mode.\n- Render a compact chip-based view of the selected items when isEditing = false, with a placeholder when nothing is selected.\n- Emit \"focus\" when focus enters the component and \"blur\" when it leaves (in editing mode).\n- Render a hidden input with the form name when the name property is set.\n\n# Constraints\n- All item-transfer actions must be blocked when disabled = true, readonly = true, or loading = true.\n- Actions are also blocked when isEditing = false (view mode), which renders the selected items as read-only chips.\n- Adding an item must be rejected silently if the item value is already in the selected set.\n- The minSelection constraint must include required = true as an implicit minimum of 1.\n- Disabled items (item-level disabled attribute) must never be transferred by either per-item or bulk actions.\n- The \"Add all\" button must be disabled when all available non-disabled items are already selected or the maxSelection cap is reached.\n- The \"Remove all\" button must be disabled when the selected count is already at or below minSelection.\n- value is always a comma-separated string of item values; multi-value selection must not use any other format.";
}
declare module "_102040_/l2/molecules/groupselectmany/ml-dual-list-select" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDualListSelectMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private hasFocus;
        private handleAddItem;
        private handleRemoveItem;
        private handleAddAll;
        private handleRemoveAll;
        private handleSearchInput;
        private handleFocusIn;
        private handleFocusOut;
        private isInteractionBlocked;
        private getMinSelection;
        private getMaxSelection;
        private canAddMore;
        private updateValue;
        private getSelectedValues;
        private mapItemElement;
        private getParsedItems;
        private getFilteredItems;
        private buildGroups;
        private getContainerClasses;
        private getPanelClasses;
        private getItemRowClasses;
        private getActionButtonClasses;
        private renderLabel;
        private renderEmpty;
        private renderSearch;
        private renderFeedback;
        private renderList;
        private renderActionColumn;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-multi-checkbox-list\n\n# Objective\nAllow the user to select multiple options from a vertical list of checkbox-style buttons. Each item shows a visible check indicator when selected. The component supports optional search filtering, grouping, min/max selection limits, a required flag, and a read-only view mode that renders selected items inline.\n\n# Responsibilities\n- Render each available item as a clickable button with a checkbox indicator showing its selected state.\n- Toggle an item's selection on click: add it to the selection if not selected, remove it if already selected.\n- Filter the visible item list by the search query when searchable = true and the user types into the search field.\n- Render items inside named group sections with a group heading when items belong to a Group slot.\n- Show standalone Item slots that are not nested in a Group alongside grouped items.\n- Store the multi-selection as a comma-separated string in value and dispatch a \"change\" custom event on each toggle.\n- Prevent selecting an additional item when maxSelection is set and already reached.\n- Show an empty-state message from the Empty slot or the default \"No items available\" text when no items match the current filter.\n- Display a loading indicator and suppress interaction when loading = true.\n- Show an error message or helper text below the list in editing mode.\n- Apply an error border when the error property is set, or when required is true and nothing is selected, or when minSelection is not met.\n- Render a compact inline view of selected item labels when isEditing = false, with a placeholder when nothing is selected.\n- Emit \"focus\" when focus enters the component and \"blur\" when it leaves (in editing mode).\n- Render a hidden input with the form name when the name property is set.\n\n# Constraints\n- All toggling must be blocked when disabled = true, readonly = true, or loading = true, and for items that carry the disabled attribute.\n- Selecting a new item must be silently rejected when maxSelection is set and the current selection count already equals it.\n- Unselecting an already-selected item must always be permitted regardless of maxSelection.\n- isEditing = false activates read-only view mode; no interaction is possible and no feedback section is rendered.\n- value is always a comma-separated string of item values; the selection must not use any other format.\n- The search filter applies only to item text content and only when searchable = true; it never mutates value.";
}
declare module "_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlMultiCheckboxListMolecule extends MoleculeAuraElement {
        private msg;
        private uid;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private isOpen;
        private handleFocusIn;
        private handleFocusOut;
        private handleSearchInput;
        private handleToggleItem;
        private parseItem;
        private parseItems;
        private filterItems;
        private getSelectedValues;
        private getSelectedLabels;
        private getContainerClasses;
        private getItemClasses;
        private renderLabel;
        private renderFeedback;
        private renderCheckIcon;
        private renderItems;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-multi-select-dropdown\n\n# Objective\nProvide a multi-select field that allows users to choose one or more options from a dropdown list. The field supports grouped options, search filtering, selection limits, and validation states, adapting its behavior between editing and viewing modes.\n\n# Responsibilities\n- Display a label to identify the field\n- Present a trigger area that shows selected items, a selection count, or placeholder text when no items are chosen\n- Toggle the dropdown panel open and closed when the user activates the trigger\n- Keep the panel open while the user selects or deselects options\n- List all available options in the dropdown panel, organized under group headers when grouping is configured\n- Allow the user to select and deselect multiple options independently\n- Provide a search input to filter the visible option list by label when search is enabled\n- Show a loading indicator and prevent panel opening while loading\n- Prevent all interaction and selection changes when disabled or readonly\n- Render selected option labels as static non-interactive content when not in editing mode\n- Notify the system when the selection value changes\n- Notify the system when the field gains or loses focus during editing\n- Enforce a minimum number of selected items by showing an error when the count is too low\n- Enforce a maximum number of selected items by preventing additional selections and treating unselected options as non-selectable when the limit is reached\n- Display individual options that are marked as non-selectable in a disabled state\n- Show helper text below the field when no error exists and the field is in editing mode\n- Show error messages below the field when validation fails or an error is explicitly set\n- Display empty state content when no options are available to show\n- Expose accessibility information including expanded state, popup role, multiselect capability, and the selected or disabled state of each option\n\n# Constraints\n- The current selection must be represented as a comma-separated list of option values; an empty string indicates no selection\n- The dropdown panel must close when the user presses Escape or clicks outside the component boundaries\n- The trigger must not activate and the panel must not open when the component is disabled, readonly, or loading\n- Options marked as disabled must be visible but cannot be selected or toggled\n- When a maximum selection limit is active and reached, unselected options must behave as disabled\n- An error state must appear when the field is required and no options are selected\n- An error state must appear when the number of selected items is below the configured minimum\n- Error messaging takes priority over helper text display\n- No trigger, dropdown panel, events, or validation messaging may be presented when the component is not in editing mode\n- The label must be programmatically associated with the field\n- Error descriptions must be programmatically associated with the field when present\n- The field must indicate when it is invalid and when it is required to assistive technologies\n\n# Notes\n- The component uses named content regions: Label, Helper, Trigger, Item, Group, and Empty\n- Each option carries a value identifier and can be marked as non-selectable\n- A custom Trigger region replaces the default trigger content entirely\n- The component supports both light and dark visual presentations";
}
declare module "_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MultiSelectDropdownMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private uid;
        private labelId;
        private helperId;
        private errorId;
        private panelId;
        private hasFocus;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private handleTriggerClick;
        private handleTriggerKeydown;
        private handlePanelKeydown;
        private handleSearchInput;
        private handleOptionClick;
        private handleFocusIn;
        private handleFocusOut;
        private handleDocumentClick;
        private toggleSelection;
        private toggleOpen;
        private closePanel;
        private registerOutsideClick;
        private unregisterOutsideClick;
        private focusSearchInput;
        private focusTrigger;
        private moveOptionFocus;
        private getSelectedValues;
        private parseItem;
        private getGroupedItems;
        private getUngroupedItems;
        private getAllItems;
        private renderLabel;
        private renderHelperOrError;
        private renderSelectedTags;
        private getTriggerClasses;
        private getPanelClasses;
        private getItemClasses;
        private renderOptionList;
        private renderTriggerContent;
        private getComputedError;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectmany/ml-popover-multi-select.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-popover-multi-select\n\n# Objective\nAct as a compact multi-selection control that opens a floating panel when activated. It allows choosing multiple options without keeping the selection interface permanently visible, making it suitable for filter bars and space-constrained interfaces.\n\n# Responsibilities\n- Follow the groupSelectMany contract using slots named Label, Helper, Trigger, Item, Group, and Empty.\n- Render a default activator displaying the placeholder text when no Trigger slot is provided.\n- Open and close the floating selection panel when the trigger is activated.\n- Keep the panel open while the user selects or deselects multiple items in one session.\n- Toggle the selection state of an Item when chosen and represent the current value as a comma-separated list of selected item values.\n- Close the panel when the user presses Escape or clicks outside the component boundaries.\n- Prevent the panel from opening when the component is disabled, readonly, or loading.\n- Show a search input that filters Items and Groups by their labels when searchable is true.\n- Enter an error state when required is true and no value is selected, or when minSelection or maxSelection constraints are violated.\n- Block selection of further items when maxSelection is reached, and treat remaining unselected items as disabled.\n- In view mode (isEditing=false), display only the selected values as static text or tags, and hide the trigger, panel, helper text, and error messaging.\n- Emit change, focus, and blur events according to the contract during edit mode interactions.\n- Show the Empty slot content when no items exist or when active filtering yields no results.\n- Display a summary of current selections, such as a count or selected tags, in the trigger when partially filled.\n- Position Label content adjacent to the trigger when provided.\n- Position Helper content below the trigger when no error is present and the component is in edit mode.\n- Indicate loading state on the trigger and keep the panel hidden during loading.\n\n# Constraints\n- Selecting an item must not close the panel.\n- The panel must stay closed while disabled, readonly, or loading is true.\n- Unselected items must not be selectable once maxSelection is reached.\n- Error state must appear for empty required fields or violated selection count limits.\n- Events must only be emitted during edit mode.\n- View mode must not expose interactive controls or helper and error text.\n\n# Notes\n- The floating panel anchors to the trigger.\n- Group slots organize items into labeled sections.\n- Item slots represent individual selectable options.";
}
declare module "_102040_/l2/molecules/groupselectmany/ml-popover-multi-select" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlPopoverMultiSelectMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private activeIndex;
        private labelId;
        private errorId;
        private panelId;
        private hasFocus;
        updated(changed: Map<string, unknown>): void;
        private handleTriggerClick;
        private handleTriggerFocus;
        private handleTriggerBlur;
        private handleItemClick;
        private handleSearchInput;
        private handlePanelKeyDown;
        private handleDocumentClick;
        private handleDocumentKeyDown;
        private openPanel;
        private closePanel;
        private focusAfterOpen;
        private dispatchChangeEvent;
        private dispatchFocusEvent;
        private dispatchBlurIfNeeded;
        private parseValue;
        private collectSlotData;
        private createItemData;
        private filterData;
        private getSelectionState;
        private getValidationError;
        private getItemDisabled;
        private getSelectedLabelMap;
        private getVisibleItems;
        private setInitialActiveIndex;
        private moveActiveIndex;
        private toggleActiveItem;
        private focusActiveItem;
        private getTriggerClasses;
        private getItemClasses;
        private renderLabel;
        private renderHelper;
        private renderError;
        private renderSelectedTag;
        private renderTriggerContent;
        private renderEmpty;
        private renderGroup;
        private renderItems;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectmany/ml-tree-multi-select.defs" {
    export const group = "groupSelectMany";
    export const skill = "# Metadata\n- TagName: groupselectmany--ml-tree-multi-select\n\n# Objective\nProvide a hierarchical tree interface that allows users to select multiple nodes. Parent nodes can be expanded or collapsed. Selecting a parent selects all its descendants. The component supports searching to filter nodes and emits the selected node identifiers following the groupSelectMany contract.\n\n# Responsibilities\n- Render a hierarchical tree structure where each node displays a label and a selection control.\n- Allow nodes with children to be expanded or collapsed independently of selection state.\n- Provide interactive checkboxes for each node when in editing mode, respecting disabled, readonly, and loading states.\n- Cascade selection downward: selecting a parent selects all non-disabled descendants; deselecting a parent deselects all descendants.\n- Update parent checkbox state based on descendants: checked if all selected, unchecked if none selected, indeterminate if partially selected.\n- Maintain the selected value as a comma-separated string of node identifiers per contract.\n- Enforce maxSelection by preventing selection of additional unselected items once the limit is reached.\n- Enter an error state when required=true and no items are selected, or when selectedCount is below minSelection.\n- Filter nodes by label text when search is enabled, showing only matching nodes and their ancestor nodes.\n- Emit a change event on any selection change, providing the comma-separated string of selected identifiers.\n- Emit focus and blur events when the component gains or loses focus.\n- Display a loading indicator and disable interactions when loading is active.\n- In read-only mode (isEditing=false), display only the labels of selected items as static text or tags without interactive controls.\n\n# Constraints\n- Must use only the contract slot tags: Label, Helper, Trigger, Item, Group, Empty.\n- Each selectable node must be represented by an Item with a value attribute; the Item content represents the node label.\n- Hierarchy must be defined by nested Items; optional Group tags may group sibling nodes with a label.\n- Leaf nodes must preserve alignment equivalent to nodes with children.\n- Disabled items, disabled state, loading state, or reached maxSelection must render nodes non-interactive with reduced opacity.\n- Error styling must apply to the container and display the error message below; Helper content must be hidden when an error is present.\n- When no items are available or search returns no results, the Empty slot content must be rendered.\n- In read-only mode without selection, a placeholder must be shown.\n- All colors must support dark mode variants using the semantic color pairs defined in the contract.\n\n# Notes\n- The expansion state of nodes is internal and does not affect the selection value.\n- Search filtering preserves ancestor visibility to maintain hierarchical context.";
}
declare module "_102040_/l2/molecules/groupselectmany/ml-tree-multi-select" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlTreeMultiSelectMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        minSelection: number;
        maxSelection: number;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private expandedNodes;
        private treeNodes;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseTreeStructure;
        private parseItems;
        private expandAllNodes;
        private getSelectedValues;
        private getSelectedCount;
        private isNodeSelected;
        private isNodeIndeterminate;
        private getAllDescendants;
        private getAllLeafDescendants;
        private canSelectMore;
        private matchesSearch;
        private getFilteredNodes;
        private filterNodes;
        private handleToggleExpand;
        private handleNodeSelect;
        private updateParentStates;
        private handleSearchInput;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getNodeClasses;
        private getCheckboxClasses;
        private getExpandIconClasses;
        private renderLabel;
        private renderSearch;
        private renderCheckIcon;
        private renderIndeterminateIcon;
        private renderExpandIcon;
        private renderNode;
        private renderTree;
        private renderEmpty;
        private renderHelper;
        private renderLoading;
        private renderViewMode;
        private getSelectedLabels;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/index" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupselectone/ml-discrete-slider';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown-img';
    import '/_102040_/l2/molecules/groupselectone/ml-card-selector';
    import '/_102040_/l2/molecules/groupselectone/ml-listbox-sidebar-select';
    export class GroupSelectOneIndex extends StateLitElement {
        cardPlan: string;
        cardCycle: string;
        cardSat: string;
        cardCountry: string;
        cardRole: string;
        cardLang: string;
        cardCard: string;
        cardSidebar: string;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-card-selector.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-card-selector\n\n# Objective\nA single-selection interface that presents choices as a grid of rich-content cards, enabling the user to review detailed descriptions before choosing one option. It serves high-stakes decisions such as plan selection, template choice, account type, risk profile, or service modality.\n\n# Responsibilities\n- Present each option as a card containing rich content including headings, descriptions, and supporting details.\n- Allow selection of exactly one enabled card at a time.\n- Update the current value to the chosen item and report the new value when a selection occurs.\n- Display the selected item's label in the trigger area when the panel is closed.\n- Show placeholder text when no item is selected; in view mode with no value, display the placeholder or a fallback dash.\n- Group related cards under labeled headings when group content is provided.\n- Display an empty state when no options are available.\n- Provide a search field inside the panel when search mode is enabled, reducing visible cards to those matching the entered text.\n- Support keyboard navigation between cards, confirmation of selection, and closing the panel.\n- Indicate loading by showing a loading indicator in the trigger area and keeping the panel closed.\n- Ignore trigger interaction and prevent the panel from opening when read-only or disabled.\n- Present an error state when the field is required and no value is selected.\n- In view mode, show only the selected label as plain text without interactive affordances, panels, helper text, or error messages.\n\n# Constraints\n- Must conform to the groupSelectOne contract for properties, events, and content regions.\n- Disabled items must remain visible but cannot be selected and must not report value changes.\n- When not in editing mode, the molecule must not display the trigger, panel, helper text, or error message.\n- When loading, the selection panel must remain closed.\n- When read-only or disabled, the panel must never open.\n- Change, focus, and blur events must propagate according to the contract.\n- The error state must apply to the trigger area and show the error message below the field; no error may appear in view mode.\n- Helper text must appear below the field only when no error is present.\n- The label must appear consistently with other groupSelectOne molecules.\n- The selected card must have a distinct visual state using the contract's selected styling.\n- Disabled cards must appear muted and must not respond to hover.\n- All colors for borders, text, backgrounds, hover, focus, and selected states must include dark-mode variants.\n- The card grid must wrap responsively to remain readable across varying container widths.\n- Empty state content must be clearly visible within the panel.\n\n# Notes\n- The rich content inside each card is supplied entirely through the item's content region, enabling full customization of the card body.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-card-selector" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlCardSelectorMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private focusedIndex;
        private boundHandleOutsideClick;
        private boundHandleKeydown;
        constructor();
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private parseGroups;
        private getAllItems;
        private getFilteredItems;
        private findItem;
        private getSelectableItems;
        private handleOutsideClick;
        private handleKeydown;
        private handleTriggerClick;
        private handleSelect;
        private handleSearchInput;
        private handleFocus;
        private handleBlur;
        private openPanel;
        private closePanel;
        private getTriggerClasses;
        private getPanelClasses;
        private getCardClasses;
        private getSearchInputClasses;
        private getGroupLabelClasses;
        private renderLabel;
        private renderTrigger;
        private renderSearch;
        private renderCard;
        private renderCardGrid;
        private renderEmpty;
        private renderPanel;
        private renderHelper;
        private renderError;
        private renderFeedback;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-combobox.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-combobox\n\n# Objective\nAllow the user to choose exactly one option from a list by typing into a text field to filter results. A dropdown of matching options appears as the user types or when the field is focused. Optionally, when free-text mode is enabled, any typed value can be accepted even if it does not match a predefined option. The component supports groups, a clearable selection, required and error states, and a read-only view mode.\n\n# Responsibilities\n- Open the dropdown and display all options when the text field is focused.\n- Filter the visible options in real time as the user types, using case-insensitive partial matching on option label text.\n- Confirm the highlighted option as the selection when Enter is pressed, and close the dropdown.\n- Move the highlight down or up through the visible non-disabled options with Arrow Down / Arrow Up keys.\n- Close the dropdown without making changes when Escape is pressed, restoring the text field to the currently selected label.\n- Close the dropdown when Tab is pressed or when the user clicks outside the component.\n- Commit the typed text as the value in free-text mode when Enter is pressed and no option is highlighted, or when the field loses focus.\n- Display a \"Use ...\" entry at the bottom of the dropdown in free-text mode when the typed text does not exactly match any visible option.\n- Sync the text field display to the selected option's label when value is changed externally while the dropdown is closed.\n- Show an optional clear (x) button when clearable = true and the field has a value; clicking it resets value to null.\n- Display items inside named group sections with a group label header when items belong to a Group slot.\n- Show a checkmark next to the currently selected option in the dropdown.\n- Render a skeleton pulse placeholder while loading = true and the dropdown is closed.\n- Dispatch \"change\" when a selection is confirmed, \"input\" on every keystroke, \"focus\" on field focus, and \"blur\" when the component loses focus.\n- Show an error message below the field or a helper text from the Helper slot.\n- Render a compact read-only label and value display when isEditing = false.\n- Render a hidden input with the form name when the name property is set.\n\n# Constraints\n- All typing, dropdown opening, and selection must be blocked when disabled = true or loading = true.\n- readonly = true must allow focus and display but block typing, dropdown opening, and selection.\n- The dropdown must not be visible while the field lacks focus, except when opened by keyboard navigation.\n- Only one option can be selected at a time; selecting a new option always replaces the previous one.\n- In non-free-text mode, closing the dropdown without making a selection must restore the text field to the label of the current value, never retain an unmatched typed string.\n- Disabled options (item-level disabled attribute) must not be selectable by mouse or keyboard.\n- The clear button must not appear unless clearable = true is set.\n- The error state must persist until the error property is cleared.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-combobox" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlComboboxMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        placeholder: string;
        name: string;
        error: string;
        /** When true, any typed text is accepted as the value (not just list items). */
        freeText: boolean;
        /** Show a clear (×) button when the field has a value. */
        clearable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private inputText;
        private isOpen;
        private activeIndex;
        private uid;
        private lastValueSynced;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private _boundDocClick;
        firstUpdated(): void;
        updated(changedProps: Map<string, unknown>): void;
        private toPlainText;
        private parseItems;
        private getAllItems;
        private filterItems;
        private syncInputFromValue;
        private getFlatVisible;
        private getNextEnabledIndex;
        private handleInputFocus;
        private handleInputInput;
        private handleInputBlur;
        private handleKeyDown;
        private selectItem;
        private commitFreeText;
        private closeAndResolve;
        private handleClear;
        private getInputClasses;
        private getOptionClasses;
        private renderCheckmark;
        private renderOption;
        private renderDropdown;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-dial-select.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-dial-select\n\n# Objective\nAllow the user to choose exactly one option from a circular dial layout. Options are arranged as buttons on concentric rings radiating outward from a central trigger button. Clicking the center opens or closes the rings; clicking a ring item selects it. Items from different groups appear on separate rings, while standalone items share an outermost ring. The component supports an optional search field, keyboard navigation, error and loading states, and a read-only view mode.\n\n# Responsibilities\n- Toggle the rings open or closed when the central trigger button is clicked.\n- Open the rings and move the highlight to the first enabled item when Arrow Down, Enter, or Space is pressed while closed.\n- Navigate the highlight forward or backward through visible non-disabled items with Arrow Down / Arrow Up keys while the rings are open.\n- Select the highlighted item when Enter is pressed while the rings are open, then close them.\n- Close the rings without making a selection when Escape is pressed.\n- Close the rings when the user clicks anywhere outside the component.\n- Arrange items from each Group slot on its own concentric ring and standalone items on a shared outer ring.\n- Show an optional search input above the dial when searchable = true and the dial is open; filter all visible items by the typed query.\n- Scale the dial container size automatically based on the number of rings and the fixed per-item size.\n- Display the selected item's label inside the central trigger button; show a placeholder or Trigger slot content when nothing is selected.\n- Dispatch a \"change\" custom event when a selection is made.\n- Emit \"focus\" and \"blur\" events when the trigger button gains or loses focus.\n- Display an error message or helper text below the dial.\n- Render a compact read-only text view of the selected label or placeholder when isEditing = false.\n- Render a hidden input with the form name when the name property is set.\n\n# Constraints\n- All interaction (trigger click, keyboard, item selection) must be blocked when disabled = true, readonly = true, or loading = true.\n- The component must not open when isEditing = false.\n- Disabled items (item-level disabled attribute) must not be selectable by click or keyboard.\n- Only one item can be selected at a time; selecting a new item replaces the previous selection immediately.\n- The highlight must stay within the flat list of currently visible non-disabled items; it must never land on a disabled item.\n- The search filter only affects the visible items in the open dial; it never alters value.\n- The central trigger must carry proper ARIA attributes (role=\"combobox\", aria-expanded, aria-haspopup, aria-invalid) at all times.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-dial-select" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class DialSelectMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private activeIndex;
        private uid;
        private lastVisibleItems;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        updated(): void;
        private handleDocumentClick;
        private handleTriggerClick;
        private handleKeyDown;
        private handleSearchInput;
        private selectItem;
        private handleFocus;
        private handleBlur;
        private getPlainText;
        private getNextEnabledIndex;
        private getTriggerClasses;
        private getItemClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-discrete-slider.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-discrete-slider\n\n# Objective\nA discrete slider that allows selection of exactly one option from a set of mutually exclusive ordinal choices arranged along a horizontal linear scale. It behaves according to the groupSelectOne selection pattern, snapping the selection indicator to fixed stopping points that represent valid options.\n\n# Responsibilities\n- Present options in a linear horizontal order that reflects their natural ordinal relationship\n- Allow the user to select exactly one option at a time by interacting with the scale\n- Display a short text label for each available option, positioned to remain readable\n- Display the currently selected option label in an indicator above the selection position\n- Show placeholder or trigger content when no option is selected\n- Support category labels that span across their associated options without interrupting the linear scale\n- Snap the selection indicator to the chosen option's position upon selection\n- Maintain visibility of all option labels and stopping points regardless of active or inactive state\n- Toggle an active state when the user interacts with the control area\n- Close the active state when the user clicks outside, presses Escape, or selects an option\n- Navigate between enabled options using directional inputs\n- Confirm selection of the focused option using a confirm action\n- Ignore focus and blur state changes when in view mode\n- Display static text showing the selected label in view mode, or a placeholder when nothing is selected\n- Indicate when the selection is invalid due to a missing required value\n- Display an error message when one is provided\n- Display helper text when no error is present\n- Indicate when the component is loading, prevent selection changes during this state, and show a loading state in the indicator\n- Ignore search functionality\n\n# Constraints\n- Must only be used for ordinal data with a natural order of magnitude, intensity, time, or hierarchy\n- Must not be used for nominal data without logical order\n- Must accept no fewer than 2 and no more than 7 options; excess options are ignored, and fewer than 2 results in a non-interactive state\n- Must not change the stored value when the user closes the control without selecting\n- Must not allow selection when disabled, readonly, loading, or when an individual option is disabled\n- Must not display interactive controls in view mode\n- Must not display error text unless an error message is explicitly provided; helper text appears otherwise\n- Must suppress interaction cues when disabled or loading\n- Must allow text selection in readonly mode while preventing value changes\n\n# Notes\n- The linear order of options determines the ordinal scale; grouping labels serve only as visual cues and do not affect selection logic\n- The displayed selected label is derived directly from the selected option content and is not independently stored";
}
declare module "_102040_/l2/molecules/groupselectone/ml-discrete-slider" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDiscreteSliderMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        fillPrevious: boolean;
        private isActive;
        private focusedIndex;
        private isDragging;
        private dragRatio;
        private parsedItems;
        private parsedGroups;
        private boundHandleOutsideClick;
        private boundHandleKeydown;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseSlotContent;
        private updateFocusedIndexFromValue;
        private findItem;
        private handleOutsideClick;
        private handleKeydown;
        private handleTrackClick;
        private handleStopPointerDown;
        private handleDragPointerMove;
        private handleDragPointerUp;
        private selectItem;
        private getContainerClasses;
        private getSliderTrackClasses;
        private getStopClasses;
        private getLabelClasses;
        private getIndicatorClasses;
        private getGroupLabelClasses;
        private calculateStopPosition;
        private getIndexFromPointerX;
        render(): any;
        private renderViewMode;
        private renderEmptyState;
        private renderLabel;
        private renderSlider;
        private renderIndicator;
        private renderFilledTrack;
        private renderDragThumb;
        private renderStop;
        private renderGroupLabels;
        private renderFeedback;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-listbox-sidebar-select.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-listbox-sidebar-select\n\n# Objective\nA permanently open listbox for sidebar master-detail selection that allows choosing a single item from a visible list. It presents options in an always-open panel during editing and collapses to a static label in view mode.\n\n# Responsibilities\n- Use the groupSelectOne contract with Label, Helper, Trigger, Group, Item, and Empty slots.\n- In edit mode, keep the listbox panel permanently open and hide the trigger control.\n- In view mode, show only the selected item's label as static text, or a placeholder when no value is selected; hide the panel, helper, and error content.\n- Update the value to an item's value attribute when that item is selected, and emit a change event carrying the selected value.\n- Ignore selection attempts on disabled items and do not emit change events for them.\n- Render a loading state and block all selection when loading is active.\n- Render a disabled state and prevent selection changes when disabled is active.\n- Render a readonly state, prevent selection changes, and allow content selection when readonly is active.\n- Render an error state when required is true and no value is selected, clearing only after a selection is made.\n- Display the error message and error state when error is a non-empty string; never show errors in view mode.\n- Render the Empty slot content inside the panel when no Item slots are present.\n- Derive display labels from Item slot content and store selection values from each Item's value attribute.\n- Support grouped items via Group slots, displaying the group's label attribute as a heading above its items.\n- Provide a search input inside the panel when searchable is true, filtering visible items by their labels.\n- Emit focus events when the listbox gains focus and blur events when it loses focus.\n- Expose correct accessibility roles and states: listbox role on the panel, option role on each item, with aria-selected, aria-disabled, aria-required, aria-invalid, aria-labelledby, and aria-describedby reflecting current conditions.\n- Support keyboard navigation in the open list: ArrowUp and ArrowDown move between items, Enter selects the focused item, and Escape clears active navigation without closing the panel.\n- In edit mode, place the Label slot above the panel and the Helper or error message below the panel.\n- Clearly indicate the currently selected item within the list.\n\n# Constraints\n- The listbox panel must remain open in edit mode and must not close as a result of selection or navigation.\n- Error messages and helper text must not appear in view mode.\n- Disabled, readonly, and loading states must prevent changes to the selected value.\n- Search filtering must only affect item visibility and must not alter available values.\n- Accessibility attributes must always match the current state and interaction mode.\n\n# Notes\n- The trigger slot is part of the contract but remains hidden in this molecule.\n- Placeholder text is only relevant in view mode when no selection exists.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-listbox-sidebar-select" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlListboxSidebarSelectMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private searchQuery;
        private focusedIndex;
        private listboxId;
        private labelId;
        private errorId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private findItem;
        private getFilteredItems;
        private getSelectableItems;
        private handleSelect;
        private handleSearchInput;
        private handleKeyDown;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getLabelClasses;
        private getPanelClasses;
        private getSearchInputClasses;
        private getListClasses;
        private getGroupLabelClasses;
        private getItemClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        private getLoadingClasses;
        private getEmptyClasses;
        private renderLabel;
        private renderSearchInput;
        private renderItem;
        private renderGroupedItems;
        private renderEmpty;
        private renderLoading;
        private renderHelper;
        private renderViewMode;
        private renderEditMode;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-radio-group.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-radio-group\n\n# Objective\nA single-selection option group that displays all available choices at once without hiding them behind a dropdown. It allows the user to pick exactly one option from a small set, making every option visible for quick comparison and selection.\n\n# Responsibilities\n- Present all options simultaneously in a visible list; never hide options behind a dropdown or collapsible panel.\n- Provide distinct areas for Label, Helper, Item, Group, and Empty content. Each Item represents one selectable option and shows its label text.\n- When the user chooses an enabled Item, set the value to that Item's value and indicate that the value has changed.\n- Show disabled Items as visible but unavailable for selection; they cannot change the current value.\n- Block selection changes and suppress change indications while readonly is active.\n- Block selection changes and appear fully inactive while disabled is active.\n- Display an error appearance and indicate invalidity when an error message is present; otherwise show helper text if available.\n- When required is true and no value exists, display an error appearance until a selection is made.\n- Display a loading appearance that prevents selection changes while loading is active.\n- In view mode, render only the selected option's label as static text, or a placeholder when nothing is selected. Hide all interactive controls, error indicators, and helper text.\n- Allow moving focus between options with arrow keys, confirm the focused option with Enter, and report when focus enters or leaves. Escape must not change the selection and may remove focus.\n- When a Group area is present, render its label and include its Items as a labeled subsection while enforcing single-selection across all options.\n- If no Items are provided, render the Empty area content if available.\n\n# Constraints\n- Only one option may be selected at any time, including across subgroups.\n- Selection changes are prohibited during loading, readonly, and disabled states.\n- Disabled options must remain visible and clearly distinguishable from enabled options.\n- Error appearance persists until a valid selection is made when required; provided error messages override helper text.\n- View mode must not expose interactive controls or validation feedback.\n- The component must remain readable and usable when presenting 2 to 6 items at once.\n- Selected, disabled, readonly, error, and loading states must each have a unique, recognizable appearance in any color context.\n\n# Notes\n- Designed for small option sets where immediate visibility of all choices improves decision speed.\n- Group labels are visual separators; they do not allow multiple independent selections within the same component.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-radio-group" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlRadioGroupMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private focusedValue;
        private labelId;
        private errorId;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private parseGroups;
        private getAllItems;
        private findItem;
        private getSelectableItems;
        private handleSelect;
        private handleFocus;
        private handleBlur;
        private handleKeyDown;
        private getContainerClasses;
        private getOptionClasses;
        private getRadioClasses;
        private getLabelTextClasses;
        private renderLabel;
        private renderRadioIndicator;
        private renderOption;
        private renderGroup;
        private renderRadioOptions;
        private renderLoading;
        private renderFeedback;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-segmented-control.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-segmented-control\n\n# Objective\nA single-selection control that presents multiple options as a connected horizontal group of segments. It allows choosing one option from a compact set, showing the selected label when inactive and displaying all options together when active for editing.\n\n# Responsibilities\n- Integrate with the groupSelectOne contract, supporting Label, Helper, Trigger, Item, Group, and Empty.\n- Render each Item as a selectable segment with a visible label and an associated value.\n- Maintain exactly one selected Item at a time; selecting an Item updates the current value and notifies the system of the change.\n- When not in editing mode, display only the label of the currently selected Item as static text. Do not render segments, error messages, helpers, or emit change notifications.\n- When not in editing mode and no Item is selected, display the configured placeholder or a default fallback if no placeholder is configured.\n- When in editing mode, present all Items simultaneously as a horizontal group without requiring any panel or dropdown to be opened.\n- Render disabled Items visibly but prevent their selection and suppress change notifications when they are activated.\n- Present an error state when the control is required and no value is selected, following the validation rules of the contract.\n- Display an error message and apply an error state when an error is present; otherwise display Helper content when available.\n- Indicate loading and block all interactions, preventing selection and focus.\n- Block all interactions and apply a disabled state to the entire control when disabled.\n- Prevent selection changes while maintaining visible selected content when readonly.\n- Render Empty content when no Items are present; if Empty is not provided, render an explicit empty state.\n- Notify when the control receives and loses focus according to the contract.\n- Support keyboard navigation between segments, confirmation of selection, and dismissal of any open state.\n- Expose accessibility information so assistive technologies can identify the control type, selected option, disabled options, required status, and error conditions.\n\n# Constraints\n- Only one Item may be selected at any time.\n- All options must remain visible simultaneously during editing; they must not be hidden behind an additional interaction layer.\n- Disabled Items must never trigger selection or change notifications.\n- The control must not emit change notifications when not in editing mode.\n- Error display takes precedence over Helper display.\n- Loading state must prevent all user interactions including focus.\n- Designed for compact sets of short labels, typically between 2 and 5 options.\n- When not in editing mode, the display must be non-interactive plain text without borders or backgrounds.\n\n# Notes\n- Trigger content serves as a placeholder only when no Item is selected.\n- The selected Item label always takes precedence over Trigger content when a value is present.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-segmented-control" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class SegmentedControlMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private focusedIndex;
        private parsedItems;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseItems;
        private findItem;
        private handleSelect;
        private handleKeyDown;
        private focusNextItem;
        private focusPreviousItem;
        private focusSegment;
        private handleFocus;
        private handleBlur;
        private getContainerClasses;
        private getSegmentClasses;
        private getLabelClasses;
        private getHelperClasses;
        private getErrorClasses;
        private getViewModeClasses;
        render(): TemplateResult;
        private renderViewMode;
        private renderEditMode;
        private renderLabel;
        private renderLoading;
        private renderSegments;
        private renderSegment;
        private renderEmpty;
        private renderFeedback;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-dropdown-img.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-dropdown-img\n\n# Objective\nA selection field that displays the currently chosen option and opens a list of choices when activated. Each option includes an icon alongside text, supporting use cases such as language or country selection where each entry is identified by a representative image or symbol.\n\n# Responsibilities\n- Display the selected option inside the trigger, including its icon and text.\n- Show a placeholder when no option is selected, using defined placeholder text or fallback visual content.\n- Toggle the options panel open and closed when the trigger is activated, unless the component is disabled, readonly, or loading.\n- Present each option with an icon to the left of its text label.\n- Set the current value when a non-disabled option is chosen, close the panel, and signal that a change occurred.\n- Provide an internal search field that filters the list of options when the search capability is enabled.\n- Close the options panel when the user presses Escape or clicks outside the component.\n- In view mode, render only the text of the selected option as static content without showing interactive controls.\n- Keep disabled options visible but prevent them from being selected and mark them as unavailable.\n- Indicate an error state when the field is required and no value is selected.\n- Block panel opening while the component is in a loading state.\n\n# Constraints\n- Must not open the options panel if the component is disabled, readonly, or loading.\n- Disabled options must remain visible but must not be selectable.\n- The panel must close after a selection is made, when Escape is pressed, or when interaction occurs outside the component.\n- In view mode, must not display the trigger, panel, helper text, or error messages.\n- Must communicate invalid and required states to assistive technologies.\n- Must preserve the icon and text arrangement of an option when it is shown in the trigger as the selected value.\n\n# Notes\n- Option content containing images or symbols should render consistently in both the dropdown list and the trigger area.\n- Placeholder behavior applies only when no option is currently selected.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-dropdown-img" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSelectDropdownImgMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private parsedItems;
        private focusedIndex;
        private boundHandleOutsideClick;
        private boundHandleKeydown;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseItems;
        private parseItemElement;
        private findItem;
        private getFilteredItems;
        private handleTriggerClick;
        private handleSelect;
        private handleOutsideClick;
        private handleKeydown;
        private handleSearchInput;
        private getTriggerClasses;
        private getPanelClasses;
        private getItemClasses;
        private getSearchInputClasses;
        private renderLabel;
        private renderTriggerContent;
        private renderChevron;
        private renderTrigger;
        private renderSearch;
        private renderItems;
        private renderPanel;
        private renderHelper;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-dropdown.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-dropdown\n\n# Objective\nProvide a single-selection control that displays the current choice in a collapsed field and reveals a list of available options when activated. It must support searching, validation, and distinct display modes for editing and viewing.\n\n# Responsibilities\n- Display the currently selected option's label or a placeholder when no selection exists.\n- Reveal a list of available options when the user activates the control.\n- Hide the list when the user selects an option, activates an area outside the control, or cancels the operation.\n- Update the stored selection to the chosen option's value and report that a change has occurred.\n- Show a waiting indication and block list opening while data is being loaded.\n- Render the current selection as plain text without interactive elements when in view mode.\n- Block interaction but allow text selection when in read-only mode.\n- Display a validation failure when a selection is required but none is present, and clear it once a selection is made.\n- Provide a way to filter the option list by text when search is enabled.\n- Keep unavailable options visible but prevent their selection.\n- Use each option's displayed text as the source for its label, separate from its stored value.\n\n# Constraints\n- The option list must remain closed while the control is in a loading state.\n- Unavailable options must not be selectable and must not trigger change reporting.\n- Closing the list without choosing an option must preserve the existing selection and must not report a change.\n- The control must not respond to user input when disabled.\n- The control must not report changes when in view mode.\n- The label shown for the selected option must always correspond to the chosen option's displayed text.\n- A required but missing selection must keep the control in an error state until a valid choice is made.\n- Filtering must compare the search text against option labels.\n\n# Notes\n- Follows the groupSelectOne contract for single-selection patterns.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-dropdown" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSelectDropdownMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        private searchQuery;
        private focusedIndex;
        private boundHandleOutsideClick;
        private boundHandleKeydown;
        constructor();
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseItems;
        private parseGroups;
        private getAllItems;
        private findItem;
        private getFilteredItems;
        private getSelectableItems;
        private handleTriggerClick;
        private handleSelect;
        private handleOutsideClick;
        private handleKeydown;
        private handleSearchInput;
        private getTriggerClasses;
        private getDropdownClasses;
        private getItemClasses;
        private getSearchInputClasses;
        private renderLabel;
        private renderTriggerContent;
        private renderChevron;
        private renderTrigger;
        private renderSearchInput;
        private renderItems;
        private renderEmpty;
        private renderDropdown;
        private renderHelper;
        private renderError;
        private renderFeedback;
        private renderViewMode;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select-one-autocomplete\n\n# Objective\nAllow the user to choose exactly one option from a list by typing into a text field to filter results. A list of matching options appears when the field gains focus. The component supports readonly, disabled, and error states, offers an optional way to clear the selection, and allows full keyboard control.\n\n# Responsibilities\n- Filter the list of options by partial case-insensitive text match on their labels as the user types.\n- Show the list of options when the field has focus; hide it when focus is lost.\n- Permit only one selected option at a time; choosing a new option replaces the previous one.\n- Display the label of the currently selected option inside the text field.\n- Allow moving a highlight through the visible options using up and down arrow keys.\n- Confirm the highlighted option as the selection when Enter is pressed.\n- Close the option list without making changes when Escape is pressed.\n- Show a message when typing yields no matching options.\n- Provide an optional clear control that removes the current selection.\n- Prevent all interaction, typing, and list display when in readonly or disabled states.\n- Present an error message and invalid appearance when the field is in an error state.\n- Indicate when data is loading and prevent selection during that time.\n- Update the displayed label if the selected value is changed from outside.\n\n# Constraints\n- The option list must not be visible while the field lacks focus.\n- Highlight navigation must remain within the filtered set of options.\n- Readonly state must show the current selection label but block focus, typing, and list opening.\n- Disabled state must show the current selection label but block all interaction.\n- The clear control must not appear unless explicitly enabled.\n- Error indication must persist until the error state is resolved.\n- Selection must always be singular; multiple simultaneous selections are not allowed.\n\n# Notes\n- The filtering logic must match partial strings regardless of case (for example, typing \"zonas\" matches \"Amazonas\").\n- The component is intended for single-item selection scenarios such as choosing one state from a country list.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class SelectOneAutocompleteMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        searchable: boolean;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        clearable: boolean;
        private isOpen;
        private searchQuery;
        private highlightedIndex;
        private labelId;
        private inputId;
        private listId;
        private errorId;
        private helperId;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        firstUpdated(): void;
        updated(changedProps: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: any): void;
        private handleDocumentClick;
        private handleInputFocus;
        private handleFocusOut;
        private handleInput;
        private handleKeyDown;
        private handleItemSelect;
        private handleClear;
        private handleMouseDown;
        private openPanel;
        private closePanel;
        private applySelection;
        private parseItem;
        private getParsedData;
        private getFilteredItems;
        private getLabelByValue;
        private getTriggerText;
        private getInputClasses;
        private getOptionClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupselectone/ml-select.defs" {
    export const group = "groupSelectOne";
    export const skill = "# Metadata\n- TagName: groupselectone--ml-select\n\n# Objective\nAllow the user to choose exactly one option from a conventional click-to-open dropdown list. The component shows a trigger button that displays the current selection or a placeholder, and opens a panel of options when clicked. Unlike the combobox, it accepts no typed input \u2014 selection is made entirely by clicking or keyboard navigation. It supports grouped options, required and error states, disabled and readonly modes, and a read-only view mode.\n\n# Responsibilities\n- Toggle the option panel open or closed when the trigger button is clicked.\n- Open the panel and pre-highlight the current value (or the first item) when Arrow Down, Arrow Up, Enter, or Space is pressed while closed.\n- Move the highlight down or up through non-disabled options with Arrow Down / Arrow Up keys while the panel is open.\n- Select the highlighted option and close the panel when Enter or Space is pressed while the panel is open.\n- Close the panel without making a selection when Escape is pressed.\n- Close the panel when the user clicks anywhere outside the component.\n- Select an option immediately when it is clicked in the panel, then close the panel.\n- Update the highlight index on mouse move over options so keyboard and pointer navigation stay in sync.\n- Display items inside labeled group sections with a separator line when items belong to a Group slot.\n- Show a checkmark next to the currently selected option in the panel.\n- Render a loading spinner and label inside the trigger button while loading = true, and disable the trigger.\n- Show an error message below the trigger when error is set, or helper text from the Helper slot when there is no error.\n- Dispatch a \"change\" custom event with the new value when a selection is made.\n- Emit \"focus\" and \"blur\" events from the trigger button.\n- Render a compact read-only label and value text when isEditing = false.\n- Append a required asterisk to the label when required = true.\n- Render an empty-state message (from the Empty slot or the default text) in the panel when no items are defined.\n\n# Constraints\n- No text input is permitted; the user can only select from the predefined item list.\n- All interaction must be blocked when disabled = true, readonly = true, or loading = true.\n- Disabled options (item-level disabled attribute) must not be selectable by click or keyboard and must appear visually dimmed.\n- Only one option can be selected at a time; selecting a new option always replaces the previous one.\n- The option panel must not be visible while the trigger does not have an open state.\n- The highlight index must stay within the bounds of the selectable (non-disabled) items array.\n- isEditing = false activates a read-only view that shows only the label and selected value text without any interactive elements.";
}
declare module "_102040_/l2/molecules/groupselectone/ml-select" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSelectMolecule extends MoleculeAuraElement {
        private msg;
        private _outsideClickHandler;
        slotTags: string[];
        /** Currently selected item value; null = nothing selected */
        value: string | null;
        error: string;
        name: string;
        placeholder: string;
        isEditing: boolean;
        disabled: boolean;
        readonly: boolean;
        required: boolean;
        loading: boolean;
        private isOpen;
        /** Index into the flat selectableItems array; -1 = nothing highlighted */
        private highlightIndex;
        createRenderRoot(): this;
        connectedCallback(): void;
        disconnectedCallback(): void;
        private parseTopItems;
        private parseGroups;
        /** Flat ordered list of non-disabled items: group items first, then top items. */
        private buildSelectableList;
        private findSelected;
        private handleTriggerClick;
        private handleSelect;
        private handleKeydown;
        private renderTrigger;
        private renderOption;
        private renderPanel;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupshowprogress/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-segmented-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-upload-progress-indicator';
    export class GroupShowProgressIndex extends StateLitElement {
        private card1;
        private card2;
        private card3;
        private card4;
        private card5;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-circular-progress.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-circular-progress\n\n# Objective\nProvide a circular progress indicator that displays completion percentage or ongoing activity status. It communicates progress through a circular ring that fills proportionally to a numeric value or signals indeterminate activity when no value is available.\n\n# Responsibilities\n- Display a circular ring composed of a background track and a progress arc\n- Show the current percentage as centered text when enabled and a valid value is present\n- Operate in determinate mode when a numeric value between 0 and 100 is provided\n- Operate in indeterminate mode when no value is provided, indicating ongoing activity\n- Adjust visual proportions according to the requested size\n- Communicate progress state to accessibility tools, including current value and valid range in determinate mode\n- Present a completed, static state when progress reaches 100 percent\n- Remain purely visual and non-interactive\n\n# Constraints\n- Only use the configured properties: value, size, label, and showValue\n- Limit any numeric value to the range of 0 through 100\n- When value is absent, activate indeterminate mode and suppress percentage display regardless of showValue\n- When showValue is enabled and value is a valid number, display the percentage formatted as a whole number followed by a percent symbol\n- Identify itself as a progress indicator to accessibility systems using the provided label\n- In determinate mode, expose the current value and the bounds of 0 to 100 to accessibility tools\n- In indeterminate mode, do not expose a specific current value to accessibility tools\n- Apply default medium size behavior when an unrecognized size is provided\n- Generate center content automatically from internal state; do not accept external content\n- Halt indeterminate activity indication when the value reaches 100 percent\n- Support dark environments by using subdued tones for the background track and prominent accent tones for the progress arc\n\n# Notes\n- Intended for corporate dashboards such as HR performance tracking, project task completion, sales quota attainment, credit limit utilization, and logistics on-time delivery metrics\n- Visual appearance should align with clean, professional circular indicators suitable for data visualization contexts";
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-circular-progress" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CircularProgressMolecule extends MoleculeAuraElement {
        slotTags: any[];
        value: number | null;
        size: string;
        label: string;
        showValue: boolean;
        render(): any;
        private renderSvg;
        private isDeterminate;
        private getClampedValue;
        private getAriaAttributes;
        private getWrapperClasses;
        private getSvgClasses;
        private getValueTextClasses;
        private getSizeClasses;
        private getResolvedSize;
    }
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-indeterminate-spinner\n\n# Objective\nProvide a purely visual loading indicator for ongoing processes that lack a measurable completion percentage. It communicates activity through continuous motion and optional accompanying text, functioning either inline or as a container overlay.\n\n# Responsibilities\n- Display continuous animation to indicate an active, unmeasured process\n- Operate exclusively in an indeterminate state without showing numeric progress or completion values\n- Support four distinct visual sizes: extra-small, small, medium, and large\n- Render optional accompanying text adjacent to the indicator when provided\n- Use provided label text as the accessible name for the component\n- Function both inline within a layout and as an overlay covering a target area\n- Remain purely visual without initiating or responding to interactions\n\n# Constraints\n- Must not display percentages, numeric values, or progress fills under any circumstance\n- Must not expose a measurable progress value while operating in indeterminate mode\n- Animation must remain active and uninterrupted whenever the component is visible\n- Must use only the system's semantic color pairings for both light and dark themes\n- Must not introduce color variants beyond the contracted semantic set\n- Must maintain a neutral, corporate visual style suitable for overlays, buttons, and cards\n- Must not require external content areas to function in inline or overlay modes\n\n# Notes\n- The label text serves as both visible context and the component's accessible identifier\n- When acting as an overlay, the component covers its target container visually without modifying the underlying content structure";
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class IndeterminateSpinnerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: any[];
        value: number | null;
        size: 'xs' | 'sm' | 'md' | 'lg';
        label: string;
        showValue: boolean;
        render(): any;
        private getSizeConfig;
    }
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-linear-progress.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-linear-progress\n\n# Objective\nA linear progress indicator for the groupShowProgress group that visually communicates completion status or ongoing activity. It supports determinate mode to show exact percentage completion and indeterminate mode to indicate that an operation is in progress without a known duration. The component is purely visual and does not emit events.\n\n# Responsibilities\n- Render a horizontal bar composed of a background track and a fill indicator.\n- In determinate mode, expand the fill indicator from left to right in proportion to the completion value.\n- In indeterminate mode, display a continuous looping animation on the indicator to show ongoing activity without a defined completion percentage.\n- Accept a text label for contextual description.\n- Support semantic color variants (default, success, warning, danger) to convey different contextual meanings.\n- Support height sizes (xs, sm, md, lg) to accommodate different layout densities while maintaining consistent visual proportions.\n- Display the current percentage as formatted text when configured to do so, but only while in determinate mode.\n- When percentage text is displayed, maintain stable visual alignment with the bar.\n- Communicate appropriate accessibility information based on the current mode and value.\n- Remain purely visual without embedding business logic or emitting events.\n\n# Constraints\n- When no value is provided, the component must operate in indeterminate mode with a continuous looping animation.\n- When a value is provided, it must be constrained to the 0\u2013100 range before visual representation.\n- In indeterminate mode, no percentage text may be rendered regardless of the text display setting.\n- Height size must be one of xs, sm, md, or lg; if unspecified, md must be used as the default.\n- The component must not emit events.\n- Text describing specific business scenarios must be handled outside the component; the component only renders its own visual state.\n- In determinate mode, assistive technologies must be informed of the current value within a minimum of 0 and a maximum of 100.\n- In indeterminate mode, the current value must not be communicated to assistive technologies.\n- At 100% completion, the bar must appear completely filled and must not show an ongoing progress animation.\n- Transitions between values in determinate mode must be visually smooth.\n- All colors must provide corresponding variants for dark mode environments.\n\n# Notes\n- The percentage display format must be \"NN%\".\n- The label provided is used for accessibility identification of the progress indicator.\n- While the component supports corporate contexts such as import tracking, onboarding completion, report loading, order picking, and budget monitoring, it remains agnostic to those specific workflows.";
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-linear-progress" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class LinearProgressMolecule extends MoleculeAuraElement {
        slotTags: string[];
        value: number | null;
        size: 'xs' | 'sm' | 'md' | 'lg';
        label: string;
        showValue: boolean;
        variant: 'default' | 'success' | 'warning' | 'danger';
        private getNormalizedValue;
        private getSizeClasses;
        private getTextSizeClasses;
        private getTrackClasses;
        private getFillClasses;
        private renderValueText;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-segmented-progress.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-segmented-progress\n\n# Objective\nProvide visual feedback of progress to the user. It indicates how much of an operation or process has been completed, or that activity is occurring when no specific completion percentage is known.\n\n# Responsibilities\n- Display a single progress indicator that fills proportionally to a provided numeric completion level.\n- Show continuous motion to indicate unspecified activity when no numeric value is available.\n- Present the current percentage as formatted text alongside or over the indicator when explicitly enabled and a numeric value exists.\n- Identify itself to assistive technologies with an appropriate label and role.\n- Report the current numeric bounds and value to assistive technologies in determinate mode.\n- Adjust its overall dimensions according to the specified size option.\n- Remain visually clear and readable in both light and dark presentation modes.\n\n# Constraints\n- The accepted numeric progress must be limited to the range 0\u2013100; anything below 0 must be treated as 0 and anything above 100 as 100.\n- When no numeric value is provided, the component must enter an indeterminate state and must suppress percentage text regardless of display settings.\n- The component must not emit events or support interactions such as clicking, hovering for details, or focusing individual segments.\n- The component must not render discrete segments, step names, labels for individual portions, or unique colors per portion.\n- In determinate mode, the component must communicate the minimum value as 0, maximum value as 100, and the current numeric value to assistive technologies.\n- In indeterminate mode, the component must not communicate a current numeric value to assistive technologies.\n- Any displayed percentage text must maintain legibility against both light and dark backgrounds.\n\n# Notes\n- The visual indicator is always a single continuous bar, never a sequence of separate segments.\n- The indeterminate animation persists until a numeric value is supplied or the component is no longer rendered.";
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-segmented-progress" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class SegmentedProgressMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: any[];
        value: number | null;
        size: string;
        label: string;
        showValue: boolean;
        render(): any;
        private clampValue;
        private getSizeConfig;
        private buildBarContainerClasses;
        private buildBarFillClasses;
        private buildIndeterminateClasses;
        private buildValueTextClasses;
    }
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-upload-progress-indicator.defs" {
    export const group = "groupShowProgress";
    export const skill = "# Metadata\n- TagName: groupshowprogress--ml-upload-progress-indicator\n\n# Objective\nProvide a visual indicator that communicates the progress of an upload operation. The component reflects whether the progress is known, unknown, or finished, and optionally presents the percentage completed.\n\n# Responsibilities\n- Interpret the provided progress value as a percentage and constrain it to a 0\u2013100 range when rendering\n- Operate in an indeterminate state when no progress value is available, ignoring any request to show a numeric percentage\n- Show partial progress proportional to the provided percentage when the value is between 0 and 99\n- Display full progress without continuous motion when the operation is complete at 100 percent\n- Present the percentage in a numeric format next to the indicator when percentage display is enabled and a valid number is present\n- Use the provided label as the accessible name for the progress indicator\n- Identify itself as a progress indicator to assistive technologies\n- Communicate the current percentage and its bounds to assistive technologies when operating in determinate mode\n- Withhold the specific current percentage from assistive technologies when operating in indeterminate mode\n- Adapt its visual size based on the configured size variant\n- Apply appropriate color variations for dark mode contexts, including background, text, border, and focus states\n\n# Constraints\n- Must not trigger or emit events, as the group contract defines none\n- Must not display file names, file type icons, upload speed, cancel actions, or file links, as the group contract does not supply data or slots for these elements\n- Must suppress percentage display while in indeterminate mode\n- Must not show continuous animation when progress is complete\n- Must reserve continuous animation for the indeterminate state only\n- Must format the visible percentage as two digits followed by a percent symbol when displayed\n\n# Notes\n- Intended for use cases such as monitoring large file uploads in learning platforms where the user remains on the same screen during the operation";
}
declare module "_102040_/l2/molecules/groupshowprogress/ml-upload-progress-indicator" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class UploadProgressIndicatorMolecule extends MoleculeAuraElement {
        slotTags: any[];
        value: number | null;
        size: string;
        label: string;
        showValue: boolean;
        render(): any;
        private clampValue;
        private formatPercentage;
        private getSizeConfig;
        private renderProgressCircle;
    }
}
declare module "_102040_/l2/molecules/grouptriggeraction/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-group';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-kebab-action-trigger';
    export class GroupTriggerActionIndex extends StateLitElement {
        private cardButtonGroup;
        private cardButtonStandard;
        private cardIconButton;
        private cardSplitButton;
        private cardKebabActionTrigger;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-button-group.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-group\n\n# Objective\nA group of related buttons that act as a single control unit, allowing users to choose between related actions or options. The buttons appear visually connected without gaps, supporting different layouts, sizes, and visual styles.\n\n# Responsibilities\n- Display multiple related buttons as a unified group without spacing between them\n- Support both horizontal and vertical arrangements\n- Allow each button to display text, an icon, or both\n- Pair icons with their corresponding text labels by order of appearance\n- Apply uniform sizing to all buttons within the group\n- Control icon placement relative to text across all buttons\n- Indicate when the entire group is disabled and prevent user interaction\n- Indicate when the entire group is loading and block interaction\n- Replace normal button content with a loading indicator during loading states\n- Notify the system when any button is activated, provided the group is not disabled or loading\n- Support distinct visual treatments for primary, secondary, and ghost presentations\n- Default to secondary presentation when no specific style is assigned to a button\n- Adapt colors and contrast for both light and dark presentation modes\n\n# Constraints\n- If no labels are provided, the group must appear empty with no visible buttons\n- Icons must align with their paired label by order; any unmatched icons must not appear\n- Disabled state must remove all interaction affordances and prevent action notification\n- Loading state must hide all standard content and display only the loading indicator\n- Internal borders between adjacent buttons must never appear duplicated\n- Outer corners must be rounded while inner corners must remain square\n- A visible focus indicator must appear when a button receives keyboard focus\n- All buttons in the group must share the same size, type, and icon position settings\n- Action notification must carry no supplementary data beyond the activation signal\n\n# Notes\n- The group is intended for related actions such as save/cancel, time period selection, view switching, status filtering, or shift selection\n- Each button within the group maintains its own variant independently";
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-button-group" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlButtonGroupMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        size: string;
        type: string;
        iconPosition: string;
        disabled: boolean;
        loading: boolean;
        private handleButtonClick;
        private getDirection;
        private getGroupClasses;
        private getSizeClasses;
        private getVariantClasses;
        private getButtonClasses;
        private renderSpinner;
        private renderButtonContent;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-button-standard.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-button-standard\n\n# Objective\nA standard button molecule for the groupTriggerAction group that triggers actions when activated. It supports text labels, icons, multiple sizes, visual styles, loading states with a spinner indicator, and disabled states. Designed for corporate interfaces such as ERP, CRM, HR, Financial, and Logistics systems.\n\n# Responsibilities\n- Display a text label and/or an icon provided through the designated Label and Icon content areas.\n- Arrange the icon either before or after the text label based on configuration.\n- Adjust overall dimensions and icon scale according to the selected size.\n- Behave as a standard button, a submit button, or a reset button based on configuration.\n- Ignore activation attempts and present a disabled state when configured as disabled.\n- Ignore activation attempts and present a busy state when configured as loading.\n- Show a loading spinner in place of the icon or text during loading, keeping the button size unchanged.\n- Trigger an action event when activated by pointer or keyboard (Enter or Space), unless disabled or loading.\n- Expose an accessible name for icon-only buttons using the Label content when available.\n- Support rich content within the Label and Icon areas.\n- Provide distinct visual feedback for Normal, Hover, Active, and Focused states, with a visible focus indicator for keyboard users.\n- Reduce opacity and remove interactive feedback when disabled.\n- Support visual variations for primary, secondary, danger, ghost, and link styles through theming.\n- Adapt colors for dark mode using semantic color definitions.\n\n# Constraints\n- Must compose content using only the Label and Icon areas.\n- Icon position must be either 'start' or 'end'.\n- Size must be one of 'xs', 'sm', 'md', or 'lg'.\n- Type must be one of 'button', 'submit', or 'reset'.\n- When disabled, the action event must not trigger.\n- When loading, the action event must not trigger, and the button must expose busy and disabled states for accessibility.\n- During loading, the spinner replaces the icon if present; otherwise, it replaces the text label.\n- The action event must contain no detail and must propagate normally.\n- For icon-only buttons, the accessible name must come from the Label content if provided; otherwise, it must be empty.\n- Visual style variations must not require additional configuration properties.\n- Dark mode colors must map to semantic tokens for background, text, border, and focus ring.\n\n# Notes\n- Designed for corporate contexts such as ERP forms, CRM proposals, HR approvals, financial payments, and logistics operations.\n- The button must preserve its dimensions during loading to prevent layout shifts.\n- Visual design aligns with Material UI, Ant Design, and Atlassian Design System button patterns.";
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-button-standard" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ButtonStandardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        private isDisabled;
        private getVariant;
        private getSizeKey;
        private getSizeClasses;
        private getVariantClasses;
        private getButtonClasses;
        private getIconClasses;
        private renderSpinner;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-icon-button.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-icon-button\n\n# Objective\nBot\u00E3o compacto contendo apenas \u00EDcone para execu\u00E7\u00E3o de a\u00E7\u00F5es r\u00E1pidas em barras de ferramentas, tabelas e listas. Deve permitir que o usu\u00E1rio execute uma a\u00E7\u00E3o imediata ao interagir com o \u00EDcone, apresentando-se em diferentes tamanhos e respeitando estados de intera\u00E7\u00E3o definidos pelo grupo groupTriggerAction.\n\n# Responsibilities\n- Apresentar exclusivamente um \u00EDcone como conte\u00FAdo vis\u00EDvel, sem texto aparente\n- Permitir a associa\u00E7\u00E3o de uma descri\u00E7\u00E3o textual oculta para identifica\u00E7\u00E3o da a\u00E7\u00E3o\n- Utilizar a descri\u00E7\u00E3o textual dispon\u00EDvel como identifica\u00E7\u00E3o acess\u00EDvel quando o bot\u00E3o contiver apenas \u00EDcone\n- Disparar a a\u00E7\u00E3o vinculada ao grupo quando acionado pelo usu\u00E1rio, exceto em estados restritivos\n- Bloquear totalmente a intera\u00E7\u00E3o quando estiver ocupado processando uma tarefa\n- Bloquear totalmente a intera\u00E7\u00E3o quando estiver inativo\n- Indicar estado de ocupado de forma percept\u00EDvel\n- Disponibilizar varia\u00E7\u00F5es de tamanho adequadas para contextos compactos\n\n# Constraints\n- N\u00E3o deve exibir texto vis\u00EDvel sob nenhuma circunst\u00E2ncia\n- N\u00E3o deve acionar a a\u00E7\u00E3o vinculada quando estiver inativo\n- N\u00E3o deve acionar a a\u00E7\u00E3o vinculada quando estiver ocupado\n- Deve manter o \u00EDcone perfeitamente centralizado em qualquer tamanho dispon\u00EDvel\n- Em estado ocupado, o indicador de ocupa\u00E7\u00E3o deve ocupar o mesmo espa\u00E7o e alinhamento do \u00EDcone\n- Deve reagir visualmente aos estados de repouso, ao passar o cursor, ao pressionar e ao receber foco\n- O estado de foco deve ser evidenciado por um anel ou contorno vis\u00EDvel\n- O estado inativo deve apresentar redu\u00E7\u00E3o de opacidade e aus\u00EAncia de resposta a intera\u00E7\u00F5es\n- Deve respeitar as varia\u00E7\u00F5es de tamanho definidas pelo grupo: xs, sm, md e lg\n\n# Notes\n- A descri\u00E7\u00E3o textual oculta \u00E9 essencial para acessibilidade em bot\u00F5es sem texto vis\u00EDvel\n- Indica\u00E7\u00E3o de estado ocupado deve ser comunicada de forma que recursos de acessibilidade possam identificar\n- Projetado para uso em espa\u00E7os restritos como linhas de tabela, cards e barras de ferramentas";
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-icon-button" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class IconButtonMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        render(): any;
        private renderIcon;
        private renderLoadingIcon;
        private getAccessibleLabel;
        private getButtonClasses;
        private getIconClasses;
        private getSizeClasses;
    }
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-kebab-action-trigger.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-kebab-action-trigger\n\n# Objective\nA compact contextual trigger presented as a kebab or ellipsis button. When activated by the user, it signals the system to open an external contextual menu. Designed for dense interfaces such as data tables, where each row requires access to secondary actions without cluttering the primary view.\n\n# Responsibilities\n- Display as an icon-only button or as a button combining an icon with a text label\n- Signal the system to open or toggle a contextual menu upon user activation\n- Prevent menu triggering and block interaction when in a disabled state\n- Prevent menu triggering and block interaction when in a loading state, showing a loading indicator instead of the default content\n- Adjust dimensions, spacing, and typography proportionally based on the configured size\n- Adapt visual appearance based on the configured type\n- Position the icon to the left or right of the label based on configuration\n- Supply an accessible name when running in icon-only mode by using provided label text\n- Provide visual feedback for hover, active, and focused states\n- Provide visual feedback for disabled and loading states\n- Render suitably in both light and dark environments\n\n# Constraints\n- Must not render or manage the contextual menu, menu items, separators, or item styling directly\n- Must not signal the menu to open while disabled or loading\n- Must maintain a compact and neutral appearance appropriate for table rows and dense lists\n- Must present a clearly visible focus indicator during keyboard navigation\n- Must clearly indicate non-interactivity through reduced opacity or equivalent styling when disabled\n\n# Notes\n- Menu content, action lists, separators, destructive action styling, and dismissal behavior are managed by the parent component or external system.\n- Typically used once per row in data tables, such as order grids offering actions like view details, edit, duplicate, or cancel.";
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-kebab-action-trigger" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlKebabActionTriggerMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private handleActionClick;
        private getButtonClasses;
        private getSizeClasses;
        private getIconSizeClasses;
        private getLabelText;
        private renderLoadingIndicator;
        private renderDefaultIcon;
        private renderIcon;
        private renderLabel;
        private renderContent;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-split-button.defs" {
    export const group = "groupTriggerAction";
    export const skill = "# Metadata\n- TagName: grouptriggeraction--ml-split-button\n\n# Objective\nProvide a split button that presents a primary action together with a dropdown of secondary actions, allowing users to execute the main action or select an alternative from the related options within the groupTriggerAction group.\n\n# Responsibilities\n- Render two adjacent interactive regions: a primary action area and a chevron trigger that reveals secondary options.\n- Display the provided label content in the primary action area.\n- Display an optional icon in the primary action area, positioned either before or after the label according to configuration.\n- Always present a chevron indicator on the secondary options trigger.\n- Derive secondary options from provided items that carry a value identifier; treat all other supplied content as the primary label.\n- Each secondary option must expose a value and may indicate that it is unavailable.\n- When the primary action area is activated, dispatch an action notification including the primary value, preferring an explicit value identifier when present, otherwise falling back to the label text.\n- When the chevron trigger is activated, toggle the visibility of the secondary options list, provided the component is interactive.\n- When an available secondary option is chosen, dispatch an action notification including that option's value and hide the secondary options list.\n- Prevent unavailable secondary options from being chosen, dispatching notifications, or closing the list.\n- Support a type setting that defines the primary action behavior as button, submit, or reset.\n- Support a size setting that applies consistently to both the primary action area and the chevron trigger to maintain unified proportions.\n\n# Constraints\n- When the component is disabled, both the primary action area and the chevron trigger must be non-interactive and must not dispatch action notifications.\n- When the component is loading, both the primary action area and the chevron trigger must be non-interactive and must not dispatch action notifications.\n- The secondary options list must open below the control and align its edge with the chevron trigger.\n- The secondary options list must be at least as wide as the combined width of the primary action area and chevron trigger.\n- Secondary options must be stacked vertically with clear separation and adequate space for selection.\n- The primary action area and chevron trigger must share equal height and aligned baselines.\n- The chevron trigger must be narrower than the primary action area and separated by a visible divider.\n- Both regions must show visible hover, active, and focused states.\n- Available secondary options must show a visible highlight when hovered.\n- Disabled states must reduce visual prominence and suppress hover and active feedback for both regions and unavailable options.\n- The loading state must display a loading indicator in the primary action area and indicate that the chevron trigger is inactive.\n- All color treatments for surfaces, text, borders, hover, focus, disabled, and loading states must support dark mode.\n- Keyboard focus must be visibly indicated with a focus ring on the currently focused region.\n\n# Notes\n- Designed for enterprise applications such as ERP, CRM, logistics, financial, and HR systems where a primary action is commonly accompanied by related alternatives.\n- Representative use cases include save variations, send options, print formats, approval workflows, and publishing destinations.";
}
declare module "_102040_/l2/molecules/grouptriggeraction/ml-split-button" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlSplitButtonMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        size: 'xs' | 'sm' | 'md' | 'lg';
        type: 'button' | 'submit' | 'reset';
        iconPosition: 'start' | 'end';
        disabled: boolean;
        loading: boolean;
        private isOpen;
        private handlePrimaryClick;
        private handleToggleMenu;
        private handleOptionClick;
        private getPrimaryValue;
        private getPrimaryLabelText;
        private collectSecondaryItems;
        private getAriaLabel;
        private getPrimaryClasses;
        private getChevronClasses;
        private getSizeClasses;
        private getOptionClasses;
        private renderIcon;
        private renderLabel;
        private renderSpinner;
        private renderChevron;
        private renderMenuOptions;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewcard/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-media';
    import '/_102040_/l2/molecules/groupviewcard/ml-profile-card';
    export class GroupViewCardIndex extends StateLitElement {
        private cardVertical;
        private cardHorizontal;
        private cardMedia;
        private cardProfile;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupviewcard/ml-profile-card.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-profile-card\n\n# Objective\nA profile and contact card that presents identity, contact details, status, and quick actions for a user or entity. It supports interactive, selected, disabled, loading, and editing states, and allows consumers to compose either vertical or horizontal layouts through its content areas.\n\n# Responsibilities\n- Present identity information such as avatar, name, and role only when provided, without leaving empty placeholders.\n- Present contact information and associated visual indicators exactly as provided.\n- Present quick actions exactly as provided.\n- Support an optional status indicator representing online, offline, or away states within any provided content area.\n- Respond to pointer and keyboard activation when interactive and enabled.\n- Be focusable only when interactive.\n- Communicate disabled, selected, and loading states clearly.\n- Display placeholder shapes approximating the header, content, and action regions while loading.\n- Allow consumers to arrange content in either vertical or horizontal orientation without enforcing a single layout direction.\n- Present content areas in a clear sequence so consumers can style for either orientation.\n- Provide hover feedback only when interactive and enabled.\n- Visually distinguish the title as primary emphasis and the description as secondary text.\n- Group multiple actions with consistent spacing and alignment.\n- Align contact indicators with their corresponding values in a readable arrangement.\n- Support dark mode equivalents for all colors, borders, backgrounds, hover states, selected states, and placeholders.\n\n# Constraints\n- Must only use the content areas defined by the groupViewCard contract: header, title, description, content, footer, and action.\n- Must not render placeholder interface elements for missing content areas.\n- Must not respond to activation or be focusable when not interactive.\n- Must be completely non-interactive when disabled, ignoring all activation attempts.\n- Must not show hover feedback when disabled or non-interactive.\n- Must maintain structural layout in the disabled state while reducing visual emphasis.\n- Individual actions within the action area handle their own specific behaviors; the card signals only overall activation.\n- Must communicate an editing state to all nested content within its regions when in editing mode.\n\n# Notes\n- Intended for employee directories, contact lists, and similar profile displays.\n- Consumers provide all content and determine the layout direction; the card provides the container behavior and state management.";
}
declare module "_102040_/l2/molecules/groupviewcard/ml-profile-card" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlProfileCardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        clickable: boolean;
        selected: boolean;
        disabled: boolean;
        loading: boolean;
        isEditing: boolean;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private handleCardClick;
        private handleCardKeydown;
        private isInteractive;
        private getCardClasses;
        private syncEditingAttribute;
        private renderHeader;
        private renderContent;
        private renderFooter;
        private renderAction;
        private renderLoadingSkeleton;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewcard/ml-vertical-card.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-vertical-card\n\n# Objective\nA vertical card for the groupViewCard group that organizes information into optional sections: header with title and description, body, footer metadata, and actions. It adapts to interactive, loading, disabled, selected, and editing states while staying neutral for use across corporate contexts such as sales pipelines, project boards, recruitment funnels, supplier lists, and executive dashboards.\n\n# Responsibilities\n- Present a header section at the top when provided, showing a title above a description when both are present.\n- Present a body section in the middle when content is provided.\n- Present a footer section at the base for metadata, dates, or status when provided.\n- Present an actions section visually separated from the main content when action elements are provided.\n- Show only the sections that are provided; absent sections must leave no visible gaps.\n- When in interactive mode, respond to pointer activation and keyboard activation, and signal that the card has been activated.\n- When loading, show a structural placeholder that reflects the card's vertical layout instead of the actual header, body, footer, and action content.\n- When selected, display a distinct visual state that indicates selection.\n- When disabled, display a distinct visual state and block all interaction and activation signaling, even if interactive mode is enabled.\n- When editing, communicate the editing context to contained elements.\n- Maintain a neutral appearance that supports multiple business domains without specialized theming.\n- Preserve correct visual state behavior in both light and dark presentation modes.\n\n# Constraints\n- Must not offer or accept visual style variants such as default, outlined, elevated, or ghost.\n- Must not embed logic for any specific business domain; all domain-specific information must be supplied from outside.\n- Loading state must suppress all provided content sections.\n- Disabled state must override interactive mode.\n- Interactive mode must include visible hover feedback and keyboard accessibility.\n- Selection, disabled, loading, and hover appearances must remain consistent across presentation modes.\n\n# Notes\n- Corporate use cases are supported entirely by the external content placed within the card's sections.\n- Editing state handling follows the group's established contract for contained elements.";
}
declare module "_102040_/l2/molecules/groupviewcard/ml-vertical-card" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlVerticalCardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        clickable: boolean;
        selected: boolean;
        disabled: boolean;
        loading: boolean;
        isEditing: boolean;
        updated(changed: Map<string, unknown>): void;
        private handleCardClick;
        private handleKeyDown;
        private isInteractive;
        private applyEditingAttribute;
        private getRootClasses;
        private renderHeader;
        private renderContent;
        private renderFooter;
        private renderAction;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-view-card-horizontal\n# Objective\nProvide a compact horizontal card for list items with left media content and right text content, supporting interactive and stateful behaviors.\n# Responsibilities\n- Render a card with a horizontal layout.\n- Display the CardContent slot on the left side of the card.\n- Display the CardHeader slot to the right of CardContent.\n- Display the CardFooter slot below the CardHeader within the right section when provided.\n- Display the CardAction slot within the right section when provided.\n- Support a clickable state that makes the card interactive.\n- Emit a cardClick event when activated by pointer interaction while clickable.\n- Emit a cardClick event when activated by Enter or Space while focused and clickable.\n- Support a selected state that visually highlights the card.\n- Support a disabled state that makes the card non-interactive and visually dimmed.\n- Support a loading state that replaces content with a placeholder representation of the layout.\n- Pass the isEditing attribute to child components within the card.\n- Apply button semantics when clickable, including focusability.\n- Expose aria-selected when selected.\n- Expose aria-disabled when disabled.\n# Constraints\n- When disabled, the card must not emit cardClick events.\n- When loading, normal content must not be displayed.\n- The card must remain compact and suitable for use in list layouts.\n- Visual placement must keep left media content constrained to a small width and text content on the right.\n# Notes\n- CardHeader may include CardTitle and CardDescription content.";
}
declare module "_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ViewCardHorizontalMolecule extends MoleculeAuraElement {
        slotTags: string[];
        clickable: boolean;
        selected: boolean;
        disabled: boolean;
        loading: boolean;
        isEditing: boolean;
        updated(): void;
        private handleCardClick;
        private handleKeyDown;
        private applyEditingAttribute;
        private getContainerClasses;
        private renderHeader;
        private renderContentLeft;
        private renderFooter;
        private renderAction;
        private renderSkeleton;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewcard/ml-view-card-media.defs" {
    export const group = "groupViewCard";
    export const skill = "# Metadata\n- TagName: groupviewcard--ml-view-card-media\n\n# Objective\nDisplay a card with featured media at the top, followed by a structured header, content, footer, and actions. It serves corporate scenarios such as courses, products, properties, job postings, and news through composable content sections.\n\n# Responsibilities\n- Present a media area at the top using the CardHeader section, occupying the full width without side padding.\n- Present CardTitle and CardDescription as the text header directly below the media area.\n- Present CardContent, CardFooter, and CardAction below the header when provided.\n- Allow the media aspect ratio to be configured on the CardHeader section with supported values of 16:9, 4:3, and 1:1, falling back to 16:9 when unspecified.\n- Center and crop media content to fill the configured aspect ratio area.\n- Show a neutral placeholder occupying the media space when media is missing or fails to load.\n- When set as clickable, make the entire card interactive, focusable, and announceable as a button; activation via pointer, Enter, or Space must trigger a cardClick notification with empty detail.\n- Provide a hover indication only when the card is clickable.\n- Apply a selected visual state and communicate the selected condition to accessibility tools when the selected state is active.\n- Apply a disabled visual state, prevent interaction, suppress cardClick notifications, and communicate the disabled condition to accessibility tools when the disabled state is active.\n- Replace all content with skeleton placeholders matching the media and text areas when in the loading state.\n- Forward the editing state to child elements according to the groupViewCard contract.\n- Support all corporate use cases exclusively through composition of the standard sections, without introducing extra dedicated properties.\n\n# Constraints\n- Must only use the groupViewCard contract sections: CardHeader, CardTitle, CardDescription, CardContent, CardFooter, and CardAction.\n- The media area must span the full top width and must not have lateral padding.\n- Only 16:9, 4:3, and 1:1 are valid media aspect ratios.\n- Media must remain centered and cropped to fill the ratio area without altering the card dimensions.\n- Clickable cards must be keyboard-operable and must expose button semantics to assistive technologies.\n- Disabled cards must not respond to activation and must not emit cardClick notifications.\n- Loading state must hide all actual content and media until deactivated.\n- The unavailable media placeholder must match the dimensions of the intended media area.\n- Interactive states must behave consistently: disabled takes precedence over clickable interaction, and loading suppresses all other states.\n- Child elements must receive the editing state through the standard group mechanism.\n\n# Notes\n- The CardHeader section carries the featured media content rather than a conventional textual header.\n- Corporate use cases are achieved by what content is placed into each section, not by variant-specific properties.";
}
declare module "_102040_/l2/molecules/groupviewcard/ml-view-card-media" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlViewCardMediaMolecule extends MoleculeAuraElement {
        slotTags: string[];
        clickable: boolean;
        selected: boolean;
        disabled: boolean;
        loading: boolean;
        isEditing: boolean;
        private mediaFailed;
        private handledMediaElements;
        updated(changedProps: Map<string, unknown>): void;
        private handleCardClick;
        private handleKeyDown;
        private handleMediaError;
        private handleMediaLoad;
        render(): any;
        private renderMediaSection;
        private renderBodySection;
        private renderHeaderText;
        private renderContentSection;
        private renderFooterSection;
        private renderSkeleton;
        private getMediaRatioClass;
        private hasSlotContent;
        private isInteractive;
        private getCardClasses;
        private attachMediaListeners;
        private applyEditingState;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-line-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-pie-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-scatter-plot';
    import '/_102040_/l2/molecules/groupviewchart/ml-radar-chart';
    export class GroupViewChartIndex extends StateLitElement {
        private cardArea;
        private cardBar;
        private cardLine;
        private cardPie;
        private cardScatter;
        private cardRadar;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-area-chart.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-area-chart\n\n# Objective\nPresent quantitative information as an area chart that highlights volume through filled regions below trend lines. Enable comparison across single or multiple data series, with a default stacked view that shows how individual parts compose a total. Offer interactive discovery, loading feedback, empty state handling, and full accessibility support.\n\n# Responsibilities\n- Render data as lines connecting points, with the area beneath each line filled using the series color at reduced opacity.\n- Accumulate multiple series vertically in a stacked view by default, making each series' contribution to the total visible at every point.\n- Activate a selection behavior when a user interacts with a data point, carrying the point's label, value, and series name when applicable.\n- Reveal a contextual description on hover over any data point, displaying its label, value, and series name when relevant.\n- Display a legend mapping each series name to its corresponding color when enabled; hide the legend entirely when disabled.\n- Replace the chart with a loading placeholder that preserves the final dimensions while data is unavailable.\n- Show an empty state when no data points exist, preferring custom empty content or falling back to a default empty indication.\n- Expose the chart container to assistive technologies as a graphical image named by the chart title.\n- Supply raw data in a structured, non-visual form accessible to assistive technologies.\n- Treat interactive data points as actionable controls described by their label and value.\n- Apply provided title content as the visible chart heading and as the accessible name for the chart container.\n\n# Constraints\n- Must handle both single-series and multi-series data seamlessly.\n- Must default to stacked mode whenever multiple series are present.\n- Tooltip information must always include label and value; series name must appear only when multiple series are present.\n- Legend colors and names must correspond exactly to the rendered areas.\n- The loading placeholder must suggest a chart shape and occupy the same space as the completed chart.\n- All visual elements must maintain adequate contrast in both light and dark presentation modes.\n- The empty state must suppress the chart area and axes.\n- Interactive points must remain operable and perceptible across all display modes.\n\n# Notes\n- Area fill opacity must remain low enough to keep grid lines and overlapping series distinguishable.\n- Tooltip placement must avoid covering the target data point or neighboring content.\n- Dark mode must rely on semantically appropriate color pairings for backgrounds, text, and borders.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-area-chart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlAreaChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private tooltip;
        private parsedSeries;
        private chartTitle;
        private readonly chartWidth;
        private readonly chartHeight;
        private readonly padding;
        private readonly defaultColors;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseData;
        private handlePointClick;
        private handlePointMouseEnter;
        private handlePointMouseLeave;
        private getStackedData;
        private getMaxValue;
        private getLabels;
        private scaleX;
        private scaleY;
        private renderLoading;
        private renderEmpty;
        private renderGrid;
        private renderAreas;
        private renderTooltip;
        private renderLegend;
        private renderAccessibleTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-bar-chart.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-bar-chart\n\n# Objective\nDisplay a vertical bar chart that visualizes one or more data series across named categories. The component accepts data through declarative slot elements (Series and Point), renders proportionally sized bars, and lets the user explore individual values through hover tooltips and keyboard-accessible bar buttons.\n\n# Responsibilities\n- Parse standalone Point slot elements and Series slot elements (each containing nested Points) to build the chart data model.\n- Calculate bar heights proportionally relative to the maximum value across all data points.\n- Render a tooltip showing the label, series name, and formatted value when the user hovers over a bar.\n- Dispatch a pointClick CustomEvent (bubbles, composed) with label, value, and series when a bar is clicked or activated with Enter or Space.\n- Show an optional label above the chart when a Label slot is provided.\n- Render a color-coded legend below the chart when showLegend is true and data is present.\n- Optionally display the numeric value above each bar when showValues is true.\n- Render an animated loading skeleton when loading is true.\n- Render an empty state message when no data is available; use the Empty slot content when provided, otherwise fall back to the localized default message.\n- Include a visually hidden accessible data table (sr-only) so screen readers can consume the full data set.\n- Format numbers according to the active locale (en-US or pt-BR).\n- Support English and Portuguese UI strings via the i18n message system.\n\n# Constraints\n- The component must not contain business logic; data interpretation is the consumer's responsibility.\n- Bar height must always be calculated as a percentage of the maximum value; a value of zero must render a bar with zero visible height.\n- The tooltip must not be visible unless the user is actively hovering over a bar.\n- The legend must only appear when showLegend is explicitly true.\n- Value labels above bars must only appear when showValues is explicitly true.\n- When both Series and standalone Point slots are present, Series-based rendering takes precedence and standalone Points are ignored.\n- Points with a non-numeric or missing value attribute must be treated as zero rather than causing a render error.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-bar-chart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlBarChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private tooltip;
        private handlePointMouseEnter;
        private handlePointMouseLeave;
        private handlePointClick;
        private handlePointKeyDown;
        private parsePoint;
        private readSeries;
        private readStandalonePoints;
        private getCategories;
        private getMaxValue;
        private renderLabel;
        private renderLoading;
        private renderEmpty;
        private renderTooltip;
        private renderLegend;
        private renderDataTable;
        private getAriaLabel;
        private formatNumber;
        private getBarWidth;
        private getBarClasses;
        private getCategoryLabelClasses;
        private renderChart;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-line-chart.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-line-chart\n\n# Objective\nDisplay the evolution of numeric data over time using a multi-series line chart. It must visualize connections between ordered data points, allow comparison across series, and handle loading, empty, and dark-mode states.\n\n# Responsibilities\n- Accept a title, grouped or ungrouped data points, and an empty state as inputs.\n- Position each data point horizontally according to its category label and vertically according to its numeric value.\n- Draw lines connecting sequential points within each series to show progression.\n- Automatically calculate the vertical scale from the minimum and maximum values present in the data.\n- Render subtle horizontal reference lines aligned to the vertical scale.\n- On hover over a data point, display contextual information including the category label, exact value, and series name.\n- On selection of a data point, expose the point's label, value, and series identity for external handling.\n- Differentiate each series by a distinct color.\n- When in a loading state, display an animated placeholder and suppress chart rendering.\n- When no data points are provided, render the empty state or a default empty message.\n- Optionally render a legend mapping each series to its visual representation.\n- Optionally render numeric values next to their corresponding data points.\n- Expose the underlying data in a text format accessible to assistive technologies.\n- Ensure interactive data points are detectable and actionable by assistive technologies.\n- Adapt all visual elements for dark presentation mode.\n\n# Constraints\n- Category labels must appear on the horizontal axis in the order received.\n- The vertical scale must be derived solely from the data values without external configuration.\n- Contextual hover information must appear only while the pointer is over the data point and must disappear on exit.\n- The loading placeholder must fully replace the chart area and block interaction with chart elements.\n- The empty state must render only when no data points exist in any series or root input.\n- The legend must accurately reflect only the series or points currently represented.\n- Visual elements must maintain sufficient contrast for readability in both light and dark modes.\n- Interactive points must present an adequate target area for pointer interaction.\n\n# Notes\n- Lines should visually suggest continuous progression between points.\n- Legend placement should default below the chart.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-line-chart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlLineChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private tooltip;
        private readonly chartWidth;
        private readonly chartHeight;
        private readonly padding;
        private parseData;
        private calculateScale;
        private getX;
        private getY;
        private handlePointMouseEnter;
        private handlePointMouseLeave;
        private handlePointClick;
        private renderLoading;
        private renderEmpty;
        private renderGridLines;
        private renderYAxis;
        private renderXAxis;
        private renderLine;
        private renderPoints;
        private renderTooltip;
        private renderLegend;
        private renderAccessibleTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-pie-chart.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-pie-chart\n\n# Objective\nDisplay a pie chart that represents proportional data as colored SVG arc segments. The component accepts data through declarative Series and Point slot elements, renders each slice proportionally to its share of the total, and supports hover tooltips, keyboard interaction, and an accessible data table for screen readers.\n\n# Responsibilities\n- Parse standalone Point slot elements or Series slot elements (each containing nested Points) to build the list of pie segments.\n- Compute the SVG arc path for each segment using polar-to-cartesian geometry, scaled to the point's proportion of the total value.\n- Assign colors to segments from the built-in palette when no explicit color attribute is provided.\n- Render a positioned tooltip showing the segment label, value, series name, and color swatch when the user hovers over or focuses a slice.\n- Dispatch a pointClick CustomEvent (bubbles, composed) with label, value, and series when a slice is clicked or activated with Enter or Space.\n- Show an optional label above the chart when a Label slot is provided.\n- Render a two-column color-coded legend below the chart when showLegend is true.\n- Optionally render the numeric value as SVG text at the midpoint of each slice when showValues is true.\n- Render an animated loading placeholder when loading is true.\n- Render an empty state message when no valid segments are available; use the Empty slot content when provided, otherwise fall back to the localized default.\n- Include a visually hidden accessible table (sr-only) listing all segment labels, values, and series.\n- Support English and Portuguese UI strings via the i18n message system.\n\n# Constraints\n- The component must not contain business logic; data interpretation is the consumer's responsibility.\n- Points with a missing label, missing value, non-numeric value, or value of zero or less must be silently excluded from rendering.\n- When Series slots are present, standalone root-level Point slots are ignored and the series points are used exclusively.\n- The tooltip must not intercept pointer events; it must use pointer-events-none so it does not block interaction with underlying elements.\n- The legend must only appear when showLegend is explicitly true and at least one valid segment exists.\n- Value labels inside slices must only appear when showValues is explicitly true.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-pie-chart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class PieChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private hoverState;
        private palette;
        private parsePoint;
        private readSeries;
        private readStandalonePoints;
        private getSegments;
        private handlePointClick;
        private handlePointKeydown;
        private handlePointEnter;
        private handlePointLeave;
        private polarToCartesian;
        private describeArc;
        private renderLabel;
        private renderLoading;
        private renderEmpty;
        private renderLegend;
        private renderAccessibleTable;
        private renderTooltip;
        private renderChart;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-radar-chart.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-radar-chart\n\n# Objective\nProvide a radar chart for comparing multiple dimensions across one or more data series. It must render labeled axes in a circular layout, display each series as a distinct visual layer, and allow users to explore and select individual values.\n\n# Responsibilities\n- Display a chart title.\n- Render up to eight labeled axes distributed uniformly around a circular layout.\n- Support multiple data series for comparison, each with a distinct name and color.\n- Support a single data series provided without explicit grouping.\n- Limit visible axes to the first eight dimensions when excess dimensions are provided.\n- Automatically determine the scale for each axis based on the maximum value found across all series for that dimension.\n- Present detailed information upon hovering over any vertex, including the axis label, numeric value, and series name when applicable.\n- Enable selection of any vertex and communicate its axis label, value, and associated series.\n- Show a loading indicator while data is being prepared.\n- Display provided empty-state content when no valid data exists; otherwise show a default empty state.\n- Render a legend identifying each series when enabled; omit the legend when disabled.\n- Show numeric values at each vertex when enabled; hide them when disabled.\n- Make the underlying data available in an accessible format.\n- Ensure every interactive vertex conveys its axis label, value, and series identity.\n\n# Constraints\n- Must not render more than eight axes.\n- Axis labels must align with their respective positions around the chart perimeter.\n- Each series must be represented as a closed shape connecting its values across all axes.\n- Multiple series must remain visually distinguishable through unique colors and semi-transparent fills.\n- Concentric reference rings must indicate scale levels.\n- Vertices must be visibly marked where series shapes intersect the axes.\n- The chart area must maintain its structure during loading and empty states.\n- Color usage must adapt appropriately for light and dark presentation modes.\n\n# Notes\n- Intended for scenarios such as semestral performance reviews comparing actual versus expected results across competencies including leadership, technical skill, communication, and deliverables.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-radar-chart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class RadarChartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private hoveredPoint;
        private parseChartData;
        private getAxisMaxValues;
        private getPlainText;
        private handlePointClick;
        private handlePointHover;
        private handlePointLeave;
        private renderLegend;
        private renderTooltip;
        private renderEmptyState;
        private renderLoadingState;
        private renderAccessibleTable;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewchart/ml-scatter-plot.defs" {
    export const group = "groupViewChart";
    export const skill = "# Metadata\n- TagName: groupviewchart--ml-scatter-plot\n\n# Objective\nDisplay a scatter plot that visualizes data points across X and Y axes, supporting multiple series, interactive tooltips, an optional trend line supplied as a dedicated series, a configurable legend, and accessible data alternatives.\n\n# Responsibilities\n- Accept data exclusively through designated slots: Series containers holding Points, or standalone Points at the root level for single-series data.\n- Map each Point's label attribute to the X-axis and its value attribute to the Y-axis.\n- Plot points as circular markers positioned by their X and Y values.\n- Display a tooltip on point hover showing the X value, Y value, and series name when applicable.\n- Emit a pointClick event upon point activation, including the X value, Y value, and associated series.\n- Show a legend with series names and colors when enabled; hide it entirely when disabled.\n- Present a loading placeholder while the loading state is active.\n- Render the Empty slot content when no Points are provided in any Series or at the root level.\n- Render a consumer-supplied dedicated series as a continuous line connecting its points to represent a trend.\n- Provide an accessible alternative containing a hidden data table with all points and series.\n- Expose the chart container with an image role and an accessible label derived from the Label slot when present.\n- Display a title above the plotting area when the Label slot is populated.\n- Render visible X and Y axes with markings based on the data's minimum and maximum values.\n- Apply the series color to its points; fallback to the individual Point color when no series color is defined.\n- Maintain uniform point size across all points.\n- Position the legend below the chart, aligned to the left.\n- Ensure tooltips appear near the hovered point with legible text and sufficient contrast in both light and dark modes.\n- Support dark mode using semantic color pairs for backgrounds, text, borders, and interactive states.\n- Center the Empty slot content within the chart area.\n\n# Constraints\n- Must not calculate trend lines or perform regression internally; trend data must be provided as a separate series through slots.\n- Must not render the chart or axes while the loading state is active.\n- Must not display the legend when it is configured as hidden.\n- Must render the Empty state only when zero Points exist across all inputs.\n- Must derive axis ranges solely from the provided Point attributes.\n- Must not vary point size by series or data values.\n- The accessible data table must remain visually hidden while available to assistive technologies.\n- The container's accessible label must reflect the Label slot content and must not introduce unrelated descriptions.\n\n# Notes\n- The consumer is responsible for pre-calculating any trend-line coordinates before providing them as a dedicated series.\n- Tooltip content is limited to the point's label, value, and series name.\n- Color inheritance follows the order: Series color takes precedence over individual Point color.";
}
declare module "_102040_/l2/molecules/groupviewchart/ml-scatter-plot" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlScatterPlotMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        showLegend: boolean;
        showValues: boolean;
        loading: boolean;
        private hoveredPoint;
        private chartContainer?;
        render(): any;
        private parseData;
        private getChartMetrics;
        private getTicks;
        private scaleX;
        private scaleY;
        private renderAxes;
        private renderPoint;
        private renderPointValue;
        private renderTrendLines;
        private renderLegend;
        private renderTooltip;
        private renderDataTable;
        private handlePointEnter;
        private handlePointLeave;
        private handlePointClick;
        private handlePointKeyDown;
        private parseNumber;
        private formatNumber;
        private getPlainText;
    }
}
declare module "_102040_/l2/molecules/groupviewdata/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewdata/ml-card-grid';
    import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view';
    import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list';
    import '/_102040_/l2/molecules/groupviewdata/ml-calendar-view';
    import '/_102040_/l2/molecules/groupviewdata/ml-kanban-board';
    export class GroupViewDataIndex extends StateLitElement {
        private cardOne;
        private cardTwo;
        private cardThree;
        private cardFour;
        private cardFive;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupviewdata/ml-calendar-view.defs" {
    export const group = "groupViewData";
    export const skill = "# Metadata\n- TagName: groupviewdata--ml-calendar-view\n\n# Objective\nA calendar visualization that allows users to browse events in monthly or weekly layouts. It organizes time into columns, rows, and cells, enabling users to view event details or initiate new events by selecting time slots.\n\n# Responsibilities\n- Provide a visible control to switch between monthly and weekly viewing modes.\n- In monthly mode, display weeks as rows and days as cells. Each day shows event chips with titles that truncate when too long. When a day contains more events than fit, show an indicator with the count of additional items.\n- In weekly mode, display days as columns and hours as rows. Events appear inside the cells that match their scheduled day and time.\n- Allow consumers to supply events into the corresponding time cells using the standard group view data structure.\n- When a user selects an existing event, communicate the selection including the event data and its row position.\n- When a user selects an empty day or hour slot, communicate the selection including the cell and row data so the consumer can start creating an event.\n- Show a loading state when data is unavailable, replacing the calendar grid entirely.\n- Show an empty state when no time rows exist to display.\n- Apply hover styling to rows when hover interaction is enabled.\n- Apply selected styling and mark the row as selected when a row carries the selected state.\n- Apply disabled styling, prevent interaction, and mark the row as disabled when a row carries the disabled state.\n- Indicate busy state to assistive technologies while loading.\n\n# Constraints\n- Event titles must never overflow their chip container; they must truncate with a clear visual indication.\n- The overflow count indicator must be accurate and visible only when events exceed the cell's display limit.\n- The calendar grid must align headers, columns, and rows consistently across both viewing modes.\n- Loading and empty states must replace the grid completely rather than appearing alongside it.\n- A disabled row must not respond to clicks, focus, or other interactions.\n- Selected and disabled visual states must not appear together; disabled state must take precedence.\n- The view mode toggle must remain accessible and functional at all times.\n- Visual styles must adapt to dark mode using equivalent color mappings for surfaces, borders, text, and state indicators.\n\n# Notes\n- The molecule follows the groupViewData contract, using Columns, Column, Rows, Row, Cell, Empty, and Loading containers to structure content.\n- Consumer-provided events are placed within cells without adding new properties to the base data contract.\n- Interactions on both event chips and empty cells share the same selection channel, distinguished by whether event data is present.";
}
declare module "_102040_/l2/molecules/groupviewdata/ml-calendar-view" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CalendarViewMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        selectable: boolean;
        hoverable: boolean;
        name: string;
        private viewMode;
        private currentDate;
        private parsedColumns;
        private parsedRows;
        private readonly MAX_EVENTS_PER_DAY;
        private readonly HOURS_IN_DAY;
        private readonly DAYS_IN_WEEK;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseSlotContent;
        private parseColumns;
        private parseRows;
        private getWeekDays;
        private getMonthDays;
        private getWeekDates;
        private isSameDay;
        private getEventsForDate;
        private formatDateString;
        private getMonthYearLabel;
        private formatHour;
        private handleViewModeChange;
        private handlePrevious;
        private handleNext;
        private handleToday;
        private handleEventClick;
        private handleCellClick;
        private getContainerClasses;
        private getHeaderClasses;
        private getViewToggleClasses;
        private getNavButtonClasses;
        private getTodayButtonClasses;
        private getWeekDayHeaderClasses;
        private getDayCellClasses;
        private getDayNumberClasses;
        private getEventChipClasses;
        private getMoreEventsClasses;
        private getHourCellClasses;
        private getHourLabelClasses;
        private getWeekHeaderCellClasses;
        private getWeekHeaderDateClasses;
        private renderHeader;
        private renderChevronLeft;
        private renderChevronRight;
        private renderMonthView;
        private renderMonthDayCell;
        private renderWeekView;
        private renderWeekHourRow;
        private renderWeekHourCell;
        private renderLoading;
        private renderEmpty;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewdata/ml-card-grid.defs" {
    export const group = "groupViewData";
    export const skill = "# Metadata\n- TagName: groupviewdata--ml-card-grid\n\n# Objective\nDisplay records as individual cards arranged in a responsive multi-column grid. Each card combines visual content, title, description, metadata, and actions, offering a spacious, visual alternative to tabular presentation. Suitable for product catalogs, employee directories, project listings, document galleries, and customer panels.\n\n# Responsibilities\n- Use exclusively the contract slot tags: Columns, Column, Rows, Row, Cell, Empty, and Loading.\n- Represent each Row as one card in the grid.\n- Present each Cell inside a Row as a content block within the card, preserving the declared order and accepting any content type\u2014such as images, avatars, titles, descriptions, metadata, or actions\u2014without enforcing additional structure.\n- Respect column definitions including field, header, width, align, and hidden to guide data presentation and omit fields marked as hidden.\n- In loading state, hide all rows and present only the Loading content when provided.\n- When no Rows are present, hide the grid and present only the Empty content when provided.\n- When selection is enabled, toggle the selected state of a card upon activation and communicate the current list of selected indices through selection-change.\n- When selection is enabled, communicate the activated row index and Row reference through row-click upon card activation.\n- When selection is disabled, communicate only the activated row index and Row reference through row-click upon card activation.\n- Prevent activation and selection changes on cards whose Row carries the disabled attribute, expose aria-disabled, and present the card as non-interactive.\n- Present cards whose Row carries the selected attribute as selected, expose aria-selected, and apply the corresponding visual highlight.\n- Provide hover feedback on cards when hoverable is enabled; suppress all hover feedback when hoverable is disabled.\n- Enforce the presence of Columns, Rows, and at least one Column, raising the contract-specified errors when any are absent.\n- Ignore unknown tags and issue the contract-specified warning.\n\n# Constraints\n- The grid must automatically adjust its column count to fit the viewport.\n- Cards must maintain comfortable internal spacing and clear visual separation.\n- Selected cards must exhibit a visual highlight consistent with the contract's Selected state.\n- Disabled cards must present reduced opacity and must not react to interaction.\n- Loading and Empty states must replace the grid entirely rather than appearing alongside it.\n- Background, border, and text colors must support dark mode variants per the general contract semantic table.\n- Cards must align uniformly and scale responsively within their container without relying on fixed dimensions.\n\n# Notes\n- The internal card layout naturally supports visual-first arrangements, allowing images or avatars to precede titles, descriptions, and actions in the order defined by Cells.\n- Unrecognized tags are ignored to preserve forward compatibility.";
}
declare module "_102040_/l2/molecules/groupviewdata/ml-card-grid" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlCardGridMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        selectable: boolean;
        hoverable: boolean;
        private selectedIndices;
        private validationDone;
        firstUpdated(): void;
        private handleRowActivation;
        private handleRowKeydown;
        render(): any;
        private renderLoading;
        private renderEmpty;
        private renderGrid;
        private renderCard;
        private renderCell;
        private getColumnDefs;
        private getRowElements;
        private getCellElements;
        private getDirectChildrenByTag;
        private getSelectedFromRows;
        private isRowSelected;
        private isTruthyAttr;
        private getCardClasses;
        private validateStructure;
        private validateUnknownTags;
    }
}
declare module "_102040_/l2/molecules/groupviewdata/ml-kanban-board.defs" {
    export const group = "groupViewData";
    export const skill = "# Metadata\n- TagName: groupviewdata--ml-kanban-board\n\n# Objective\nDisplay a Kanban board with configurable columns and vertically stacked cards. Enable moving cards between columns, adding new cards per column, and handling loading, empty, and selection states. Notify consumers of card movements and additions.\n\n# Responsibilities\n- Present columns side by side in a horizontal layout following the defined column order.\n- Render each column header showing a primary title and complementary information such as color or an optional work-in-progress limit.\n- Stack cards vertically inside each column.\n- Display card content including title, subtitle, and badges while maintaining visual hierarchy.\n- Allow cards to be dragged from one column to another when neither the source nor destination column is disabled.\n- Upon dropping a card into a destination Row, emit a row-click event carrying the destination Row index and the moved Cell element so the consumer can derive the card identity.\n- Include a dedicated add action Cell within each Row to support creating a new card; this Cell must not participate in drag-and-drop.\n- Upon activating the add action Cell, emit a row-click event carrying the Row index and the add action Cell element.\n- Show a loading state and hide column content while loading.\n- Show an empty state when no Rows exist.\n- Support column selection when enabled, track selected Row indices, and emit selection-change with the list of selected indices.\n- Apply visual hover feedback to Rows and their Cells when hover is enabled.\n- Expose busy, selected, and disabled states through aria-busy, aria-selected, and aria-disabled attributes.\n\n# Constraints\n- Must use only the contract slot tags: Columns, Column, Rows, Row, Cell, Empty, and Loading.\n- Column headers must use the header attribute for the primary title; complementary header content must be placed in the Column slot content.\n- Each Row must represent a Kanban column in the same order as the Column definitions.\n- Each Cell inside a Row must represent exactly one card in that column.\n- Card content must be rendered from the Cell's provided content without altering the intended visual structure.\n- Cards must not be draggable to or from Rows marked with a disabled attribute.\n- The add-card action must be a dedicated Cell within each Row and must not be treated as a draggable card.\n- While loading is true, the Loading slot must fill the main area and Rows must be hidden.\n- When no Rows are defined, the Empty slot must fill the main area.\n- Selected Rows must show a distinct selected state; disabled Rows must show reduced opacity and inactive styling.\n- All background, border, text, and state colors must have corresponding dark variants per the semantic contract.\n- Horizontal scrolling must be available when total column width exceeds the available space.\n- The component must declare aria-busy when loading, aria-selected on selected Rows, and aria-disabled on disabled Rows.\n\n# Notes\n- The consumer determines card identity by inspecting the card element returned in move and add notifications.\n- Hover, selected, and disabled appearances must align with the system design contract.";
}
declare module "_102040_/l2/molecules/groupviewdata/ml-kanban-board" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlKanbanBoardMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        selectable: boolean;
        hoverable: boolean;
        private selectedIndices;
        private draggedCard;
        private dropTargetRowIndex;
        private parsedColumns;
        private parsedRows;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseSlotContent;
        private parseColumns;
        private parseRows;
        private handleRowClick;
        private toggleSelection;
        private handleDragStart;
        private handleDragOver;
        private handleDragLeave;
        private handleDrop;
        private handleDragEnd;
        private handleAddCardClick;
        private getColumnHeaderClasses;
        private getColumnClasses;
        private getCardClasses;
        private getAddCardClasses;
        private getDropZoneClasses;
        render(): TemplateResult;
        private renderLoading;
        private renderEmpty;
        private renderBoard;
        private renderColumn;
        private spreadAttributes;
        private renderColumnHeader;
        private renderColumnContent;
        private renderCard;
        private renderAddCard;
    }
}
declare module "_102040_/l2/molecules/groupviewdata/ml-timeline-view.defs" {
    export const group = "groupViewData";
    export const skill = "# Metadata\n- TagName: groupviewdata--ml-timeline-view\n\n# Objective\nPresent events in chronological order along a timeline. The molecule must support vertical and horizontal reading flows, group events by date, handle item selection and hover, manage disabled items, and switch between loading, empty, and populated states using designated content regions.\n\n# Responsibilities\n- Display chronological events using a structure of rows and columns, where each row represents one event and cells supply content for each visible column.\n- Automatically choose the layout orientation: horizontal when only one column is visible and multiple events are present; vertical in all other cases.\n- Respect column order and visibility; exclude any column marked as hidden.\n- Support full-width group headers that span all visible columns to separate event groups such as dates or categories.\n- Allow selection of events when selection is enabled, toggling the selection state and reporting which events are selected.\n- Notify when an interactive event is activated, providing its position and identity, regardless of selection mode.\n- Prevent activation and selection on disabled events, and indicate the disabled condition.\n- Identify which events are currently selected.\n- Present a dedicated loading region when loading, hiding all events and signaling that the molecule is busy.\n- Present a dedicated empty region when no events exist, centered within the available space.\n- Enforce structural rules by requiring necessary column identifiers and headers.\n\n# Constraints\n- Group header rows must not respond to activation or participate in selection, even when selection mode is enabled.\n- Only events that are not disabled may be activated or selected.\n- Activating an event must always trigger a notification, independent of selection mode.\n- In loading state, no timeline track, markers, or event content may appear; only the loading region may be visible.\n- In empty state, only the empty region may be visible, centered within the molecule.\n- In vertical layout, a continuous track must align with the marker column, each marker must be centered on the track, and event content must align consistently to the side of the track with uniform spacing between events.\n- In horizontal layout, a continuous track must align with the markers, events must be distributed left to right in chronological order, each marker centered on the track, and content stacked above or below the marker according to column order.\n- Group headers must visually interrupt the timeline track and appear distinct from regular events.\n- Hover highlighting must apply only when hover interaction is enabled and must not appear on disabled events or group headers.\n- Selected events must be highlighted using semantic accent colors for background, border, and text.\n- Disabled events must appear at reduced opacity and must not display interactive visual cues.\n- All background, text, border, and accent colors must provide a dark variant under the semantic color contract.\n\n# Notes\n- Event content supports free content within the cell structure.\n- Marker appearance and color are defined per event through the content structure.\n- Layout orientation is derived from the number of visible columns and the quantity of events, not by explicit configuration.";
}
declare module "_102040_/l2/molecules/groupviewdata/ml-timeline-view" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class TimelineViewMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        selectable: boolean;
        hoverable: boolean;
        private selectedIndices;
        private parsedColumns;
        private parsedRows;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseSlotContent;
        private parseColumns;
        private parseRows;
        private get visibleColumns();
        private get isHorizontalLayout();
        private get isEmpty();
        private handleRowClick;
        private getContainerClasses;
        private getTimelineWrapperClasses;
        private getRowClasses;
        private getMarkerClasses;
        private getCellClasses;
        private getTrackClasses;
        private renderLoading;
        private renderEmpty;
        private renderEmptyIcon;
        private renderGroupHeader;
        private renderEventRow;
        private renderVerticalEvent;
        private renderHorizontalEvent;
        private renderEventContent;
        private renderTimeline;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupviewdata/ml-vertical-record-list.defs" {
    export const group = "groupViewData";
    export const skill = "# Metadata\n- TagName: groupviewdata--ml-vertical-record-list\n\n# Objective\nDisplay a vertical list of records within the groupViewData context. Each record supports multiple content regions such as visual identifiers, titles, descriptions, metadata, and actions. The molecule manages loading states, empty collections, item selection, and user interaction events.\n\n# Responsibilities\n- Display a collection of items in vertical sequence, preserving the provided order.\n- Support multiple content regions within each item, arranged horizontally from start to end.\n- Validate that column definitions are provided; surface validation errors when column definitions are missing.\n- When loading, display loading content and hide the item list.\n- When no items exist, display empty state content.\n- Allow toggling selection of individual items when selection is enabled, and communicate the set of selected item indices whenever selection changes.\n- Communicate which item was activated when a user selects or activates an item.\n- Ignore interactions, prevent selection changes, and suppress activation communication for disabled items.\n- Recognize pre-selected items upon initial display and include them in subsequent selection state updates.\n- Apply a hover visual state to items when hover interaction is enabled; provide no hover effect when hover interaction is disabled.\n- Indicate a busy state while loading, mark selected items as selected, and mark disabled items as disabled for accessibility purposes.\n\n# Constraints\n- Items must be presented as a vertical list without table header styling.\n- Adjacent items must be separated by a visual divider spanning the full width, except after the last item.\n- Selected items must use a distinct visual state consistent with the selected state definition.\n- Disabled items must appear visually inactive.\n- Empty state content must be centered or visually isolated within the list container.\n- Loading content must fill the list area and align with the item layout to maintain visual continuity.\n- All color and surface styling must include dark mode equivalents using semantic pairings for surfaces, borders, text, hover, and selection states.\n\n# Notes\n- Intended for corporate use cases including activity feeds, team directories, ticket queues, financial transaction lists, and task boards.\n- Item content is expected to accommodate patterns such as avatars, title and subtitle blocks, meta information, and action controls.";
}
declare module "_102040_/l2/molecules/groupviewdata/ml-vertical-record-list" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlVerticalRecordListMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        selectable: boolean;
        hoverable: boolean;
        private selectedIndices;
        private selectionInitialized;
        private lastRowCount;
        updated(): void;
        private initializeSelection;
        private pruneSelection;
        private emitSelectionChange;
        private handleRowClick;
        private parseColumns;
        private parseBooleanAttr;
        private getValidationErrors;
        private renderValidation;
        private renderLoading;
        private renderEmpty;
        private renderRows;
        private renderRow;
        private renderCells;
        private getCellClasses;
        private getCellStyle;
        private getRowClasses;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewhierarchy/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-view-hierarchy-mindmap';
    export class GroupViewHierarchyIndex extends StateLitElement {
        private card1;
        private card2;
        private card3;
        private card4;
        protected render(): TemplateResult;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
    }
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart.defs" {
    export const group = "groupViewHierarchy";
    export const skill = "# Metadata\n- TagName: groupviewhierarchy--ml-hierarchy-orgchart\n\n# Objective\nRender an interactive organizational-chart-style hierarchy tree where each node is displayed as a card-like button connected to its children by vertical and horizontal lines. Users can expand or collapse branches, navigate the tree with the keyboard, and select individual nodes.\n\n# Responsibilities\n- Parse nested Node slot elements recursively to build the full tree model, preserving parent-child relationships and depth information.\n- Render each node as a focusable button with an optional expand/collapse toggle button when the node has children.\n- Draw connector lines between parent and child nodes to visually communicate the hierarchy.\n- Track expanded/collapsed state per node path; nodes marked with the expanded attribute start expanded by default.\n- Expand all nodes simultaneously when expandAll is true.\n- When multiple is false, collapse all sibling nodes at the same level when one is expanded.\n- Dispatch a nodeClick CustomEvent (bubbles, composed) with the node's value when a node button is clicked or Enter is pressed.\n- Dispatch a toggle CustomEvent (bubbles, composed) with the node's value and the new expanded state when a node is toggled.\n- Support full keyboard navigation: ArrowDown/ArrowUp move focus between visible nodes; ArrowRight expands a collapsed node or moves focus forward; ArrowLeft collapses an expanded node or moves focus to the parent.\n- Show an optional title when a Label slot is provided.\n- Render an animated loading skeleton when loading is true.\n- Render an empty state message when no nodes are present; use the Empty slot content when provided, otherwise use the localized default.\n- Manage roving tabindex so only one node is in the tab sequence at a time.\n\n# Constraints\n- The component must not contain business logic; node meaning and actions are the consumer's responsibility.\n- Nodes marked with the disabled attribute or when the component-level disabled property is true must not respond to click, toggle, or keyboard activation.\n- When multiple is false, expanding one node must immediately collapse all its siblings at the same hierarchy level.\n- Focus must remain within the currently rendered set of visible node buttons; focus must not move to hidden or collapsed nodes.\n- The component renders with role=\"tree\" and each node button with role=\"treeitem\" to maintain ARIA tree semantics.";
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class HierarchyOrgchartMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        expandAll: boolean;
        disabled: boolean;
        loading: boolean;
        private expandedState;
        private focusedPath;
        firstUpdated(): void;
        updated(): void;
        private buildTree;
        private createNodeModel;
        private getRootNodeElements;
        private getChildNodeElements;
        private getNodeLabelHtml;
        private getExpandedForPath;
        private ensureFocusPath;
        private focusButton;
        private handleNodeClick;
        private handleToggleClick;
        private applyToggle;
        private handleKeyDown;
        render(): any;
        private renderLoading;
        private renderEmpty;
        private renderNode;
        private renderChevron;
        private getNodeButtonClasses;
        private getToggleButtonClasses;
    }
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram.defs" {
    export const group = "groupViewHierarchy";
    export const skill = "# Metadata\n- TagName: groupviewhierarchy--ml-hierarchy-tree-diagram\n\n# Objective\nRender an interactive hierarchy tree in a horizontal diagram style where each node is shown with a circular state indicator, a toggle button, and its label, connected to children through decorative SVG connectors. The layout flows top-to-bottom with children arranged to the right, providing a clear branching visual metaphor.\n\n# Responsibilities\n- Parse nested Node slot elements recursively to build the tree model, assigning stable path-based IDs to each node.\n- Render each node with a circular state indicator (highlighted when expanded), a toggle button for nodes with children, and a label area.\n- Render SVG connector curves between parent nodes and their children to communicate the branching structure visually.\n- Track expanded/collapsed state in an internal map, using each node's expanded attribute as the initial default.\n- Expand all nodes when expandAll is true by clearing the expanded state map so all nodes default to expanded.\n- When multiple is false, collapse all sibling nodes at the same parent level when one sibling is expanded.\n- Maintain a list of currently visible node IDs and use it for arrow-key focus navigation.\n- Dispatch a nodeClick CustomEvent (bubbles, composed) with the node's value when a node label is clicked.\n- Dispatch a toggle CustomEvent (bubbles, composed) with the node's value and the new expanded state when a toggle button is activated.\n- Support keyboard navigation: ArrowDown/ArrowUp move focus through visible nodes; ArrowRight expands a collapsed node; ArrowLeft collapses an expanded node; Enter toggles a node with children.\n- Show an optional label when a Label slot is provided.\n- Render a loading message when loading is true.\n- Render an empty state message when no nodes exist; use the Empty slot content when provided, otherwise use the localized default.\n\n# Constraints\n- The component must not contain business logic; node meaning and actions are the consumer's responsibility.\n- Nodes with the disabled attribute or when the component-level disabled property is true must not respond to any interaction including click, toggle, and keyboard activation.\n- When multiple is false, expanding a node must collapse its siblings within the same parent before expanding the target node.\n- Focus movement via arrow keys must be constrained to the current set of visible (non-collapsed) node IDs.\n- The component uses createRenderRoot returning this, meaning it renders without a shadow DOM.";
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class HierarchyTreeDiagramMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        expandAll: boolean;
        disabled: boolean;
        loading: boolean;
        private focusedId;
        private expandedMap;
        private nodeIndex;
        private visibleNodeIds;
        createRenderRoot(): this;
        updated(changedProps: Map<string, unknown>): void;
        private buildTree;
        private isNestedNode;
        private parseNode;
        private getNodeLabelHtml;
        private isExpanded;
        private refreshVisibleNodes;
        private handleNodeClick;
        private handleToggle;
        private handleNodeKeydown;
        private moveFocus;
        private focusCurrentNode;
        private getToggleClasses;
        private getLabelClasses;
        private getCircleClasses;
        private renderToggleIcon;
        private renderConnector;
        private renderNode;
        private renderLabel;
        private renderEmpty;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree.defs" {
    export const group = "groupViewHierarchy";
    export const skill = "# Metadata\n- TagName: groupviewhierarchy--ml-hierarchy-tree\n\n# Objective\nDisplay a hierarchical tree structure that allows users to navigate nested levels by expanding and collapsing nodes, while emitting events for interactions. The tree renders user-provided nested content, supports disabled states, and adapts to single or multiple selection patterns without maintaining selection state internally.\n\n# Responsibilities\n- Render the hierarchy based on nested Node items provided by the user, where nesting establishes parent-child relationships.\n- Display the Empty content as a placeholder when no Node items are provided.\n- Display the Label content as a title above the tree when provided.\n- Allow nodes with children to expand and reveal their children or collapse and hide them.\n- Treat nodes without children as leaves and do not present expansion controls for them.\n- Emit a toggle event containing the node's value and its expanded state when the expansion control is activated.\n- Emit a nodeClick event containing the node's value when a node's content is activated.\n- Respect the initial expanded state indicated on each Node, unless expandAll is active, in which case all nodes must start expanded.\n- Collapse sibling nodes at the same level when a node is expanded and multiple selection is disabled.\n- Block all expansion, collapse, and click interactions when the component is disabled.\n- Block interactions only on specific nodes marked as disabled.\n- Preserve and display the full user-provided content of each Node as its visual label, including any checkboxes, icons, or other elements.\n- Emit nodeClick events for selection purposes without maintaining internal selection state.\n- Render exactly the nodes provided by the user without applying internal filtering, searching, or term highlighting.\n- Display an expansion indicator exclusively on nodes that contain children.\n- Visually indent child nodes relative to their parent to indicate hierarchy.\n- Show only the node label when collapsed; show the label and its children when expanded.\n- Present disabled nodes with a visually dimmed appearance.\n- Present all nodes as visually dimmed when the entire component is disabled.\n- Adapt visual presentation for dark mode with appropriate treatment for surfaces, text, borders, and hover states according to the group's semantic contract.\n\n# Constraints\n- Must not maintain internal selection state; selection must be handled entirely by the consuming system through emitted events.\n- Must not perform internal search, filtering, or text highlighting; the provided Node content must be rendered exactly as received.\n- Leaf nodes must never display expansion controls or empty child areas.\n- Sibling collapse behavior applies only when multiple selection is disabled.\n- Disabled states on individual nodes and on the component must prevent associated interaction events from emitting.\n\n# Notes\n- The user is responsible for providing pre-filtered and pre-highlighted content within Node items when search or highlight behavior is desired.\n- Selection indicators such as checkboxes must be included by the user inside the Node content; the component provides only the structural behavior and events.";
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class HierarchyTreeMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        expandAll: boolean;
        disabled: boolean;
        loading: boolean;
        private expandedNodes;
        private parsedNodes;
        private focusedNodeId;
        private nodeIdCounter;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseNodes;
        private parseNodeElement;
        private initializeExpandedState;
        private expandAllNodes;
        private initializeFromAttributes;
        private handleToggle;
        private handleNodeClick;
        private handleKeyDown;
        private focusNode;
        private getFlatNodes;
        private getContainerClasses;
        private getLabelClasses;
        private getNodeClasses;
        private getToggleClasses;
        private getEmptyClasses;
        private getLoadingClasses;
        private getChildrenContainerClasses;
        render(): any;
        private renderLoading;
        private renderEmpty;
        private renderLabel;
        private renderNode;
        private renderToggleIcon;
        private renderLeafSpacer;
        private renderChildren;
    }
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-view-hierarchy-mindmap.defs" {
    export const group = "groupViewHierarchy";
    export const skill = "# Metadata\n- TagName: groupviewhierarchy--ml-view-hierarchy-mindmap\n\n# Objective\nPresent a mind-map hierarchy with a configurable central node and radial child layout. Enable users to explore parent-child relationships through expand and collapse interactions, navigate the view via pan and zoom, and interact with nodes while delegating all structural changes to the consumer.\n\n# Responsibilities\n- Present a central node with children arranged radially on concentric rings, maintaining spacing to avoid overlap.\n- When multiple top-level nodes exist, treat the first as the central node and place the remaining top-level nodes on the first radial ring.\n- Draw connection lines between parents and children, colored to match the parent node's text styling.\n- Present node labels using the provided content, allowing rich embedded content for consumer-supplied controls.\n- Provide expand and collapse interaction only on nodes that have children; present leaf nodes without a toggle.\n- Hide all descendants of a collapsed node; reveal the full subtree of an expanded node.\n- Start every node expanded when expand-all is active, ignoring individual node preferences.\n- Start a node expanded only when it is explicitly configured to do so and expand-all is inactive; otherwise start collapsed.\n- In single-expand mode, collapse siblings at the same depth when a node is expanded.\n- In multiple-expand mode, allow multiple siblings at the same depth to remain expanded simultaneously.\n- Prevent all node interactions when the component is disabled; prevent only the specific interaction when an individual node is disabled.\n- Visually de-emphasize disabled nodes; de-emphasize every node when the entire component is disabled.\n- Signal node selection when a node is clicked or double-clicked, including the node's identifier or null if absent.\n- Signal state changes when a node is expanded or collapsed, including the node's identifier and its new expanded state.\n- Never create, remove, or modify nodes internally; reflect only the structure supplied by the consumer.\n- Allow panning the view by dragging the background area.\n- Allow zooming the entire view with pointer wheel or trackpad gestures, scaling nodes and connections smoothly.\n- Present an empty state when no nodes are supplied.\n- Present a loading indicator when loading is active.\n- Communicate the hierarchy structure, expansion state, and disabled state to assistive technologies.\n- Support keyboard navigation: move focus between nodes with up and down arrows, expand with right arrow, collapse with left arrow, and toggle with enter.\n\n# Constraints\n- Only recognize content supplied through the three named contract regions: Label, Node, and Empty.\n- Treat nested Node regions as parent-child relationships.\n- Use the direct content of a Node as its label, excluding any nested Node regions.\n- Show the Empty region only when no Node regions are provided.\n- Do not provide a built-in label editing interface; rely on external workflows triggered by selection signals.\n\n# Notes\n- Double-clicking intentionally triggers the same selection signal as clicking to support external editing workflows.\n- Rich content inside labels is presented as-is to enable consumer-defined action controls such as add or remove buttons.";
}
declare module "_102040_/l2/molecules/groupviewhierarchy/ml-view-hierarchy-mindmap" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlViewHierarchyMindmapMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        multiple: boolean;
        expandAll: boolean;
        disabled: boolean;
        loading: boolean;
        private parsedNodes;
        private expandedMap;
        private viewBox;
        private scale;
        private focusedNodeId;
        private nodeIdCounter;
        private isPanning;
        private panStart;
        private viewBoxStart;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseNodes;
        private parseNodeElement;
        private initializeExpandedState;
        private isExpanded;
        private calculatePositions;
        private layoutChildren;
        private handleNodeClick;
        private handleNodeDblClick;
        private handleToggle;
        private handleWheel;
        private handleMouseDown;
        private handleMouseMove;
        private handleMouseUp;
        private handleKeyDown;
        private findNodeById;
        private getNodeClasses;
        private renderConnections;
        private renderNodes;
        private renderNode;
        private renderToggleButton;
        private renderLabel;
        private renderEmpty;
        private renderLoading;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewmetric/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-gauge';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-card';
    import '/_102040_/l2/molecules/groupviewmetric/ml-compact-metric-sparkline';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-trend-compare';
    export class GroupViewMetricIndex extends StateLitElement {
        private cardBigNumberLoading;
        private cardGaugeLoading;
        private cardMetricCardLoading;
        private cardSparklineLoading;
        private cardTrendCompareLoading;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        protected render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-compact-metric-sparkline.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-compact-metric-sparkline\n\n# Objective\nDisplay a compact metric with an inline sparkline trend, supporting loading states and accessible markup.\n\n# Responsibilities\n- Render the primary metric value using the required Value slot.\n- Render the Trend slot content adjacent to the Value, allowing it to wrap below when horizontal space is insufficient.\n- Preserve hover interactions on the Trend content so that point tooltips can appear.\n- When the Trend slot provides a direction, apply an accessible label to the Trend container describing that direction.\n- During loading, show a skeleton placeholder that mirrors the presence and positions of the Label, Value, Trend, Icon, and Helper slots, and do not render slot content.\n- Expose the container as a figure and derive its accessible label from the Label slot content when present.\n- Announce updates to the Value region politely.\n- Accept sparkline data, point tooltips, and line color exclusively through the Trend slot content.\n\n# Constraints\n- Must use only the groupViewMetric slot tags: Label, Value, Icon, Trend, and Helper.\n- Must not accept sparkline data arrays through properties.\n- Must not emit events.\n- Must present the sparkline without axes, gridlines, or labels.\n- Must apply semantic positive, negative, or neutral styling to the Trend container based on direction, while permitting the slot content to define its own line color.\n- Must support dark-mode counterparts for surface, text, border, and accent colors.\n- Must maintain compact visual hierarchy: Value is prominent, Label is smaller and secondary, Helper appears below the Value, and Icon is aligned with the Label/Value block without dominating the Value.\n\n# Notes\n- The sparkline is presented as a clean inline graphic.";
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-compact-metric-sparkline" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class CompactMetricSparklineMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        render(): any;
        private renderContent;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderSkeleton;
        private getTrendClasses;
        private getFigureAriaLabel;
        private stripHtml;
    }
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-big-number.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-big-number\n\n# Objective\nDisplay a single key metric as a large prominent number accompanied by optional contextual elements: an icon, a descriptive label, a trend indicator with directional coloring, and a helper text. The component is designed for dashboard-style KPI cards where a value needs to be immediately scannable.\n\n# Responsibilities\n- Render the Value slot content in a large, bold typography style as the focal point of the component.\n- Render the Label slot content in a smaller, muted style above the value when the Label slot is present.\n- Render the Icon slot content in a neutral color container when the Icon slot is present.\n- Render the Trend slot content with color-coded styling based on the direction attribute of the Trend slot: green for \"up\", red for \"down\", and neutral gray for \"neutral\" or any unrecognized value.\n- Render the Helper slot content in a small, subdued style below the trend when the Helper slot is present.\n- Render an animated loading skeleton with pulse placeholders when loading is true.\n- Set aria-live=\"polite\" on the value container so assistive technologies announce value changes.\n- Derive the accessible aria-label for the figure container from the Label slot text content, stripping HTML tags.\n\n# Constraints\n- The component must not contain business logic; metric computation and data binding are the consumer's responsibility.\n- The component must render nothing (empty template) when the Value slot is absent and loading is false.\n- Icon, Label, Trend, and Helper are all optional; the component must render correctly when any combination of them is absent.\n- Trend color must be determined exclusively by the direction attribute on the Trend slot element; the component must not infer direction from the value content itself.\n- The component must not alter the content of any slot; it only wraps slot content in styled containers.";
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-big-number" {
    import { TemplateResult } from 'lit';
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlMetricBigNumberMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        render(): TemplateResult;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderLoadingSkeleton;
        private getContainerClasses;
        private getTrendClasses;
        private getTrendDirection;
        private getAriaLabel;
    }
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-card.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-card\n\n# Objective\nPresent a statistical card that displays a configurable icon, a descriptive label, a primary highlighted value, and a trend indicator with period comparison. It must support a loading state and follow the groupViewMetric contract.\n\n# Responsibilities\n- Display an icon when icon content is provided.\n- Display a label as the metric title or description.\n- Display a primary value with the highest visual prominence.\n- Display a trend indicator when trend content is provided, applying the appropriate state based on the declared direction of up, down, or neutral.\n- Display helper text as supporting information for period comparisons when helper content is provided.\n- Replace visible content with a skeleton representation that mirrors the card layout during loading.\n- Behave as a figure and derive its accessible name from the label content.\n- Announce updates to the primary value politely to assistive technologies.\n- Describe the trend direction through an accessible label on the trend indicator.\n\n# Constraints\n- Must only use the contract-defined content areas: Icon, Label, Value, Trend, and Helper.\n- The primary value is mandatory and must always be present.\n- Must not offer multiple size variants; it must render at a single default size.\n- Must not emit events.\n- The trend indicator must visually distinguish positive, negative, and neutral states using green, red, and gray respectively, including equivalent dark variants.\n- Colors and visual states must follow semantic pairings with corresponding dark variants for backgrounds, text, and borders.\n- The skeleton state must preserve the overall card layout, representing the icon, label, value, and trend areas.\n- The primary value must maintain greater visual hierarchy than the label and helper text.\n- Helper text must remain visually subordinate to the primary value and label.\n\n# Notes\n- The component is purely presentational and depends on externally provided content.\n- Trend direction styling applies only when trend content is supplied and a direction is explicitly declared.";
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-card" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MetricCardMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        private getBaseClasses;
        private getLabelClasses;
        private getValueClasses;
        private getHelperClasses;
        private getTrendClasses;
        private getAriaLabelFromHtml;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderSkeleton;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-gauge.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-gauge\n\n# Objective\nDisplay a compact metric card that combines a key value with a horizontal gauge bar, providing an immediate visual sense of progress or fill level. The card optionally includes an icon, a label, a trend badge with directional coloring, and helper text, making it suitable for dashboard KPI widgets that need both a numeric readout and a relative-position indicator.\n\n# Responsibilities\n- Render the Value slot content in a bold numeric style as the primary readout.\n- Render a horizontal gauge bar below the value as a static visual track with a filled region and a circular indicator marker.\n- Render the Label slot content in a small muted style above the value when the Label slot is present.\n- Render the Icon slot content inside a square rounded container when the Icon slot is present.\n- Render the Trend slot content as a pill badge with color-coded border and text based on the direction attribute of the Trend slot: green for \"up\", red for \"down\", and neutral gray for any other value.\n- Render the Helper slot content in a small subdued style below the gauge bar when the Helper slot is present.\n- Render an animated pulse loading skeleton that mirrors the card layout when loading is true.\n- Derive the accessible aria-label of the figure container from the Label slot's text content when present.\n- Set aria-live=\"polite\" on the value container so assistive technologies announce value changes.\n\n# Constraints\n- The component must not contain business logic; metric value, gauge fill level computation, and trend direction are the consumer's responsibility.\n- The gauge bar is a purely decorative static element; it does not reflect the Value slot content programmatically.\n- Icon, Label, Trend, and Helper are all optional; the component must render correctly when any combination of them is absent.\n- Trend color must be determined exclusively by the direction attribute on the Trend slot element; the component must not infer direction from the value content.\n- The component must not alter the content of any slot; it only wraps slot content in styled containers.";
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-gauge" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MetricGaugeMolecule extends MoleculeAuraElement {
        slotTags: string[];
        loading: boolean;
        render(): any;
        private renderIcon;
        private renderLabel;
        private renderValue;
        private renderTrend;
        private renderHelper;
        private renderGauge;
        private renderLoading;
        private getAriaLabel;
        private getTrendClasses;
    }
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-trend-compare.defs" {
    export const group = "groupViewMetric";
    export const skill = "# Metadata\n- TagName: groupviewmetric--ml-metric-trend-compare\n\n# Objective\nDisplay a metric with emphasis on the current value, accompanied by a reference label, previous period context, and a directional trend indicator that communicates performance semantically.\n\n# Responsibilities\n- Display a label identifying the metric above the primary value.\n- Display the current value as the most prominent element, preserving any provided formatting such as numbers, currency, or percentages.\n- Display comparison context below the current value, including the reference period and the previous period value when available.\n- Display a trend indicator visually linked to the current value, with explicit semantic direction: positive, negative, or neutral.\n- Render a loading state that replaces all data content while preserving the intended visual structure.\n- Expose the metric container with an accessible name derived from its label.\n- Announce changes to the current value to assistive technologies in a non-intrusive manner.\n- Provide a textual description of the trend direction for assistive technologies.\n- Remain purely visual and non-interactive, producing no events.\n\n# Constraints\n- The component must not infer or calculate trend direction from numeric values; direction must be explicitly defined.\n- During loading, no actual data or text may be visible; only structural placeholders may appear.\n- Trend indicator styling must map consistently to semantic direction across all supported color schemes, including dark variants.\n- The component must not support or emit user interaction events.\n\n# Notes\n- Comparison period descriptions are configurable to support various analytical contexts (e.g., prior week, prior year).\n- The component receives values already formatted and renders them without modification.";
}
declare module "_102040_/l2/molecules/groupviewmetric/ml-metric-trend-compare" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlMetricTrendCompareMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        loading: boolean;
        private announceKey;
        render(): any;
        private renderLabel;
        private renderValue;
        private renderIcon;
        private renderTrend;
        private renderHelper;
        private renderLoadingSkeleton;
        private getTrendClasses;
        private getTrendAriaLabel;
        private getLabelText;
        private stripHtml;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/index" {
    import { TemplateResult } from 'lit';
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupviewtable/ml-view-table';
    import '/_102040_/l2/molecules/groupviewtable/ml-inline-edit-table';
    import '/_102040_/l2/molecules/groupviewtable/ml-pivot-table';
    export class GroupGroupViewTableIndex extends StateLitElement {
        private card1;
        private card2;
        private card3;
        private card4;
        private card5;
        private renderHero;
        private renderShowcaseCards;
        private renderReferenceTable;
        render(): TemplateResult;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/ml-data-table-minimal.defs" {
    export const group = "groupViewTable";
    export const skill = "# Metadata\n- TagName: groupviewtable--ml-data-table-minimal\n\n# Objective\nFornecer uma tabela de dados minimalista com ordena\u00E7\u00E3o, sele\u00E7\u00E3o opcional, estados de vazio e carregamento, pagina\u00E7\u00E3o e suporte completo a dark mode.\n\n# Responsibilities\n- Renderizar a hierarquia de slots do grupo (Caption, TableHeader, TableBody, TableRow, TableHead, TableCell, TableFooter, Empty, Loading) conforme o contrato.\n- Exibir o estado de carregamento quando solicitado, substituindo o conte\u00FAdo da tabela pelo conte\u00FAdo de Loading ou pelo padr\u00E3o do contrato.\n- Exibir o estado vazio quando n\u00E3o houver linhas no corpo, usando Empty ou o padr\u00E3o do contrato.\n- Permitir ordena\u00E7\u00E3o nas colunas marcadas como orden\u00E1veis, alternando a dire\u00E7\u00E3o e emitindo o evento de ordena\u00E7\u00E3o com a chave e dire\u00E7\u00E3o.\n- Indicar visualmente a coluna ativa de ordena\u00E7\u00E3o e a dire\u00E7\u00E3o atual.\n- Quando a sele\u00E7\u00E3o estiver habilitada, permitir selecionar/deselecionar todas as linhas e linhas individuais, mantendo o valor de sele\u00E7\u00E3o e emitindo altera\u00E7\u00F5es.\n- Emitir evento de clique em linha quando uma linha for acionada fora do controle de sele\u00E7\u00E3o.\n- Quando houver pagina\u00E7\u00E3o habilitada, permitir a troca de p\u00E1gina e emitir o evento correspondente.\n- Propagar o estado de edi\u00E7\u00E3o para conte\u00FAdos dentro de c\u00E9lulas conforme o contrato.\n- Exibir mensagem de erro abaixo da tabela quando houver erro informado.\n- Renderizar o conte\u00FAdo fornecido pelos slots TableHead, TableCell, Empty e Loading conforme fornecido pelo usu\u00E1rio.\n\n# Constraints\n- Quando loading estiver ativo, o conte\u00FAdo da tabela n\u00E3o deve ser exibido.\n- Quando n\u00E3o houver linhas, o estado vazio deve ser mostrado e nenhuma linha deve ser exibida.\n- A ordena\u00E7\u00E3o s\u00F3 deve estar dispon\u00EDvel para colunas marcadas como orden\u00E1veis.\n- Quando disabled estiver ativo, deve bloquear ordena\u00E7\u00E3o, sele\u00E7\u00E3o e pagina\u00E7\u00E3o, mantendo o estado visual de desabilitado.\n- O valor de sele\u00E7\u00E3o deve refletir os \u00EDndices das linhas selecionadas no formato esperado pelo contrato.\n- O estado de sele\u00E7\u00E3o n\u00E3o deve interferir no disparo do evento de clique em linha fora do controle de sele\u00E7\u00E3o.\n\n# Notes\n- O suporte a dark mode deve cobrir todos os estados visuais e de feedback (normal, selecionado, vazio, carregando, erro e desabilitado).";
}
declare module "_102040_/l2/molecules/groupviewtable/ml-data-table-minimal" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDataTableMinimalMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        selectable: boolean;
        isEditing: boolean;
        page: number;
        pageSize: number;
        totalItems: number;
        value: string;
        error: string;
        disabled: boolean;
        loading: boolean;
        private sortKey;
        private sortDirection;
        firstUpdated(): void;
        updated(changedProps: Map<string, any>): void;
        private getHeaderCells;
        private getBodyRows;
        private getFooterRows;
        private getSortedRows;
        private getSelectionSet;
        private updateSelection;
        private getTotalPages;
        private propagateIsEditing;
        private syncSelectAllState;
        private handleSort;
        private handleSortKeydown;
        private handleRowSelection;
        private handleSelectAll;
        private handleRowClick;
        private handleRowKeydown;
        private handlePageChange;
        private renderCaption;
        private renderHeaderCell;
        private renderBodyRow;
        private renderFooter;
        private renderPagination;
        private renderError;
        private renderLoading;
        private renderEmpty;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/ml-data-table.defs" {
    export const group = "groupViewTable";
    export const skill = "# Metadata\n- TagName: groupviewtable--ml-data-table\n\n# Objective\nRender a full-featured data table that supports column-based sorting, row selection with checkboxes, pagination, an optional footer, an editing mode, and accessible semantics. The component reads its column definitions and row data from declarative slot elements and exposes rich interaction events so the host application can respond to user actions without the table containing any business logic.\n\n# Responsibilities\n- Parse TableHeader > TableHead slot elements to derive column definitions including key, label, sortable flag, text alignment, and optional width.\n- Parse TableBody > TableRow > TableCell slot elements to derive body row data.\n- Parse TableFooter > TableRow > TableCell slot elements to derive optional footer rows.\n- Sort rows client-side by the active column key when a sortable column header is clicked or activated with Enter or Space; toggle between ascending and descending on repeated activations; prefer numeric comparison when cell text is parseable as a number, otherwise use locale-aware string comparison.\n- Dispatch a sort CustomEvent (bubbles, composed) with key and direction after each sort activation.\n- Render per-row checkboxes and a select-all header checkbox when selectable is true; manage indeterminate state on the header checkbox when some but not all rows are selected.\n- Represent the selected rows as a comma-separated string of row indices in the value property; dispatch a change CustomEvent (bubbles, composed) with the new value string on every selection change.\n- Dispatch a rowClick CustomEvent (bubbles, composed) with the row index when a data row is clicked outside of its checkbox.\n- Render a page number bar with previous/next buttons and ellipsis markers when pageSize is greater than zero and totalPages is greater than one; dispatch a pageChange CustomEvent (bubbles, composed) with the new page number.\n- Propagate the is-editing attribute with its current boolean value to all custom elements (tags containing a hyphen) found inside TableCell slots after every render update.\n- Show an optional caption above the table and as a visually hidden table caption element when the Caption slot is provided.\n- Display a selection count badge when selectable is true and at least one row is selected.\n- Render an animated skeleton loading state when loading is true; use the Loading slot content if provided, otherwise use the built-in skeleton.\n- Render an empty state row spanning all columns when no body rows are present; use the Empty slot content if provided, otherwise use the localized default message.\n- Render an error message below the table when the error property is non-empty.\n- Support English and Portuguese UI strings via the i18n message system.\n\n# Constraints\n- The component must not contain business logic; data fetching, filtering, and server-side sorting are the consumer's responsibility.\n- Column definitions must be derived exclusively from TableHead elements that have a non-empty key attribute; elements without a key must be silently ignored.\n- When disabled is true, the entire table must be rendered with reduced opacity and pointer-events-none so no interaction is possible.\n- The sort state is maintained internally and resets only when the component is re-created; the component does not persist sort state externally.\n- Pagination UI must not appear when pageSize is zero or totalPages is one or less.\n- The component uses createRenderRoot returning this, meaning it renders without a shadow DOM.";
}
declare module "_102040_/l2/molecules/groupviewtable/ml-data-table" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlDataTableMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        /** Comma-separated selected row indices, e.g. "0,2,5" */
        value: string;
        selectable: boolean;
        /** Propagates is-editing attribute to all web components inside TableCell elements */
        isEditing: boolean;
        page: number;
        pageSize: number;
        totalItems: number;
        error: string;
        disabled: boolean;
        loading: boolean;
        private sortKey;
        private sortDirection;
        createRenderRoot(): this;
        updated(): void;
        private propagateIsEditing;
        private parseColumns;
        private parseBodyRows;
        private parseFooterRows;
        private getSelectedSet;
        private getSortedRows;
        private handleSort;
        private handleRowClick;
        private handleRowSelect;
        private handleSelectAll;
        private handlePageChange;
        private getThClasses;
        private getTdClasses;
        private getTrClasses;
        private renderSortIcon;
        private renderSkeleton;
        private renderEmpty;
        private renderPagination;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/ml-inline-edit-table.defs" {
    export const group = "groupViewTable";
    export const skill = "# Metadata\n- TagName: groupviewtable--ml-inline-edit-table\n\n# Objective\nProvide a data table that supports inline editing through cell contents, column sorting, row selection, pagination, and distinct states for loading and empty data. It organizes content through named regions and delegates editing interfaces, validation presentation, and footer actions to the consuming context.\n\n# Responsibilities\n- Display table content in the sequence: caption, header, body, and footer, followed by global error messages when an error state is present.\n- Require header and body sections to be provided and enforce the contract hierarchy where rows in the header contain column headers and rows in the body contain cells.\n- Activate editing mode across all table cells simultaneously when the table enters an editing state, enabling nested interactive elements to present their editing interfaces.\n- Notify the consuming context with the index of a row when any cell in that row is clicked, allowing external logic to control entry into editing mode.\n- Accept all input types\u2014such as text, number, selection, and date\u2014exclusively from the content placed inside table cells; do not generate or substitute input controls automatically.\n- Delegate individual cell validation and error presentation to the contents of each cell; display a global error state below the table according to the contract.\n- Show a loading state using provided loading content when available, otherwise display the standard loading representation defined by the contract.\n- Show an empty state using provided empty content when available, otherwise display the standard empty message defined by the contract, whenever the body contains no rows.\n- Toggle sort direction between ascending and descending when an interactive column header is activated, reorder the visible rows accordingly, and notify the consuming context with the column key and direction.\n- Support keyboard navigation between rows using vertical arrow keys, toggle row selection with the space key when selection is enabled, and trigger column sorting with the enter key on interactive headers.\n- Allow default keyboard behavior for tab and enter keys to continue operating inside cell contents, enabling natural navigation and confirmation of edits by nested controls.\n- Maintain selected row indices as a comma-separated value when selection is enabled, and notify the consuming context whenever the selection changes.\n- Present pagination controls when a page size is specified, notify the consuming context of page changes, and do not fetch or manage data pages internally.\n- Provide a footer area to accommodate consumer-provided actions, such as adding a new row, handled entirely by the content placed in that area.\n\n# Constraints\n- Header and body sections are mandatory; the table must not present a valid structure without them.\n- The table must not create, inject, or replace input elements inside cells; all editing interfaces must originate from externally provided content.\n- The table must not intercept or suppress native keyboard behaviors inside cell contents, ensuring tab and enter keys continue to operate nested controls as expected.\n- Sorting must only respond to column headers explicitly marked as sortable, and the table must notify the consuming context when sorting occurs.\n- Pagination must notify the consuming context of page changes without performing internal data retrieval; data management remains external.\n- The global error state must appear below the table, but the table must not attempt to validate individual cell values internally.\n- When selection is enabled, the value must remain a comma-separated list of row indices.\n- The footer must not introduce additional communication mechanisms beyond the contract; actions such as adding rows must be handled entirely by the footer content.\n\n# Notes\n- The inline editing experience depends on cooperation between the table's editing state and the interactive elements placed inside table cells.\n- All data operations\u2014including saving edits, validating inputs, and adding rows\u2014are the responsibility of the consuming context.";
}
declare module "_102040_/l2/molecules/groupviewtable/ml-inline-edit-table" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlInlineEditTableMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        selectable: boolean;
        isEditing: boolean;
        page: number;
        pageSize: number;
        totalItems: number;
        value: string;
        error: string;
        disabled: boolean;
        loading: boolean;
        private sortKey;
        private sortDirection;
        private focusedRowIndex;
        private parsedColumns;
        private parsedRows;
        private sortedRowIndices;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private parseTableStructure;
        private parseColumns;
        private parseRows;
        private initializeSortedIndices;
        private propagateEditingState;
        private getSelectedIndices;
        private setSelectedIndices;
        private handleSelectAll;
        private handleRowSelect;
        private handleSort;
        private applySorting;
        private extractTextContent;
        private handleRowClick;
        private get totalPages();
        private handlePageChange;
        private handleKeyDown;
        private handleHeaderKeyDown;
        private moveFocus;
        private getTableClasses;
        private getHeaderCellClasses;
        private getRowClasses;
        private getCellClasses;
        private getCheckboxClasses;
        private renderCaption;
        private renderHeader;
        private renderHeaderCell;
        private renderSortIcon;
        private renderBody;
        private renderRow;
        private renderCell;
        private renderEmpty;
        private renderLoading;
        private renderFooter;
        private renderPagination;
        private renderPaginationWithEllipsis;
        private renderPageButton;
        private getPaginationButtonClasses;
        private renderError;
        render(): any;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/ml-pivot-table.defs" {
    export const group = "groupViewTable";
    export const skill = "# Metadata\n- TagName: groupviewtable--ml-pivot-table\n\n# Objective\nProvide a pivot table interface that interprets dynamic table intent through column sorting and externally controlled group expansion. It renders tabular data with headers, body, and footer while delegating calculations, groupings, and aggregation logic to the consumer.\n\n# Responsibilities\n- Accept data structure exclusively through the contract's structural children, not through external data properties.\n- Define columns via header child elements with identifiers; support user sorting interaction on columns enabled for ordering.\n- Toggle sort direction between ascending and descending when an orderable header is activated.\n- Reorder body rows based on the textual content of cells in the corresponding column.\n- Emit a sort event identifying the column and direction.\n- Render subtotal and grand total rows as normal rows without internal calculation; these are supplied by the consumer via body and footer content.\n- Emit a row click event containing the row index when a group row is clicked, leaving the consumer responsible for updating which rows are visible.\n- Display consumer-provided loading content when loading, or fall back to the contract's default loading presentation.\n- Display consumer-provided empty content when no rows exist, or fall back to the contract's default empty presentation.\n- Propagate editing state to inner components within cells per the contract, enabling view and edit mode transitions.\n- Maintain compatibility with contract selection and pagination behaviors.\n- Keep columns aligned across headers, body, and footer.\n- Visually differentiate subtotal and total rows with stronger text emphasis.\n- Show a directional indicator on the currently sorted header.\n- Present a loading placeholder that preserves the table's occupied area.\n- Present empty messaging with subdued text styling.\n- Apply reduced opacity and blocked interactions when disabled.\n- Adapt colors and states for dark presentation per the contract.\n\n# Constraints\n- Must not compute aggregations, subtotals, or totals internally.\n- Must not store or manage group expansion state; row visibility is controlled externally.\n- Must not accept data through mechanisms outside the contract's structural children.\n- Sorting must only affect the presentation order of existing rows based on cell text.\n- Loading and empty presentations must maintain layout stability.\n- Editing state propagation must respect inner component autonomy.\n\n# Notes\n- The component serves as a presentation layer for pivot-style data, expecting the consumer to provide pre-grouped and pre-aggregated information.\n- Dynamic pivot behavior is limited to column sorting; drag-and-drop field arrangement is not supported.";
}
declare module "_102040_/l2/molecules/groupviewtable/ml-pivot-table" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class MlPivotTableMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        selectable: boolean;
        isEditing: boolean;
        page: number;
        pageSize: number;
        totalItems: number;
        value: string;
        error: string;
        disabled: boolean;
        loading: boolean;
        private sortKey;
        private sortDirection;
        private parsedHeaders;
        private parsedBodyRows;
        private parsedFooterRows;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        handleIcaStateChange(key: string, value: unknown): void;
        private parseSlotContent;
        private parseHeaders;
        private parseBodyRows;
        private parseFooterRows;
        private propagateEditingState;
        private getSelectedIndices;
        private setSelectedIndices;
        private handleSelectAll;
        private handleRowSelect;
        private handleSort;
        private sortBodyRows;
        private extractTextContent;
        private handleRowClick;
        private getTotalPages;
        private handlePageChange;
        private getContainerClasses;
        private getTableClasses;
        private getHeaderCellClasses;
        private getBodyRowClasses;
        private getBodyCellClasses;
        private getFooterCellClasses;
        private getCheckboxClasses;
        private getPaginationClasses;
        private getPaginationButtonClasses;
        private getPageNumberClasses;
        render(): any;
        private renderCaption;
        private renderTableHeader;
        private renderHeaderCell;
        private renderSortIndicator;
        private renderTableBody;
        private renderTableFooter;
        private renderPagination;
        private getPageNumbers;
        private renderLoading;
        private renderEmpty;
        private renderError;
    }
}
declare module "_102040_/l2/molecules/groupviewtable/ml-view-table.defs" {
    export const group = "groupViewTable";
    export const skill = "# Metadata\n- TagName: groupviewtable--ml-view-table\n\n# Objective\nPresent data in a clean, minimalist table format that supports ordering, pagination, row selection, and adaptive states for loading and empty data. It must provide clear visual feedback for interactions and maintain full compatibility with dark appearance modes.\n\n# Responsibilities\n- Present data in a structured table with distinguishable header and body areas, plus optional caption and footer regions.\n- Enable column header interaction to sort the displayed data, alternating between ascending and descending order with clear directional indicators.\n- Manage data ordering internally based on the active column and direction.\n- Divide data into pages internally when a page limit is defined, and provide navigation between pages.\n- Offer an optional row selection mode that presents a checkbox at the start of each row and a corresponding master checkbox in the header to select or clear all rows.\n- Maintain and display the current selection state as rows are checked or unchecked individually or collectively.\n- Recognize when a user activates a specific row separately from selection controls.\n- Show an animated loading placeholder that imitates the table layout while data is unavailable, falling back to a default skeleton if no custom loading presentation is supplied.\n- Show a centered empty-state message with an empty-table icon when no data exists, falling back to a default message if no custom empty presentation is supplied.\n- Apply a subdued horizontal rule between rows without vertical dividers between columns for a minimalist appearance.\n- Visually distinguish the header background from the body.\n- Highlight the active sort column header and any selected rows with dedicated color treatments.\n- Adapt all colors\u2014including backgrounds, text, borders, and highlights\u2014for dark mode presentation.\n- Disable all sorting, selection, and pagination interactions when placed in an inactive state.\n\n# Constraints\n- Sort indicators must always match the currently applied column and direction.\n- Page navigation must respect the calculated total pages and current position.\n- The master selection checkbox must accurately reflect whether all, some, or no rows are selected.\n- Loading, empty, and data states must not overlap; only one may be visible at a time.\n- Selected and highlighted states must remain clearly distinguishable in both light and dark appearances.\n- All interactive features must be inoperable when the inactive state is active.\n\n# Notes\n- Custom presentations for empty and loading states take precedence over default representations when provided.\n- Activating a row and toggling its selection are separate, non-conflicting interactions.";
}
declare module "_102040_/l2/molecules/groupviewtable/ml-view-table" {
    import { MoleculeAuraElement } from '_102033_/l2/moleculeBase';
    export class ViewTableMolecule extends MoleculeAuraElement {
        private msg;
        slotTags: string[];
        selectable: boolean;
        isEditing: boolean;
        page: number;
        pageSize: number;
        totalItems: number;
        value: string;
        error: string;
        disabled: boolean;
        loading: boolean;
        private sortKey;
        private sortDirection;
        private parsedHeaders;
        private parsedRows;
        private sortedRowIndices;
        firstUpdated(): void;
        updated(changedProperties: Map<string, unknown>): void;
        private parseSlotContent;
        private parseHeaders;
        private parseRows;
        private initializeSortedIndices;
        private propagateEditingState;
        private getSelectedIndices;
        private setSelectedIndices;
        private handleSelectAll;
        private handleRowSelect;
        private handleRowClick;
        private handleSort;
        private applySorting;
        private stripHtml;
        private getTotalPages;
        private handlePageChange;
        private getTableClasses;
        private getHeaderCellClasses;
        private getRowClasses;
        private getCellClasses;
        private getCheckboxClasses;
        private renderCaption;
        private renderSortIcon;
        private renderHeader;
        private renderBody;
        private renderFooter;
        private renderEmpty;
        private renderLoading;
        private renderPagination;
        private getPaginationPages;
        private getPaginationButtonClasses;
        private getPageNumberClasses;
        private renderError;
        render(): any;
    }
}
declare module "_102040_/l2/testes/account-settings" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class AccountSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingPerfil: boolean;
        isEditingSeguranca: boolean;
        isEditingCobranca: boolean;
        errors: Record<string, string>;
        name: string;
        email: string;
        phone: string;
        birthDate: string;
        bio: string;
        recoveryEmail: string;
        twoFaEnabled: boolean;
        pushNotif: boolean;
        cpf: string;
        spendingLimit: number;
        spendingAlert: number;
        autoPayment: boolean;
        termsAccepted: boolean;
        language: string;
        timezone: string;
        theme: string;
        private snapshotPerfil;
        private snapshotSeguranca;
        private snapshotCobranca;
        private editPerfil;
        private cancelPerfil;
        private savePerfil;
        private editSeguranca;
        private cancelSeguranca;
        private saveSeguranca;
        private editCobranca;
        private cancelCobranca;
        private saveCobranca;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get themeLabel();
        private formatMoney;
        private formatCpf;
        private err;
        private badge;
        private editHeader;
        private renderPerfilView;
        private renderSegurancaView;
        private renderCobrancaView;
        private renderPreferenciasView;
        private renderPerfilEditForm;
        private renderSegurancaEditForm;
        private renderCobrancaEditForm;
        private renderPreferenciasControls;
        private renderActivePanel;
        private renderTabs;
        render(): any;
    }
}
declare module "_102040_/l2/testes/appointment-scheduler" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdatetime/ml-datetime-picker';
    import '/_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval';
    import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    interface Meeting {
        id: number;
        title: string;
        date: string;
        room: string;
        participants: number;
    }
    export class AppointmentScheduler extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        title: string;
        agenda: string;
        startAt: string;
        intervalStart: string;
        intervalEnd: string;
        preferredStart: string;
        preferredEnd: string;
        participants: string[];
        selectedRooms: string[];
        recurrence: string;
        recurrenceCount: number;
        errors: Record<string, string>;
        upcomingMeetings: Meeting[];
        private readonly availableRooms;
        private readonly allParticipants;
        private validate;
        private err;
        private handleAgendar;
        private handleParticipantSelect;
        private removeParticipant;
        private renderTabs;
        private renderNovaReuniaoForm;
        private renderMinhasReunioes;
        render(): any;
    }
}
declare module "_102040_/l2/testes/budget-editor" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface BudgetRow {
        id: number;
        description: string;
        costCenter: string;
        qty: number;
        planned: number;
        actual: number;
    }
    export class BudgetEditor extends StateLitElement {
        rows: BudgetRow[];
        activeFilter: 'all' | 'over' | 'within';
        editingRowId: number | null;
        tableEpoch: number;
        bannerDismissed: boolean;
        toastVisible: boolean;
        editDescription: string;
        editCostCenter: string;
        editQty: number;
        editPlanned: number;
        editActual: number;
        errors: Record<string, string>;
        private editSnapshot;
        private get filteredRows();
        private get overBudgetRows();
        private get editingRow();
        private fmt;
        private err;
        private handleRowClick;
        private openEdit;
        private cancelEdit;
        private saveEdit;
        private renderTable;
        private renderEditPanel;
        render(): any;
    }
}
declare module "_102040_/l2/testes/candidate-pipeline" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-thumbs-rating';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-dropzone';
    import '/_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload';
    import '/_102040_/l2/molecules/groupviewdata/ml-vertical-record-list';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand';
    import '/_102040_/l2/molecules/groupenterdate/ml-compact-calendar';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type Stage = 'triagem' | 'interview' | 'technical' | 'proposal' | 'hired';
    interface HistoryEntry {
        date: string;
        type: string;
        description: string;
    }
    interface Candidate {
        id: number;
        name: string;
        role: string;
        stage: Stage;
        rating: number;
        thumb: 'up' | 'down' | null;
        cvFile: string | null;
        interviewDate: string;
        history: HistoryEntry[];
    }
    export class CandidatePipeline extends StateLitElement {
        activeStage: Stage;
        searchQuery: string;
        selectedId: number;
        toastVisible: boolean;
        toastMessage: string;
        candidates: Candidate[];
        private readonly job;
        private readonly stageOrder;
        private readonly stageLabels;
        private readonly nextStageLabel;
        private get selectedCandidate();
        private get filteredCandidates();
        private countByStage;
        private initials;
        private selectFirstInStage;
        private autoSelectAfterMutation;
        private advanceCandidate;
        private rejectCandidate;
        private updateCandidate;
        private showToast;
        render(): any;
        private renderCandidateCard;
        private renderEmptyPanel;
        private renderDetailPanel;
    }
}
declare module "_102040_/l2/testes/corporate-dashboard" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-gauge';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class CorporateDashboard extends StateLitElement {
        period: string;
        bannerVisible: boolean;
        private readonly kpiData;
        private readonly transactions;
        private get kpis();
        private statusBadge;
        render(): any;
    }
}
declare module "_102040_/l2/testes/customer-profile" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class CustomerProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        clientName: string;
        personType: string;
        cnpj: string;
        cpf: string;
        email: string;
        phone: string;
        segment: string;
        city: string;
        stateUF: string;
        registerDate: string;
        birthday: string;
        channels: string;
        acceptsOffers: boolean;
        acceptsWpp: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get segmentLabel();
        private get initials();
        private get personTypeLabel();
        render(): any;
    }
}
declare module "_102040_/l2/testes/edicao-cliente" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class EdicaoClientePage extends StateLitElement {
        private nome;
        private endereco;
        private situacao;
        private clienteAtual;
        private errors;
        private saved;
        connectedCallback(): void;
        private getClientes;
        private err;
        private handleSelect;
        private handleSave;
        private handleCancel;
        private clearForm;
        render(): any;
        private renderForm;
        editável: any;
    }
}
declare module "_102040_/l2/testes/employee-profile" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeProfile extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        admissionDate: string;
        department: string;
        role: string;
        workRegime: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get departmentLabel();
        private get roleLabel();
        private get initials();
        render(): any;
    }
}
declare module "_102040_/l2/testes/employee-registration" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-horizontal-stepper';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-cpf-input';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class EmployeeRegistration extends StateLitElement {
        currentStep: number;
        toastVisible: boolean;
        errors: Record<string, string>;
        name: string;
        cpf: string;
        email: string;
        phone: string;
        birthDate: string;
        department: string;
        role: string;
        workRegime: string;
        admissionDate: string;
        salary: number | null;
        systemAccess: boolean;
        isAdmin: boolean;
        modules: string;
        privacyAccepted: boolean;
        private readonly steps;
        private validate;
        private next;
        private back;
        private err;
        render(): any;
        private renderStep0;
        private renderStep1;
        private renderStep2;
    }
}
declare module "_102040_/l2/testes/field-service-order" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesteps/ml-vertical-stepper';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code-1d';
    import '/_102040_/l2/molecules/groupscancode/ml-scan-code';
    import '/_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker';
    import '/_102040_/l2/molecules/grouplocateposition/ml-geolocation-trigger';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner';
    import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
    import '/_102040_/l2/molecules/groupentertime/ml-time-scroll-picker';
    import '/_102040_/l2/molecules/groupviewdata/ml-timeline-view';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-standard';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    interface ChecklistItem {
        id: number;
        label: string;
        done: boolean;
    }
    export class FieldServiceOrder extends StateLitElement {
        currentStep: number;
        scannedBarcode: string;
        scannedQr: string;
        locationCoords: string;
        arrivalTime: string;
        preferredWindowStart: string;
        preferredWindowEnd: string;
        report: string;
        loadingHistory: boolean;
        historyLoaded: boolean;
        toastVisible: boolean;
        toastMessage: string;
        checklist: ChecklistItem[];
        private readonly order;
        private readonly serviceHistory;
        private get doneCount();
        private get allDone();
        private get checklistProgress();
        private toggleItem;
        private showToast;
        private loadHistory;
        private nextStep;
        render(): any;
    }
}
declare module "_102040_/l2/testes/financial-report" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupviewmetric/ml-metric-big-number';
    import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
    import '/_102040_/l2/molecules/groupviewchart/ml-pie-chart';
    import '/_102040_/l2/molecules/groupviewtable/ml-view-table';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class FinancialReport extends StateLitElement {
        startDate: string;
        endDate: string;
        granularity: string;
        activeView: 'revenue' | 'expense' | 'margin';
        activeTab: string;
        private readonly summary;
        private kpiRing;
        render(): any;
    }
}
declare module "_102040_/l2/testes/ml-radio-group-exemple" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    interface Config {
        value: string;
        isEditing: boolean;
        required: boolean;
        disabled: boolean;
        readonly: boolean;
        loading: boolean;
        error: string;
    }
    export class MlRadioGroupExemple extends StateLitElement {
        basic: Config;
        grouped: Config;
        private toggle;
        private renderToggle;
        private renderConfig;
        render(): any;
    }
}
declare module "_102040_/l2/testes/order-management" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-range-dual-calendar';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupviewtable/ml-data-table';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    import '/_102040_/l2/molecules/groupviewchart/ml-line-chart';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    export class OrderManagement extends StateLitElement {
        activeTab: string;
        search: string;
        statusFilter: string;
        sortBy: string;
        filterStartDate: string;
        filterEndDate: string;
        page: number;
        bannerVisible: boolean;
        private readonly pageSize;
        private readonly allOrders;
        private readonly volumePoints;
        private get filteredOrders();
        private get visibleOrders();
        private toStatusKey;
        private countByTab;
        private statusBadge;
        private lateInTransit;
        render(): any;
    }
}
declare module "_102040_/l2/testes/org-chart" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree';
    import '/_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram';
    import '/_102040_/l2/molecules/groupviewcard/ml-vertical-card';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-icon-button';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type ViewMode = 'orgchart' | 'tree' | 'diagram';
    type LevelFilter = 'all' | 'exec' | 'manager' | 'operational';
    interface Employee {
        name: string;
        role: string;
        level: LevelFilter;
        dept: string;
        email: string;
    }
    export class OrgChart extends StateLitElement {
        activeDept: string;
        activeView: ViewMode;
        levelFilter: LevelFilter;
        searchQuery: string;
        selectedEmployee: Employee | null;
        loadingChart: boolean;
        loadingProgress: number;
        toastVisible: boolean;
        toastMessage: string;
        private readonly navItems;
        private readonly allEmployees;
        private get currentDeptLabel();
        private get employees();
        private initials;
        private levelLabel;
        private matchesSearch;
        private matchesLevel;
        private switchDept;
        private showToast;
        private handleNodeClick;
        private renderHierarchyNodes;
        render(): any;
    }
}
declare module "_102040_/l2/testes/product-edit" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-stepper';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class ProductEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        errors: Record<string, string>;
        productName: string;
        sku: string;
        barcode: string;
        description: string;
        salePrice: number | null;
        costPrice: number | null;
        stock: number | null;
        minStock: number | null;
        packQty: number | null;
        category: string;
        supplier: string;
        tags: string;
        isActive: boolean;
        availOnline: boolean;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get margin();
        private get marginColor();
        private get stockStatus();
        private get categoryLabel();
        private get supplierLabel();
        render(): any;
    }
}
declare module "_102040_/l2/testes/select-one" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    export class SelectOne102040 extends StateLitElement {
        radioValue: string;
        radioGroupedValue: string;
        segmentedValue: string;
        segmentedErrorValue: string;
        render(): any;
    }
}
declare module "_102040_/l2/testes/supplier-edit" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-accordion';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupentertext/ml-multiline-text';
    import '/_102040_/l2/molecules/groupenterdate/ml-date-picker';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-radio-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-checkbox-list';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SupplierEdit extends StateLitElement {
        isEditing: boolean;
        toastVisible: boolean;
        viewEpoch: number;
        errors: Record<string, string>;
        companyName: string;
        cnpj: string;
        email: string;
        website: string;
        address: string;
        companyType: string;
        paymentTerm: string;
        currency: string;
        taxRegime: string;
        contractStart: string;
        certExpiry: string;
        categories: string;
        isActive: boolean;
        isHomologated: boolean;
        isPreferred: boolean;
        notes: string;
        private snapshot;
        private takeSnapshot;
        private restoreSnapshot;
        private edit;
        private cancel;
        private validate;
        private save;
        private err;
        private get companyTypeLabel();
        private get taxRegimeLabel();
        private get paymentTermLabel();
        private get currencyLabel();
        private readonly categoryMap;
        private get categoryLabels();
        private get initials();
        private statusBadge;
        private renderViewMode;
        private renderEditMode;
        render(): any;
    }
}
declare module "_102040_/l2/testes/system-settings" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-tabs';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-select-dropdown';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupentermoney/ml-enter-money-br';
    import '/_102040_/l2/molecules/groupenterboolean/ml-toggle-switch';
    import '/_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    export class SystemSettings extends StateLitElement {
        activeTab: string;
        viewEpoch: number;
        toastVisible: boolean;
        toastMsg: string;
        isEditingGeral: boolean;
        isEditingNotif: boolean;
        isEditingLimites: boolean;
        isEditingIntegracoes: boolean;
        errors: Record<string, string>;
        companyName: string;
        domain: string;
        supportEmail: string;
        language: string;
        timezone: string;
        currency: string;
        theme: string;
        emailNotif: boolean;
        smsNotif: boolean;
        pushNotif: boolean;
        require2fa: boolean;
        autoApproveLimit: number;
        defaultingAlert: number;
        sessionTimeout: number;
        loginAttempts: number;
        erp: string;
        termsAccepted: boolean;
        dataRetention: boolean;
        private snapshotGeral;
        private snapshotNotif;
        private snapshotLimites;
        private snapshotIntegracoes;
        private editGeral;
        private cancelGeral;
        private saveGeral;
        private editNotif;
        private cancelNotif;
        private saveNotif;
        private editLimites;
        private cancelLimites;
        private saveLimites;
        private editIntegracoes;
        private cancelIntegracoes;
        private saveIntegracoes;
        private handleRequestEdit;
        private get languageLabel();
        private get timezoneLabel();
        private get currencyLabel();
        private get themeLabel();
        private get erpLabel();
        private formatMoney;
        private err;
        private badge;
        private editHeader;
        private renderGeralView;
        private renderNotifView;
        private renderLimitesView;
        private renderIntegracoesView;
        private renderGeralEditForm;
        private renderNotifEditForm;
        private renderLimitesEditForm;
        private renderIntegracoesEditForm;
        private renderActiveEditForm;
        private renderTabs;
        render(): any;
    }
}
declare module "_102040_/l2/testes/training-catalog" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail';
    import '/_102040_/l2/molecules/groupviewcard/ml-view-card-media';
    import '/_102040_/l2/molecules/groupviewdata/ml-card-grid';
    import '/_102040_/l2/molecules/groupplaymedia/ml-video-player';
    import '/_102040_/l2/molecules/groupplaymedia/ml-audio-player';
    import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
    import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
    import '/_102040_/l2/molecules/grouprateitem/ml-star-rating';
    import '/_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps';
    import '/_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content';
    import '/_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-drag';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-split-button';
    import '/_102040_/l2/molecules/grouptriggeraction/ml-button-group';
    import '/_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown';
    import '/_102040_/l2/molecules/groupsearchcontent/ml-search-bar';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-toast-notification';
    type FormatFilter = 'video' | 'audio' | 'reading';
    export class TrainingCatalog extends StateLitElement {
        lessonProgress: number;
        courseComplete: boolean;
        userRating: number;
        npsScore: number | null;
        formatFilter: FormatFilter;
        areaFilter: string;
        searchQuery: string;
        enrollmentStart: string;
        enrollmentEnd: string;
        toastVisible: boolean;
        toastMessage: string;
        private readonly course;
        private readonly recommendedCourses;
        private get filteredCourses();
        private showToast;
        private simulateProgress;
        private formatLabel;
        render(): any;
    }
}
declare module "_102040_/l2/testes/vehicle-registration" {
    import { StateLitElement } from '_102029_/l2/stateLitElement';
    import '/_102040_/l2/molecules/groupentertext/ml-floating-text-input';
    import '/_102040_/l2/molecules/groupselectone/ml-combobox';
    import '/_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete';
    import '/_102040_/l2/molecules/groupselectone/ml-segmented-control';
    import '/_102040_/l2/molecules/groupenternumber/ml-number-input';
    import '/_102040_/l2/molecules/groupnotifyuser/ml-notify-banner';
    export class VehicleRegistration extends StateLitElement {
        codigo: string;
        dataInclusao: string;
        dataModificacao: string;
        placa: string;
        situacao: string;
        marca: string;
        modelo: string;
        anoFabricacao: number | null;
        anoModelo: number | null;
        quilometragem: number | null;
        errors: Record<string, string>;
        saved: boolean;
        private readonly currentYear;
        private readonly brands;
        private readonly modelsByBrand;
        private err;
        private getModelos;
        private validate;
        private handleSave;
        private handleCancel;
        render(): any;
        private renderControle;
        private renderIdentificacao;
        private renderDadosVeiculo;
        private renderEstadoAtual;
        private renderSectionHeader;
    }
}
