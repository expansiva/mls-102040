/// <mls fileReference="_102040_/l2/teste.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import { initState, getState } from '/_102029_/l2/collabState.js';
import '/_102040_/l2/molecules/groupviewtable/ml-data-table-minimal';
import '/_102033_/l2/molecules/groupentertext/ml-floating-text-input';
let Teste102040 = class Teste102040 extends StateLitElement {
    constructor() {
        super();
        this.data = [];
    }
    connectedCallback() {
        super.connectedCallback();
        initState('test', { users: [{ name: 'Lucas', age: 22, cod: 1, role: 'admin' }] });
        this.data = getState('test.users');
        console.log('dados 1', this.data);
        //this.requestUpdate();
    }
    render() {
        //const data = getState('test')
        console.log('dados ddd', this.data);
        return html `
<groupviewtable--ml-data-table-minimal
  value=""
  error=""
  selectable="false"
  is-editing="false"
  page="1"
  page-size="0"
  total-items="0"
  disabled="false"
  loading="false"
>
  <Caption>Users</Caption>
  <TableHeader>
    <TableRow>
      <TableHead key="id">ID</TableHead>
      <TableHead key="name">Name</TableHead>
      <TableHead key="role">Role</TableHead>
    </TableRow>
  </TableHeader>
  <TableBody>
    ${this.data.map((item, index) => {
            return html `    <TableRow>
      <TableCell>${index + 1}</TableCell>
      <TableCell>${item.name}</TableCell>
      <TableCell>${item.role}</TableCell>
    </TableRow>
`;
        })}
  </TableBody>
</groupviewtable--ml-data-table-minimal>
    `;
    }
};
__decorate([
    property()
], Teste102040.prototype, "data", void 0);
Teste102040 = __decorate([
    customElement('teste-102040')
], Teste102040);
export { Teste102040 };
