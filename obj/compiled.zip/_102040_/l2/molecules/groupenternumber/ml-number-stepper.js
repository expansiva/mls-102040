var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102033_/l2/molecules/groupenternumber/ml-number-stepper.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// NUMBER STEPPER MOLECULE
// =============================================================================
// Skill Group: enter + number
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    required: 'This field is required',
    increment: 'Increment',
    decrement: 'Decrement',
    emptyValue: '—',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        required: 'Este campo é obrigatório',
        increment: 'Incrementar',
        decrement: 'Decrementar',
        emptyValue: '—',
    },
};
/// **collab_i18n_end**
let NumberStepperMolecule = class NumberStepperMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = null;
        this.max = null;
        this.step = 1;
        this.decimals = 0;
        this.locale = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.rawValue = '';
        this.inputId = `ml-number-stepper-${Math.random().toString(36).slice(2)}`;
        this.labelId = `${this.inputId}-label`;
        this.helperId = `${this.inputId}-helper`;
        this.errorId = `${this.inputId}-error`;
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.rawValue = this.formatToDisplay(this.value);
    }
    // =========================================================================
    // STATE CHANGE HANDLER
    // =========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const decimalsAttr = this.getAttribute('decimals');
        const localeAttr = this.getAttribute('locale');
        if (valueAttr === `{{${key}}}` || decimalsAttr === `{{${key}}}` || localeAttr === `{{${key}}}`) {
            this.rawValue = this.formatToDisplay(this.value);
        }
        this.requestUpdate();
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleInput(e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        this.rawValue = input.value;
        const parsed = this.parseRawToNumber(this.rawValue);
        this.value = parsed;
        this.emitInput();
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        const normalized = this.normalizeValue(this.rawValue);
        this.value = normalized;
        this.rawValue = this.formatToDisplay(this.value);
        this.emitChange();
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    handleFocus() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    increment() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const current = this.value ?? 0;
        const next = current + this.step;
        if (this.max !== null && next > this.max)
            return;
        this.value = this.roundToDecimals(next);
        this.rawValue = this.formatToDisplay(this.value);
        this.emitChange();
    }
    decrement() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const current = this.value ?? 0;
        const next = current - this.step;
        if (this.min !== null && next < this.min)
            return;
        this.value = this.roundToDecimals(next);
        this.rawValue = this.formatToDisplay(this.value);
        this.emitChange();
    }
    emitInput() {
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    emitChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    formatToDisplay(value) {
        if (value === null || value === undefined)
            return '';
        const options = {
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        };
        const locale = this.locale && this.locale.trim().length > 0 ? this.locale : undefined;
        return new Intl.NumberFormat(locale, options).format(value);
    }
    parseRawToNumber(raw) {
        const trimmed = raw.trim();
        if (!trimmed)
            return null;
        const { group, decimal } = this.getNumberSeparators();
        const cleaned = trimmed
            .split(group)
            .join('')
            .split(decimal)
            .join('.')
            .replace(/\s/g, '');
        const num = parseFloat(cleaned);
        if (Number.isNaN(num))
            return null;
        return num;
    }
    normalizeValue(raw) {
        const parsed = this.parseRawToNumber(raw);
        if (parsed === null)
            return null;
        let value = this.roundToDecimals(parsed);
        if (this.min !== null && value < this.min)
            value = this.min;
        if (this.max !== null && value > this.max)
            value = this.max;
        return value;
    }
    roundToDecimals(value) {
        const factor = Math.pow(10, Math.max(0, this.decimals));
        return Math.round(value * factor) / factor;
    }
    getNumberSeparators() {
        const locale = this.locale && this.locale.trim().length > 0 ? this.locale : undefined;
        const parts = new Intl.NumberFormat(locale).formatToParts(12345.6);
        const group = parts.find(p => p.type === 'group')?.value ?? ',';
        const decimal = parts.find(p => p.type === 'decimal')?.value ?? '.';
        return { group, decimal };
    }
    getInputClasses(hasError) {
        return [
            'w-full flex-1 rounded-md px-3 py-2 text-sm border transition outline-none',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            hasError ? 'border-red-500 dark:border-red-400' : 'border-slate-200 dark:border-slate-700',
            'focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled || this.loading ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getButtonClasses() {
        return [
            'h-9 w-9 inline-flex items-center justify-center rounded-md border text-sm transition',
            'bg-white dark:bg-slate-800',
            'text-slate-900 dark:text-slate-100',
            'border-slate-200 dark:border-slate-700',
            !this.disabled && !this.readonly && !this.loading
                ? 'hover:bg-slate-50 dark:hover:bg-slate-700'
                : 'opacity-50 cursor-not-allowed',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getContainerClasses() {
        return [
            'w-full',
            this.disabled || this.loading ? 'opacity-50' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getRowClasses() {
        return [
            'flex items-center gap-2',
            'rounded-lg',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const effectiveError = this.error || (this.required && (this.value === null || this.value === undefined) ? this.msg.required : '');
        const hasError = String(effectiveError).length > 0;
        const ariaDescribedBy = hasError ? this.errorId : this.hasSlot('Helper') ? this.helperId : undefined;
        const placeholder = this.placeholder || '';
        return html `
      <div class="${this.getContainerClasses()}">
        ${this.renderLabel()}
        <div class="${this.getRowClasses()}">
          ${this.renderPrefix()}
          <input
            id="${this.inputId}"
            class="${this.getInputClasses(hasError)}"
            type="text"
            inputmode="${this.decimals > 0 ? 'decimal' : 'numeric'}"
            .value=${this.rawValue}
            placeholder="${this.value === null ? placeholder : ''}"
            ?disabled=${this.disabled || this.loading}
            ?readonly=${this.readonly}
            aria-labelledby="${this.hasSlot('Label') ? this.labelId : nothing}"
            aria-describedby="${ariaDescribedBy || nothing}"
            aria-invalid="${hasError ? 'true' : 'false'}"
            aria-required="${this.required ? 'true' : 'false'}"
            @input=${this.handleInput}
            @blur=${this.handleBlur}
            @focus=${this.handleFocus}
          />
          ${this.renderSuffix()}
          <button
            type="button"
            class="${this.getButtonClasses()}"
            aria-label="${this.msg.decrement}"
            ?disabled=${this.disabled || this.readonly || this.loading}
            @click=${this.decrement}
          >
            −
          </button>
          <button
            type="button"
            class="${this.getButtonClasses()}"
            aria-label="${this.msg.increment}"
            ?disabled=${this.disabled || this.readonly || this.loading}
            @click=${this.increment}
          >
            +
          </button>
        </div>
        ${this.loading
            ? html `<div class="mt-2 text-xs text-slate-500 dark:text-slate-400">${this.msg.loading}</div>`
            : this.renderHelperOrError(effectiveError)}
      </div>
    `;
    }
    renderViewMode() {
        const display = this.value === null || this.value === undefined ? this.msg.emptyValue : this.formatToDisplay(this.value);
        return html `
      <div class="${this.getContainerClasses()}">
        ${this.renderLabel()}
        <div class="flex items-center gap-2 text-sm text-slate-900 dark:text-slate-100">
          ${this.renderPrefix()}
          <span>${display}</span>
          ${this.renderSuffix()}
        </div>
      </div>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id="${this.labelId}" class="mb-1 block text-sm text-slate-600 dark:text-slate-400">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderHelperOrError(effectiveError) {
        if (String(effectiveError).length > 0) {
            return html `
        <p id="${this.errorId}" class="mt-1 text-xs text-red-600 dark:text-red-400">
          ${unsafeHTML(String(effectiveError))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p id="${this.helperId}" class="mt-1 text-xs text-slate-500 dark:text-slate-400">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `
      <span class="text-sm text-slate-600 dark:text-slate-400">
        ${unsafeHTML(this.getSlotContent('Prefix'))}
      </span>
    `;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `
      <span class="text-sm text-slate-600 dark:text-slate-400">
        ${unsafeHTML(this.getSlotContent('Suffix'))}
      </span>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], NumberStepperMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], NumberStepperMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], NumberStepperMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NumberStepperMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NumberStepperMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NumberStepperMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NumberStepperMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: String })
], NumberStepperMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], NumberStepperMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], NumberStepperMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NumberStepperMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NumberStepperMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NumberStepperMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NumberStepperMolecule.prototype, "loading", void 0);
__decorate([
    state()
], NumberStepperMolecule.prototype, "rawValue", void 0);
NumberStepperMolecule = __decorate([
    customElement('groupenternumber--ml-number-stepper')
], NumberStepperMolecule);
export { NumberStepperMolecule };
