var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102033_/l2/molecules/groupenternumber/ml-number-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NUMBER INPUT MOLECULE
// =============================================================================
// Skill Group: enter + number
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: '—',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let idCounter = 0;
let MlNumberInputMolecule = class MlNumberInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        this.componentId = `ml-number-input-${++idCounter}`;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = null;
        this.max = null;
        this.step = 1;
        this.decimals = 0;
        this.locale = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.rawValue = '';
    }
    // ==========================================================================
    // STATE CHANGE HANDLER
    // ==========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const localeAttr = this.getAttribute('locale');
        const decimalsAttr = this.getAttribute('decimals');
        if (valueAttr === `{{${key}}}`) {
            this.rawValue = this.value === null || this.value === undefined
                ? ''
                : this.formatToDisplay(this.value);
        }
        if (localeAttr === `{{${key}}}` || decimalsAttr === `{{${key}}}`) {
            this.rawValue = this.value === null || this.value === undefined
                ? ''
                : this.formatToDisplay(this.value);
        }
        this.requestUpdate();
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleInput(e) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        this.rawValue = input.value;
        const parsed = this.parseRawValue(this.rawValue);
        this.value = parsed;
        this.emitInput();
    }
    handleBlur() {
        this.emitBlur();
        if (this.disabled || this.readonly || this.loading)
            return;
        const parsed = this.parseRawValue(this.rawValue);
        if (parsed === null) {
            this.value = null;
            this.rawValue = '';
            this.emitChange();
            return;
        }
        let next = this.roundToDecimals(parsed);
        if (this.min !== null && next < this.min)
            next = this.min;
        if (this.max !== null && next > this.max)
            next = this.max;
        this.value = next;
        this.rawValue = this.formatToDisplay(next);
        this.emitChange();
    }
    handleFocus() {
        this.emitFocus();
    }
    // ==========================================================================
    // EMITTERS
    // ==========================================================================
    emitInput() {
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    emitChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    emitBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    emitFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    getSeparators() {
        try {
            const parts = new Intl.NumberFormat(this.locale || undefined).formatToParts(1000.1);
            const group = parts.find(p => p.type === 'group')?.value || ',';
            const decimal = parts.find(p => p.type === 'decimal')?.value || '.';
            return { group, decimal };
        }
        catch (e) {
            return { group: ',', decimal: '.' };
        }
    }
    parseRawValue(raw) {
        const trimmed = raw.trim();
        if (!trimmed)
            return null;
        const { group, decimal } = this.getSeparators();
        let normalized = trimmed.split(group).join('');
        if (decimal !== '.') {
            normalized = normalized.split(decimal).join('.');
        }
        let cleaned = normalized.replace(/[^0-9.-]/g, '');
        if (!cleaned)
            return null;
        // Keep only one leading minus
        if (cleaned.includes('-')) {
            cleaned = cleaned.replace(/-/g, '');
            cleaned = `-${cleaned}`;
            if (cleaned === '-')
                return null;
        }
        // Keep only first decimal separator
        const parts = cleaned.split('.');
        if (parts.length > 2) {
            cleaned = `${parts[0]}.${parts.slice(1).join('')}`;
        }
        const num = parseFloat(cleaned);
        if (isNaN(num))
            return null;
        return num;
    }
    roundToDecimals(num) {
        const factor = Math.pow(10, Math.max(0, this.decimals));
        return Math.round(num * factor) / factor;
    }
    formatToDisplay(num) {
        try {
            return num.toLocaleString(this.locale || undefined, {
                minimumFractionDigits: Math.max(0, this.decimals),
                maximumFractionDigits: Math.max(0, this.decimals),
            });
        }
        catch (e) {
            return num.toFixed(Math.max(0, this.decimals));
        }
    }
    getInputClasses() {
        return [
            'w-full flex-1 rounded-md px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            this.error
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            (this.disabled || this.loading) ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getContainerClasses() {
        return [
            'w-full',
            (this.disabled || this.loading) ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label id=${labelId} class="mb-1 block text-sm font-medium text-slate-600 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderHelperOrError(errorId, helperId) {
        if (this.error) {
            return html `
<p id=${errorId} class="mt-1 text-xs text-red-600 dark:text-red-400">
${unsafeHTML(String(this.error))}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p id=${helperId} class="mt-1 text-xs text-slate-500 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `
<span class="mr-2 text-sm text-slate-600 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Prefix'))}
</span>
`;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `
<span class="ml-2 text-sm text-slate-600 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Suffix'))}
</span>
`;
    }
    renderViewMode() {
        const labelId = `${this.componentId}-label`;
        const displayValue = this.value === null || this.value === undefined
            ? this.msg.empty
            : this.formatToDisplay(this.value);
        return html `
<div class="${this.getContainerClasses()}">
${this.renderLabel(labelId)}
<div class="flex items-center gap-2 text-sm text-slate-900 dark:text-slate-100">
${this.renderPrefix()}
<span>${displayValue}</span>
${this.renderSuffix()}
</div>
</div>
`;
    }
    renderEditMode() {
        if (this.rawValue === '' && this.value !== null && this.value !== undefined) {
            this.rawValue = this.formatToDisplay(this.value);
        }
        const labelId = `${this.componentId}-label`;
        const errorId = `${this.componentId}-error`;
        const helperId = `${this.componentId}-helper`;
        const describedBy = this.error
            ? errorId
            : this.hasSlot('Helper')
                ? helperId
                : undefined;
        return html `
<div class="${this.getContainerClasses()}">
${this.renderLabel(labelId)}
<div class="flex items-center rounded-md">
${this.renderPrefix()}
<input
class="${this.getInputClasses()}"
.type=${'text'}
inputmode="decimal"
.name=${this.name || ''}
.value=${this.rawValue}
.placeholder=${this.placeholder || ''}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
aria-labelledby=${ifDefined(this.hasSlot('Label') ? labelId : undefined)}
aria-describedby=${ifDefined(describedBy)}
aria-invalid=${this.error ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@input=${this.handleInput}
@blur=${this.handleBlur}
@focus=${this.handleFocus}
/>
${this.renderSuffix()}
</div>
${this.loading ? html `<p class="mt-1 text-xs text-slate-500 dark:text-slate-400">${this.msg.loading}</p>` : nothing}
${this.renderHelperOrError(errorId, helperId)}
</div>
`;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.isEditing ? this.renderEditMode() : this.renderViewMode();
    }
};
__decorate([
    propertyDataSource({ type: Number })
], MlNumberInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberInputMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberInputMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberInputMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberInputMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberInputMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlNumberInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlNumberInputMolecule.prototype, "rawValue", void 0);
MlNumberInputMolecule = __decorate([
    customElement('groupenternumber--ml-number-input')
], MlNumberInputMolecule);
export { MlNumberInputMolecule };
