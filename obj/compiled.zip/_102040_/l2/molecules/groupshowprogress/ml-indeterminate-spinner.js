var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// INDETERMINATE SPINNER MOLECULE
// =============================================================================
// Skill Group: groupShowProgress
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let IndeterminateSpinnerMolecule = class IndeterminateSpinnerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-indeterminate-spinner .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-indeterminate-spinner .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-indeterminate-spinner .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupshowprogress--ml-indeterminate-spinner .ml-border-top-primary {
  border-top-color: var(--ml-primary, #3b82f6);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.size = 'md';
        this.label = '';
        this.showValue = false;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const ariaLabel = this.label || this.msg.loading;
        const sizeConfig = this.getSizeConfig();
        return html `
<div
class="${cn(sizeConfig.wrapper, this.cssClass)}"
role="progressbar"
aria-label="${ariaLabel}"
>
<div class="${sizeConfig.spinner}"></div>
${this.label
            ? html `<span class="${sizeConfig.text}">${this.label}</span>`
            : html ``}
</div>
`;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getSizeConfig() {
        const baseWrapper = 'inline-flex items-center';
        const baseSpinner = [
            'rounded-full border-solid animate-spin',
            'ml-border',
            'ml-border-top-primary',
            'motion-reduce:animate-none',
        ].join(' ');
        const baseText = 'ml-text-muted';
        switch (this.size) {
            case 'xs':
                return {
                    wrapper: `${baseWrapper} gap-1`,
                    spinner: `${baseSpinner} w-3 h-3 border-2`,
                    text: `${baseText} text-xs`,
                };
            case 'sm':
                return {
                    wrapper: `${baseWrapper} gap-2`,
                    spinner: `${baseSpinner} w-5 h-5 border-2`,
                    text: `${baseText} text-sm`,
                };
            case 'lg':
                return {
                    wrapper: `${baseWrapper} gap-3`,
                    spinner: `${baseSpinner} w-12 h-12 border-4`,
                    text: `${baseText} text-base`,
                };
            case 'md':
            default:
                return {
                    wrapper: `${baseWrapper} gap-2`,
                    spinner: `${baseSpinner} w-8 h-8 border-4`,
                    text: `${baseText} text-sm`,
                };
        }
    }
};
__decorate([
    propertyDataSource({ type: Number })
], IndeterminateSpinnerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], IndeterminateSpinnerMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], IndeterminateSpinnerMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], IndeterminateSpinnerMolecule.prototype, "showValue", void 0);
IndeterminateSpinnerMolecule = __decorate([
    customElement('groupshowprogress--ml-indeterminate-spinner')
], IndeterminateSpinnerMolecule);
export { IndeterminateSpinnerMolecule };
