var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupshowprogress/ml-circular-progress.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CIRCULAR PROGRESS MOLECULE
// =============================================================================
// Skill Group: groupShowProgress
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
let CircularProgressMolecule = class CircularProgressMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-circular-progress .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-circular-progress .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-circular-progress .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-circular-progress .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupshowprogress--ml-circular-progress .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-circular-progress .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-circular-progress .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-circular-progress .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupshowprogress--ml-circular-progress .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupshowprogress--ml-circular-progress .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
groupshowprogress--ml-circular-progress .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
groupshowprogress--ml-circular-progress .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
groupshowprogress--ml-circular-progress .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupshowprogress--ml-circular-progress .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupshowprogress--ml-circular-progress .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupshowprogress--ml-circular-progress .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupshowprogress--ml-circular-progress .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupshowprogress--ml-circular-progress .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupshowprogress--ml-circular-progress .ml-stroke-primary {
  stroke: var(--button-primary-bg, #3b82f6);
}
groupshowprogress--ml-circular-progress .ml-stroke-track {
  stroke: var(--border-default, #e2e8f0);
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = [];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.size = 'md';
        this.label = '';
        this.showValue = false;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const determinate = this.isDeterminate();
        const clampedValue = determinate ? this.getClampedValue() : null;
        const showText = determinate && this.showValue;
        const ariaAttrs = this.getAriaAttributes(clampedValue);
        return html `
<div
class="${cn(this.getWrapperClasses(), this.cssClass)}"
role="progressbar"
aria-label="${this.label || 'Progress'}"
${ariaAttrs}
>
${this.renderSvg(clampedValue, determinate)}
${showText
            ? html `<div class="${this.getValueTextClasses()}">${Math.round(clampedValue || 0)}%</div>`
            : html ``}
</div>
`;
    }
    // ==========================================================================
    // SVG RENDERING
    // ==========================================================================
    renderSvg(value, determinate) {
        const radius = 45;
        const circumference = 2 * Math.PI * radius;
        const dashOffset = determinate && value !== null
            ? circumference * (1 - value / 100)
            : circumference * 0.25;
        const progressClasses = [
            'ml-stroke-primary',
            value === 100 ? '' : '',
        ].filter(Boolean).join(' ');
        return html `
<svg
viewBox="0 0 100 100"
class="${this.getSvgClasses()}"
aria-hidden="true"
>
${svg `
<circle
cx="50"
cy="50"
r="45"
fill="none"
stroke-width="10"
class="ml-stroke-track"
></circle>
<circle
cx="50"
cy="50"
r="45"
fill="none"
stroke-width="10"
stroke-linecap="round"
stroke-dasharray="${circumference}"
stroke-dashoffset="${dashOffset}"
class="${progressClasses}"
transform="${determinate ? 'rotate(-90 50 50)' : ''}"
>
${!determinate
            ? svg `<!-- Use SVG animation to avoid lateral movement in indeterminate mode -->
<animateTransform
attributeName="transform"
attributeType="XML"
type="rotate"
from="0 50 50"
to="360 50 50"
dur="1s"
repeatCount="indefinite"
></animateTransform>`
            : svg ``}
</circle>
`}
</svg>
`;
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    isDeterminate() {
        return this.value !== null && !Number.isNaN(this.value);
    }
    getClampedValue() {
        const raw = this.value ?? 0;
        return Math.min(100, Math.max(0, raw));
    }
    getAriaAttributes(value) {
        if (!this.isDeterminate() || value === null) {
            return html ``;
        }
        return html `aria-valuenow="${value}" aria-valuemin="0" aria-valuemax="100"`;
    }
    getWrapperClasses() {
        return [
            'relative inline-flex items-center justify-center',
            this.getSizeClasses(),
        ].join(' ');
    }
    getSvgClasses() {
        return [
            'w-full h-full',
        ].join(' ');
    }
    getValueTextClasses() {
        return [
            'absolute text-xs font-medium',
            'ml-text',
            'pointer-events-none',
        ].join(' ');
    }
    getSizeClasses() {
        const size = this.getResolvedSize();
        const map = {
            xs: 'w-4 h-4',
            sm: 'w-6 h-6',
            md: 'w-10 h-10',
            lg: 'w-16 h-16',
        };
        return map[size] || map.md;
    }
    getResolvedSize() {
        const sizes = ['xs', 'sm', 'md', 'lg'];
        return sizes.includes(this.size) ? this.size : 'md';
    }
};
__decorate([
    propertyDataSource({ type: Number })
], CircularProgressMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], CircularProgressMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], CircularProgressMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], CircularProgressMolecule.prototype, "showValue", void 0);
CircularProgressMolecule = __decorate([
    customElement('groupshowprogress--ml-circular-progress')
], CircularProgressMolecule);
export { CircularProgressMolecule };
