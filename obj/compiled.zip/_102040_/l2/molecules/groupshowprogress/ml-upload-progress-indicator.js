var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupshowprogress/ml-upload-progress-indicator.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// UPLOAD PROGRESS INDICATOR MOLECULE
// =============================================================================
// Skill Group: groupShowProgress
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
let UploadProgressIndicatorMolecule = class UploadProgressIndicatorMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-upload-progress-indicator .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-upload-progress-indicator .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-upload-progress-indicator .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-upload-progress-indicator .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupshowprogress--ml-upload-progress-indicator .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-upload-progress-indicator .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-upload-progress-indicator .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-upload-progress-indicator .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupshowprogress--ml-upload-progress-indicator .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupshowprogress--ml-upload-progress-indicator .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
groupshowprogress--ml-upload-progress-indicator .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
groupshowprogress--ml-upload-progress-indicator .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
groupshowprogress--ml-upload-progress-indicator .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupshowprogress--ml-upload-progress-indicator .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupshowprogress--ml-upload-progress-indicator .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupshowprogress--ml-upload-progress-indicator .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupshowprogress--ml-upload-progress-indicator .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupshowprogress--ml-upload-progress-indicator .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = [];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.size = 'md';
        this.label = '';
        this.showValue = false;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const isIndeterminate = this.value === null || this.value === undefined;
        const clampedValue = isIndeterminate ? null : this.clampValue(this.value);
        const showPercent = this.showValue && clampedValue !== null;
        const sizeConfig = this.getSizeConfig(this.size);
        const ariaLabel = this.label || 'Progress';
        const containerClasses = [
            'inline-flex items-center gap-2',
            'ml-text-muted',
        ].join(' ');
        const svgClasses = [
            sizeConfig.sizeClass,
            isIndeterminate ? 'animate-spin' : '',
        ].filter(Boolean).join(' ');
        const progressCircle = this.renderProgressCircle(clampedValue, isIndeterminate, sizeConfig.strokeWidth);
        return html `
 <div
 class="${cn(containerClasses, this.cssClass)}"
 role="progressbar"
 aria-label="${ariaLabel}"
 aria-valuemin="${isIndeterminate ? '' : '0'}"
 aria-valuemax="${isIndeterminate ? '' : '100'}"
 aria-valuenow="${isIndeterminate ? '' : String(clampedValue)}"
 >
 <svg class="${svgClasses}" viewBox="0 0 36 36" aria-hidden="true">
 ${progressCircle}
 </svg>
 ${showPercent ? html `<span class="text-sm font-medium ml-text">${this.formatPercentage(clampedValue)}</span>` : html ``}
 </div>
 `;
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    clampValue(value) {
        if (value === null || value === undefined)
            return 0;
        return Math.min(100, Math.max(0, value));
    }
    formatPercentage(value) {
        if (value === null || value === undefined)
            return '';
        if (value === 100)
            return '100%';
        return `${String(Math.round(value)).padStart(2, '0')}%`;
    }
    getSizeConfig(size) {
        switch (size) {
            case 'xs':
                return { sizeClass: 'w-4 h-4', strokeWidth: 3 };
            case 'sm':
                return { sizeClass: 'w-6 h-6', strokeWidth: 3 };
            case 'lg':
                return { sizeClass: 'w-16 h-16', strokeWidth: 4 };
            case 'md':
            default:
                return { sizeClass: 'w-10 h-10', strokeWidth: 4 };
        }
    }
    renderProgressCircle(value, isIndeterminate, strokeWidth) {
        const radius = 16;
        const circumference = 2 * Math.PI * radius;
        if (isIndeterminate) {
            return svg `
 <circle
 cx="18"
 cy="18"
 r="${radius}"
 fill="none"
 stroke-width="${strokeWidth}"
 class="ml-text-muted"
 stroke="currentColor"
 ></circle>
 <circle
 cx="18"
 cy="18"
 r="${radius}"
 fill="none"
 stroke-width="${strokeWidth}"
 stroke-linecap="round"
 class="ml-primary-text"
 stroke="currentColor"
 stroke-dasharray="80 200"
 stroke-dashoffset="0"
 ></circle>
 `;
        }
        const dashOffset = circumference - (circumference * (value || 0)) / 100;
        return svg `
 <circle
 cx="18"
 cy="18"
 r="${radius}"
 fill="none"
 stroke-width="${strokeWidth}"
 class="ml-text-muted"
 stroke="currentColor"
 ></circle>
 <circle
 cx="18"
 cy="18"
 r="${radius}"
 fill="none"
 stroke-width="${strokeWidth}"
 stroke-linecap="round"
 class="ml-primary-text"
 stroke="currentColor"
 stroke-dasharray="${circumference} ${circumference}"
 stroke-dashoffset="${dashOffset}"
 ></circle>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], UploadProgressIndicatorMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], UploadProgressIndicatorMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], UploadProgressIndicatorMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], UploadProgressIndicatorMolecule.prototype, "showValue", void 0);
UploadProgressIndicatorMolecule = __decorate([
    customElement('groupshowprogress--ml-upload-progress-indicator')
], UploadProgressIndicatorMolecule);
export { UploadProgressIndicatorMolecule };
