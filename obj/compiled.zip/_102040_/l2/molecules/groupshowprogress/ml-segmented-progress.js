var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupshowprogress/ml-segmented-progress.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEGMENTED PROGRESS MOLECULE
// =============================================================================
// Skill Group: groupShowProgress
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    defaultLabel: 'Progress',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let SegmentedProgressMolecule = class SegmentedProgressMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.size = 'md';
        this.label = '';
        this.showValue = false;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const isIndeterminate = this.value === null || this.value === undefined;
        const clampedValue = this.clampValue(this.value ?? 0);
        const sizeConfig = this.getSizeConfig();
        const barContainerClasses = this.buildBarContainerClasses(sizeConfig.heightClass, sizeConfig.radiusClass);
        const barFillClasses = this.buildBarFillClasses();
        const indeterminateClasses = this.buildIndeterminateClasses();
        const valueTextClasses = this.buildValueTextClasses(sizeConfig.textClass);
        return html `
      <div
        class="flex items-center gap-2 w-full"
        role="progressbar"
        aria-label=${this.label || this.msg.defaultLabel}
        aria-valuemin=${isIndeterminate ? nothing : '0'}
        aria-valuemax=${isIndeterminate ? nothing : '100'}
        aria-valuenow=${isIndeterminate ? nothing : String(clampedValue)}
      >
        <div class=${barContainerClasses}>
          ${isIndeterminate
            ? html `<div class=${indeterminateClasses}></div>`
            : html `<div class=${barFillClasses} style="width: ${clampedValue}%;"></div>`}
        </div>
        ${!isIndeterminate && this.showValue
            ? html `<span class=${valueTextClasses}>${clampedValue}%</span>`
            : nothing}
      </div>
    `;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    clampValue(value) {
        if (Number.isNaN(value))
            return 0;
        return Math.max(0, Math.min(100, value));
    }
    getSizeConfig() {
        switch (this.size) {
            case 'xs':
                return { heightClass: 'h-1.5', textClass: 'text-xs', radiusClass: 'rounded-full' };
            case 'sm':
                return { heightClass: 'h-2', textClass: 'text-xs', radiusClass: 'rounded-full' };
            case 'lg':
                return { heightClass: 'h-4', textClass: 'text-sm', radiusClass: 'rounded-full' };
            case 'md':
            default:
                return { heightClass: 'h-3', textClass: 'text-sm', radiusClass: 'rounded-full' };
        }
    }
    buildBarContainerClasses(heightClass, radiusClass) {
        return [
            'relative flex-1 overflow-hidden border',
            heightClass,
            radiusClass,
            'bg-slate-50 dark:bg-slate-900',
            'border-slate-200 dark:border-slate-700',
        ].filter(Boolean).join(' ');
    }
    buildBarFillClasses() {
        return [
            'absolute inset-y-0 left-0 transition-all duration-300 ease-out',
            'bg-sky-500 dark:bg-sky-400',
        ].filter(Boolean).join(' ');
    }
    buildIndeterminateClasses() {
        return [
            'absolute inset-y-0 left-0 w-1/2',
            'bg-sky-500 dark:bg-sky-400',
            'animate-pulse',
        ].filter(Boolean).join(' ');
    }
    buildValueTextClasses(textClass) {
        return [
            textClass,
            'text-slate-700 dark:text-slate-300',
            'tabular-nums',
        ].filter(Boolean).join(' ');
    }
};
__decorate([
    propertyDataSource({ type: Number })
], SegmentedProgressMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedProgressMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedProgressMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], SegmentedProgressMolecule.prototype, "showValue", void 0);
SegmentedProgressMolecule = __decorate([
    customElement('groupshowprogress--ml-segmented-progress')
], SegmentedProgressMolecule);
export { SegmentedProgressMolecule };
