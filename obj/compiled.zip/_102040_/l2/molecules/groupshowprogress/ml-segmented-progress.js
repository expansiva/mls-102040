var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupshowprogress/ml-segmented-progress.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEGMENTED PROGRESS MOLECULE
// =============================================================================
// Skill Group: groupShowProgress
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    defaultLabel: 'Progress',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let SegmentedProgressMolecule = class SegmentedProgressMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupshowprogress--ml-segmented-progress .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-segmented-progress .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-segmented-progress .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-segmented-progress .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupshowprogress--ml-segmented-progress .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-segmented-progress .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-segmented-progress .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupshowprogress--ml-segmented-progress .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupshowprogress--ml-segmented-progress .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupshowprogress--ml-segmented-progress .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
}
groupshowprogress--ml-segmented-progress .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupshowprogress--ml-segmented-progress .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupshowprogress--ml-segmented-progress .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupshowprogress--ml-segmented-progress .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupshowprogress--ml-segmented-progress .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupshowprogress--ml-segmented-progress .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupshowprogress--ml-segmented-progress .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupshowprogress--ml-segmented-progress .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.size = 'md';
        this.label = '';
        this.showValue = false;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const isIndeterminate = this.value === null || this.value === undefined;
        const clampedValue = this.clampValue(this.value ?? 0);
        const sizeConfig = this.getSizeConfig();
        const barContainerClasses = this.buildBarContainerClasses(sizeConfig.heightClass, sizeConfig.radiusClass);
        const barFillClasses = this.buildBarFillClasses();
        const indeterminateClasses = this.buildIndeterminateClasses();
        const valueTextClasses = this.buildValueTextClasses(sizeConfig.textClass);
        return html `
 <div
 class="${cn('flex items-center gap-2 w-full', this.cssClass)}"
 role="progressbar"
 aria-label=${this.label || this.msg.defaultLabel}
 aria-valuemin=${isIndeterminate ? nothing : '0'}
 aria-valuemax=${isIndeterminate ? nothing : '100'}
 aria-valuenow=${isIndeterminate ? nothing : String(clampedValue)}
 >
 <div class=${barContainerClasses}>
 ${isIndeterminate
            ? html `<div class=${indeterminateClasses}></div>`
            : html `<div class=${barFillClasses} style="width: ${clampedValue}%;"></div>`}
 </div>
 ${!isIndeterminate && this.showValue
            ? html `<span class=${valueTextClasses}>${clampedValue}%</span>`
            : nothing}
 </div>
 `;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    clampValue(value) {
        if (Number.isNaN(value))
            return 0;
        return Math.max(0, Math.min(100, value));
    }
    getSizeConfig() {
        switch (this.size) {
            case 'xs':
                return { heightClass: 'h-1.5', textClass: 'text-xs', radiusClass: 'rounded-full' };
            case 'sm':
                return { heightClass: 'h-2', textClass: 'text-xs', radiusClass: 'rounded-full' };
            case 'lg':
                return { heightClass: 'h-4', textClass: 'text-sm', radiusClass: 'rounded-full' };
            case 'md':
            default:
                return { heightClass: 'h-3', textClass: 'text-sm', radiusClass: 'rounded-full' };
        }
    }
    buildBarContainerClasses(heightClass, radiusClass) {
        return [
            'relative flex-1 overflow-hidden border',
            heightClass,
            radiusClass,
            'ml-surface-dim-bg',
            'ml-border',
        ].filter(Boolean).join(' ');
    }
    buildBarFillClasses() {
        return [
            'absolute inset-y-0 left-0 transition-all duration-300 ease-out',
            'ml-primary-bg',
        ].filter(Boolean).join(' ');
    }
    buildIndeterminateClasses() {
        return [
            'absolute inset-y-0 left-0 w-1/2',
            'ml-primary-bg',
            'animate-pulse',
        ].filter(Boolean).join(' ');
    }
    buildValueTextClasses(textClass) {
        return [
            textClass,
            'ml-text',
            'tabular-nums',
        ].filter(Boolean).join(' ');
    }
};
__decorate([
    propertyDataSource({ type: Number })
], SegmentedProgressMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedProgressMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], SegmentedProgressMolecule.prototype, "label", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-value' })
], SegmentedProgressMolecule.prototype, "showValue", void 0);
SegmentedProgressMolecule = __decorate([
    customElement('groupshowprogress--ml-segmented-progress')
], SegmentedProgressMolecule);
export { SegmentedProgressMolecule };
