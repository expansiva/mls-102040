var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupshowprogress/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupshowprogress/ml-circular-progress';
import '/_102040_/l2/molecules/groupshowprogress/ml-indeterminate-spinner';
import '/_102040_/l2/molecules/groupshowprogress/ml-linear-progress';
import '/_102040_/l2/molecules/groupshowprogress/ml-segmented-progress';
import '/_102040_/l2/molecules/groupshowprogress/ml-upload-progress-indicator';
import { molecules, scenarios } from '/_102040_/l2/molecules/groupshowprogress/index.defs.js';
import { renderCatalogReferenceTable } from '/_102020_/l2/aura/molecules/shared/indexReferenceTable.js';
let GroupShowProgressIndex = class GroupShowProgressIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        // ── Showcase card states ─────────────────────────────────────
        this.card1 = 68;
        this.card2 = null;
        this.card3 = 42;
        this.card4 = 75;
        this.card5 = 88;
    }
    // ===========================================================================
    // SECTION: Hero
    renderHero() {
        return html `
      <header class="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-8 py-20 text-center">
        <span
          class="inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-600 dark:text-sky-300 rounded-full text-xs font-semibold uppercase tracking-widest mb-6"
        >
          groupShowProgress
        </span>
        <h1 class="text-5xl font-bold text-slate-900 dark:text-slate-50 mb-5 tracking-tight">
          Show Progress
        </h1>
        <p class="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Indicates the progress of an operation or process. Visual primitive designed for composition inside other components. Supports determinate mode (0-100%) and indeterminate mode (unknown duration). Implementations include progress bar, progress ring/circle, spinner, and percentage indicator.
        </p>
      </header>
    `;
    }
    // ===========================================================================
    // SECTION: Showcase Cards
    renderShowcaseCards() {
        return html `
      <section class="bg-slate-50 dark:bg-slate-950 px-8 py-12 border-b border-slate-200 dark:border-slate-700">
        <div class="max-w-2xl mx-auto flex flex-col gap-5">
          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-violet-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Circular Progress</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupshowprogress--ml-circular-progress</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Compact determinate ring with a visible percentage.</p>
              <groupshowprogress--ml-circular-progress
                name="card-1"
                .value=${this.card1}
                size="md"
                label="Generating report"
                .showValue=${true}
                .isEditing=${true}
                @change=${(e) => {
            this.card1 = e.detail.value;
        }}
              ></groupshowprogress--ml-circular-progress>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-emerald-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Indeterminate Spinner</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupshowprogress--ml-indeterminate-spinner</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Use when duration is unknown and feedback must stay lightweight.</p>
              <groupshowprogress--ml-indeterminate-spinner
                name="card-2"
                .value=${this.card2}
                size="sm"
                label="Saving changes"
                .isEditing=${true}
                @change=${(e) => {
            this.card2 = e.detail.value;
        }}
              ></groupshowprogress--ml-indeterminate-spinner>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-amber-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Linear Progress</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupshowprogress--ml-linear-progress</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Best for full-width task progress in layouts or dialogs.</p>
              <groupshowprogress--ml-linear-progress
                name="card-3"
                .value=${this.card3}
                size="lg"
                label="Uploading files"
                .showValue=${true}
                .isEditing=${true}
                @change=${(e) => {
            this.card3 = e.detail.value;
        }}
              ></groupshowprogress--ml-linear-progress>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-rose-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Segmented Progress</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupshowprogress--ml-segmented-progress</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Segmented indicators suit multi-step flows and milestones.</p>
              <groupshowprogress--ml-segmented-progress
                name="card-4"
                .value=${this.card4}
                size="md"
                label="Completing steps"
                .showValue=${true}
                .isEditing=${true}
                @change=${(e) => {
            this.card4 = e.detail.value;
        }}
              ></groupshowprogress--ml-segmented-progress>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-sky-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Upload Progress Indicator</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupshowprogress--ml-upload-progress-indicator</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Expresses file transfer progress with a clear percent readout.</p>
              <groupshowprogress--ml-upload-progress-indicator
                name="card-5"
                .value=${this.card5}
                size="md"
                label="Syncing assets"
                .showValue=${true}
                .isEditing=${true}
                @change=${(e) => {
            this.card5 = e.detail.value;
        }}
              ></groupshowprogress--ml-upload-progress-indicator>
            </div>
          </div>
        </div>
      </section>
    `;
    }
    // ===========================================================================
    // SECTION: Reference Table
    renderReferenceTable() {
        return renderCatalogReferenceTable(molecules, scenarios);
    }
    // ===========================================================================
    // SECTION: Render
    render() {
        return html `
      <div class="font-sans min-h-screen">
        ${this.renderHero()}
        ${this.renderShowcaseCards()}
        ${this.renderReferenceTable()}
      </div>
    `;
    }
};
__decorate([
    state()
], GroupShowProgressIndex.prototype, "card1", void 0);
__decorate([
    state()
], GroupShowProgressIndex.prototype, "card2", void 0);
__decorate([
    state()
], GroupShowProgressIndex.prototype, "card3", void 0);
__decorate([
    state()
], GroupShowProgressIndex.prototype, "card4", void 0);
__decorate([
    state()
], GroupShowProgressIndex.prototype, "card5", void 0);
GroupShowProgressIndex = __decorate([
    customElement('molecules--groupshowprogress--index-102040')
], GroupShowProgressIndex);
export { GroupShowProgressIndex };
