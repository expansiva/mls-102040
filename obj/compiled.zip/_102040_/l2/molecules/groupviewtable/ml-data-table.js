/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-data-table.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML DATA TABLE MOLECULE
// =============================================================================
// Skill Group: groupViewTable
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
import { cellSortKey, compareSortKeys } from '/_102033_/l2/shared/molecules/tableSort.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No records found.',
    selectAll: 'Select all rows',
    selectRow: 'Select row',
    selected: 'selected',
    sortAscending: 'Sort ascending',
    sortDescending: 'Sort descending',
    previous: 'Previous',
    next: 'Next',
    page: 'Table pagination',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhum registro encontrado.',
        selectAll: 'Selecionar todos',
        selectRow: 'Selecionar linha',
        selected: 'selecionado(s)',
        sortAscending: 'Ordenar crescente',
        sortDescending: 'Ordenar decrescente',
        previous: 'Anterior',
        next: 'Próximo',
        page: 'Paginação da tabela',
    },
};
// =============================================================================
// COMPONENT
// =============================================================================
let MlDataTableMolecule = class MlDataTableMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['TableCaption', 'TableHeader', 'TableBody', 'TableRow', 'TableHead', 'TableCell', 'TableFooter', 'Empty', 'Loading'];
        // Esta molécula TRANSFORMA os slots: lê TableBody > TableRow > TableCell, ordena e re-emite
        // <tr>/<td> de verdade. No caminho antigo o conteúdo de célula passava por DUAS serializações
        // (outerHTML para o snapshot, innerHTML para o unsafeHTML), o que matava handler e binding — o
        // botão de ação por linha (ex.: "Cancelar item" em comandaRestaurante/atendimento) era HTML morto.
        //
        // Com slot vivo o conteúdo é MOVIDO para a célula renderizada. A estrutura passa a ser lida do
        // DOM VIVO (getLiveSlot), não do snapshot: uma célula já projetada está vazia, e um re-snapshot
        // leria vazio.
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        /** Comma-separated selected row indices, e.g."0,2,5" */
        this.value = '';
        this.selectable = false;
        /** Propagates is-editing attribute to all web components inside TableCell elements */
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    createRenderRoot() { return this; }
    updated() {
        this.propagateIsEditing();
    }
    // ===========================================================================
    // IS-EDITING PROPAGATION
    // ===========================================================================
    // O conteúdo das células é projetado para os <td> renderizados; uma célula ainda não desenhada
    // guarda os próprios filhos. Os dois lugares são cobertos.
    //
    // Só grava quando o valor muda: setAttribute com o MESMO valor ainda gera um MutationRecord, e
    // dentro de um slot tag isso agenda outro render, que chama esta função de novo — um laço.
    propagateIsEditing() {
        const value = this.isEditing ? 'true' : 'false';
        const roots = [
            ...Array.from(this.querySelectorAll('td > [data-ml-live-ref]')),
            ...Array.from(this.querySelectorAll('TableCell')),
        ];
        roots.forEach(root => {
            root.querySelectorAll('*').forEach(el => {
                if (el.tagName.includes('-') && el.getAttribute('is-editing') !== value) {
                    el.setAttribute('is-editing', value);
                }
            });
        });
    }
    // ===========================================================================
    // PARSERS
    // ===========================================================================
    // Estrutura vem do DOM VIVO e só dos filhos DIRETOS: uma tabela aninhada dentro de uma célula
    // tem TableRow/TableCell próprios, que um querySelectorAll de descendentes também pegaria.
    parseColumns() {
        const header = this.getLiveSlot('TableHeader');
        if (!header)
            return [];
        return Array.from(header.querySelectorAll(':scope > TableRow > TableHead')).map(el => ({
            key: el.getAttribute('key') || '',
            element: el,
            sortable: el.hasAttribute('sortable'),
            headClass: el.getAttribute('data-class') || '',
            width: el.getAttribute('width'),
        })).filter(c => c.key);
    }
    parseBodyRows() {
        const body = this.getLiveSlot('TableBody');
        if (!body)
            return [];
        return Array.from(body.querySelectorAll(':scope > TableRow')).map((row, index) => ({
            cells: Array.from(row.querySelectorAll(':scope > TableCell')),
            index,
        }));
    }
    parseFooterRows() {
        const footer = this.getLiveSlot('TableFooter');
        if (!footer)
            return [];
        return Array.from(footer.querySelectorAll(':scope > TableRow')).map(row => Array.from(row.querySelectorAll(':scope > TableCell')));
    }
    getSelectedSet() {
        if (!this.value)
            return new Set();
        return new Set(this.value.split(',').map(s => s.trim()).filter(Boolean));
    }
    // ===========================================================================
    // SORTING
    // ===========================================================================
    getSortedRows(rows, columns) {
        if (!this.sortKey)
            return rows;
        const colIndex = columns.findIndex(c => c.key === this.sortKey);
        if (colIndex < 0)
            return rows;
        // `cellSortKey` honors the cell's `sort-value` and `compareSortKeys` understands formatted
        // numbers. The previous path did `parseFloat(text.replace(/[^\d.-]/g,''))`, which read
        // `R$ 1.234,50` as 1.2345 — the comma vanished and the thousands dot became the decimal.
        const dir = this.sortDirection === 'asc' ? 1 : -1;
        return [...rows].sort((a, b) => {
            // getLiveText: a célula projetada está vazia (os filhos foram movidos), então textContent
            // leria ''. O `sort-value` declarado continua tendo prioridade.
            const keyA = cellSortKey(a.cells[colIndex], this.getLiveText(a.cells[colIndex]));
            const keyB = cellSortKey(b.cells[colIndex], this.getLiveText(b.cells[colIndex]));
            return compareSortKeys(keyA, keyB) * dir;
        });
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSort(col) {
        if (!col.sortable || this.disabled)
            return;
        if (this.sortKey === col.key) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortKey = col.key;
            this.sortDirection = 'asc';
        }
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true, composed: true,
            detail: { key: this.sortKey, direction: this.sortDirection },
        }));
    }
    handleRowClick(index, event) {
        if (this.disabled)
            return;
        if (event.target.closest('input[type="checkbox"]'))
            return;
        // Conteúdo projetado pode ser interativo (o botão de ação da linha); o clique dele sobe até o
        // <tr> e não deve virar também um rowClick.
        const tr = event.currentTarget;
        const interactive = event.target.closest?.('button, a[href], input, select, textarea, label, [role="button"], [contenteditable="true"]');
        if (interactive && interactive !== tr && tr.contains(interactive))
            return;
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true, composed: true,
            detail: { index },
        }));
    }
    handleRowSelect(index, checked) {
        if (this.disabled)
            return;
        const sel = this.getSelectedSet();
        if (checked)
            sel.add(String(index));
        else
            sel.delete(String(index));
        this.value = Array.from(sel).join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true, composed: true,
            detail: { value: this.value },
        }));
    }
    handleSelectAll(rows, checked) {
        if (this.disabled)
            return;
        this.value = checked ? rows.map(r => String(r.index)).join(',') : '';
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true, composed: true,
            detail: { value: this.value },
        }));
    }
    handlePageChange(newPage) {
        if (this.disabled)
            return;
        this.page = newPage;
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true, composed: true,
            detail: { page: newPage },
        }));
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getThClasses(col) {
        const isActive = this.sortKey === col.key;
        return [
            'px-4 py-3 text-xs font-semibold uppercase tracking-wide whitespace-nowrap transition',
            col.headClass,
            isActive ? 'ml-primary-text' : 'ml-text-muted',
            col.sortable && !this.disabled
                ? 'cursor-pointer select-none hover:ml-text'
                : '',
        ].filter(Boolean).join(' ');
    }
    /**
     * `extra` é o `data-class` que o consumidor pôs na `<TableCell>` — parte do contrato do grupo
     * (skills/groupViewTable, §data-class), que esta molécula ignorava.
     *
     * O `text-left` deixou de ser emitido no caso padrão: ele não muda nada (célula de tabela já
     * alinha à esquerda em LTR) e BRIGAVA com o `data-class` do consumidor — duas utilitárias de
     * alinhamento na mesma célula resolvem pela ordem na folha de estilo, não pela ordem aqui.
     */
    getTdClasses(dataClass = '', bold = false) {
        return [
            'px-4 py-3 text-sm ml-text',
            bold ? 'font-medium' : '',
            dataClass,
        ].filter(Boolean).join(' ');
    }
    getTrClasses(index, selected) {
        const isSelected = selected.has(String(index));
        return [
            'border-b ml-border transition-colors',
            isSelected ? 'ml-primary-dim-bg' : 'ml-surface-bg',
            !this.disabled ? 'hover:ml-surface-dim-bg cursor-pointer' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderSortIcon(col) {
        if (!col.sortable)
            return html ``;
        const isActive = this.sortKey === col.key;
        const isDesc = isActive && this.sortDirection === 'desc';
        return html `
 <svg
 class="ml-1 h-3.5 w-3.5 inline-block flex-shrink-0 ${isActive ? 'ml-primary-text' : 'ml-text-muted'}"
 viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"
 >
 ${isDesc
            ? html `<path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clip-rule="evenodd"/>`
            : html `<path fill-rule="evenodd" d="M14.77 12.79a.75.75 0 01-1.06-.02L10 8.832l-3.71 3.938a.75.75 0 01-1.08-1.04l4.25-4.5a.75.75 0 011.08 0l4.25 4.5a.75.75 0 01-.02 1.06z" clip-rule="evenodd"/>`}
 </svg>
 `;
    }
    renderSkeleton() {
        const cols = [0, 1, 2, 3];
        const rows = [0, 1, 2, 3, 4];
        return html `
 <div class="w-full overflow-hidden rounded-xl border ml-border animate-pulse">
 <div class="flex items-center gap-6 border-b ml-border ml-surface-dim-bg px-4 py-3">
 ${cols.map((_, i) => html `
 <div class="h-3 rounded ml-surface-dim-bg ${i === 0 ? 'w-20' : i === 1 ? 'w-32' : i === 2 ? 'w-24' : 'w-16'}"></div>
 `)}
 </div>
 ${rows.map(() => html `
 <div class="flex items-center gap-6 border-b ml-border ml-surface-bg px-4 py-3">
 ${cols.map((_, i) => html `
 <div class="h-3 rounded ml-surface-dim-bg ${i === 0 ? 'w-24' : i === 1 ? 'w-40' : i === 2 ? 'w-20' : 'w-12'}"></div>
 `)}
 </div>
 `)}
 </div>
 `;
    }
    renderEmpty() {
        const content = this.hasSlot('Empty') ? this.renderLiveSlot('Empty') : html `${this.msg.empty}`;
        return html `
 <tr>
 <td colspan="999">
 <div class="flex flex-col items-center justify-center py-14 ml-text-faint">
 <svg class="mb-3 h-10 w-10 ml-text-muted" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5" aria-hidden="true">
 <path stroke-linecap="round" stroke-linejoin="round"
 d="M3.375 19.5h17.25m-17.25 0a1.125 1.125 0 01-1.125-1.125M3.375 19.5h7.5c.621 0 1.125-.504 1.125-1.125m-9.75 0V5.625m0 12.75v-1.5c0-.621.504-1.125 1.125-1.125m18.375 2.625V5.625m0 12.75c0 .621-.504 1.125-1.125 1.125m1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125m0 3.75h-7.5A1.125 1.125 0 0112 18.375m9.75-12.75c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125m19.5 0v1.5c0 .621-.504 1.125-1.125 1.125M2.25 5.625v1.5c0 .621.504 1.125 1.125 1.125m0 0h17.25m-17.25 0h7.5c.621 0 1.125.504 1.125 1.125M3.375 8.25c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375z"
 />
 </svg>
 <p class="text-sm">${content}</p>
 </div>
 </td>
 </tr>
 `;
    }
    renderPagination(totalPages) {
        if (this.pageSize <= 0 || totalPages <= 1)
            return html ``;
        const current = this.page;
        // Build page list with ellipsis markers (-1)
        const visible = new Set();
        visible.add(1);
        visible.add(totalPages);
        for (let i = Math.max(2, current - 1); i <= Math.min(totalPages - 1, current + 1); i++) {
            visible.add(i);
        }
        const sorted = Array.from(visible).sort((a, b) => a - b);
        const withEllipsis = [];
        for (let i = 0; i < sorted.length; i++) {
            if (i > 0 && sorted[i] - sorted[i - 1] > 1)
                withEllipsis.push(-1);
            withEllipsis.push(sorted[i]);
        }
        const btnBase = 'flex h-8 min-w-[2rem] items-center justify-center rounded-lg px-2 text-sm transition';
        return html `
 <nav class="mt-4 flex items-center justify-end gap-1" role="navigation" aria-label=${this.msg.page}>
 <button
 class="${btnBase} ml-text-muted hover:ml-surface-dim-bg disabled:opacity-40 disabled:cursor-not-allowed"
 ?disabled=${current <= 1 || this.disabled}
 aria-label=${this.msg.previous}
 @click=${() => this.handlePageChange(current - 1)}
 >
 <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
 <path fill-rule="evenodd" d="M12.79 5.23a.75.75 0 01-.02 1.06L8.832 10l3.938 3.71a.75.75 0 11-1.04 1.08l-4.5-4.25a.75.75 0 010-1.08l4.5-4.25a.75.75 0 011.06.02z" clip-rule="evenodd"/>
 </svg>
 </button>

 ${withEllipsis.map(p => p === -1
            ? html `<span class="flex h-8 w-8 items-center justify-center text-sm ml-text-faint select-none">…</span>`
            : html `
 <button
 class="${btnBase} ${p === current
                ? 'ml-primary-bg font-semibold'
                : 'ml-text-muted hover:ml-surface-dim-bg'}"
 ?disabled=${this.disabled}
 aria-current=${p === current ? 'page' : nothing}
 @click=${() => this.handlePageChange(p)}
 >${p}</button>
 `)}

 <button
 class="${btnBase} ml-text-muted hover:ml-surface-dim-bg disabled:opacity-40 disabled:cursor-not-allowed"
 ?disabled=${current >= totalPages || this.disabled}
 aria-label=${this.msg.next}
 @click=${() => this.handlePageChange(current + 1)}
 >
 <svg class="h-4 w-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
 <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd"/>
 </svg>
 </button>
 </nav>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // O TableCaption aparece duas vezes (visível e no <caption> sr-only). Um nó só pode estar num lugar,
        // então a cópia visível recebe o conteúdo projetado e a sr-only, o texto atual dele.
        const hasCaption = this.hasSlot('TableCaption');
        const captionText = hasCaption ? this.getLiveText(this.getLiveSlot('TableCaption')) : '';
        // Loading state
        if (this.loading) {
            return html `
 <div class="${cn('w-full', this.cssClass)}">
 ${hasCaption ? html `<div class="${cn('mb-3 text-sm font-semibold ml-text', this.getSlotClass('TableCaption'))}">${this.renderLiveSlot('TableCaption')}</div>` : nothing}
 ${this.hasSlot('Loading')
                ? this.renderLiveSlot('Loading')
                : this.renderSkeleton()}
 </div>
 `;
        }
        const columns = this.parseColumns();
        const rawRows = this.parseBodyRows();
        const footerRows = this.parseFooterRows();
        const sortedRows = this.getSortedRows(rawRows, columns);
        const selected = this.getSelectedSet();
        const allSelected = sortedRows.length > 0 && sortedRows.every(r => selected.has(String(r.index)));
        const someSelected = !allSelected && sortedRows.some(r => selected.has(String(r.index)));
        const totalPages = this.pageSize > 0 ? Math.ceil(this.totalItems / this.pageSize) : 0;
        return html `
 <div class="${cn('w-full', this.disabled ? 'opacity-60 pointer-events-none' : '', this.cssClass)}">

 ${hasCaption ? html `<div class="${cn('mb-3 text-sm font-semibold ml-text', this.getSlotClass('TableCaption'))}">${this.renderLiveSlot('TableCaption')}</div>` : nothing}

 ${this.selectable && selected.size > 0 ? html `
 <div class="mb-2 flex items-center gap-2">
 <span class="inline-flex items-center rounded-full ml-primary-dim-bg px-2.5 py-0.5 text-xs font-semibold ml-primary-text">
 ${selected.size} ${this.msg.selected}
 </span>
 </div>
 ` : nothing}

 <div class="w-full overflow-x-auto rounded-xl border ml-border">
 <table class="w-full border-collapse text-sm" role="table">

 ${captionText ? html `<caption class="sr-only">${captionText}</caption>` : nothing}

 <!-- HEAD -->
 <thead class="${cn('border-b ml-border ml-surface-dim-bg', this.getSlotClass('TableHeader'))}" role="rowgroup">
 <tr role="row">
 ${this.selectable ? html `
 <th class="w-10 px-4 py-3" scope="col" role="columnheader">
 <input
 type="checkbox"
 class="h-4 w-4 rounded ml-border ml-primary-text cursor-pointer"
 .checked=${allSelected}
 .indeterminate=${someSelected}
 ?disabled=${this.disabled}
 aria-label=${this.msg.selectAll}
 @change=${(e) => { e.stopPropagation(); this.handleSelectAll(sortedRows, e.target.checked); }}
 
 @input=${(e) => e.stopPropagation()}
/>
 </th>
 ` : nothing}

 ${columns.map(col => html `
 <th
 class=${this.getThClasses(col)}
 style=${col.width ? `width:${col.width}` : ''}
 scope="col"
 role="columnheader"
 tabindex=${col.sortable ? '0' : nothing}
 aria-sort=${col.sortable && this.sortKey === col.key
            ? (this.sortDirection === 'asc' ? 'ascending' : 'descending')
            : nothing}
 @click=${() => this.handleSort(col)}
 @keydown=${(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                this.handleSort(col);
            }
        }}
 >
 <span class="inline-flex items-center">
 ${this.renderLiveSlotFrom(col.element)}
 ${this.renderSortIcon(col)}
 </span>
 </th>
 `)}
 </tr>
 </thead>

 <!-- BODY -->
 <tbody role="rowgroup">
 ${sortedRows.length === 0
            ? this.renderEmpty()
            : sortedRows.map(row => html `
 <tr
 class=${this.getTrClasses(row.index, selected)}
 role="row"
 aria-selected=${this.selectable ? (selected.has(String(row.index)) ? 'true' : 'false') : nothing}
 @click=${(e) => this.handleRowClick(row.index, e)}
 >
 ${this.selectable ? html `
 <td class="w-10 px-4 py-3" role="cell" @click=${(e) => e.stopPropagation()}>
 <input
 type="checkbox"
 class="h-4 w-4 rounded ml-border ml-primary-text cursor-pointer"
 .checked=${selected.has(String(row.index))}
 ?disabled=${this.disabled}
 aria-label="${this.msg.selectRow} ${row.index + 1}"
 @change=${(e) => { e.stopPropagation(); this.handleRowSelect(row.index, e.target.checked); }}
 
 @input="${(e) => e.stopPropagation()}"
/>
 </td>
 ` : nothing}

 ${columns.map((col, ci) => html `
 <td class=${this.getTdClasses(row.cells[ci]?.getAttribute('data-class') ?? '')} role="cell">
 ${this.renderLiveSlotFrom(row.cells[ci])}
 </td>
 `)}
 </tr>
 `)}
 </tbody>

 <!-- FOOTER -->
 ${footerRows.length > 0 ? html `
 <tfoot class="${cn('border-t ml-border ml-surface-dim-bg', this.getSlotClass('TableFooter'))}" role="rowgroup">
 ${footerRows.map(cells => html `
 <tr role="row">
 ${this.selectable ? html `<td class="w-10 px-4 py-3" role="cell"></td>` : nothing}
 ${columns.map((col, ci) => html `
 <td class=${this.getTdClasses(cells[ci]?.getAttribute('data-class') ?? '', true)} role="cell">
 ${this.renderLiveSlotFrom(cells[ci])}
 </td>
 `)}
 </tr>
 `)}
 </tfoot>
 ` : nothing}

 </table>
 </div>

 ${this.renderPagination(totalPages)}

 ${this.error ? html `
 <p class="mt-2 text-xs ml-error-text">${this.error}</p>
 ` : nothing}

 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlDataTableMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDataTableMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlDataTableMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], MlDataTableMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], MlDataTableMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDataTableMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlDataTableMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlDataTableMolecule.prototype, "sortDirection", void 0);
MlDataTableMolecule = __decorate([
    customElement('groupviewtable--ml-data-table')
], MlDataTableMolecule);
export { MlDataTableMolecule };
