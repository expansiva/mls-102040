var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-data-table-minimal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML DATA TABLE MINIMAL MOLECULE
// =============================================================================
// Skill Group: groupViewTable
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    empty: 'No data available',
    loading: 'Loading...',
    selectAll: 'Select all rows',
    selectRow: 'Select row',
    prev: 'Previous',
    next: 'Next',
    page: 'Page',
};
const messages = {
    en: message_en,
    pt: {
        empty: 'Nenhum dado disponível',
        loading: 'Carregando...',
        selectAll: 'Selecionar todas as linhas',
        selectRow: 'Selecionar linha',
        prev: 'Anterior',
        next: 'Próxima',
        page: 'Página',
    },
};
/// **collab_i18n_end**
let MlDataTableMinimalMolecule = class MlDataTableMinimalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-data-table-minimal {
  /* Custom elements are display: inline by default, so the inner h-full resolves against an
     auto-sized box and containment silently fails. Opt-in: without fit-height nothing changes.
     Both selectors on purpose: the class is mirrored by the TS, the attribute also covers plain
     HTML and the first paint, before the molecule updates. */
}
groupviewtable--ml-data-table-minimal[fit-height],
groupviewtable--ml-data-table-minimal.ml-fit-height {
  display: flex;
  flex-direction: column;
  min-height: 0;
  /* the host claims the space it was given: flex-basis rules in a flex column parent,
       height rules in a block parent with a defined height. They do not compete. */
  flex: 1 1 0%;
  height: 100%;
}
groupviewtable--ml-data-table-minimal .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-minimal .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-minimal .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-minimal .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupviewtable--ml-data-table-minimal .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-minimal .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-minimal .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-minimal .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupviewtable--ml-data-table-minimal .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewtable--ml-data-table-minimal .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
groupviewtable--ml-data-table-minimal .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
groupviewtable--ml-data-table-minimal .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
groupviewtable--ml-data-table-minimal .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupviewtable--ml-data-table-minimal .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-data-table-minimal .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewtable--ml-data-table-minimal .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewtable--ml-data-table-minimal .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupviewtable--ml-data-table-minimal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Caption', 'TableHeader', 'TableBody', 'TableRow', 'TableHead', 'TableCell', 'TableFooter', 'Empty', 'Loading'];
        // Esta molécula TRANSFORMA os slots: lê TableBody > TableRow > TableCell, ordena, pagina e
        // re-emite <tr>/<td> de verdade. No caminho antigo o conteúdo de célula passava por DUAS
        // serializações (outerHTML para o snapshot, innerHTML para o unsafeHTML), o que matava handler
        // e binding — então botão de ação por linha, o padrão mais comum de grid, era HTML morto.
        //
        // Com slot vivo o conteúdo é MOVIDO para a célula renderizada. Consequência importante: a
        // estrutura passa a ser lida do DOM VIVO (getLiveSlot), não do snapshot, porque uma célula já
        // projetada está vazia e um re-snapshot — disparado por qualquer inclusão/remoção de linha —
        // leria vazio.
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        /**
         * Faz a tabela caber na altura que o pai der, em vez de crescer com as linhas.
         *
         * Desligada (padrão), a molécula ocupa a altura do próprio conteúdo — comportamento de sempre,
         * bom para tabela curta dentro de página que rola.
         *
         * Ligada, a molécula assume a altura do contêiner: só o CORPO rola, o cabeçalho de coluna fica
         * fixo no topo e a paginação fica presa no rodapé, sempre visível. É o que uma tabela precisa
         * quando vive dentro de uma viewport limitada (split view, painel lateral) — sem isso a paginação
         * é empurrada para fora da vista pelas linhas.
         *
         * Opt-in de propósito: ligar por padrão mudaria o layout de todo consumidor existente.
         */
        this.fitHeight = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
    }
    // ===========================================================================
    // LAYOUT (fit-height)
    // ===========================================================================
    /**
     * Container: divide a altura do host em corpo rolante + rodapé fixo.
     *
     * `flex-1` e não `h-full`: o host recebe `display:flex; flex-direction:column` do `.less` quando
     * `fit-height` está ligado, então o container cresce pelo eixo flex. Percentual (`h-full`) só
     * funcionaria se o host tivesse altura definida — e custom element é `inline` por padrão, sem
     * altura, o que fazia a contenção falhar em silêncio.
     *
     * `min-h-0` é obrigatório nos dois níveis: sem ele o filho flex se recusa a encolher abaixo do
     * conteúdo e a área rolável nunca fica menor que a tabela.
     */
    get fitHeightClasses() {
        return this.fitHeight ? 'flex min-h-0 flex-1 flex-col' : '';
    }
    /** Só o corpo rola. Fora do fit-height, string vazia = comportamento anterior intacto. */
    get scrollerClasses() {
        return this.fitHeight ? 'min-h-0 flex-1 overflow-y-auto' : '';
    }
    /** Cabeçalho fixo só faz sentido quando existe um scroller para ele grudar. */
    get theadClasses() {
        return this.fitHeight ? 'ml-surface-dim-bg sticky top-0 z-10' : 'ml-surface-dim-bg';
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.propagateIsEditing();
    }
    updated(changedProps) {
        if (changedProps.has('isEditing')) {
            this.propagateIsEditing();
        }
        // O efeito de `fit-height` é metade em TS (as classes do container) e metade em CSS (a altura do
        // HOST, no .less). Se a metade de CSS casar por atributo, quem escreve `.fitHeight=${true}` —
        // property binding, que NÃO escreve atributo — liga só metade: o host continua `inline`, sem
        // altura, o container não tem contra o que encolher, e a tabela fica sem scroll em silêncio.
        // Espelhar numa classe aqui faz as duas grafias funcionarem. Classe e não atributo de propósito:
        // o atributo é observado, e escrevê-lo daqui realimentaria o setter da própria prop.
        this.classList.toggle('ml-fit-height', this.fitHeight);
        this.syncSelectAllState();
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    // Estrutura vem do DOM VIVO: é sempre atual (o snapshot só se atualiza no debounce do
    // observer) e sobrevive à projeção — mover filhos de célula não remove linha nem célula.
    getHeaderCells() {
        const header = this.getLiveSlot('TableHeader');
        const row = header?.querySelector('TableRow');
        if (!row)
            return [];
        return Array.from(row.querySelectorAll('TableHead'));
    }
    getBodyRows() {
        const body = this.getLiveSlot('TableBody');
        if (!body)
            return [];
        return Array.from(body.querySelectorAll('TableRow'));
    }
    getFooterRows() {
        const footer = this.getLiveSlot('TableFooter');
        if (!footer)
            return [];
        return Array.from(footer.querySelectorAll('TableRow'));
    }
    getSortedRows(rows, headCells) {
        if (!this.sortKey)
            return rows;
        const columnIndex = headCells.findIndex(cell => (cell.getAttribute('key') || '').trim() === this.sortKey);
        if (columnIndex < 0)
            return rows;
        const direction = this.sortDirection;
        return [...rows].sort((a, b) => {
            const aCell = a.querySelectorAll('TableCell')[columnIndex];
            const bCell = b.querySelectorAll('TableCell')[columnIndex];
            // getLiveText e não textContent: a célula já projetada está vazia (os filhos foram movidos
            // para a âncora), e ler direto dela ordenaria por string vazia.
            const aText = this.getLiveText(aCell);
            const bText = this.getLiveText(bCell);
            const result = aText.localeCompare(bText, undefined, { numeric: true, sensitivity: 'base' });
            return direction === 'asc' ? result : -result;
        });
    }
    getSelectionSet() {
        if (!this.value)
            return new Set();
        return new Set(this.value
            .split(',')
            .map(v => v.trim())
            .filter(v => v !== '')
            .map(v => Number(v))
            .filter(v => !Number.isNaN(v)));
    }
    updateSelection(set) {
        const value = Array.from(set).sort((a, b) => a - b).join(',');
        this.value = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value }
        }));
    }
    getTotalPages(itemCount) {
        if (this.pageSize <= 0)
            return 1;
        const pages = Math.ceil(itemCount / this.pageSize);
        return pages > 0 ? pages : 1;
    }
    propagateIsEditing() {
        const cells = Array.from(this.querySelectorAll('td'));
        cells.forEach(cell => {
            const customElements = Array.from(cell.querySelectorAll('*')).filter(el => el.tagName.includes('-'));
            customElements.forEach(el => {
                el.setAttribute('is-editing', this.isEditing ? 'true' : 'false');
            });
        });
    }
    syncSelectAllState() {
        if (!this.selectable)
            return;
        const headerCheckbox = this.querySelector('input[data-select-all="true"]');
        if (!headerCheckbox)
            return;
        const rows = this.getBodyRows();
        const selected = this.getSelectionSet();
        if (rows.length === 0) {
            headerCheckbox.indeterminate = false;
            headerCheckbox.checked = false;
            return;
        }
        headerCheckbox.indeterminate = selected.size > 0 && selected.size < rows.length;
        headerCheckbox.checked = selected.size === rows.length;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSort(key, sortable) {
        if (this.disabled || !sortable)
            return;
        const nextDirection = this.sortKey === key && this.sortDirection === 'asc' ? 'desc' : 'asc';
        this.sortKey = key;
        this.sortDirection = nextDirection;
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true,
            composed: true,
            detail: { key, direction: nextDirection }
        }));
    }
    handleSortKeydown(e, key, sortable) {
        if (!sortable)
            return;
        if (e.key === 'Enter' || e.key === '') {
            e.preventDefault();
            this.handleSort(key, sortable);
        }
    }
    handleRowSelection(index) {
        if (this.disabled)
            return;
        const selected = this.getSelectionSet();
        if (selected.has(index)) {
            selected.delete(index);
        }
        else {
            selected.add(index);
        }
        this.updateSelection(selected);
    }
    handleSelectAll(totalRows) {
        if (this.disabled)
            return;
        const selected = this.getSelectionSet();
        if (selected.size === totalRows) {
            this.updateSelection(new Set());
            return;
        }
        const next = new Set();
        for (let i = 0; i < totalRows; i += 1) {
            next.add(i);
        }
        this.updateSelection(next);
    }
    handleRowClick(index, e) {
        if (this.disabled)
            return;
        const target = e.target;
        if (target.closest('input[type="checkbox"]'))
            return;
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true,
            composed: true,
            detail: { index }
        }));
    }
    handleRowKeydown(e, index) {
        const rows = Array.from(this.querySelectorAll('tbody tr[data-row-index]'));
        const currentIndex = rows.findIndex(r => r.getAttribute('data-row-index') === String(index));
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            const next = rows[currentIndex + 1];
            if (next)
                next.focus();
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            const prev = rows[currentIndex - 1];
            if (prev)
                prev.focus();
        }
        if (e.key === '' && this.selectable) {
            e.preventDefault();
            this.handleRowSelection(index);
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            this.dispatchEvent(new CustomEvent('rowClick', {
                bubbles: true,
                composed: true,
                detail: { index }
            }));
        }
    }
    handlePageChange(nextPage) {
        if (this.disabled)
            return;
        this.page = nextPage;
        // 'pageChange' (camelCase) é o nome do CONTRATO — skills creation.ts e usage.ts do
        // GroupViewTable documentam assim, e é o padrão dos outros eventos desta molécula
        // ('rowClick'). Estava disparando 'page-change', que nenhum consumidor escuta: clique na
        // paginação atualizava só o estado interno e o pai nunca era avisado para trocar os dados.
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true,
            composed: true,
            detail: { page: nextPage }
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderCaption() {
        if (!this.hasSlot('Caption'))
            return html ``;
        return html `<caption class="${cn('text-left px-3 py-2 text-sm ml-text-muted', this.getSlotClass('Caption'))}">${this.renderLiveSlot('Caption')}</caption>`;
    }
    renderHeaderCell(cell, index) {
        const key = (cell.getAttribute('key') || String(index)).trim();
        const sortable = cell.hasAttribute('sortable');
        const isSorted = this.sortKey === key;
        const ariaSort = sortable ? (isSorted ? (this.sortDirection === 'asc' ? 'ascending' : 'descending') : 'none') : undefined;
        const buttonClasses = [
            'flex items-center gap-2 w-full text-left',
            'ml-text',
            sortable ? 'cursor-pointer select-none' : 'cursor-default',
        ].filter(Boolean).join(' ');
        const iconClasses = [
            'text-xs',
            isSorted ? 'ml-primary-text' : 'ml-text-faint',
        ].filter(Boolean).join(' ');
        const icon = isSorted ? (this.sortDirection === 'asc' ? '▲' : '▼') : '↕';
        return html `
 <th
 role="columnheader"
 aria-sort="${ariaSort || 'none'}"
 class="px-3 py-2 text-sm font-semibold border-b ml-border"
 >
 <button
 class="${buttonClasses}"
 @click=${() => this.handleSort(key, sortable)}
 @keydown=${(e) => this.handleSortKeydown(e, key, sortable)}
 ?disabled=${this.disabled || !sortable}
 >
 <span>${this.renderLiveSlotFrom(cell)}</span>
 ${sortable ? html `<span class="${iconClasses}">${icon}</span>` : html ``}
 </button>
 </th>
 `;
    }
    renderBodyRow(row, index, selection) {
        const cells = Array.from(row.querySelectorAll('TableCell'));
        const isSelected = selection.has(index);
        const rowClasses = [
            'border-b ml-border',
            'ml-text',
            isSelected ? 'ml-primary-dim-bg' : 'ml-surface-bg',
            !this.disabled ? 'hover:ml-surface-dim-bg' : '',
            '',
        ].filter(Boolean).join(' ');
        return html `
 <tr
 role="row"
 class="${rowClasses}"
 data-row-index="${index}"
 tabindex="0"
 @click=${(e) => this.handleRowClick(index, e)}
 @keydown=${(e) => this.handleRowKeydown(e, index)}
 >
 ${this.selectable ? html `
 <td role="cell" class="px-3 py-2">
 <input
 type="checkbox"
 class="h-4 w-4 rounded ml-border ml-primary-text"
 aria-label="${this.msg.selectRow} ${index + 1}"
 .checked=${isSelected}
 @change=${(e) => { e.stopPropagation(); this.handleRowSelection(index); }}
 ?disabled=${this.disabled}
 
 @input="${(e) => e.stopPropagation()}"
/>
 </td>
 ` : html ``}
 ${cells.map(cell => html `
 <td role="cell" class="${cn('px-3 py-2 text-sm', cell.getAttribute('data-class') || '')}">
 ${this.renderLiveSlotFrom(cell)}
 </td>
 `)}
 </tr>
 `;
    }
    renderFooter(colCount) {
        if (!this.hasSlot('TableFooter'))
            return html ``;
        const rows = this.getFooterRows();
        return html `
 <tfoot role="rowgroup" class="${cn('ml-surface-dim-bg', this.getSlotClass('TableFooter'))}">
 ${rows.map(row => {
            const cells = Array.from(row.querySelectorAll('TableCell'));
            return html `
 <tr role="row" class="border-t ml-border">
 ${this.selectable ? html `<td role="cell" class="px-3 py-2"></td>` : html ``}
 ${cells.map(cell => html `
 <td role="cell" class="px-3 py-2 text-sm ml-text">
 ${this.renderLiveSlotFrom(cell)}
 </td>
 `)}
 </tr>
 `;
        })}
 </tfoot>
 `;
    }
    renderPagination(totalPages) {
        if (this.pageSize <= 0 || totalPages <= 1)
            return html ``;
        const pages = Array.from({ length: totalPages }, (_, i) => i + 1);
        const navClasses = [
            'mt-3 flex items-center gap-2',
            'text-sm ml-text-muted',
        ].join(' ');
        const buttonBase = [
            'px-2 py-1 rounded-md border transition',
            'ml-border',
            'ml-surface-bg',
            'ml-text',
            !this.disabled ? 'hover:ml-surface-dim-bg' : 'ml-disabled',
        ].join(' ');
        const currentClasses = [
            'px-2 py-1 rounded-md border',
            'ml-border-focus',
            'ml-primary-dim-bg',
            'ml-primary-text',
        ].join(' ');
        return html `
 <nav class="${navClasses}" role="navigation" aria-label="Table pagination">
 <button
 class="${buttonBase}"
 @click=${() => this.handlePageChange(Math.max(1, this.page - 1))}
 ?disabled=${this.disabled || this.page <= 1}
 >
 ${this.msg.prev}
 </button>
 ${pages.map(p => html `
 <button
 class="${p === this.page ? currentClasses : buttonBase}"
 aria-current=${p === this.page ? 'page' : 'false'}
 @click=${() => this.handlePageChange(p)}
 ?disabled=${this.disabled}
 >
 ${this.msg.page} ${p}
 </button>
 `)}
 <button
 class="${buttonBase}"
 @click=${() => this.handlePageChange(Math.min(totalPages, this.page + 1))}
 ?disabled=${this.disabled || this.page >= totalPages}
 >
 ${this.msg.next}
 </button>
 </nav>
 `;
    }
    renderError() {
        if (!this.error)
            return html ``;
        return html `<p class="mt-2 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
    }
    renderLoading(columnCount) {
        if (this.hasSlot('Loading')) {
            return html `<div class="w-full text-sm ml-text-muted">${this.renderLiveSlot('Loading')}</div>`;
        }
        const cols = Math.max(columnCount + (this.selectable ? 1 : 0), 3);
        const rows = 3;
        return html `
 <div class="w-full">
 <div class="mb-2 text-sm ml-text-muted">${this.msg.loading}</div>
 <table class="min-w-full border ml-border">
 <tbody>
 ${Array.from({ length: rows }).map(() => html `
 <tr class="animate-pulse border-b ml-border">
 ${Array.from({ length: cols }).map(() => html `
 <td class="px-3 py-3">
 <div class="h-3 rounded ml-surface-dim-bg"></div>
 </td>
 `)}
 </tr>
 `)}
 </tbody>
 </table>
 </div>
 `;
    }
    renderEmpty(headerCells) {
        // Slot vivo quando o consumidor deu um Empty; texto padrão da molécula quando não deu.
        const content = this.hasSlot('Empty') ? this.renderLiveSlot('Empty') : html `${this.msg.empty}`;
        // mesma divisão do estado preenchido: sem isso a moldura pularia ao trocar de estado
        return html `
 <div class="${cn('w-full', this.fitHeightClasses, this.cssClass)}">
 <div class="${this.scrollerClasses}">
 <table class="min-w-full border ml-border">
 ${headerCells.length > 0 ? html `
 <thead class="${this.theadClasses}">
 <tr>
 ${this.selectable ? html `<th class="px-3 py-2"></th>` : html ``}
 ${headerCells.map((cell, index) => this.renderHeaderCell(cell, index))}
 </tr>
 </thead>
 ` : html ``}
 <tbody></tbody>
 </table>
 <div class="py-4 text-sm ml-text-muted">${content}</div>
 </div>
 ${this.renderPagination(this.getTotalPages(0))}
 ${this.renderError()}
 </div>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const headerCells = this.getHeaderCells();
        const bodyRows = this.getBodyRows();
        if (this.loading) {
            return html `<div class="${cn('w-full', this.fitHeightClasses, this.cssClass)}">${this.renderLoading(headerCells.length)}</div>`;
        }
        if (bodyRows.length === 0) {
            return this.renderEmpty(headerCells);
        }
        // External pagination: totalItems > bodyRows.length means the parent already
        // sliced the dataset — render all received rows as-is.
        // Internal pagination: all rows are in the DOM — slice to the current page.
        const isExternalPagination = this.totalItems > bodyRows.length;
        // Em modo EXTERNO a molécula NÃO reordena. Ela só recebeu a página corrente, então ordenar
        // aqui ordenaria 10 linhas de 60 — e, pior, leria um passo atrasado: o clique no cabeçalho
        // agenda o render DELA antes de emitir `sort`, então ela lê o texto anterior e o consumidor
        // atualiza os nós projetados logo depois, deixando a ordem de uma coisa com o conteúdo de
        // outra. Medido na P4b em 2026-08-04. O evento `sort` continua saindo.
        const sortedRows = isExternalPagination ? bodyRows : this.getSortedRows(bodyRows, headerCells);
        const visibleRows = (this.pageSize > 0 && !isExternalPagination)
            ? sortedRows.slice((this.page - 1) * this.pageSize, this.page * this.pageSize)
            : sortedRows;
        const selection = this.getSelectionSet();
        const totalPages = this.getTotalPages(this.totalItems > 0 ? this.totalItems : bodyRows.length);
        const containerClasses = [
            'w-full',
            this.fitHeightClasses,
            this.disabled ? 'opacity-50 pointer-events-none' : '',
        ].filter(Boolean).join(' ');
        return html `
 <div class="${cn(containerClasses, this.cssClass)}">
 <div class="${this.scrollerClasses}">
 <table class="min-w-full border ml-border ml-surface-bg" role="table">
 ${this.renderCaption()}
 <thead class="${this.theadClasses}" role="rowgroup">
 <tr role="row">
 ${this.selectable ? html `
 <th role="columnheader" class="px-3 py-2 border-b ml-border">
 <input
 type="checkbox"
 data-select-all="true"
 class="h-4 w-4 rounded ml-border ml-primary-text"
 aria-label="${this.msg.selectAll}"
 @change=${(e) => { e.stopPropagation(); this.handleSelectAll(sortedRows.length); }}
 ?disabled=${this.disabled}
 
 @input="${(e) => e.stopPropagation()}"
/>
 </th>
 ` : html ``}
 ${headerCells.map((cell, index) => this.renderHeaderCell(cell, index))}
 </tr>
 </thead>
 <tbody role="rowgroup">
 ${visibleRows.map((row, index) => this.renderBodyRow(row, index, selection))}
 </tbody>
 ${this.renderFooter(headerCells.length)}
 </table>
 </div>
 ${this.renderPagination(totalPages)}
 ${this.renderError()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableMinimalMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDataTableMinimalMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlDataTableMinimalMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], MlDataTableMinimalMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], MlDataTableMinimalMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDataTableMinimalMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDataTableMinimalMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableMinimalMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableMinimalMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'fit-height' })
], MlDataTableMinimalMolecule.prototype, "fitHeight", void 0);
__decorate([
    state()
], MlDataTableMinimalMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlDataTableMinimalMolecule.prototype, "sortDirection", void 0);
MlDataTableMinimalMolecule = __decorate([
    customElement('groupviewtable--ml-data-table-minimal')
], MlDataTableMinimalMolecule);
export { MlDataTableMinimalMolecule };
