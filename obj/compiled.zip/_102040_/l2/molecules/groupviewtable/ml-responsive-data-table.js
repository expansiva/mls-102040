var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-responsive-data-table.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No records found',
    selectAll: 'Select all rows',
    selectRow: 'Select row',
    previousPage: 'Previous page',
    nextPage: 'Next page',
    pagination: 'Table pagination',
    pageOf: 'Page',
    of: 'of',
    sortAsc: 'sorted ascending',
    sortDesc: 'sorted descending',
    sortable: 'sortable',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhum registro encontrado',
        selectAll: 'Selecionar todas as linhas',
        selectRow: 'Selecionar linha',
        previousPage: 'Página anterior',
        nextPage: 'Próxima página',
        pagination: 'Paginação da tabela',
        pageOf: 'Página',
        of: 'de',
        sortAsc: 'ordenado ascendente',
        sortDesc: 'ordenado descendente',
        sortable: 'ordenável',
    },
};
let MlResponsiveDataTableMolecule = class MlResponsiveDataTableMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-responsive-data-table {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-responsive-data-table .ml-table-root {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-0, none);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-data-table .ml-table {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-data-table .ml-table-header,
groupviewtable--ml-responsive-data-table .ml-table-body,
groupviewtable--ml-responsive-data-table .ml-table-footer {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-data-table .ml-table-header-row {
  background: var(--ml-surface-dim, #f5f5f5);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-data-table .ml-table-head {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  font-weight: var(--ml-font-weight-medium, 500);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-data-table .ml-table-head-sortable {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-responsive-data-table .ml-table-head-sortable:hover {
  background: var(--ml-surface-variant, #f0f0f0);
}
groupviewtable--ml-responsive-data-table .ml-table-head-sortable:focus-within {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: -2px;
}
groupviewtable--ml-responsive-data-table .ml-table-head-sorted {
  color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-responsive-data-table .ml-table-head-label,
groupviewtable--ml-responsive-data-table .ml-table-head-content {
  color: inherit;
}
groupviewtable--ml-responsive-data-table .ml-table-sort-btn {
  color: inherit;
  font-weight: inherit;
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-data-table .ml-table-sort-btn:hover {
  color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-responsive-data-table .ml-table-sort-btn:focus-visible,
groupviewtable--ml-responsive-data-table .ml-table-page-btn:focus-visible,
groupviewtable--ml-responsive-data-table .ml-table-checkbox:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: 2px;
}
groupviewtable--ml-responsive-data-table .ml-table-sort-icon {
  color: var(--ml-primary, #3b82f6);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-responsive-data-table .ml-table-cell,
groupviewtable--ml-responsive-data-table .ml-table-cell-select,
groupviewtable--ml-responsive-data-table .ml-table-select-col {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-data-table .ml-table-cell {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-responsive-data-table .ml-table-row {
  background: var(--ml-surface, #ffffff);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-data-table .ml-table-row:not(.ml-table-row-selected):hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-responsive-data-table .ml-table-row:focus-visible,
groupviewtable--ml-responsive-data-table .ml-table-row-focused {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-outline-focus, #3b82f6);
  outline-offset: -2px;
}
groupviewtable--ml-responsive-data-table .ml-table-row-selected,
groupviewtable--ml-responsive-data-table .ml-table-row-selected .ml-table-cell,
groupviewtable--ml-responsive-data-table .ml-table-row-selected .ml-table-cell-select {
  color: var(--ml-on-primary-container, #1c1b1f);
  background: var(--ml-primary-container, #e8f0fe);
}
groupviewtable--ml-responsive-data-table .ml-table-row-selected:hover,
groupviewtable--ml-responsive-data-table .ml-table-row-selected:hover .ml-table-cell,
groupviewtable--ml-responsive-data-table .ml-table-row-selected:hover .ml-table-cell-select {
  background: var(--ml-primary-container, #e8f0fe);
}
groupviewtable--ml-responsive-data-table .ml-table-checkbox {
  accent-color: var(--ml-primary, #3b82f6);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-data-table .ml-table-footer-row {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-responsive-data-table .ml-table-footer-cell {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-data-table .ml-table-caption {
  color: var(--ml-on-surface-muted, #49454f);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-responsive-data-table .ml-table-scroll {
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-responsive-data-table .ml-table-pagination {
  color: var(--ml-on-surface-muted, #49454f);
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-data-table .ml-table-pagination-status {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-responsive-data-table .ml-table-page-btn {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-data-table .ml-table-page-btn:hover:not(:disabled) {
  color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-responsive-data-table .ml-table-page-btn-active {
  color: var(--ml-on-primary, #ffffff);
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-responsive-data-table .ml-table-page-btn-active:hover:not(:disabled) {
  color: var(--ml-on-primary, #ffffff);
  background: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-responsive-data-table .ml-table-empty-state,
groupviewtable--ml-responsive-data-table .ml-table-loading-state {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-responsive-data-table .ml-table-empty-message,
groupviewtable--ml-responsive-data-table .ml-table-empty-slot {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-responsive-data-table .ml-table-loading-slot {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-responsive-data-table .ml-skeleton {
  background: var(--ml-surface-variant, #f0f0f0);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-data-table .ml-table-error,
groupviewtable--ml-responsive-data-table .ml-table-error-message {
  color: var(--ml-error, #ef4444);
}
groupviewtable--ml-responsive-data-table .ml-table-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewtable--ml-responsive-data-table .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupviewtable--ml-responsive-data-table .ml-table-editing {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: inset 0 0 0 var(--ml-border-width, 1px) var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-responsive-data-table .ml-disabled,
groupviewtable--ml-responsive-data-table .ml-table-root.ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupviewtable--ml-responsive-data-table .ml-table-loading {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-responsive-data-table .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-responsive-data-table .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-responsive-data-table .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [
            'Caption',
            'TableHeader',
            'TableBody',
            'TableRow',
            'TableHead',
            'TableCell',
            'TableFooter',
            'Empty',
            'Loading',
        ];
        /** Transforming table: project cell/header content as live DOM nodes. */
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
        this.focusedRowIndex = -1;
        this.hiddenColumnCount = 0;
        this._resizeObserver = null;
        this._tableWrapEl = null;
        this._lastEditing = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this._setupResizeObserver();
        this._propagateEditing();
    }
    updated(changedProps) {
        if (changedProps.has('isEditing')) {
            this._propagateEditing();
        }
        // Re-measure after render when columns/rows may have changed
        this._scheduleColumnMeasure();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this._teardownResizeObserver();
    }
    // ===========================================================================
    // STATE CHANGE HANDLER — propagate isEditing only
    // ===========================================================================
    handleIcaStateChange(key, _value) {
        const isEditingAttr = this.getAttribute('is-editing');
        if (isEditingAttr === `{{${key}}}`) {
            this._propagateEditing();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // RESIZE / RESPONSIVE COLUMNS
    // ===========================================================================
    _setupResizeObserver() {
        if (typeof ResizeObserver === 'undefined')
            return;
        this._resizeObserver = new ResizeObserver(() => {
            this._measureHiddenColumns();
        });
        // Observe host; wrap may appear later
        this._resizeObserver.observe(this);
    }
    _teardownResizeObserver() {
        if (this._resizeObserver) {
            this._resizeObserver.disconnect();
            this._resizeObserver = null;
        }
        this._tableWrapEl = null;
    }
    _scheduleColumnMeasure() {
        requestAnimationFrame(() => this._measureHiddenColumns());
    }
    /**
     * Progressively hide columns from right to left as width shrinks.
     * Never hide the first three columns; enable horizontal scroll instead.
     */
    _measureHiddenColumns() {
        const wrap = this.querySelector('.ml-table-scroll');
        const table = this.querySelector('.ml-table');
        if (!wrap || !table)
            return;
        this._tableWrapEl = wrap;
        const columns = this._parseColumns();
        const colCount = columns.length;
        if (colCount <= 3) {
            if (this.hiddenColumnCount !== 0)
                this.hiddenColumnCount = 0;
            return;
        }
        // Temporarily show all columns to measure natural widths
        const cells = table.querySelectorAll('[data-col-index]');
        cells.forEach((el) => {
            el.style.display = '';
        });
        const headerCells = table.querySelectorAll('thead th[data-col-index]');
        if (headerCells.length === 0)
            return;
        const available = wrap.clientWidth;
        // Selection column width if present
        const selectCol = table.querySelector('th.ml-table-select-col');
        const selectWidth = selectCol ? selectCol.offsetWidth : 0;
        let used = selectWidth;
        let fitCount = 0;
        for (let i = 0; i < headerCells.length; i++) {
            const w = headerCells[i].offsetWidth || 80;
            if (used + w <= available || fitCount < 3) {
                used += w;
                fitCount++;
            }
            else {
                break;
            }
        }
        // Keep at least 3 columns visible
        fitCount = Math.max(3, Math.min(fitCount, colCount));
        const hide = Math.max(0, colCount - fitCount);
        if (hide !== this.hiddenColumnCount) {
            this.hiddenColumnCount = hide;
        }
        else {
            // Re-apply display without state churn
            this._applyColumnVisibility(table, colCount, hide);
        }
    }
    _applyColumnVisibility(table, colCount, hide) {
        const cutoff = colCount - hide; // columns with index >= cutoff are hidden
        const cells = table.querySelectorAll('[data-col-index]');
        cells.forEach((el) => {
            const idx = Number(el.dataset.colIndex);
            if (Number.isFinite(idx) && idx >= cutoff && hide > 0) {
                el.style.display = 'none';
            }
            else {
                el.style.display = '';
            }
        });
    }
    _isColumnHidden(colIndex, colCount) {
        if (this.hiddenColumnCount <= 0)
            return false;
        const cutoff = colCount - this.hiddenColumnCount;
        return colIndex >= cutoff;
    }
    // ===========================================================================
    // PARSING — live slot structure
    // ===========================================================================
    _parseColumns() {
        const header = this.getLiveSlot('TableHeader') || this.getSlot('TableHeader');
        if (!header)
            return [];
        const headerRow = Array.from(header.children).find((c) => c.tagName === 'TABLEROW') ||
            header.querySelector('TableRow');
        if (!headerRow)
            return [];
        const heads = Array.from(headerRow.children).filter((c) => c.tagName === 'TABLEHEAD');
        return heads.map((head, index) => ({
            key: head.getAttribute('key') || `col-${index}`,
            label: (head.textContent || '').trim(),
            sortable: head.hasAttribute('sortable'),
            headEl: head,
            index,
        }));
    }
    _parseRows() {
        const body = this.getLiveSlot('TableBody') || this.getSlot('TableBody');
        if (!body)
            return [];
        const rows = Array.from(body.children).filter((c) => c.tagName === 'TABLEROW');
        return rows.map((row, index) => {
            const cells = Array.from(row.children).filter((c) => c.tagName === 'TABLECELL');
            return { index, cells, rowEl: row };
        });
    }
    _parseFooterRows() {
        const footer = this.getLiveSlot('TableFooter') || this.getSlot('TableFooter');
        if (!footer)
            return [];
        const rows = Array.from(footer.children).filter((c) => c.tagName === 'TABLEROW');
        return rows.map((row, index) => {
            const cells = Array.from(row.children).filter((c) => c.tagName === 'TABLECELL');
            return { index, cells, rowEl: row };
        });
    }
    _getCellText(cell) {
        if (!cell)
            return '';
        // Prefer live projected text (source may be emptied after projection)
        const live = this.getLiveText(cell);
        if (live)
            return live;
        return (cell.textContent || '').trim();
    }
    // ===========================================================================
    // SELECTION HELPERS
    // ===========================================================================
    _getSelectedIndices() {
        const raw = String(this.value ?? '').trim();
        if (!raw)
            return new Set();
        return new Set(raw
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => !Number.isNaN(n)));
    }
    _setSelectedIndices(indices) {
        const sorted = Array.from(indices).sort((a, b) => a - b);
        const next = sorted.join(',');
        this.value = next;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: next },
        }));
    }
    _isRowSelected(index) {
        return this._getSelectedIndices().has(index);
    }
    _allRowsSelected(rowCount) {
        if (rowCount === 0)
            return false;
        const selected = this._getSelectedIndices();
        for (let i = 0; i < rowCount; i++) {
            if (!selected.has(i))
                return false;
        }
        return true;
    }
    _someRowsSelected(rowCount) {
        if (rowCount === 0)
            return false;
        const selected = this._getSelectedIndices();
        let count = 0;
        for (let i = 0; i < rowCount; i++) {
            if (selected.has(i))
                count++;
        }
        return count > 0 && count < rowCount;
    }
    // ===========================================================================
    // SORTING
    // ===========================================================================
    _sortedRows(rows, columns) {
        if (!this.sortKey)
            return rows;
        const colIndex = columns.findIndex((c) => c.key === this.sortKey);
        if (colIndex < 0)
            return rows;
        const dir = this.sortDirection === 'asc' ? 1 : -1;
        const decorated = rows.map((row, i) => ({
            row,
            i,
            text: this._getCellText(row.cells[colIndex]).toLowerCase(),
        }));
        decorated.sort((a, b) => {
            if (a.text < b.text)
                return -1 * dir;
            if (a.text > b.text)
                return 1 * dir;
            return a.i - b.i;
        });
        return decorated.map((d) => d.row);
    }
    _handleSort(column) {
        if (this.disabled || this.loading)
            return;
        if (!column.sortable)
            return;
        if (this.sortKey === column.key) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortKey = column.key;
            this.sortDirection = 'asc';
        }
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true,
            composed: true,
            detail: { key: this.sortKey, direction: this.sortDirection },
        }));
    }
    // ===========================================================================
    // SELECTION HANDLERS
    // ===========================================================================
    _handleToggleRow(index, e) {
        if (e) {
            e.stopPropagation();
            e.preventDefault();
        }
        if (this.disabled || this.loading || !this.selectable)
            return;
        const selected = this._getSelectedIndices();
        if (selected.has(index)) {
            selected.delete(index);
        }
        else {
            selected.add(index);
        }
        this._setSelectedIndices(selected);
    }
    _handleToggleAll(rowCount, e) {
        if (e) {
            e.stopPropagation();
            e.preventDefault();
        }
        if (this.disabled || this.loading || !this.selectable)
            return;
        if (this._allRowsSelected(rowCount)) {
            this._setSelectedIndices(new Set());
        }
        else {
            const all = new Set();
            for (let i = 0; i < rowCount; i++)
                all.add(i);
            this._setSelectedIndices(all);
        }
    }
    _handleRowClick(index, e) {
        if (this.disabled || this.loading)
            return;
        const target = e.target;
        // Selection-control interaction must not emit rowClick
        if (target?.closest('.ml-table-select-col, .ml-table-checkbox'))
            return;
        this.focusedRowIndex = index;
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true,
            composed: true,
            detail: { index },
        }));
    }
    // ===========================================================================
    // PAGINATION
    // ===========================================================================
    _totalPages() {
        const size = Number(this.pageSize) || 0;
        if (size <= 0)
            return 0;
        const total = Number(this.totalItems) || 0;
        return Math.max(1, Math.ceil(total / size));
    }
    _goToPage(page) {
        if (this.disabled || this.loading)
            return;
        const total = this._totalPages();
        if (total <= 0)
            return;
        const next = Math.min(Math.max(1, page), total);
        if (next === this.page)
            return;
        this.page = next;
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true,
            composed: true,
            detail: { page: next },
        }));
    }
    // ===========================================================================
    // KEYBOARD
    // ===========================================================================
    _handleTableKeydown(e, rowCount, columns) {
        if (this.disabled || this.loading)
            return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (rowCount === 0)
                return;
            this.focusedRowIndex =
                this.focusedRowIndex < 0 ? 0 : Math.min(rowCount - 1, this.focusedRowIndex + 1);
            this._focusRow(this.focusedRowIndex);
        }
        else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (rowCount === 0)
                return;
            this.focusedRowIndex =
                this.focusedRowIndex < 0 ? 0 : Math.max(0, this.focusedRowIndex - 1);
            this._focusRow(this.focusedRowIndex);
        }
        else if (e.key === ' ' || e.key === 'Spacebar') {
            if (this.selectable && this.focusedRowIndex >= 0) {
                e.preventDefault();
                this._handleToggleRow(this.focusedRowIndex);
            }
        }
        else if (e.key === 'Enter') {
            // Sort active sortable header when focus is on a header button — handled there.
            // When focus is on a row, treat as row activation.
            if (this.focusedRowIndex >= 0) {
                e.preventDefault();
                this.dispatchEvent(new CustomEvent('rowClick', {
                    bubbles: true,
                    composed: true,
                    detail: { index: this.focusedRowIndex },
                }));
            }
        }
    }
    _focusRow(index) {
        requestAnimationFrame(() => {
            const row = this.querySelector(`[data-row-index="${index}"]`);
            row?.focus();
        });
    }
    // ===========================================================================
    // isEditing PROPAGATION
    // ===========================================================================
    _propagateEditing() {
        const editing = !!this.isEditing;
        if (this._lastEditing === editing) {
            // Still walk cells on first pass after projection
        }
        this._lastEditing = editing;
        const body = this.getLiveSlot('TableBody');
        const roots = [];
        if (body)
            roots.push(body);
        const footer = this.getLiveSlot('TableFooter');
        if (footer)
            roots.push(footer);
        // Also propagate into already-projected anchors inside the rendered table
        const projected = this.querySelectorAll('.ml-table-cell, .ml-table-footer-cell');
        projected.forEach((cell) => roots.push(cell));
        for (const root of roots) {
            const customs = root.querySelectorAll('*');
            customs.forEach((el) => {
                if (el.tagName.includes('-')) {
                    el.setAttribute('is-editing', editing ? 'true' : 'false');
                }
            });
        }
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    _rootClasses() {
        return cn([
            'flex flex-col w-full gap-3',
            'ml-table-root',
            this.disabled ? 'ml-disabled' : '',
            this.loading ? 'ml-table-loading' : '',
            this.isEditing ? 'ml-table-editing' : '',
            this.error ? 'ml-table-error' : '',
        ]
            .filter(Boolean)
            .join(' '), this.cssClass);
    }
    _headerCellClasses(col) {
        return [
            'px-3 py-2 text-left text-sm font-semibold',
            'ml-table-head',
            col.sortable ? 'ml-table-head-sortable' : '',
            this.sortKey === col.key ? 'ml-table-head-sorted' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    _rowClasses(index, selected) {
        return [
            'ml-table-row',
            selected ? 'ml-table-row-selected' : '',
            this.focusedRowIndex === index ? 'ml-table-row-focused' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    _ariaSort(col) {
        if (!col.sortable)
            return nothing;
        if (this.sortKey !== col.key)
            return 'none';
        return this.sortDirection === 'asc' ? 'ascending' : 'descending';
    }
    _renderSortIndicator(col) {
        if (!col.sortable)
            return nothing;
        if (this.sortKey !== col.key) {
            return html `<span class="ml-table-sort-icon ml-text-faint" aria-hidden="true">⇅</span>`;
        }
        const arrow = this.sortDirection === 'asc' ? '↑' : '↓';
        return html `<span class="ml-table-sort-icon ml-text" aria-hidden="true">${arrow}</span>`;
    }
    _renderCaption() {
        if (!this.hasSlot('Caption') && !this.getLiveSlot('Caption'))
            return html ``;
        const live = this.getLiveSlot('Caption');
        return html `
      <caption class="${cn('caption-bottom text-sm mt-2 ml-text-muted ml-table-caption', this.getSlotClass('Caption'))}">
        ${live ? this.renderLiveSlotFrom(live) : unsafeHTML(this.getSlotContent('Caption'))}
      </caption>
    `;
    }
    _renderSelectAllHeader(rowCount) {
        if (!this.selectable)
            return html ``;
        const all = this._allRowsSelected(rowCount);
        const some = this._someRowsSelected(rowCount);
        return html `
      <th
        class="w-10 px-2 py-2 ml-table-select-col ml-table-head"
        scope="col"
        role="columnheader"
      >
        <input
          type="checkbox"
          class="ml-table-checkbox"
          .checked=${all}
          .indeterminate=${some}
          aria-label=${this.msg.selectAll}
          ?disabled=${this.disabled || this.loading}
          @click=${(e) => this._handleToggleAll(rowCount, e)}
          @change=${(e) => e.stopPropagation()}
          @input=${(e) => e.stopPropagation()}
        />
      </th>
    `;
    }
    _renderSelectCell(rowIndex) {
        if (!this.selectable)
            return html ``;
        const selected = this._isRowSelected(rowIndex);
        return html `
      <td class="w-10 px-2 py-2 ml-table-select-col ml-table-cell-select" role="cell">
        <input
          type="checkbox"
          class="ml-table-checkbox"
          .checked=${selected}
          aria-label=${`${this.msg.selectRow} ${rowIndex + 1}`}
          ?disabled=${this.disabled || this.loading}
          @click=${(e) => this._handleToggleRow(rowIndex, e)}
          @change=${(e) => e.stopPropagation()}
          @input=${(e) => e.stopPropagation()}
        />
      </td>
    `;
    }
    _renderHeader(columns, rowCount) {
        return html `
      <thead class="ml-table-header" role="rowgroup">
        <tr class="ml-table-header-row" role="row">
          ${this._renderSelectAllHeader(rowCount)}
          ${columns.map((col) => {
            const hidden = this._isColumnHidden(col.index, columns.length);
            const headContent = col.headEl
                ? this.renderLiveSlotFrom(col.headEl, 'ml-table-head-content')
                : html `${col.label}`;
            if (col.sortable) {
                return html `
                <th
                  class="${this._headerCellClasses(col)}"
                  scope="col"
                  role="columnheader"
                  data-col-index=${col.index}
                  data-col-key=${col.key}
                  aria-sort=${this._ariaSort(col)}
                  style=${hidden ? 'display:none' : nothing}
                >
                  <button
                    type="button"
                    class="inline-flex items-center gap-1 w-full text-left ml-table-sort-btn"
                    ?disabled=${this.disabled || this.loading}
                    @click=${() => this._handleSort(col)}
                    @keydown=${(e) => {
                    if (e.key === 'Enter') {
                        e.preventDefault();
                        this._handleSort(col);
                    }
                }}
                  >
                    <span class="ml-table-head-label">${headContent}</span>
                    ${this._renderSortIndicator(col)}
                    <span class="sr-only">
                      ${this.sortKey === col.key
                    ? this.sortDirection === 'asc'
                        ? this.msg.sortAsc
                        : this.msg.sortDesc
                    : this.msg.sortable}
                    </span>
                  </button>
                </th>
              `;
            }
            return html `
              <th
                class="${this._headerCellClasses(col)}"
                scope="col"
                role="columnheader"
                data-col-index=${col.index}
                data-col-key=${col.key}
                style=${hidden ? 'display:none' : nothing}
              >
                <span class="ml-table-head-label">${headContent}</span>
              </th>
            `;
        })}
        </tr>
      </thead>
    `;
    }
    _renderBody(rows, columns) {
        if (rows.length === 0)
            return html ``;
        return html `
      <tbody class="ml-table-body" role="rowgroup">
        ${rows.map((row, visualIndex) => {
            const selected = this._isRowSelected(row.index);
            return html `
            <tr
              class="${this._rowClasses(row.index, selected)}"
              role="row"
              data-row-index=${row.index}
              tabindex=${this.disabled ? nothing : 0}
              aria-selected=${this.selectable ? (selected ? 'true' : 'false') : nothing}
              @click=${(e) => this._handleRowClick(row.index, e)}
              @keydown=${(e) => this._handleTableKeydown(e, rows.length, columns)}
            >
              ${this._renderSelectCell(row.index)}
              ${columns.map((col) => {
                const cell = row.cells[col.index];
                const hidden = this._isColumnHidden(col.index, columns.length);
                return html `
                  <td
                    class="px-3 py-2 text-sm ml-table-cell ml-text"
                    role="cell"
                    data-col-index=${col.index}
                    style=${hidden ? 'display:none' : nothing}
                  >
                    ${cell ? this.renderLiveSlotFrom(cell) : nothing}
                  </td>
                `;
            })}
            </tr>
          `;
        })}
      </tbody>
    `;
    }
    _renderFooter(columns) {
        const footerRows = this._parseFooterRows();
        if (footerRows.length === 0)
            return html ``;
        return html `
      <tfoot class="ml-table-footer" role="rowgroup">
        ${footerRows.map((row) => html `
            <tr class="ml-table-footer-row" role="row">
              ${this.selectable
            ? html `<td class="ml-table-select-col ml-table-footer-cell" role="cell"></td>`
            : nothing}
              ${columns.map((col) => {
            const cell = row.cells[col.index];
            const hidden = this._isColumnHidden(col.index, columns.length);
            return html `
                  <td
                    class="px-3 py-2 text-sm font-semibold ml-table-footer-cell ml-text"
                    role="cell"
                    data-col-index=${col.index}
                    style=${hidden ? 'display:none' : nothing}
                  >
                    ${cell ? this.renderLiveSlotFrom(cell) : nothing}
                  </td>
                `;
        })}
            </tr>
          `)}
      </tfoot>
    `;
    }
    _renderLoading() {
        const hasLoading = !!(this.getLiveSlot('Loading') || this.hasSlot('Loading'));
        return html `
      <div class="flex flex-col items-center justify-center gap-3 p-8 w-full ml-table-loading-state" role="status" aria-live="polite">
        ${hasLoading
            ? html `
              <div class="${cn('w-full ml-table-loading-slot', this.getSlotClass('Loading'))}">
                ${this.getLiveSlot('Loading')
                ? this.renderLiveSlotFrom(this.getLiveSlot('Loading'))
                : unsafeHTML(this.getSlotContent('Loading'))}
              </div>
            `
            : html `
              <div class="flex flex-col gap-2 w-full" aria-label=${this.msg.loading}>
                <div class="h-10 w-full rounded ml-skeleton"></div>
                <div class="h-10 w-full rounded ml-skeleton"></div>
                <div class="h-10 w-full rounded ml-skeleton"></div>
                <span class="sr-only">${this.msg.loading}</span>
              </div>
            `}
      </div>
    `;
    }
    _renderEmpty() {
        const hasEmpty = !!(this.getLiveSlot('Empty') || this.hasSlot('Empty'));
        return html `
      <div class="flex flex-col items-center justify-center gap-2 p-8 w-full ml-table-empty-state" role="status" aria-live="polite">
        ${hasEmpty
            ? html `
              <div class="${cn('w-full text-sm ml-text-muted ml-table-empty-slot', this.getSlotClass('Empty'))}">
                ${this.getLiveSlot('Empty')
                ? this.renderLiveSlotFrom(this.getLiveSlot('Empty'))
                : unsafeHTML(this.getSlotContent('Empty'))}
              </div>
            `
            : html `
              <p class="text-sm ml-text-muted ml-table-empty-message">${this.msg.empty}</p>
            `}
      </div>
    `;
    }
    _renderError() {
        const err = String(this.error ?? '').trim();
        if (!err)
            return html ``;
        return html `
      <div class="mt-2 text-sm ml-error-text ml-table-error-message" role="alert" aria-live="assertive">
        ${unsafeHTML(err)}
      </div>
    `;
    }
    _pageNumbers(total, current) {
        if (total <= 7) {
            return Array.from({ length: total }, (_, i) => i + 1);
        }
        const pages = new Set();
        pages.add(1);
        pages.add(total);
        for (let p = current - 1; p <= current + 1; p++) {
            if (p >= 1 && p <= total)
                pages.add(p);
        }
        return Array.from(pages).sort((a, b) => a - b);
    }
    _renderPagination() {
        const size = Number(this.pageSize) || 0;
        if (size <= 0)
            return html ``;
        const total = this._totalPages();
        if (total <= 0)
            return html ``;
        const current = Math.min(Math.max(1, Number(this.page) || 1), total);
        const pages = this._pageNumbers(total, current);
        return html `
      <nav
        class="flex flex-wrap items-center justify-between gap-2 pt-2 ml-table-pagination"
        role="navigation"
        aria-label=${this.msg.pagination}
      >
        <span class="text-xs ml-text-muted ml-table-pagination-status">
          ${this.msg.pageOf} ${current} ${this.msg.of} ${total}
        </span>
        <div class="inline-flex items-center gap-1">
          <button
            type="button"
            class="px-2 py-1 text-sm rounded ml-table-page-btn"
            aria-label=${this.msg.previousPage}
            ?disabled=${this.disabled || this.loading || current <= 1}
            @click=${() => this._goToPage(current - 1)}
          >
            ‹
          </button>
          ${pages.map((p, i) => {
            const prev = pages[i - 1];
            const gap = prev !== undefined && p - prev > 1;
            return html `
              ${gap
                ? html `<span class="px-1 text-sm ml-text-faint" aria-hidden="true">…</span>`
                : nothing}
              <button
                type="button"
                class="${[
                'min-w-[2rem] px-2 py-1 text-sm rounded ml-table-page-btn',
                p === current ? 'ml-table-page-btn-active' : '',
            ]
                .filter(Boolean)
                .join(' ')}"
                aria-label=${`${this.msg.pageOf} ${p}`}
                aria-current=${p === current ? 'page' : nothing}
                ?disabled=${this.disabled || this.loading}
                @click=${() => this._goToPage(p)}
              >
                ${p}
              </button>
            `;
        })}
          <button
            type="button"
            class="px-2 py-1 text-sm rounded ml-table-page-btn"
            aria-label=${this.msg.nextPage}
            ?disabled=${this.disabled || this.loading || current >= total}
            @click=${() => this._goToPage(current + 1)}
          >
            ›
          </button>
        </div>
      </nav>
    `;
    }
    _renderTable() {
        const columns = this._parseColumns();
        const rawRows = this._parseRows();
        const rows = this._sortedRows(rawRows, columns);
        const isEmpty = rawRows.length === 0;
        if (isEmpty) {
            return this._renderEmpty();
        }
        // Apply column visibility after paint via measure; also stamp current hide state
        const colCount = columns.length;
        return html `
      <div class="w-full overflow-x-auto ml-table-scroll">
        <table
          class="w-full border-collapse text-sm ml-table"
          role="table"
          aria-busy=${this.loading ? 'true' : 'false'}
          aria-disabled=${this.disabled ? 'true' : nothing}
        >
          ${this._renderCaption()}
          ${this._renderHeader(columns, rows.length)}
          ${this._renderBody(rows, columns)}
          ${this._renderFooter(columns)}
        </table>
      </div>
      <!-- stamp for measure helper -->
      <span hidden data-col-count=${colCount} data-hidden-cols=${this.hiddenColumnCount}></span>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages.en;
        return html `
      <div class="${this._rootClasses()}">
        ${this.loading ? this._renderLoading() : this._renderTable()}
        ${this._renderPagination()}
        ${this._renderError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlResponsiveDataTableMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlResponsiveDataTableMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlResponsiveDataTableMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], MlResponsiveDataTableMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], MlResponsiveDataTableMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlResponsiveDataTableMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlResponsiveDataTableMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlResponsiveDataTableMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlResponsiveDataTableMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlResponsiveDataTableMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlResponsiveDataTableMolecule.prototype, "sortDirection", void 0);
__decorate([
    state()
], MlResponsiveDataTableMolecule.prototype, "focusedRowIndex", void 0);
__decorate([
    state()
], MlResponsiveDataTableMolecule.prototype, "hiddenColumnCount", void 0);
MlResponsiveDataTableMolecule = __decorate([
    customElement('groupviewtable--ml-responsive-data-table')
], MlResponsiveDataTableMolecule);
export { MlResponsiveDataTableMolecule };
