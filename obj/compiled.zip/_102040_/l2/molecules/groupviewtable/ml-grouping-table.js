/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-grouping-table.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GROUPING TABLE MOLECULE
// =============================================================================
// Skill Group: groupViewTable
// A table that groups rows by a user-selected groupable column with collapsible
// group headers. Presentation-only — no business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    groupBy: 'Group by',
    noGrouping: 'None',
    empty: 'No data available',
    loading: 'Loading...',
    selectAll: 'Select all rows',
    selectRow: 'Select row',
    expandGroup: 'Expand group',
    collapseGroup: 'Collapse group',
    previousPage: 'Previous page',
    nextPage: 'Next page',
    page: 'Page',
    of: 'of',
    rows: 'rows',
    sortAsc: 'sorted ascending',
    sortDesc: 'sorted descending',
    notSorted: 'not sorted',
};
const messages = {
    en: message_en,
    pt: {
        groupBy: 'Agrupar por',
        noGrouping: 'Nenhum',
        empty: 'Nenhum dado disponível',
        loading: 'Carregando...',
        selectAll: 'Selecionar todas as linhas',
        selectRow: 'Selecionar linha',
        expandGroup: 'Expandir grupo',
        collapseGroup: 'Recolher grupo',
        previousPage: 'Página anterior',
        nextPage: 'Próxima página',
        page: 'Página',
        of: 'de',
        rows: 'linhas',
        sortAsc: 'ordenado ascendente',
        sortDesc: 'ordenado descendente',
        notSorted: 'não ordenado',
    },
};
let MlGroupingTableMolecule = class MlGroupingTableMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-grouping-table {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
  display: flex;
  flex-direction: column;
  width: 100%;
}
groupviewtable--ml-grouping-table .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  pointer-events: none;
  user-select: none;
}
groupviewtable--ml-grouping-table .ml-loading {
  opacity: 0.85;
}
groupviewtable--ml-grouping-table .ml-group-control {
  background: var(--ml-surface-dim, #f5f5f5);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px) var(--ml-radius-sm, 6px) 0 0;
}
groupviewtable--ml-grouping-table .ml-label {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
  letter-spacing: 0.01em;
  text-transform: uppercase;
  font-size: 0.7rem;
}
groupviewtable--ml-grouping-table .ml-group-select {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-size: 0.875rem;
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
  outline: none;
  cursor: pointer;
}
groupviewtable--ml-grouping-table .ml-group-select:focus {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewtable--ml-grouping-table .ml-group-select:disabled {
  cursor: not-allowed;
}
groupviewtable--ml-grouping-table .ml-table-wrapper {
  width: 100%;
  overflow-x: auto;
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-top: none;
  border-radius: 0 0 var(--ml-radius-sm, 6px) var(--ml-radius-sm, 6px);
  background: var(--ml-surface, #ffffff);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupviewtable--ml-grouping-table .ml-table {
  width: 100%;
  border-collapse: collapse;
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-grouping-table .ml-caption {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
  background: var(--ml-surface, #ffffff);
  caption-side: top;
}
groupviewtable--ml-grouping-table .ml-table-thead {
  background: var(--ml-surface-dim, #f5f5f5);
  border-bottom: calc(var(--ml-border-width, 1px) * 2) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-grouping-table .ml-table-head {
  color: var(--ml-on-surface-muted, #49454f);
  font-weight: var(--ml-font-weight-medium, 500);
  font-size: 0.8125rem;
  letter-spacing: 0.03em;
  text-transform: uppercase;
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  white-space: nowrap;
  transition: color var(--ml-transition, 200ms ease), background var(--ml-transition, 200ms ease);
}
groupviewtable--ml-grouping-table .ml-table-head[tabindex="0"]:hover {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface-variant, #ede8f5);
}
groupviewtable--ml-grouping-table .ml-table-head:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: -2px;
}
groupviewtable--ml-grouping-table .ml-table-head-sorted {
  color: var(--ml-primary, #3b82f6) !important;
  background: var(--ml-surface-variant, #ede8f5);
}
groupviewtable--ml-grouping-table .ml-sort-indicator {
  opacity: 0.45;
  transition: opacity var(--ml-transition, 200ms ease);
}
groupviewtable--ml-grouping-table .ml-sort-active {
  opacity: 1;
  color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-grouping-table .ml-table-tbody {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-grouping-table .ml-group-header-row {
  background: var(--ml-surface-dim, #f5f5f5);
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-grouping-table .ml-group-header {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
  font-size: 0.875rem;
  transition: background var(--ml-transition, 200ms ease);
}
groupviewtable--ml-grouping-table .ml-group-header.cursor-pointer:hover {
  background: var(--ml-surface-variant, #ede8f5);
}
groupviewtable--ml-grouping-table .ml-group-header:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: -2px;
}
groupviewtable--ml-grouping-table .ml-group-label {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-grouping-table .ml-group-count {
  color: var(--ml-on-surface-muted, #49454f);
  font-size: 0.75rem;
}
groupviewtable--ml-grouping-table .ml-group-chevron {
  color: var(--ml-on-surface-muted, #49454f);
  flex-shrink: 0;
}
groupviewtable--ml-grouping-table .ml-table-row {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  transition: background var(--ml-transition, 200ms ease);
  outline: none;
}
groupviewtable--ml-grouping-table .ml-table-row:last-child {
  border-bottom: none;
}
groupviewtable--ml-grouping-table .ml-table-row:hover:not(.ml-table-row-selected) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-grouping-table .ml-table-row:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: -2px;
}
groupviewtable--ml-grouping-table .ml-table-row-selected {
  background: var(--ml-primary-container, #dbeafe) !important;
}
groupviewtable--ml-grouping-table .ml-table-row-selected:hover {
  background: var(--ml-primary-container, #dbeafe) !important;
  filter: brightness(0.97);
}
groupviewtable--ml-grouping-table .ml-table-cell {
  color: var(--ml-on-surface, #1c1b1f);
  font-size: 0.875rem;
  vertical-align: middle;
}
groupviewtable--ml-grouping-table .ml-table-checkbox-cell {
  width: 2.5rem;
  text-align: center;
  vertical-align: middle;
}
groupviewtable--ml-grouping-table .ml-grouped-cell {
  padding-left: 2rem !important;
}
groupviewtable--ml-grouping-table .ml-checkbox {
  width: 1rem;
  height: 1rem;
  accent-color: var(--ml-primary, #3b82f6);
  cursor: pointer;
  border-radius: var(--ml-radius-sm, 6px);
  transition: box-shadow var(--ml-transition, 200ms ease);
}
groupviewtable--ml-grouping-table .ml-checkbox:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: 2px;
}
groupviewtable--ml-grouping-table .ml-checkbox:disabled {
  cursor: not-allowed;
}
groupviewtable--ml-grouping-table .ml-table-tfoot {
  background: var(--ml-surface-dim, #f5f5f5);
  border-top: calc(var(--ml-border-width, 1px) * 2) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-grouping-table .ml-table-footer-row {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-grouping-table .ml-table-footer-row:last-child {
  border-bottom: none;
}
groupviewtable--ml-grouping-table .ml-table-footer-cell {
  color: var(--ml-on-surface-muted, #49454f);
  font-size: 0.8125rem;
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-grouping-table .ml-table-empty-row {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-grouping-table .ml-table-empty {
  color: var(--ml-on-surface-muted, #49454f);
  font-size: 0.875rem;
}
groupviewtable--ml-grouping-table .ml-loading-slot {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: 0 0 var(--ml-radius-sm, 6px) var(--ml-radius-sm, 6px);
}
groupviewtable--ml-grouping-table .ml-skeleton {
  background: linear-gradient(90deg, var(--ml-surface-dim, #f5f5f5) 25%, var(--ml-surface-variant, #ede8f5) 50%, var(--ml-surface-dim, #f5f5f5) 75%);
  background-size: 200% 100%;
  animation: ml-skeleton-shimmer 1.4s ease-in-out infinite;
  border-radius: var(--ml-radius-sm, 6px);
  display: block;
}
@keyframes ml-skeleton-shimmer {
  0% {
    background-position: 200% 0;
  }
  100% {
    background-position: -200% 0;
  }
}
groupviewtable--ml-grouping-table .ml-pagination {
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: 0 0 var(--ml-radius-sm, 6px) var(--ml-radius-sm, 6px);
}
groupviewtable--ml-grouping-table .ml-pagination-btn {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-size: 0.8125rem;
  cursor: pointer;
  transition: background var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
  line-height: 1;
}
groupviewtable--ml-grouping-table .ml-pagination-btn:hover:not(:disabled):not(.ml-pagination-btn-active) {
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-on-surface-faint, #79747e);
}
groupviewtable--ml-grouping-table .ml-pagination-btn:focus-visible {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewtable--ml-grouping-table .ml-pagination-btn:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
groupviewtable--ml-grouping-table .ml-pagination-btn-active {
  background: var(--ml-primary, #3b82f6) !important;
  color: var(--ml-on-primary, #ffffff) !important;
  border-color: var(--ml-primary, #3b82f6) !important;
  font-weight: var(--ml-font-weight-medium, 500);
  cursor: default;
}
groupviewtable--ml-grouping-table .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-grouping-table .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
}
groupviewtable--ml-grouping-table .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-size: 0.75rem;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [
            'Caption',
            'TableHeader',
            'TableBody',
            'TableRow',
            'TableHead',
            'TableCell',
            'TableFooter',
            'Empty',
            'Loading',
        ];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
        /** Selected grouping column key (empty = no grouping). */
        this.groupKey = '';
        /** Map of group value → expanded flag. Defaults to expanded. */
        this.expandedGroups = {};
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.propagateEditing();
    }
    updated(changedProps) {
        if (changedProps.has('isEditing')) {
            this.propagateEditing();
        }
    }
    handleIcaStateChange(key, _value) {
        const isEditingAttr = this.getAttribute('is-editing');
        if (isEditingAttr === `{{${key}}}`) {
            this.propagateEditing();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // isEditing PROPAGATION
    // ===========================================================================
    propagateEditing() {
        const editing = !!this.isEditing;
        // Propagate to live DOM children inside original slot tags
        const bodies = Array.from(this.querySelectorAll('TableBody'));
        for (const body of bodies) {
            const customEls = body.querySelectorAll('*');
            customEls.forEach((el) => {
                if (el.tagName.includes('-')) {
                    if (editing) {
                        el.setAttribute('is-editing', 'true');
                    }
                    else {
                        el.setAttribute('is-editing', 'false');
                    }
                }
            });
        }
    }
    // ===========================================================================
    // PARSERS — columns & rows from slot tags
    // ===========================================================================
    parseColumns() {
        const header = this.getSlot('TableHeader');
        if (!header)
            return [];
        const headerRow = header.querySelector('TableRow');
        if (!headerRow)
            return [];
        const heads = Array.from(headerRow.querySelectorAll('TableHead'));
        return heads.map((head, index) => ({
            key: head.getAttribute('key') || `col-${index}`,
            label: head.innerHTML || head.textContent || '',
            sortable: head.hasAttribute('sortable'),
            groupable: head.hasAttribute('groupable'),
            index,
            dataClass: head.getAttribute('data-class') || '',
        }));
    }
    parseRows() {
        const body = this.getSlot('TableBody');
        if (!body)
            return [];
        const rows = Array.from(body.querySelectorAll('TableRow'));
        return rows.map((row, index) => {
            const cells = Array.from(row.querySelectorAll('TableCell'));
            return {
                index,
                cells: cells.map((c) => c.innerHTML || ''),
                dataClass: row.getAttribute('data-class') || '',
                element: row,
            };
        });
    }
    parseFooterRows() {
        const footer = this.getSlot('TableFooter');
        if (!footer)
            return [];
        const rows = Array.from(footer.querySelectorAll('TableRow'));
        return rows.map((row, index) => {
            const cells = Array.from(row.querySelectorAll('TableCell'));
            return {
                index,
                cells: cells.map((c) => c.innerHTML || ''),
                dataClass: row.getAttribute('data-class') || '',
                element: row,
            };
        });
    }
    // ===========================================================================
    // SELECTION HELPERS
    // ===========================================================================
    getSelectedIndices() {
        const raw = String(this.value ?? '').trim();
        if (!raw)
            return new Set();
        return new Set(raw
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => !isNaN(n)));
    }
    setSelectedIndices(indices) {
        const sorted = Array.from(indices).sort((a, b) => a - b);
        this.value = sorted.join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    isRowSelected(index) {
        return this.getSelectedIndices().has(index);
    }
    areAllVisibleSelected(rows) {
        if (rows.length === 0)
            return false;
        const selected = this.getSelectedIndices();
        return rows.every((r) => selected.has(r.index));
    }
    areSomeVisibleSelected(rows) {
        if (rows.length === 0)
            return false;
        const selected = this.getSelectedIndices();
        const count = rows.filter((r) => selected.has(r.index)).length;
        return count > 0 && count < rows.length;
    }
    // ===========================================================================
    // SORTING
    // ===========================================================================
    getSortedRows(rows, columns) {
        if (!this.sortKey)
            return rows;
        const col = columns.find((c) => c.key === this.sortKey);
        if (!col)
            return rows;
        const colIndex = col.index;
        const dir = this.sortDirection === 'desc' ? -1 : 1;
        return [...rows].sort((a, b) => {
            const aText = this.cellText(a.cells[colIndex] || '');
            const bText = this.cellText(b.cells[colIndex] || '');
            const aNum = parseFloat(aText);
            const bNum = parseFloat(bText);
            if (!isNaN(aNum) && !isNaN(bNum)) {
                return (aNum - bNum) * dir;
            }
            return aText.localeCompare(bText, undefined, { sensitivity: 'base' }) * dir;
        });
    }
    cellText(htmlContent) {
        const tmp = document.createElement('div');
        tmp.innerHTML = htmlContent;
        return (tmp.textContent || '').trim();
    }
    // ===========================================================================
    // GROUPING
    // ===========================================================================
    getGroupableColumns(columns) {
        return columns.filter((c) => c.groupable);
    }
    buildGroups(rows, columns) {
        if (!this.groupKey)
            return [];
        const col = columns.find((c) => c.key === this.groupKey);
        if (!col)
            return [];
        const colIndex = col.index;
        const map = new Map();
        for (const row of rows) {
            const label = this.cellText(row.cells[colIndex] || '') || '(empty)';
            const existing = map.get(label);
            if (existing) {
                existing.push(row);
            }
            else {
                map.set(label, [row]);
            }
        }
        return Array.from(map.entries()).map(([label, groupRows]) => ({
            key: label,
            label,
            rows: groupRows,
        }));
    }
    isGroupExpanded(groupKey) {
        // Default to expanded when key is absent
        if (!(groupKey in this.expandedGroups))
            return true;
        return this.expandedGroups[groupKey] !== false;
    }
    toggleGroup(groupKey) {
        if (this.disabled)
            return;
        const next = { ...this.expandedGroups };
        next[groupKey] = !this.isGroupExpanded(groupKey);
        this.expandedGroups = next;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleGroupChange(e) {
        e.stopPropagation();
        if (this.disabled)
            return;
        const select = e.target;
        const key = select.value || '';
        this.groupKey = key;
        // Reset expansion state when grouping column changes — all expanded
        this.expandedGroups = {};
        this.dispatchEvent(new CustomEvent('groupChange', {
            bubbles: true,
            composed: true,
            detail: { key },
        }));
    }
    handleSort(col) {
        if (this.disabled || !col.sortable)
            return;
        if (this.sortKey === col.key) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortKey = col.key;
            this.sortDirection = 'asc';
        }
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true,
            composed: true,
            detail: { key: this.sortKey, direction: this.sortDirection },
        }));
    }
    handleRowCheckbox(e, index) {
        e.stopPropagation();
        if (this.disabled)
            return;
        const checked = e.target.checked;
        const selected = this.getSelectedIndices();
        if (checked) {
            selected.add(index);
        }
        else {
            selected.delete(index);
        }
        this.setSelectedIndices(selected);
    }
    handleSelectAll(e, rows) {
        e.stopPropagation();
        if (this.disabled)
            return;
        const checked = e.target.checked;
        const selected = this.getSelectedIndices();
        if (checked) {
            rows.forEach((r) => selected.add(r.index));
        }
        else {
            rows.forEach((r) => selected.delete(r.index));
        }
        this.setSelectedIndices(selected);
    }
    handleRowClick(e, index) {
        if (this.disabled)
            return;
        // Ignore clicks originating from checkboxes / interactive controls
        const target = e.target;
        if (target.tagName === 'INPUT' ||
            target.tagName === 'BUTTON' ||
            target.tagName === 'SELECT' ||
            target.closest('input, button, select, a, label')) {
            return;
        }
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true,
            composed: true,
            detail: { index },
        }));
    }
    handlePageChange(newPage) {
        if (this.disabled)
            return;
        const totalPages = this.getTotalPages();
        if (newPage < 1 || newPage > totalPages)
            return;
        this.page = newPage;
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true,
            composed: true,
            detail: { page: newPage },
        }));
    }
    handleHeaderKeydown(e, col) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleSort(col);
        }
    }
    handleGroupHeaderKeydown(e, groupKey) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.toggleGroup(groupKey);
        }
    }
    handleRowKeydown(e, index, rows) {
        if (this.disabled)
            return;
        if (e.key === ' ' && this.selectable) {
            e.preventDefault();
            const selected = this.getSelectedIndices();
            if (selected.has(index)) {
                selected.delete(index);
            }
            else {
                selected.add(index);
            }
            this.setSelectedIndices(selected);
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            this.dispatchEvent(new CustomEvent('rowClick', {
                bubbles: true,
                composed: true,
                detail: { index },
            }));
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const currentIdx = rows.findIndex((r) => r.index === index);
            const nextIdx = e.key === 'ArrowDown' ? currentIdx + 1 : currentIdx - 1;
            if (nextIdx >= 0 && nextIdx < rows.length) {
                const rowEls = this.querySelectorAll('[data-row-index]');
                const target = Array.from(rowEls).find((el) => el.getAttribute('data-row-index') === String(rows[nextIdx].index));
                target?.focus();
            }
        }
    }
    // ===========================================================================
    // PAGINATION HELPERS
    // ===========================================================================
    getTotalPages() {
        const size = Number(this.pageSize) || 0;
        if (size <= 0)
            return 1;
        const total = Number(this.totalItems) || 0;
        if (total <= 0)
            return 1;
        return Math.max(1, Math.ceil(total / size));
    }
    getPageNumbers() {
        const total = this.getTotalPages();
        const current = Number(this.page) || 1;
        const pages = [];
        if (total <= 7) {
            for (let i = 1; i <= total; i++)
                pages.push(i);
            return pages;
        }
        pages.push(1);
        if (current > 3)
            pages.push(-1); // ellipsis marker
        const start = Math.max(2, current - 1);
        const end = Math.min(total - 1, current + 1);
        for (let i = start; i <= end; i++)
            pages.push(i);
        if (current < total - 2)
            pages.push(-1);
        pages.push(total);
        return pages;
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getRootClasses() {
        return cn([
            'flex flex-col w-full',
            'ml-grouping-table',
            this.disabled ? 'ml-disabled' : '',
            this.loading ? 'ml-loading' : '',
            this.error ? 'ml-has-error' : '',
        ]
            .filter(Boolean)
            .join(' '), this.cssClass);
    }
    getTableClasses() {
        return ['w-full border-collapse', 'ml-table'].filter(Boolean).join(' ');
    }
    getHeadCellClasses(col) {
        return [
            'px-3 py-2 text-left text-sm font-semibold',
            'ml-table-head',
            col.sortable && !this.disabled ? 'cursor-pointer select-none' : '',
            this.sortKey === col.key ? 'ml-table-head-sorted' : '',
            col.dataClass,
        ]
            .filter(Boolean)
            .join(' ');
    }
    getBodyRowClasses(row, isSelected) {
        return [
            'ml-table-row',
            isSelected ? 'ml-table-row-selected' : '',
            row.dataClass,
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCellClasses() {
        return ['px-3 py-2 text-sm', 'ml-table-cell'].filter(Boolean).join(' ');
    }
    getGroupHeaderClasses() {
        return [
            'px-3 py-2 text-sm font-semibold',
            'ml-group-header',
            this.disabled ? '' : 'cursor-pointer',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS — icons
    // ===========================================================================
    renderChevronIcon(expanded) {
        // Points down when expanded, right when collapsed
        const rotation = expanded ? 'rotate(0deg)' : 'rotate(-90deg)';
        return html `
      <svg
        class="w-4 h-4 shrink-0 transition-transform duration-200 ml-group-chevron"
        style="transform: ${rotation}"
        viewBox="0 0 16 16"
        fill="none"
        aria-hidden="true"
      >
        ${svg `
          <path
            d="M4 6l4 4 4-4"
            stroke="currentColor"
            stroke-width="1.5"
            stroke-linecap="round"
            stroke-linejoin="round"
          />
        `}
      </svg>
    `;
    }
    renderSortIcon(col) {
        if (!col.sortable)
            return nothing;
        const isActive = this.sortKey === col.key;
        const isDesc = isActive && this.sortDirection === 'desc';
        return html `
      <span class="inline-flex flex-col ml-sort-indicator ${isActive ? 'ml-sort-active' : ''}" aria-hidden="true">
        <svg class="w-3 h-3 ${isActive && !isDesc ? 'ml-sort-asc' : ''}" viewBox="0 0 12 12" fill="none">
          ${svg `
            <path d="M6 3l3 3H3L6 3z" fill="currentColor" opacity="${isActive && !isDesc ? '1' : '0.35'}" />
          `}
        </svg>
        <svg class="w-3 h-3 -mt-0.5 ${isActive && isDesc ? 'ml-sort-desc' : ''}" viewBox="0 0 12 12" fill="none">
          ${svg `
            <path d="M6 9L3 6h6L6 9z" fill="currentColor" opacity="${isActive && isDesc ? '1' : '0.35'}" />
          `}
        </svg>
      </span>
    `;
    }
    // ===========================================================================
    // RENDER — grouping control
    // ===========================================================================
    renderGroupControl(columns) {
        const groupable = this.getGroupableColumns(columns);
        if (groupable.length === 0)
            return html ``;
        return html `
      <div class="flex items-center gap-2 px-3 py-2 ml-group-control">
        <label class="text-sm font-semibold ml-label shrink-0" for="ml-group-select">
          ${this.msg.groupBy}
        </label>
        <select
          id="ml-group-select"
          class="text-sm px-2 py-1.5 rounded-md border w-full max-w-xs ml-group-select"
          .value=${this.groupKey}
          ?disabled=${this.disabled || this.loading}
          @change=${this.handleGroupChange}
          @input=${(e) => e.stopPropagation()}
          aria-label=${this.msg.groupBy}
        >
          <option value="">${this.msg.noGrouping}</option>
          ${groupable.map((col) => html `
              <option value=${col.key} ?selected=${this.groupKey === col.key}>
                ${this.cellText(col.label)}
              </option>
            `)}
        </select>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER — caption
    // ===========================================================================
    renderCaption() {
        if (!this.hasSlot('Caption'))
            return html ``;
        return html `
      <caption class=${cn('text-sm font-semibold text-left px-3 py-2 ml-caption', this.getSlotClass('Caption'))}>
        ${unsafeHTML(this.getSlotContent('Caption'))}
      </caption>
    `;
    }
    // ===========================================================================
    // RENDER — header
    // ===========================================================================
    renderHeader(columns, visibleRows) {
        const allSelected = this.areAllVisibleSelected(visibleRows);
        const someSelected = this.areSomeVisibleSelected(visibleRows);
        return html `
      <thead class="ml-table-thead" role="rowgroup">
        <tr class="ml-table-header-row" role="row">
          ${this.selectable
            ? html `
                <th class="px-3 py-2 w-10 ml-table-head ml-table-checkbox-cell" scope="col" role="columnheader">
                  <input
                    type="checkbox"
                    class="ml-checkbox"
                    .checked=${allSelected}
                    .indeterminate=${someSelected}
                    ?disabled=${this.disabled || this.loading}
                    aria-label=${this.msg.selectAll}
                    @change=${(e) => this.handleSelectAll(e, visibleRows)}
                    @input=${(e) => e.stopPropagation()}
                    @click=${(e) => e.stopPropagation()}
                  />
                </th>
              `
            : nothing}
          ${columns.map((col) => {
            const ariaSort = col.sortable && this.sortKey === col.key
                ? this.sortDirection === 'asc'
                    ? 'ascending'
                    : 'descending'
                : col.sortable
                    ? 'none'
                    : nothing;
            return html `
              <th
                class=${this.getHeadCellClasses(col)}
                scope="col"
                role="columnheader"
                aria-sort=${ariaSort}
                tabindex=${col.sortable && !this.disabled ? '0' : nothing}
                @click=${() => this.handleSort(col)}
                @keydown=${(e) => this.handleHeaderKeydown(e, col)}
              >
                <span class="inline-flex items-center gap-1">
                  ${unsafeHTML(col.label)}
                  ${this.renderSortIcon(col)}
                </span>
              </th>
            `;
        })}
        </tr>
      </thead>
    `;
    }
    // ===========================================================================
    // RENDER — body rows
    // ===========================================================================
    renderDataRow(row, columns, allVisibleRows) {
        const isSelected = this.selectable && this.isRowSelected(row.index);
        return html `
      <tr
        class=${this.getBodyRowClasses(row, isSelected)}
        role="row"
        tabindex="0"
        data-row-index=${row.index}
        aria-selected=${this.selectable ? (isSelected ? 'true' : 'false') : nothing}
        @click=${(e) => this.handleRowClick(e, row.index)}
        @keydown=${(e) => this.handleRowKeydown(e, row.index, allVisibleRows)}
      >
        ${this.selectable
            ? html `
              <td class="px-3 py-2 w-10 ml-table-cell ml-table-checkbox-cell" role="cell">
                <input
                  type="checkbox"
                  class="ml-checkbox"
                  .checked=${isSelected}
                  ?disabled=${this.disabled || this.loading}
                  aria-label=${`${this.msg.selectRow} ${row.index + 1}`}
                  @change=${(e) => this.handleRowCheckbox(e, row.index)}
                  @input=${(e) => e.stopPropagation()}
                  @click=${(e) => e.stopPropagation()}
                />
              </td>
            `
            : nothing}
        ${row.cells.map((cell, i) => {
            // Indent first data cell when grouping is active
            const indentClass = this.groupKey && i === 0 ? 'ml-grouped-cell' : '';
            return html `
            <td class="${this.getCellClasses()} ${indentClass}" role="cell">
              ${unsafeHTML(cell)}
            </td>
          `;
        })}
        ${row.cells.length < columns.length
            ? Array.from({ length: columns.length - row.cells.length }).map(() => html `<td class=${this.getCellClasses()} role="cell"></td>`)
            : nothing}
      </tr>
    `;
    }
    renderGroupHeaderRow(group, colSpan) {
        const expanded = this.isGroupExpanded(group.key);
        const label = expanded ? this.msg.collapseGroup : this.msg.expandGroup;
        return html `
      <tr
        class="ml-group-header-row"
        role="row"
        aria-expanded=${expanded ? 'true' : 'false'}
      >
        <td
          class=${this.getGroupHeaderClasses()}
          colspan=${colSpan}
          role="cell"
          tabindex="0"
          aria-label=${`${label}: ${group.label}, ${group.rows.length} ${this.msg.rows}`}
          @click=${() => this.toggleGroup(group.key)}
          @keydown=${(e) => this.handleGroupHeaderKeydown(e, group.key)}
        >
          <span class="inline-flex items-center gap-2">
            ${this.renderChevronIcon(expanded)}
            <span class="ml-group-label">${group.label}</span>
            <span class="text-xs font-normal ml-group-count ml-text-muted">
              (${group.rows.length} ${this.msg.rows})
            </span>
          </span>
        </td>
      </tr>
    `;
    }
    renderBody(columns, rows) {
        if (rows.length === 0) {
            return html `
        <tbody class="ml-table-tbody" role="rowgroup">
          ${this.renderEmptyRow(columns)}
        </tbody>
      `;
        }
        const colSpan = columns.length + (this.selectable ? 1 : 0);
        // Grouped view
        if (this.groupKey) {
            const groups = this.buildGroups(rows, columns);
            return html `
        <tbody class="ml-table-tbody ml-table-tbody-grouped" role="rowgroup">
          ${groups.map((group) => {
                const expanded = this.isGroupExpanded(group.key);
                return html `
              ${this.renderGroupHeaderRow(group, colSpan)}
              ${expanded
                    ? group.rows.map((row) => this.renderDataRow(row, columns, rows))
                    : nothing}
            `;
            })}
        </tbody>
      `;
        }
        // Flat view
        return html `
      <tbody class="ml-table-tbody" role="rowgroup">
        ${rows.map((row) => this.renderDataRow(row, columns, rows))}
      </tbody>
    `;
    }
    renderEmptyRow(columns) {
        const colSpan = columns.length + (this.selectable ? 1 : 0);
        const content = this.hasSlot('Empty')
            ? this.getSlotContent('Empty')
            : this.msg.empty;
        return html `
      <tr class="ml-table-empty-row" role="row">
        <td
          class=${cn('px-3 py-8 text-sm text-center ml-table-empty', this.hasSlot('Empty') ? this.getSlotClass('Empty') : '')}
          colspan=${colSpan}
          role="cell"
        >
          ${unsafeHTML(content)}
        </td>
      </tr>
    `;
    }
    // ===========================================================================
    // RENDER — footer
    // ===========================================================================
    renderFooter(columns) {
        const footerRows = this.parseFooterRows();
        if (footerRows.length === 0)
            return html ``;
        return html `
      <tfoot class="ml-table-tfoot" role="rowgroup">
        ${footerRows.map((row) => html `
            <tr class="ml-table-footer-row ${row.dataClass}" role="row">
              ${this.selectable
            ? html `<td class="px-3 py-2 ml-table-cell" role="cell"></td>`
            : nothing}
              ${row.cells.map((cell) => html `
                  <td class="${this.getCellClasses()} ml-table-footer-cell" role="cell">
                    ${unsafeHTML(cell)}
                  </td>
                `)}
              ${row.cells.length < columns.length
            ? Array.from({ length: columns.length - row.cells.length }).map(() => html `<td class=${this.getCellClasses()} role="cell"></td>`)
            : nothing}
            </tr>
          `)}
      </tfoot>
    `;
    }
    // ===========================================================================
    // RENDER — loading
    // ===========================================================================
    renderLoading(columns) {
        if (this.hasSlot('Loading')) {
            return html `
        <div class=${cn('w-full p-4 ml-loading-slot', this.getSlotClass('Loading'))}>
          ${unsafeHTML(this.getSlotContent('Loading'))}
        </div>
      `;
        }
        // Default skeleton rows
        const colCount = Math.max(columns.length, 3);
        const skeletonRows = [1, 2, 3, 4];
        return html `
      <div class="w-full overflow-x-auto" role="status" aria-label=${this.msg.loading}>
        <table class=${this.getTableClasses()}>
          <thead class="ml-table-thead">
            <tr>
              ${this.selectable
            ? html `<th class="px-3 py-2 w-10"><div class="h-4 w-4 rounded ml-skeleton"></div></th>`
            : nothing}
              ${Array.from({ length: colCount }).map(() => html `
                  <th class="px-3 py-2">
                    <div class="h-4 w-24 rounded ml-skeleton"></div>
                  </th>
                `)}
            </tr>
          </thead>
          <tbody>
            ${skeletonRows.map(() => html `
                <tr>
                  ${this.selectable
            ? html `<td class="px-3 py-3"><div class="h-4 w-4 rounded ml-skeleton"></div></td>`
            : nothing}
                  ${Array.from({ length: colCount }).map(() => html `
                      <td class="px-3 py-3">
                        <div class="h-4 w-full max-w-[8rem] rounded ml-skeleton"></div>
                      </td>
                    `)}
                </tr>
              `)}
          </tbody>
        </table>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER — pagination
    // ===========================================================================
    renderPagination() {
        const size = Number(this.pageSize) || 0;
        if (size <= 0)
            return html ``;
        const totalPages = this.getTotalPages();
        const current = Number(this.page) || 1;
        const pages = this.getPageNumbers();
        return html `
      <nav
        class="flex items-center justify-between gap-2 px-3 py-2 ml-pagination"
        role="navigation"
        aria-label="Table pagination"
      >
        <span class="text-xs ml-text-muted">
          ${this.msg.page} ${current} ${this.msg.of} ${totalPages}
        </span>
        <div class="flex items-center gap-1">
          <button
            type="button"
            class="px-2 py-1 text-sm rounded-md border ml-pagination-btn"
            ?disabled=${this.disabled || current <= 1}
            aria-label=${this.msg.previousPage}
            @click=${() => this.handlePageChange(current - 1)}
          >
            ‹
          </button>
          ${pages.map((p) => p === -1
            ? html `<span class="px-1 text-sm ml-text-faint" aria-hidden="true">…</span>`
            : html `
                  <button
                    type="button"
                    class="px-2.5 py-1 text-sm rounded-md border ml-pagination-btn ${p === current ? 'ml-pagination-btn-active' : ''}"
                    ?disabled=${this.disabled}
                    aria-label=${`${this.msg.page} ${p}`}
                    aria-current=${p === current ? 'page' : nothing}
                    @click=${() => this.handlePageChange(p)}
                  >
                    ${p}
                  </button>
                `)}
          <button
            type="button"
            class="px-2 py-1 text-sm rounded-md border ml-pagination-btn"
            ?disabled=${this.disabled || current >= totalPages}
            aria-label=${this.msg.nextPage}
            @click=${() => this.handlePageChange(current + 1)}
          >
            ›
          </button>
        </div>
      </nav>
    `;
    }
    // ===========================================================================
    // RENDER — error
    // ===========================================================================
    renderError() {
        const err = String(this.error ?? '').trim();
        if (!err)
            return html ``;
        return html `
      <p class="mt-1 px-3 text-xs ml-error-text" role="alert">${unsafeHTML(err)}</p>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages.en;
        const columns = this.parseColumns();
        let rows = this.parseRows();
        // Apply internal sort
        rows = this.getSortedRows(rows, columns);
        return html `
      <div class=${this.getRootClasses()}>
        <!-- Grouping control — strongest visual weight at top -->
        ${this.renderGroupControl(columns)}

        ${this.loading
            ? this.renderLoading(columns)
            : html `
              <div class="w-full overflow-x-auto ml-table-wrapper">
                <table
                  class=${this.getTableClasses()}
                  role="table"
                  aria-disabled=${this.disabled ? 'true' : nothing}
                >
                  ${this.renderCaption()}
                  ${this.renderHeader(columns, rows)}
                  ${this.renderBody(columns, rows)}
                  ${this.renderFooter(columns)}
                </table>
              </div>
            `}

        ${this.renderPagination()}
        ${this.renderError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlGroupingTableMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlGroupingTableMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlGroupingTableMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], MlGroupingTableMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], MlGroupingTableMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlGroupingTableMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlGroupingTableMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlGroupingTableMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlGroupingTableMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlGroupingTableMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlGroupingTableMolecule.prototype, "sortDirection", void 0);
__decorate([
    state()
], MlGroupingTableMolecule.prototype, "groupKey", void 0);
__decorate([
    state()
], MlGroupingTableMolecule.prototype, "expandedGroups", void 0);
MlGroupingTableMolecule = __decorate([
    customElement('groupviewtable--ml-grouping-table')
], MlGroupingTableMolecule);
export { MlGroupingTableMolecule };
