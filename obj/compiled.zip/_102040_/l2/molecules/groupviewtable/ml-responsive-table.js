var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-responsive-table.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
import { cellSortKey, compareSortKeys } from '/_102033_/l2/shared/molecules/tableSort.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No records to display',
    selectAll: 'Select all rows',
    selectRow: 'Select row {n}',
    pagination: 'Table pagination',
    previousPage: 'Previous page',
    nextPage: 'Next page',
    pageOf: 'Page {page} of {total}',
    sortAsc: 'sorted ascending',
    sortDesc: 'sorted descending',
    sortable: 'sortable',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhum registro para exibir',
        selectAll: 'Selecionar todas as linhas',
        selectRow: 'Selecionar linha {n}',
        pagination: 'Paginação da tabela',
        previousPage: 'Página anterior',
        nextPage: 'Próxima página',
        pageOf: 'Página {page} de {total}',
        sortAsc: 'ordenado ascendente',
        sortDesc: 'ordenado descendente',
        sortable: 'ordenável',
    },
};
let MlResponsiveTableMolecule = class MlResponsiveTableMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-responsive-table {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-responsive-table .ml-responsive-table {
  width: 100%;
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-responsive-table .ml-table-scroll {
  width: 100%;
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-md, 8px);
  background: var(--ml-surface, #ffffff);
  box-shadow: var(--ml-shadow-0, none);
}
groupviewtable--ml-responsive-table .ml-table {
  width: 100%;
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-table .ml-table-caption {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
  text-align: left;
}
groupviewtable--ml-responsive-table .ml-table-header {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-responsive-table .ml-table-header-row {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-table .ml-table-head {
  color: var(--ml-on-surface-muted, #49454f);
  font-weight: var(--ml-font-weight-medium, 500);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-table .ml-head-label {
  color: inherit;
}
groupviewtable--ml-responsive-table .ml-sortable {
  cursor: pointer;
}
groupviewtable--ml-responsive-table .ml-sortable:hover:not(.ml-disabled),
groupviewtable--ml-responsive-table .ml-sort-active {
  color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-responsive-table .ml-sortable:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: -2px;
}
groupviewtable--ml-responsive-table .ml-sort-indicator {
  color: var(--ml-primary, #3b82f6);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-responsive-table .ml-sort-asc .ml-sort-indicator,
groupviewtable--ml-responsive-table .ml-sort-desc .ml-sort-indicator {
  color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-responsive-table .ml-table-row {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-table .ml-table-row:hover:not(.ml-row-selected):not(.ml-disabled) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-responsive-table .ml-table-row:focus-visible,
groupviewtable--ml-responsive-table .ml-row-focused {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: -2px;
}
groupviewtable--ml-responsive-table .ml-row-selected {
  background: var(--ml-primary-container, #e8f0fe);
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-responsive-table .ml-table-cell,
groupviewtable--ml-responsive-table .ml-footer-cell {
  color: var(--ml-on-surface, #1c1b1f);
  vertical-align: middle;
}
groupviewtable--ml-responsive-table .ml-cell-value,
groupviewtable--ml-responsive-table .ml-cell-content {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-responsive-table .ml-card-label,
groupviewtable--ml-responsive-table .ml-label {
  color: var(--ml-on-surface-muted, #49454f);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-responsive-table .ml-select-cell {
  color: var(--ml-on-surface-muted, #49454f);
  vertical-align: middle;
}
groupviewtable--ml-responsive-table .ml-checkbox {
  accent-color: var(--ml-primary, #3b82f6);
  cursor: pointer;
}
groupviewtable--ml-responsive-table .ml-checkbox:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: 2px;
}
groupviewtable--ml-responsive-table .ml-table-footer {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-responsive-table .ml-table-footer-row {
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-responsive-table .ml-table-pagination {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-responsive-table .ml-page-status,
groupviewtable--ml-responsive-table .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-responsive-table .ml-page-btn {
  min-width: 2.25rem;
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-responsive-table .ml-page-btn:hover:not(:disabled),
groupviewtable--ml-responsive-table .ml-page-btn:focus-visible {
  color: var(--ml-primary, #3b82f6);
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-responsive-table .ml-page-btn:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: 2px;
}
groupviewtable--ml-responsive-table .ml-table-loading,
groupviewtable--ml-responsive-table .ml-table-empty {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-responsive-table .ml-skeleton {
  background: var(--ml-surface-variant, #eef0f3);
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-responsive-table .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupviewtable--ml-responsive-table .ml-disabled,
groupviewtable--ml-responsive-table .ml-loading {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupviewtable--ml-responsive-table .ml-loading .ml-table-loading,
groupviewtable--ml-responsive-table .ml-loading .ml-skeleton {
  opacity: 1;
}
@media (max-width: 640px) {
  groupviewtable--ml-responsive-table .ml-table-scroll {
    border: 0;
    background: transparent;
    box-shadow: var(--ml-shadow-0, none);
  }
  groupviewtable--ml-responsive-table .ml-table,
  groupviewtable--ml-responsive-table .ml-table-header,
  groupviewtable--ml-responsive-table .ml-table-body,
  groupviewtable--ml-responsive-table .ml-table-footer,
  groupviewtable--ml-responsive-table .ml-table-header-row,
  groupviewtable--ml-responsive-table .ml-table-footer-row,
  groupviewtable--ml-responsive-table .ml-table-row {
    display: block;
    width: 100%;
  }
  groupviewtable--ml-responsive-table .ml-table-header {
    background: transparent;
  }
  groupviewtable--ml-responsive-table .ml-table-header-row {
    display: flex;
    align-items: center;
    min-height: 2.5rem;
    border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  }
  groupviewtable--ml-responsive-table .ml-table-header-row .ml-table-head {
    display: none;
  }
  groupviewtable--ml-responsive-table .ml-table-header-row .ml-select-cell {
    display: block;
    width: 2.5rem;
  }
  groupviewtable--ml-responsive-table .ml-table-row {
    display: grid;
    grid-template-columns: 2.5rem minmax(0, 1fr);
    margin: 0 0 0.75rem;
    border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
    border-radius: var(--ml-radius-md, 8px);
    box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
  }
  groupviewtable--ml-responsive-table .ml-table-row .ml-select-cell {
    grid-column: 1;
    grid-row: 1 / -1;
    width: auto;
    padding-top: 0.75rem;
  }
  groupviewtable--ml-responsive-table .ml-table-row .ml-table-cell {
    grid-column: 2;
    display: grid;
    grid-template-columns: minmax(5rem, 35%) minmax(0, 1fr);
    gap: 0.5rem;
    align-items: start;
    width: auto;
    border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  }
  groupviewtable--ml-responsive-table .ml-table-row .ml-table-cell:last-child {
    border-bottom: 0;
  }
  groupviewtable--ml-responsive-table .ml-card-label {
    display: block;
    min-width: 0;
  }
  groupviewtable--ml-responsive-table .ml-cell-value,
  groupviewtable--ml-responsive-table .ml-cell-content {
    min-width: 0;
    overflow-wrap: anywhere;
  }
  groupviewtable--ml-responsive-table .ml-table-footer {
    margin-top: 0.75rem;
  }
  groupviewtable--ml-responsive-table .ml-table-footer-row {
    display: grid;
    grid-template-columns: 2.5rem minmax(0, 1fr);
    border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
    border-radius: var(--ml-radius-md, 8px);
    background: var(--ml-surface, #ffffff);
  }
  groupviewtable--ml-responsive-table .ml-table-footer-row .ml-footer-cell {
    grid-column: 2;
  }
  groupviewtable--ml-responsive-table .ml-table-footer-row .ml-select-cell {
    grid-column: 1;
  }
  groupviewtable--ml-responsive-table .ml-table-pagination {
    margin-top: 0.75rem;
  }
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [
            'Caption',
            'TableHeader',
            'TableBody',
            'TableRow',
            'TableHead',
            'TableCell',
            'TableFooter',
            'Empty',
            'Loading',
        ];
        /** Project cell content as live DOM so interactive controls stay alive. */
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
        this.focusedRowIndex = -1;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.propagateEditing();
    }
    updated(changedProps) {
        if (changedProps.has('isEditing')) {
            this.propagateEditing();
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER — propagate isEditing only (never reassign bound props)
    // ===========================================================================
    handleIcaStateChange(key, _value) {
        const isEditingAttr = this.getAttribute('is-editing');
        if (isEditingAttr === `{{${key}}}`) {
            this.propagateEditing();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // isEditing PROPAGATION
    // ===========================================================================
    propagateEditing() {
        const flag = this.isEditing ? 'true' : 'false';
        // Projected cell content lives under live-ref anchors after the first paint.
        this.querySelectorAll('[data-ml-live-ref]').forEach((anchor) => {
            anchor.querySelectorAll('*').forEach((node) => {
                if (node instanceof HTMLElement && node.tagName.includes('-')) {
                    node.setAttribute('is-editing', flag);
                }
            });
        });
        // Also cover not-yet-projected sources still under the slot tags.
        const body = this.getLiveSlot('TableBody');
        if (body) {
            body.querySelectorAll('tablecell *').forEach((node) => {
                if (node instanceof HTMLElement && node.tagName.includes('-')) {
                    node.setAttribute('is-editing', flag);
                }
            });
        }
        const footer = this.getLiveSlot('TableFooter');
        if (footer) {
            footer.querySelectorAll('tablecell *').forEach((node) => {
                if (node instanceof HTMLElement && node.tagName.includes('-')) {
                    node.setAttribute('is-editing', flag);
                }
            });
        }
    }
    // ===========================================================================
    // SLOT PARSERS
    // ===========================================================================
    parseHeaderCells() {
        const header = this.getLiveSlot('TableHeader');
        if (!header)
            return [];
        const heads = Array.from(header.querySelectorAll(':scope > tablerow > tablehead, :scope > tablehead'));
        return heads.map((el, index) => {
            const key = el.getAttribute('key') || `col-${index}`;
            const sortable = el.hasAttribute('sortable');
            const label = (el.textContent || '').trim();
            const htmlContent = el.innerHTML;
            return { key, sortable, label, html: htmlContent, el };
        });
    }
    parseBodyRows() {
        const body = this.getLiveSlot('TableBody');
        if (!body)
            return [];
        const rows = Array.from(body.querySelectorAll(':scope > tablerow'));
        return rows.map((el, originalIndex) => {
            const cells = Array.from(el.querySelectorAll(':scope > tablecell'));
            return { el, originalIndex, cells };
        });
    }
    parseFooterRows() {
        const footer = this.getLiveSlot('TableFooter');
        if (!footer)
            return [];
        const rows = Array.from(footer.querySelectorAll(':scope > tablerow'));
        return rows.map((el) => ({
            cells: Array.from(el.querySelectorAll(':scope > tablecell')),
        }));
    }
    // ===========================================================================
    // MODE / PAGINATION / SORT HELPERS
    // ===========================================================================
    isExternalMode(rowCount) {
        const declared = Number(this.totalItems) || 0;
        return declared > rowCount;
    }
    getTotalItemCount(rowCount) {
        const declared = Number(this.totalItems) || 0;
        if (declared > rowCount)
            return declared;
        return rowCount;
    }
    getPageSize() {
        const size = Number(this.pageSize);
        return Number.isFinite(size) && size > 0 ? size : 0;
    }
    getCurrentPage() {
        const p = Number(this.page);
        return Number.isFinite(p) && p >= 1 ? Math.floor(p) : 1;
    }
    getTotalPages(rowCount) {
        const size = this.getPageSize();
        if (size <= 0)
            return 1;
        const total = this.getTotalItemCount(rowCount);
        return Math.max(1, Math.ceil(total / size));
    }
    getSelectedSet() {
        const raw = String(this.value ?? '').trim();
        if (!raw)
            return new Set();
        return new Set(raw
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => !isNaN(n)));
    }
    sortedRows(rows, headers) {
        if (this.isExternalMode(rows.length)) {
            // External mode: keep received order; consumer re-queries on sort.
            return rows.slice();
        }
        if (!this.sortKey)
            return rows.slice();
        const colIndex = headers.findIndex((h) => h.key === this.sortKey);
        if (colIndex < 0)
            return rows.slice();
        const dir = this.sortDirection === 'desc' ? -1 : 1;
        const decorated = rows.map((row, idx) => {
            const cell = row.cells[colIndex];
            const key = cell ? cellSortKey(cell, this.getLiveText(cell)) : '';
            return { row, key, idx };
        });
        decorated.sort((a, b) => {
            const cmp = compareSortKeys(a.key, b.key) * dir;
            return cmp !== 0 ? cmp : a.idx - b.idx;
        });
        return decorated.map((d) => d.row);
    }
    paginateRows(rows) {
        const size = this.getPageSize();
        if (size <= 0)
            return rows;
        // External mode already holds one page — do not slice again.
        if (this.isExternalMode(this.parseBodyRows().length))
            return rows;
        const page = this.getCurrentPage();
        const start = (page - 1) * size;
        return rows.slice(start, start + size);
    }
    getVisibleRows(headers) {
        const all = this.parseBodyRows();
        const ordered = this.sortedRows(all, headers);
        return this.paginateRows(ordered);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    emitChange(selected) {
        const ordered = Array.from(selected).sort((a, b) => a - b);
        const next = ordered.join(',');
        this.value = next;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: next },
        }));
    }
    handleSort(key) {
        if (this.disabled || this.loading)
            return;
        if (this.sortKey === key) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortKey = key;
            this.sortDirection = 'asc';
        }
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true,
            composed: true,
            detail: { key: this.sortKey, direction: this.sortDirection },
        }));
    }
    handleRowCheck(originalIndex, checked) {
        if (this.disabled || this.loading)
            return;
        const selected = this.getSelectedSet();
        if (checked)
            selected.add(originalIndex);
        else
            selected.delete(originalIndex);
        this.emitChange(selected);
    }
    handleSelectAll(checked, allRows) {
        if (this.disabled || this.loading)
            return;
        const selected = this.getSelectedSet();
        if (checked) {
            allRows.forEach((r) => selected.add(r.originalIndex));
        }
        else {
            allRows.forEach((r) => selected.delete(r.originalIndex));
        }
        this.emitChange(selected);
    }
    handleRowActivate(originalIndex, e) {
        if (this.disabled || this.loading)
            return;
        const target = e.target;
        if (target?.closest('input[type="checkbox"]'))
            return;
        if (target?.closest('button, a, input, select, textarea, label'))
            return;
        this.focusedRowIndex = originalIndex;
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true,
            composed: true,
            detail: { index: originalIndex },
        }));
    }
    handlePageChange(nextPage, totalPages) {
        if (this.disabled || this.loading)
            return;
        const page = Math.min(Math.max(1, nextPage), totalPages);
        if (page === this.getCurrentPage())
            return;
        this.page = page;
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true,
            composed: true,
            detail: { page },
        }));
    }
    handleCheckboxChange(e, originalIndex) {
        e.stopPropagation();
        if (this.disabled || this.loading)
            return;
        const input = e.target;
        this.handleRowCheck(originalIndex, input.checked);
    }
    handleSelectAllChange(e, allRows) {
        e.stopPropagation();
        if (this.disabled || this.loading)
            return;
        const input = e.target;
        this.handleSelectAll(input.checked, allRows);
    }
    handleKeyDown(e, visibleRows, headers) {
        if (this.disabled || this.loading)
            return;
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            if (visibleRows.length === 0)
                return;
            const currentPos = visibleRows.findIndex((r) => r.originalIndex === this.focusedRowIndex);
            let nextPos;
            if (e.key === 'ArrowDown') {
                nextPos = currentPos < 0 ? 0 : Math.min(visibleRows.length - 1, currentPos + 1);
            }
            else {
                nextPos = currentPos < 0 ? visibleRows.length - 1 : Math.max(0, currentPos - 1);
            }
            this.focusedRowIndex = visibleRows[nextPos].originalIndex;
            const rowEl = this.querySelector(`[data-row-index="${this.focusedRowIndex}"]`);
            rowEl?.focus();
            return;
        }
        if (e.key === ' ' || e.key === 'Spacebar') {
            const target = e.target;
            if (target.closest('input, button, a, select, textarea'))
                return;
            if (!this.selectable)
                return;
            if (this.focusedRowIndex < 0)
                return;
            e.preventDefault();
            const selected = this.getSelectedSet();
            if (selected.has(this.focusedRowIndex))
                selected.delete(this.focusedRowIndex);
            else
                selected.add(this.focusedRowIndex);
            this.emitChange(selected);
            return;
        }
        if (e.key === 'Enter') {
            const target = e.target;
            const th = target.closest('[data-sort-key]');
            if (th) {
                const key = th.getAttribute('data-sort-key');
                if (key) {
                    e.preventDefault();
                    this.handleSort(key);
                }
                return;
            }
        }
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getRootClasses() {
        return cn([
            'w-full flex flex-col gap-3',
            'ml-responsive-table',
            this.disabled ? 'ml-disabled' : '',
            this.loading ? 'ml-loading' : '',
        ]
            .filter(Boolean)
            .join(' '), this.cssClass);
    }
    getRowClasses(isSelected, isFocused) {
        return [
            'ml-table-row',
            isSelected ? 'ml-row-selected' : '',
            isFocused ? 'ml-row-focused' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getHeadClasses(header) {
        const isActive = this.sortKey === header.key;
        return [
            'ml-table-head',
            header.sortable ? 'ml-sortable' : '',
            isActive ? 'ml-sort-active' : '',
            isActive && this.sortDirection === 'asc' ? 'ml-sort-asc' : '',
            isActive && this.sortDirection === 'desc' ? 'ml-sort-desc' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderCaption() {
        if (!this.hasSlot('Caption') && !this.getLiveSlot('Caption'))
            return html ``;
        const live = this.getLiveSlot('Caption');
        const content = live ? live.innerHTML : this.getSlotContent('Caption');
        if (!content)
            return html ``;
        return html `
      <caption class="${cn('ml-table-caption text-sm font-semibold text-left mb-2', this.getSlotClass('Caption'))}">
        ${unsafeHTML(content)}
      </caption>
    `;
    }
    ariaSortFor(header) {
        if (!header.sortable)
            return nothing;
        if (this.sortKey !== header.key)
            return 'none';
        return this.sortDirection === 'desc' ? 'descending' : 'ascending';
    }
    renderSortIndicator(header) {
        if (!header.sortable)
            return html ``;
        const isActive = this.sortKey === header.key;
        const arrow = isActive && this.sortDirection === 'desc'
            ? '▼'
            : isActive && this.sortDirection === 'asc'
                ? '▲'
                : '↕';
        const sr = isActive
            ? this.sortDirection === 'desc'
                ? this.msg.sortDesc
                : this.msg.sortAsc
            : this.msg.sortable;
        return html `
      <span class="ml-sort-indicator inline-flex ml-1 text-xs" aria-hidden="true">${arrow}</span>
      <span class="sr-only">${sr}</span>
    `;
    }
    renderSelectAllCell(allRows, selected) {
        if (!this.selectable)
            return html ``;
        const enabledRows = allRows;
        const allSelected = enabledRows.length > 0 && enabledRows.every((r) => selected.has(r.originalIndex));
        const someSelected = enabledRows.some((r) => selected.has(r.originalIndex));
        return html `
      <th class="ml-select-cell w-10 px-2 py-2" scope="col">
        <input
          type="checkbox"
          class="ml-checkbox"
          aria-label=${this.msg.selectAll}
          .checked=${allSelected}
          .indeterminate=${someSelected && !allSelected}
          ?disabled=${this.disabled || this.loading || enabledRows.length === 0}
          @change=${(e) => this.handleSelectAllChange(e, enabledRows)}
          @input=${(e) => e.stopPropagation()}
          @click=${(e) => e.stopPropagation()}
        />
      </th>
    `;
    }
    renderHeaderRow(headers, allRows, selected) {
        return html `
      <tr class="ml-table-header-row" role="row">
        ${this.renderSelectAllCell(allRows, selected)}
        ${headers.map((header) => html `
            <th
              class="${this.getHeadClasses(header)} px-3 py-2 text-sm font-semibold text-left"
              scope="col"
              role="columnheader"
              data-sort-key=${header.sortable ? header.key : nothing}
              aria-sort=${this.ariaSortFor(header)}
              tabindex=${header.sortable && !this.disabled && !this.loading ? '0' : nothing}
              @click=${header.sortable
            ? (e) => {
                e.preventDefault();
                this.handleSort(header.key);
            }
            : nothing}
              @keydown=${header.sortable
            ? (e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    this.handleSort(header.key);
                }
            }
            : nothing}
            >
              <span class="inline-flex items-center gap-1 ml-head-label">
                ${unsafeHTML(header.html || header.label)}
                ${this.renderSortIndicator(header)}
              </span>
            </th>
          `)}
      </tr>
    `;
    }
    renderRowCheckbox(originalIndex, isSelected) {
        if (!this.selectable)
            return html ``;
        const label = this.msg.selectRow.replace('{n}', String(originalIndex + 1));
        return html `
      <td class="ml-select-cell w-10 px-2 py-2" role="cell" data-label="">
        <input
          type="checkbox"
          class="ml-checkbox"
          aria-label=${label}
          .checked=${isSelected}
          ?disabled=${this.disabled || this.loading}
          @change=${(e) => this.handleCheckboxChange(e, originalIndex)}
          @input=${(e) => e.stopPropagation()}
          @click=${(e) => e.stopPropagation()}
        />
      </td>
    `;
    }
    renderBodyRow(row, headers, selected) {
        const isSelected = selected.has(row.originalIndex);
        const isFocused = this.focusedRowIndex === row.originalIndex;
        return html `
      <tr
        class="${this.getRowClasses(isSelected, isFocused)}"
        role="row"
        data-row-index=${row.originalIndex}
        tabindex="0"
        aria-selected=${this.selectable ? (isSelected ? 'true' : 'false') : nothing}
        @click=${(e) => this.handleRowActivate(row.originalIndex, e)}
        @focus=${() => {
            this.focusedRowIndex = row.originalIndex;
        }}
      >
        ${this.renderRowCheckbox(row.originalIndex, isSelected)}
        ${row.cells.map((cell, colIndex) => {
            const header = headers[colIndex];
            const label = header?.label || '';
            const slotClass = cell.getAttribute('data-class') || '';
            return html `
            <td
              class="${cn('ml-table-cell px-3 py-2 text-sm', slotClass)}"
              role="cell"
              data-label=${label}
            >
              ${label
                ? html `<span class="ml-card-label ml-label text-xs font-medium" aria-hidden="true"
                    >${label}</span
                  >`
                : nothing}
              <div class="ml-cell-value">
                ${this.renderLiveSlotFrom(cell, 'ml-cell-content')}
              </div>
            </td>
          `;
        })}
      </tr>
    `;
    }
    renderFooter(headers) {
        const footerRows = this.parseFooterRows();
        if (footerRows.length === 0)
            return html ``;
        return html `
      <tfoot class="ml-table-footer" role="rowgroup">
        ${footerRows.map((row) => html `
            <tr class="ml-table-footer-row" role="row">
              ${this.selectable
            ? html `<td class="ml-select-cell w-10 px-2 py-2" role="cell"></td>`
            : nothing}
              ${row.cells.map((cell, colIndex) => {
            const slotClass = cell.getAttribute('data-class') || '';
            const label = headers[colIndex]?.label || '';
            return html `
                  <td
                    class="${cn('ml-table-cell ml-footer-cell px-3 py-2 text-sm', slotClass)}"
                    role="cell"
                    data-label=${label}
                  >
                    <div class="ml-cell-value">
                      ${this.renderLiveSlotFrom(cell, 'ml-cell-content')}
                    </div>
                  </td>
                `;
        })}
            </tr>
          `)}
      </tfoot>
    `;
    }
    renderLoading() {
        const live = this.getLiveSlot('Loading');
        const content = live?.innerHTML || this.getSlotContent('Loading');
        if (content) {
            return html `
        <div class="${cn('ml-table-loading p-6', this.getSlotClass('Loading'))}" role="status" aria-live="polite">
          ${unsafeHTML(content)}
        </div>
      `;
        }
        return html `
      <div class="ml-table-loading flex flex-col gap-2 p-6" role="status" aria-live="polite">
        <div class="ml-skeleton h-4 w-full rounded"></div>
        <div class="ml-skeleton h-4 w-5/6 rounded"></div>
        <div class="ml-skeleton h-4 w-4/6 rounded"></div>
        <span class="sr-only">${this.msg.loading}</span>
      </div>
    `;
    }
    renderEmpty() {
        const live = this.getLiveSlot('Empty');
        const content = live?.innerHTML || this.getSlotContent('Empty');
        if (content) {
            return html `
        <div class="${cn('ml-table-empty p-6 text-sm ml-text-muted', this.getSlotClass('Empty'))}" role="status">
          ${unsafeHTML(content)}
        </div>
      `;
        }
        return html `
      <div class="ml-table-empty p-6 text-sm ml-text-muted" role="status">${this.msg.empty}</div>
    `;
    }
    renderPagination(rowCount) {
        const size = this.getPageSize();
        if (size <= 0)
            return html ``;
        const totalPages = this.getTotalPages(rowCount);
        if (totalPages <= 1 && !this.isExternalMode(rowCount))
            return html ``;
        const page = Math.min(this.getCurrentPage(), totalPages);
        const label = this.msg.pageOf
            .replace('{page}', String(page))
            .replace('{total}', String(totalPages));
        return html `
      <nav
        class="ml-table-pagination flex items-center justify-between gap-3 text-sm"
        role="navigation"
        aria-label=${this.msg.pagination}
      >
        <button
          type="button"
          class="ml-page-btn px-3 py-1 rounded border text-sm"
          ?disabled=${this.disabled || this.loading || page <= 1}
          aria-label=${this.msg.previousPage}
          @click=${() => this.handlePageChange(page - 1, totalPages)}
        >
          ‹
        </button>
        <span class="ml-page-status ml-text-muted">${label}</span>
        <button
          type="button"
          class="ml-page-btn px-3 py-1 rounded border text-sm"
          ?disabled=${this.disabled || this.loading || page >= totalPages}
          aria-label=${this.msg.nextPage}
          @click=${() => this.handlePageChange(page + 1, totalPages)}
        >
          ›
        </button>
      </nav>
    `;
    }
    renderError() {
        const err = String(this.error ?? '').trim();
        if (!err)
            return html ``;
        return html `
      <p class="ml-error-text mt-1 text-xs" role="alert">${unsafeHTML(err)}</p>
    `;
    }
    renderTableShell(headers, visibleRows, allRows, selected) {
        return html `
      <div class="ml-table-scroll w-full overflow-x-auto">
        <table
          class="ml-table w-full border-collapse"
          role="table"
          @keydown=${(e) => this.handleKeyDown(e, visibleRows, headers)}
        >
          ${this.renderCaption()}
          <thead class="ml-table-header" role="rowgroup">
            ${this.renderHeaderRow(headers, allRows, selected)}
          </thead>
          <tbody class="ml-table-body" role="rowgroup">
            ${visibleRows.map((row) => this.renderBodyRow(row, headers, selected))}
          </tbody>
          ${this.renderFooter(headers)}
        </table>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages.en;
        const headers = this.parseHeaderCells();
        const allRows = this.parseBodyRows();
        const selected = this.getSelectedSet();
        const rowCount = allRows.length;
        // Loading takes precedence over empty-state presentation.
        if (this.loading) {
            return html `
        <div class="${this.getRootClasses()}">
          ${this.renderLoading()}
          ${this.renderError()}
        </div>
      `;
        }
        if (rowCount === 0) {
            return html `
        <div class="${this.getRootClasses()}">
          ${this.renderEmpty()}
          ${this.renderPagination(rowCount)}
          ${this.renderError()}
        </div>
      `;
        }
        const visibleRows = this.getVisibleRows(headers);
        return html `
      <div class="${this.getRootClasses()}">
        ${this.renderTableShell(headers, visibleRows, allRows, selected)}
        ${this.renderPagination(rowCount)}
        ${this.renderError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlResponsiveTableMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlResponsiveTableMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlResponsiveTableMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], MlResponsiveTableMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], MlResponsiveTableMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlResponsiveTableMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlResponsiveTableMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlResponsiveTableMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlResponsiveTableMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlResponsiveTableMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlResponsiveTableMolecule.prototype, "sortDirection", void 0);
__decorate([
    state()
], MlResponsiveTableMolecule.prototype, "focusedRowIndex", void 0);
MlResponsiveTableMolecule = __decorate([
    customElement('groupviewtable--ml-responsive-table')
], MlResponsiveTableMolecule);
export { MlResponsiveTableMolecule };
