/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-inline-edit-table.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// INLINE EDIT TABLE MOLECULE
// =============================================================================
// Skill Group: groupViewTable
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No data available',
    selectAll: 'Select all rows',
    selectRow: 'Select row',
    sortAscending: 'Sort ascending',
    sortDescending: 'Sort descending',
    pagination: 'Table pagination',
    previous: 'Previous',
    next: 'Next',
    page: 'Page',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhum dado disponível',
        selectAll: 'Selecionar todas as linhas',
        selectRow: 'Selecionar linha',
        sortAscending: 'Ordenar crescente',
        sortDescending: 'Ordenar decrescente',
        pagination: 'Paginação da tabela',
        previous: 'Anterior',
        next: 'Próximo',
        page: 'Página',
    },
};
let MlInlineEditTableMolecule = class MlInlineEditTableMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-inline-edit-table .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-inline-edit-table .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-inline-edit-table .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-inline-edit-table .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-inline-edit-table .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-inline-edit-table .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-inline-edit-table .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-inline-edit-table .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-inline-edit-table .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-inline-edit-table .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupviewtable--ml-inline-edit-table .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-inline-edit-table .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-inline-edit-table .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-inline-edit-table .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-inline-edit-table .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewtable--ml-inline-edit-table .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-inline-edit-table .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewtable--ml-inline-edit-table .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Caption', 'TableHeader', 'TableBody', 'TableRow', 'TableHead', 'TableCell', 'TableFooter', 'Empty', 'Loading'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
        this.focusedRowIndex = -1;
        this.parsedColumns = [];
        this.parsedRows = [];
        this.sortedRowIndices = [];
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseTableStructure();
        this.propagateEditingState();
    }
    updated(changedProperties) {
        if (changedProperties.has('isEditing')) {
            this.propagateEditingState();
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const isEditingAttr = this.getAttribute('is-editing');
        if (isEditingAttr === `{{${key}}}`) {
            this.propagateEditingState();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    parseTableStructure() {
        this.parseColumns();
        this.parseRows();
        this.initializeSortedIndices();
    }
    parseColumns() {
        const headerSlot = this.getSlot('TableHeader');
        if (!headerSlot) {
            this.parsedColumns = [];
            return;
        }
        const headerRow = headerSlot.querySelector('TableRow');
        if (!headerRow) {
            this.parsedColumns = [];
            return;
        }
        const heads = Array.from(headerRow.querySelectorAll('TableHead'));
        this.parsedColumns = heads.map((head) => ({
            key: head.getAttribute('key') || '',
            sortable: head.hasAttribute('sortable'),
            content: head.innerHTML,
        }));
    }
    parseRows() {
        const bodySlot = this.getSlot('TableBody');
        if (!bodySlot) {
            this.parsedRows = [];
            return;
        }
        const rows = Array.from(bodySlot.querySelectorAll('TableRow'));
        this.parsedRows = rows.map((row, index) => {
            const cells = Array.from(row.querySelectorAll('TableCell'));
            return {
                element: row,
                cells: cells.map((cell) => cell.innerHTML),
                index,
            };
        });
    }
    initializeSortedIndices() {
        this.sortedRowIndices = this.parsedRows.map((_, i) => i);
    }
    // ===========================================================================
    // EDITING PROPAGATION
    // ===========================================================================
    propagateEditingState() {
        const bodySlot = this.getSlot('TableBody');
        if (!bodySlot)
            return;
        const cells = bodySlot.querySelectorAll('TableCell');
        cells.forEach((cell) => {
            const children = cell.querySelectorAll('*');
            children.forEach((child) => {
                if (child.tagName.includes('-')) {
                    child.setAttribute('is-editing', String(this.isEditing));
                }
            });
        });
    }
    // ===========================================================================
    // SELECTION
    // ===========================================================================
    getSelectedIndices() {
        if (!this.value)
            return new Set();
        return new Set(this.value
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => !isNaN(n)));
    }
    setSelectedIndices(indices) {
        const sorted = Array.from(indices).sort((a, b) => a - b);
        this.value = sorted.join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleSelectAll() {
        if (this.disabled)
            return;
        const selected = this.getSelectedIndices();
        const allSelected = this.parsedRows.every((row) => selected.has(row.index));
        if (allSelected) {
            this.setSelectedIndices(new Set());
        }
        else {
            this.setSelectedIndices(new Set(this.parsedRows.map((row) => row.index)));
        }
    }
    handleRowSelect(index) {
        if (this.disabled)
            return;
        const selected = this.getSelectedIndices();
        if (selected.has(index)) {
            selected.delete(index);
        }
        else {
            selected.add(index);
        }
        this.setSelectedIndices(selected);
    }
    // ===========================================================================
    // SORTING
    // ===========================================================================
    handleSort(key) {
        if (this.disabled)
            return;
        if (this.sortKey === key) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortKey = key;
            this.sortDirection = 'asc';
        }
        this.applySorting();
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true,
            composed: true,
            detail: { key: this.sortKey, direction: this.sortDirection },
        }));
    }
    applySorting() {
        if (!this.sortKey) {
            this.initializeSortedIndices();
            return;
        }
        const columnIndex = this.parsedColumns.findIndex((col) => col.key === this.sortKey);
        if (columnIndex === -1) {
            this.initializeSortedIndices();
            return;
        }
        const rowsWithValues = this.parsedRows.map((row) => {
            const cellContent = row.cells[columnIndex] || '';
            const textContent = this.extractTextContent(cellContent);
            return { index: row.index, value: textContent };
        });
        rowsWithValues.sort((a, b) => {
            const comparison = a.value.localeCompare(b.value, undefined, { numeric: true, sensitivity: 'base' });
            return this.sortDirection === 'asc' ? comparison : -comparison;
        });
        this.sortedRowIndices = rowsWithValues.map((r) => r.index);
    }
    extractTextContent(html) {
        const div = document.createElement('div');
        div.innerHTML = html;
        return div.textContent || '';
    }
    // ===========================================================================
    // ROW CLICK
    // ===========================================================================
    handleRowClick(index, event) {
        const target = event.target;
        if (target.tagName === 'INPUT' && target.type === 'checkbox') {
            return;
        }
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true,
            composed: true,
            detail: { index },
        }));
    }
    // ===========================================================================
    // PAGINATION
    // ===========================================================================
    get totalPages() {
        if (this.pageSize <= 0)
            return 1;
        return Math.ceil(this.totalItems / this.pageSize) || 1;
    }
    handlePageChange(newPage) {
        if (this.disabled)
            return;
        if (newPage < 1 || newPage > this.totalPages)
            return;
        this.page = newPage;
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true,
            composed: true,
            detail: { page: newPage },
        }));
    }
    // ===========================================================================
    // KEYBOARD NAVIGATION
    // ===========================================================================
    handleKeyDown(event) {
        if (this.disabled)
            return;
        const target = event.target;
        const isInsideCell = target.closest('td') !== null;
        if (isInsideCell && (event.key === 'Tab' || event.key === 'Enter')) {
            return;
        }
        switch (event.key) {
            case 'ArrowUp':
                event.preventDefault();
                this.moveFocus(-1);
                break;
            case 'ArrowDown':
                event.preventDefault();
                this.moveFocus(1);
                break;
            case '':
                if (this.selectable && this.focusedRowIndex >= 0) {
                    event.preventDefault();
                    this.handleRowSelect(this.focusedRowIndex);
                }
                break;
        }
    }
    handleHeaderKeyDown(event, key, sortable) {
        if (event.key === 'Enter' && sortable) {
            event.preventDefault();
            this.handleSort(key);
        }
    }
    moveFocus(direction) {
        const rowCount = this.sortedRowIndices.length;
        if (rowCount === 0)
            return;
        if (this.focusedRowIndex === -1) {
            this.focusedRowIndex = direction > 0 ? 0 : rowCount - 1;
        }
        else {
            const currentPosition = this.sortedRowIndices.indexOf(this.focusedRowIndex);
            const newPosition = Math.max(0, Math.min(rowCount - 1, currentPosition + direction));
            this.focusedRowIndex = this.sortedRowIndices[newPosition];
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getTableClasses() {
        return [
            'w-full border-collapse',
            'ml-surface-bg',
            'ml-text',
            this.disabled ? 'opacity-50 pointer-events-none' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getHeaderCellClasses(sortable) {
        return [
            'px-4 py-3 text-left text-sm font-semibold',
            'ml-surface-dim-bg',
            'ml-text',
            'border-b ml-border',
            sortable ? 'cursor-pointer select-none hover:ml-surface-dim-bg' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getRowClasses(index, isSelected) {
        return [
            'transition-colors',
            isSelected ? 'ml-primary-dim-bg' : 'ml-surface-bg',
            this.focusedRowIndex === index ? 'ring-2 ring-inset ml-focus-ring' : '',
            'hover:ml-surface-dim-bg',
            'border-b ml-border',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCellClasses() {
        return ['px-4 py-3 text-sm', 'ml-text'].join(' ');
    }
    getCheckboxClasses() {
        return [
            'w-4 h-4 rounded',
            'ml-border',
            'ml-primary-text',
            '',
            'ml-surface-bg',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER SECTIONS
    // ===========================================================================
    renderCaption() {
        if (!this.hasSlot('Caption'))
            return nothing;
        const content = this.getSlotContent('Caption');
        return html `
 <caption class="${cn('px-4 py-3 text-left text-lg font-semibold ml-text ml-surface-bg', this.getSlotClass('Caption'))}">
 ${unsafeHTML(content)}
 </caption>
 `;
    }
    renderHeader() {
        const selected = this.getSelectedIndices();
        const allSelected = this.parsedRows.length > 0 && this.parsedRows.every((row) => selected.has(row.index));
        const someSelected = this.parsedRows.some((row) => selected.has(row.index));
        return html `
 <thead role="rowgroup">
 <tr role="row">
 ${this.selectable
            ? html `
 <th class="${this.getHeaderCellClasses(false)} w-12" role="columnheader">
 <input
 type="checkbox"
 class="${this.getCheckboxClasses()}"
 .checked=${allSelected}
 .indeterminate=${someSelected && !allSelected}
 @change=${this.handleSelectAll}
 aria-label=${this.msg.selectAll}
 ?disabled=${this.disabled}
 />
 </th>
 `
            : nothing}
 ${this.parsedColumns.map((col) => this.renderHeaderCell(col))}
 </tr>
 </thead>
 `;
    }
    renderHeaderCell(col) {
        const isSorted = this.sortKey === col.key;
        const ariaSort = isSorted ? (this.sortDirection === 'asc' ? 'ascending' : 'descending') : undefined;
        return html `
 <th
 class="${this.getHeaderCellClasses(col.sortable)}"
 role="columnheader"
 aria-sort=${ariaSort || nothing}
 tabindex=${col.sortable ? '0' : nothing}
 @click=${col.sortable ? () => this.handleSort(col.key) : nothing}
 @keydown=${col.sortable ? (e) => this.handleHeaderKeyDown(e, col.key, col.sortable) : nothing}
 >
 <span class="flex items-center gap-2">
 ${unsafeHTML(col.content)}
 ${col.sortable ? this.renderSortIcon(isSorted) : nothing}
 </span>
 </th>
 `;
    }
    renderSortIcon(isSorted) {
        if (!isSorted) {
            return html `
 <span class="ml-text-faint">
 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16V4m0 0L3 8m4-4l4 4m6 0v12m0 0l4-4m-4 4l-4-4"/>`}
 </svg>
 </span>
 `;
        }
        return html `
 <span class="ml-primary-text">
 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 ${this.sortDirection === 'asc'
            ? svg `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 15l7-7 7 7"/>`
            : svg `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>`}
 </svg>
 </span>
 `;
    }
    renderBody() {
        if (this.parsedRows.length === 0) {
            return this.renderEmpty();
        }
        const selected = this.getSelectedIndices();
        return html `
 <tbody role="rowgroup">
 ${this.sortedRowIndices.map((rowIndex) => {
            const row = this.parsedRows.find((r) => r.index === rowIndex);
            if (!row)
                return nothing;
            return this.renderRow(row, selected.has(rowIndex));
        })}
 </tbody>
 `;
    }
    renderRow(row, isSelected) {
        return html `
 <tr
 class="${this.getRowClasses(row.index, isSelected)}"
 role="row"
 tabindex="0"
 @click=${(e) => this.handleRowClick(row.index, e)}
 @focus=${() => (this.focusedRowIndex = row.index)}
 >
 ${this.selectable
            ? html `
 <td class="${this.getCellClasses()} w-12" role="cell">
 <input
 type="checkbox"
 class="${this.getCheckboxClasses()}"
 .checked=${isSelected}
 @change=${() => this.handleRowSelect(row.index)}
 aria-label="${this.msg.selectRow} ${row.index + 1}"
 ?disabled=${this.disabled}
 />
 </td>
 `
            : nothing}
 ${row.cells.map((cell) => this.renderCell(cell))}
 </tr>
 `;
    }
    renderCell(content) {
        return html ` <td class="${this.getCellClasses()}" role="cell">${unsafeHTML(content)}</td> `;
    }
    renderEmpty() {
        const colSpan = this.parsedColumns.length + (this.selectable ? 1 : 0);
        const content = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
        return html `
 <tbody role="rowgroup">
 <tr role="row">
 <td colspan="${colSpan}" class="px-4 py-12 text-center ml-text-muted" role="cell">
 ${unsafeHTML(content)}
 </td>
 </tr>
 </tbody>
 `;
    }
    renderLoading() {
        const colSpan = this.parsedColumns.length + (this.selectable ? 1 : 0);
        if (this.hasSlot('Loading')) {
            return html `
 <tbody role="rowgroup">
 <tr role="row">
 <td colspan="${colSpan}" class="px-4 py-8" role="cell">${unsafeHTML(this.getSlotContent('Loading'))}</td>
 </tr>
 </tbody>
 `;
        }
        return html `
 <tbody role="rowgroup">
 ${[1, 2, 3].map(() => html `
 <tr role="row" class="border-b ml-border">
 ${this.selectable
            ? html `
 <td class="px-4 py-3 w-12" role="cell">
 <div class="w-4 h-4 ml-surface-dim-bg rounded animate-pulse"></div>
 </td>
 `
            : nothing}
 ${this.parsedColumns.map(() => html `
 <td class="px-4 py-3" role="cell">
 <div class="h-4 ml-surface-dim-bg rounded animate-pulse"></div>
 </td>
 `)}
 </tr>
 `)}
 </tbody>
 `;
    }
    renderFooter() {
        if (!this.hasSlot('TableFooter'))
            return nothing;
        const footerSlot = this.getSlot('TableFooter');
        if (!footerSlot)
            return nothing;
        const footerRows = Array.from(footerSlot.querySelectorAll('TableRow'));
        return html `
 <tfoot role="rowgroup" class="${cn('ml-surface-dim-bg', this.getSlotClass('TableFooter'))}">
 ${footerRows.map((row) => {
            const cells = Array.from(row.querySelectorAll('TableCell'));
            return html `
 <tr role="row" class="border-t ml-border">
 ${this.selectable ? html `<td class="px-4 py-3" role="cell"></td>` : nothing}
 ${cells.map((cell) => html ` <td class="${this.getCellClasses()}" role="cell">${unsafeHTML(cell.innerHTML)}</td> `)}
 </tr>
 `;
        })}
 </tfoot>
 `;
    }
    renderPagination() {
        if (this.pageSize <= 0)
            return nothing;
        const pages = Array.from({ length: this.totalPages }, (_, i) => i + 1);
        const showEllipsis = this.totalPages > 7;
        return html `
 <nav
 class="flex items-center justify-between px-4 py-3 ml-surface-bg border-t ml-border"
 role="navigation"
 aria-label=${this.msg.pagination}
 >
 <button
 class="${this.getPaginationButtonClasses(this.page === 1)}"
 @click=${() => this.handlePageChange(this.page - 1)}
 ?disabled=${this.page === 1 || this.disabled}
 aria-label=${this.msg.previous}
 >
 <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>`}
 </svg>
 <span class="sr-only">${this.msg.previous}</span>
 </button>

 <div class="flex items-center gap-1">
 ${showEllipsis ? this.renderPaginationWithEllipsis() : pages.map((p) => this.renderPageButton(p))}
 </div>

 <button
 class="${this.getPaginationButtonClasses(this.page === this.totalPages)}"
 @click=${() => this.handlePageChange(this.page + 1)}
 ?disabled=${this.page === this.totalPages || this.disabled}
 aria-label=${this.msg.next}
 >
 <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/>`}
 </svg>
 <span class="sr-only">${this.msg.next}</span>
 </button>
 </nav>
 `;
    }
    renderPaginationWithEllipsis() {
        const pages = [];
        const current = this.page;
        const total = this.totalPages;
        pages.push(1);
        if (current > 3) {
            pages.push('...');
        }
        for (let i = Math.max(2, current - 1); i <= Math.min(total - 1, current + 1); i++) {
            pages.push(i);
        }
        if (current < total - 2) {
            pages.push('...');
        }
        if (total > 1) {
            pages.push(total);
        }
        return html `
 ${pages.map((p) => typeof p === 'string'
            ? html `<span class="px-2 ml-text-faint">...</span>`
            : this.renderPageButton(p))}
 `;
    }
    renderPageButton(pageNum) {
        const isActive = pageNum === this.page;
        const classes = [
            'min-w-[2rem] h-8 px-2 text-sm font-medium rounded transition-colors',
            isActive
                ? 'ml-primary-bg text-white'
                : 'ml-text hover:ml-surface-dim-bg',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].join(' ');
        return html `
 <button
 class="${classes}"
 @click=${() => this.handlePageChange(pageNum)}
 ?disabled=${this.disabled}
 aria-label="${this.msg.page} ${pageNum}"
 aria-current=${isActive ? 'page' : nothing}
 >
 ${pageNum}
 </button>
 `;
    }
    getPaginationButtonClasses(isDisabled) {
        return [
            'p-2 rounded transition-colors',
            'ml-text-muted',
            isDisabled
                ? 'ml-disabled'
                : 'hover:ml-surface-dim-bg cursor-pointer',
        ].join(' ');
    }
    renderError() {
        if (!this.error)
            return nothing;
        return html `
 <div class="px-4 py-3 text-sm ml-error-text ml-error-dim-bg border-t ml-border-error">
 ${this.error}
 </div>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.parseTableStructure();
        return html `
 <div
 class="${cn('overflow-hidden rounded-lg border ml-border ml-surface-bg', this.cssClass)}"
 @keydown=${this.handleKeyDown}
 >
 <div class="overflow-x-auto">
 <table class="${this.getTableClasses()}" role="table">
 ${this.renderCaption()} ${this.renderHeader()} ${this.loading ? this.renderLoading() : this.renderBody()}
 ${this.renderFooter()}
 </table>
 </div>
 ${this.renderPagination()} ${this.renderError()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlInlineEditTableMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlInlineEditTableMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlInlineEditTableMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], MlInlineEditTableMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], MlInlineEditTableMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlInlineEditTableMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlInlineEditTableMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlInlineEditTableMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlInlineEditTableMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlInlineEditTableMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlInlineEditTableMolecule.prototype, "sortDirection", void 0);
__decorate([
    state()
], MlInlineEditTableMolecule.prototype, "focusedRowIndex", void 0);
__decorate([
    state()
], MlInlineEditTableMolecule.prototype, "parsedColumns", void 0);
__decorate([
    state()
], MlInlineEditTableMolecule.prototype, "parsedRows", void 0);
__decorate([
    state()
], MlInlineEditTableMolecule.prototype, "sortedRowIndices", void 0);
MlInlineEditTableMolecule = __decorate([
    customElement('groupviewtable--ml-inline-edit-table')
], MlInlineEditTableMolecule);
export { MlInlineEditTableMolecule };
