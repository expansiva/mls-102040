var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-lcrud-detail-grid.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
import { cellSortKey, compareSortKeys } from '/_102033_/l2/shared/molecules/tableSort.js';
/// **collab_i18n_start**
const message_en = {
    noRecords: 'No records found',
    loading: 'Loading...',
    selectAll: 'Select all rows',
    selectRow: 'Select row',
    openRecord: 'Open record',
    backToList: 'Back to the list',
    recordDetail: 'Record detail',
    pagination: 'Table pagination',
    previousPage: 'Previous page',
    nextPage: 'Next page',
    page: 'Page',
    of: 'of',
    sortAsc: 'sorted ascending',
    sortDesc: 'sorted descending',
};
const messages = {
    en: message_en,
    pt: {
        noRecords: 'Nenhum registro encontrado',
        loading: 'Carregando...',
        selectAll: 'Selecionar todas as linhas',
        selectRow: 'Selecionar linha',
        openRecord: 'Abrir registro',
        backToList: 'Voltar para a lista',
        recordDetail: 'Detalhe do registro',
        pagination: 'Pagina\u00e7\u00e3o da tabela',
        previousPage: 'P\u00e1gina anterior',
        nextPage: 'Pr\u00f3xima p\u00e1gina',
        page: 'P\u00e1gina',
        of: 'de',
        sortAsc: 'ordenado ascendente',
        sortDesc: 'ordenado descendente',
    },
};
let MlLcrudDetailGridMolecule = class MlLcrudDetailGridMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-lcrud-detail-grid {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-root {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-md, var(--ml-radius-sm, 6px));
  box-shadow: var(--ml-shadow-0, none);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-wrap {
  border-radius: var(--ml-radius-md, var(--ml-radius-sm, 6px));
}
groupviewtable--ml-lcrud-detail-grid .ml-table {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-label {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-thead {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-header-row {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-head {
  color: var(--ml-on-surface-muted, #49454f);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  font-weight: var(--ml-font-weight-medium, 500);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-head-sortable:not([aria-disabled='true']):hover {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-head-sorted {
  color: var(--ml-primary, #3b82f6);
  border-bottom-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-tbody {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-row {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-row:hover:not(.ml-table-row-selected):not(.ml-table-row-focused) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-row-selected {
  background: var(--ml-primary-container, #e8f0fe);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-row-selected:hover {
  background: var(--ml-primary-container, #e8f0fe);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-row-focused {
  background: var(--ml-surface-dim, #f5f5f5);
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: calc(-1 * var(--ml-focus-ring-width, 2px));
}
groupviewtable--ml-lcrud-detail-grid .ml-table-cell {
  color: var(--ml-on-surface, #1c1b1f);
  border-bottom-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-select-cell,
groupviewtable--ml-lcrud-detail-grid .ml-grid-open-cell {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-open-btn {
  color: var(--ml-on-surface-muted, #49454f);
  background: transparent;
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) transparent;
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-open-btn:hover:not(:disabled) {
  color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-checkbox {
  accent-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-scene {
  padding: 0.25rem 0 0.5rem;
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-scene-head {
  padding-bottom: 0.75rem;
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-scene-body {
  padding-top: 0.75rem;
  max-width: 60rem;
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-scene-title {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-back-btn {
  color: var(--ml-on-surface-muted, #49454f);
  background: transparent;
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) transparent;
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-back-btn:hover:not(:disabled) {
  color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-back-btn:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: 2px;
}
groupviewtable--ml-lcrud-detail-grid .ml-table-tfoot {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-footer-row {
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-footer-cell {
  color: var(--ml-on-surface-muted, #49454f);
  border-bottom-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-empty-row {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-empty {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-lcrud-detail-grid .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-pagination {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-page-btn {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-page-btn:hover:not(:disabled) {
  color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-page-btn-active {
  color: var(--ml-on-primary, #ffffff);
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-loading {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-lcrud-detail-grid .ml-skeleton {
  background: var(--ml-surface-variant, #e5e7eb);
}
groupviewtable--ml-lcrud-detail-grid .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupviewtable--ml-lcrud-detail-grid .ml-disabled,
groupviewtable--ml-lcrud-detail-grid .ml-grid-open-btn:disabled,
groupviewtable--ml-lcrud-detail-grid .ml-table-page-btn:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-open-btn:focus-visible,
groupviewtable--ml-lcrud-detail-grid .ml-table-head-sortable:focus-visible,
groupviewtable--ml-lcrud-detail-grid .ml-table-checkbox:focus-visible,
groupviewtable--ml-lcrud-detail-grid .ml-table-page-btn:focus-visible,
groupviewtable--ml-lcrud-detail-grid .ml-table-row:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: 2px;
}
groupviewtable--ml-lcrud-detail-grid .ml-grid-open-btn:focus-visible,
groupviewtable--ml-lcrud-detail-grid .ml-table-page-btn:focus-visible {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-lcrud-detail-grid .ml-table-root:has(.ml-table-row-selected) .ml-table-checkbox:checked {
  accent-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-lcrud-detail-grid button:disabled,
groupviewtable--ml-lcrud-detail-grid input:disabled {
  cursor: not-allowed;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [
            'Caption',
            'TableHeader',
            'TableBody',
            'TableRow',
            'TableHead',
            'TableCell',
            'TableFooter',
            'Empty',
            'Loading',
            // Conteúdo que aparece ao expandir a linha. Vai DENTRO da <TableRow>, ao lado das
            // <TableCell>, e é preenchido pelo consumidor depois do `rowClick` — o fluxo lazy.
            'Detail',
        ];
        /** Live slots preserve nested interactive components inside cells and details. */
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES \u2014 From Contract
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
        /**
         * The record whose scene is open, by original-order index — or `null` for the list.
         *
         * A single index, not a set: the scene takes the whole surface, so two records cannot be open at
         * once. This is the only piece of state the scene needs; everything the list holds (page, sort,
         * selection, focus) stays untouched, which is why going back costs nothing.
         */
        this.openIndex = null;
        /** Keyboard-focused row index within the currently visible page. */
        this.focusedRowIndex = -1;
        this.sceneObserver = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.propagateEditing();
    }
    updated(changedProps) {
        // Also on `openIndex`: the scene's content only exists in the DOM after it opens, so a record
        // opened while `isEditing` was already true would never receive the attribute.
        if (changedProps.has('isEditing') || changedProps.has('openIndex')) {
            this.propagateEditing();
        }
        this.watchScene();
    }
    disconnectedCallback() {
        this.sceneObserver?.disconnect();
        this.sceneObserver = null;
        super.disconnectedCallback();
    }
    handleIcaStateChange(key, _value) {
        const isEditingAttr = this.getAttribute('is-editing');
        if (isEditingAttr === `{{${key}}}`) {
            this.propagateEditing();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // IS-EDITING PROPAGATION
    // ===========================================================================
    propagateEditing() {
        const flag = this.isEditing ? 'true' : 'false';
        this.propagateEditingToScene(flag);
        const body = this.getLiveSlot('TableBody');
        if (!body)
            return;
        const cells = body.querySelectorAll('TableCell');
        cells.forEach((cell) => {
            cell.querySelectorAll('*').forEach((el) => {
                if (el.tagName.includes('-'))
                    this.setEditingFlag(el, flag);
            });
        });
    }
    /**
     * Propagates into the OPEN SCENE, reading the projected nodes and not the source.
     *
     * The source `<Detail>` is empty once projected — its children were moved into the anchor — so
     * querying it would find nothing. This runs from `updated()`, after `update()` has projected.
     */
    propagateEditingToScene(flag) {
        const scene = this.querySelector('.ml-grid-scene-body');
        if (!scene)
            return;
        scene.querySelectorAll('*').forEach((el) => {
            if (el.tagName.includes('-'))
                this.setEditingFlag(el, flag);
        });
    }
    /**
     * Writes `is-editing` and MAKES THE ELEMENT RE-RENDER.
     *
     * Setting the attribute alone is not enough, and the reason is subtle: Lit's Boolean converter is
     * `v => v !== null`, so the attribute "false" and the attribute "true" both reach the property
     * setter as `true`. The value does not change, `hasChanged` says no, and the element never
     * re-renders — while the collab getter, which reads the ATTRIBUTE and honours the literal
     * "false", now disagrees with what is on screen.
     *
     * The asymmetry that exposed it: going to read mode appeared to work, because it happens right
     * after saving, when other bindings change and force a render anyway. Going back to edit mode
     * changes nothing else, so the stale view stayed. Measured on 2026-08-05 with
     * `demotable--funcionariosdetalhe`.
     */
    setEditingFlag(el, flag) {
        if (el.getAttribute('is-editing') === flag)
            return;
        el.setAttribute('is-editing', flag);
        el.requestUpdate?.();
    }
    /**
     * Watches the scene for content that arrives LATE, and re-applies the editing flag.
     *
     * Propagating only when `isEditing`/`openIndex` change is not enough, and this is the reason:
     * the scene's content belongs to the consumer and typically arrives one round later — after
     * `rowClick`, when the fetch returns. Those nodes are created INSIDE the anchor, where the
     * consumer's own Lit render puts them, so nothing about them reaches this molecule: they are not
     * inside a slot tag, so the base class's observer ignores them, and no property of ours changed.
     * A field born after the last sweep keeps its own default — and every field molecule in this
     * library defaults to `isEditing = true`, so a record opened for READING would show a form.
     * Measured on 2026-08-05 with `demotable--funcionariosdetalhe`.
     *
     * Only `childList`/`subtree`: the attribute writes are ours, and observing attributes would make
     * this re-enter on its own changes.
     */
    watchScene() {
        this.sceneObserver?.disconnect();
        const scene = this.querySelector('.ml-grid-scene-body');
        if (!scene) {
            this.sceneObserver = null;
            return;
        }
        this.sceneObserver = new MutationObserver(() => {
            this.propagateEditingToScene(this.isEditing ? 'true' : 'false');
        });
        this.sceneObserver.observe(scene, { childList: true, subtree: true });
        // Primeira aplicação: o conteúdo pode já estar aqui quando a âncora nasce.
        this.propagateEditingToScene(this.isEditing ? 'true' : 'false');
    }
    // ===========================================================================
    // PARSERS
    // ===========================================================================
    parseHeaders() {
        const header = this.getLiveSlot('TableHeader');
        if (!header)
            return [];
        const row = header.querySelector('TableRow');
        if (!row)
            return [];
        return Array.from(row.querySelectorAll('TableHead')).map((th) => ({
            key: th.getAttribute('key') || '',
            label: (th.textContent || '').trim(),
            sortable: th.hasAttribute('sortable'),
            element: th,
        }));
    }
    // Sem o fallback `|| this.getSlot(...)`: o `getSlot` lê do SNAPSHOT, e molécula que projeta não
    // pode ler de lá — a origem fica vazia depois da projeção e um re-snapshot leria vazio.
    parseBodyRows() {
        const body = this.getLiveSlot('TableBody');
        if (!body)
            return [];
        return Array.from(body.querySelectorAll(':scope > TableRow')).map((row, index) => ({
            index,
            cells: Array.from(row.querySelectorAll(':scope > TableCell')),
            element: row,
            detailEl: row.querySelector(':scope > Detail'),
        }));
    }
    parseFooterRows() {
        const footer = this.getLiveSlot('TableFooter');
        if (!footer)
            return [];
        return Array.from(footer.querySelectorAll(':scope > TableRow')).map((row, index) => ({
            index,
            cells: Array.from(row.querySelectorAll(':scope > TableCell')),
            element: row,
            detailEl: null,
        }));
    }
    getSelectedSet() {
        const raw = String(this.value ?? '').trim();
        if (!raw)
            return new Set();
        return new Set(raw
            .split(',')
            .map((s) => parseInt(s.trim(), 10))
            .filter((n) => !isNaN(n)));
    }
    // ===========================================================================
    // SORTING
    // ===========================================================================
    /** Cell key, with the text taken from the projected nodes — the source is empty once projected. */
    sortValueOf(cell) {
        return cellSortKey(cell, this.getLiveText(cell));
    }
    getSortedRows(rows, headers) {
        if (!this.sortKey)
            return rows;
        const colIndex = headers.findIndex((h) => h.key === this.sortKey);
        if (colIndex < 0)
            return rows;
        const dir = this.sortDirection === 'asc' ? 1 : -1;
        return [...rows].sort((a, b) => compareSortKeys(this.sortValueOf(a.cells[colIndex]), this.sortValueOf(b.cells[colIndex])) *
            dir);
    }
    handleSort(key) {
        if (this.disabled || this.loading)
            return;
        if (this.sortKey === key) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortKey = key;
            this.sortDirection = 'asc';
        }
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true,
            composed: true,
            detail: { key: this.sortKey, direction: this.sortDirection },
        }));
    }
    // ===========================================================================
    // SELECTION
    // ===========================================================================
    emitChange(selected) {
        const next = Array.from(selected)
            .sort((a, b) => a - b)
            .join(',');
        this.value = next;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: next },
        }));
    }
    handleToggleRow(index, e) {
        if (e)
            e.stopPropagation();
        if (this.disabled || this.loading || !this.selectable)
            return;
        const selected = this.getSelectedSet();
        if (selected.has(index)) {
            selected.delete(index);
        }
        else {
            selected.add(index);
        }
        this.emitChange(selected);
    }
    handleToggleAll(visibleRows) {
        if (this.disabled || this.loading || !this.selectable)
            return;
        const selected = this.getSelectedSet();
        const indices = visibleRows.map((r) => r.index);
        const allSelected = indices.length > 0 && indices.every((i) => selected.has(i));
        if (allSelected) {
            indices.forEach((i) => selected.delete(i));
        }
        else {
            indices.forEach((i) => selected.add(i));
        }
        this.emitChange(selected);
    }
    // ===========================================================================
    // SCENE (record detail)
    // ===========================================================================
    handleOpenRecord(index, e) {
        if (e) {
            e.stopPropagation();
            e.preventDefault();
        }
        if (this.disabled || this.loading)
            return;
        if (this.openIndex === index)
            return;
        this.openIndex = index;
        // Same contract as the accordion sibling: `rowClick` is the signal for the consumer to load
        // this record's detail on demand and write it inside that row's `<Detail>`.
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true,
            composed: true,
            detail: { index },
        }));
    }
    /**
     * Back to the list.
     *
     * Emits NOTHING on purpose. `pageChange` would be the wrong signal — a consumer in EXTERNAL mode
     * reacts to it by requerying and rewriting `<TableBody>`, which is exactly the repaint this
     * molecule exists to avoid, and it would say "the page changed" when it did not. A dedicated
     * event can be added to the group contract later, when a consumer actually needs it.
     */
    handleBackToList(e) {
        if (e) {
            e.stopPropagation();
            e.preventDefault();
        }
        this.openIndex = null;
    }
    // ===========================================================================
    // PAGINATION
    // ===========================================================================
    /**
     * Total pages, counting the rows in INTERNAL mode.
     *
     * `total-items` unset means the consumer wrote the WHOLE set in `<TableBody>`, so the row count
     * is the total — §9.1 of the group contract. Returning 1 here (the previous behaviour) made the
     * two halves of pagination disagree: `render()` still sliced to `pageSize`, but the control was
     * born with "next" disabled, and `handlePageChange` clamped every page to 1. With 8 rows and
     * `page-size="5"`, the last 3 were rendered nowhere and unreachable. Measured on 2026-08-05 with
     * `demotable--pedidosdetalhe`.
     */
    getTotalPages() {
        const size = Number(this.pageSize) || 0;
        if (size <= 0)
            return 1;
        const declared = Number(this.totalItems) || 0;
        const total = declared > 0 ? declared : this.parseBodyRows().length;
        if (total <= 0)
            return 1;
        return Math.max(1, Math.ceil(total / size));
    }
    handlePageChange(nextPage) {
        if (this.disabled || this.loading)
            return;
        const totalPages = this.getTotalPages();
        const page = Math.min(Math.max(1, nextPage), totalPages);
        if (page === this.page)
            return;
        this.page = page;
        this.focusedRowIndex = -1;
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true,
            composed: true,
            detail: { page },
        }));
    }
    // ===========================================================================
    // KEYBOARD NAVIGATION
    // ===========================================================================
    handleTableKeyDown(e, visibleRows) {
        if (this.disabled || this.loading)
            return;
        const count = visibleRows.length;
        if (count === 0)
            return;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.focusedRowIndex =
                this.focusedRowIndex < 0 ? 0 : Math.min(this.focusedRowIndex + 1, count - 1);
        }
        else if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.focusedRowIndex =
                this.focusedRowIndex < 0 ? count - 1 : Math.max(this.focusedRowIndex - 1, 0);
        }
        else if (e.key === ' ' || e.key === 'Spacebar') {
            if (this.focusedRowIndex >= 0 && this.focusedRowIndex < count && this.selectable) {
                e.preventDefault();
                this.handleToggleRow(visibleRows[this.focusedRowIndex].index);
            }
        }
        else if (e.key === 'Enter') {
            if (this.focusedRowIndex >= 0 && this.focusedRowIndex < count) {
                e.preventDefault();
                this.handleOpenRecord(visibleRows[this.focusedRowIndex].index);
            }
        }
    }
    handleHeaderKeyDown(e, key, sortable) {
        if (!sortable || this.disabled || this.loading)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleSort(key);
        }
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getRootClasses() {
        return cn([
            'flex w-full flex-col gap-2',
            'ml-table-root',
            this.disabled ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' '), this.cssClass);
    }
    getTableWrapClasses() {
        return ['w-full overflow-x-auto', 'ml-table-wrap'].filter(Boolean).join(' ');
    }
    getTableClasses() {
        return ['w-full border-collapse text-sm', 'ml-table'].filter(Boolean).join(' ');
    }
    getHeadCellClasses(header) {
        const isActive = this.sortKey === header.key;
        return [
            'px-3 py-2 text-left font-semibold',
            'ml-table-head',
            header.sortable ? 'ml-table-head-sortable cursor-pointer select-none' : '',
            isActive ? 'ml-table-head-sorted' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getBodyRowClasses(isSelected, isFocused) {
        return [
            'ml-table-row',
            isSelected ? 'ml-table-row-selected' : '',
            isFocused ? 'ml-table-row-focused' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getOpenBtnClasses() {
        return [
            'inline-flex items-center justify-center w-7 h-7 rounded-md',
            'ml-grid-open-btn',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSceneClasses() {
        return ['flex w-full flex-col gap-3', 'ml-grid-scene'].filter(Boolean).join(' ');
    }
    getBackBtnClasses() {
        return [
            'inline-flex items-center gap-1 h-8 px-2 rounded-md text-sm',
            'ml-grid-back-btn',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCheckboxClasses() {
        return ['ml-table-checkbox'].filter(Boolean).join(' ');
    }
    getPaginationClasses() {
        return [
            'flex w-full items-center justify-between gap-2 px-1 py-2 text-sm',
            'ml-table-pagination',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getPageBtnClasses(active, navDisabled) {
        return [
            'inline-flex items-center justify-center min-w-[2rem] h-8 px-2 rounded-md text-sm',
            'ml-table-page-btn',
            active ? 'ml-table-page-btn-active' : '',
            navDisabled ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // SVG ICONS
    // ===========================================================================
    /**
     * Chevron pointing RIGHT, and it never rotates.
     *
     * The accordion sibling points DOWN because the content opens underneath. Here the record opens
     * elsewhere, so the arrow reads as navigation. There is no open state to show in the list either
     * — when a record is open, the list is not on screen.
     */
    renderOpenIcon() {
        return html `
      <svg class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        ${svg `<path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />`}
      </svg>
    `;
    }
    /** Chevron pointing LEFT, for the back control. */
    renderBackIcon() {
        return html `
      <svg class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        ${svg `<path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />`}
      </svg>
    `;
    }
    renderSortIcon(key) {
        if (this.sortKey !== key) {
            return html `
        <svg class="w-3.5 h-3.5 ml-1 inline-block opacity-40" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          ${svg `<path d="M5 8l5-5 5 5H5zm0 4l5 5 5-5H5z" />`}
        </svg>
      `;
        }
        if (this.sortDirection === 'asc') {
            return html `
        <svg class="w-3.5 h-3.5 ml-1 inline-block" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          ${svg `<path fill-rule="evenodd" d="M14.707 12.707a1 1 0 01-1.414 0L10 9.414l-3.293 3.293a1 1 0 01-1.414-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 010 1.414z" clip-rule="evenodd" />`}
        </svg>
      `;
        }
        return html `
      <svg class="w-3.5 h-3.5 ml-1 inline-block" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        ${svg `<path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />`}
      </svg>
    `;
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderCaption() {
        if (!this.hasSlot('Caption'))
            return html ``;
        return html `
      <caption class=${cn('text-left px-3 py-2 text-sm font-semibold ml-label', this.getSlotClass('Caption'))}>
        ${this.renderLiveSlot('Caption')}
      </caption>
    `;
    }
    renderSelectAllCell(visibleRows) {
        if (!this.selectable)
            return html ``;
        const selected = this.getSelectedSet();
        const indices = visibleRows.map((r) => r.index);
        const allSelected = indices.length > 0 && indices.every((i) => selected.has(i));
        const someSelected = indices.some((i) => selected.has(i)) && !allSelected;
        return html `
      <th class="w-10 px-2 py-2 ml-table-head ml-table-select-cell" scope="col">
        <input
          type="checkbox"
          class=${this.getCheckboxClasses()}
          .checked=${allSelected}
          .indeterminate=${someSelected}
          ?disabled=${this.disabled || this.loading}
          aria-label=${this.msg.selectAll}
          @change=${(e) => {
            e.stopPropagation();
            this.handleToggleAll(visibleRows);
        }}
          @input=${(e) => e.stopPropagation()}
          @click=${(e) => e.stopPropagation()}
        />
      </th>
    `;
    }
    renderOpenHeadCell() {
        // Untitled control column, LAST — it opens the record's scene.
        return html `
      <th class="w-10 px-2 py-2 ml-table-head ml-grid-open-cell" scope="col">
        <span class="sr-only">${this.msg.openRecord}</span>
      </th>
    `;
    }
    renderHeader(headers, visibleRows) {
        return html `
      <thead class="ml-table-thead" role="rowgroup">
        <tr class="ml-table-header-row" role="row">
          ${this.renderSelectAllCell(visibleRows)}
          ${headers.map((header) => {
            const isActive = this.sortKey === header.key;
            const ariaSort = !header.sortable
                ? nothing
                : isActive
                    ? this.sortDirection === 'asc'
                        ? 'ascending'
                        : 'descending'
                    : 'none';
            return html `
              <th
                class=${this.getHeadCellClasses(header)}
                scope="col"
                role="columnheader"
                aria-sort=${ariaSort}
                tabindex=${header.sortable && !this.disabled ? '0' : nothing}
                @click=${() => header.sortable && this.handleSort(header.key)}
                @keydown=${(e) => this.handleHeaderKeyDown(e, header.key, header.sortable)}
              >
                <span class="inline-flex items-center">
                  ${header.element
                ? this.renderLiveSlotFrom(header.element)
                : html `${header.label}`}
                  ${header.sortable ? this.renderSortIcon(header.key) : nothing}
                </span>
              </th>
            `;
        })}
          ${this.renderOpenHeadCell()}
        </tr>
      </thead>
    `;
    }
    renderSelectCell(rowIndex, isSelected) {
        if (!this.selectable)
            return html ``;
        return html `
      <td class="w-10 px-2 py-2 ml-table-cell ml-table-select-cell" role="cell">
        <input
          type="checkbox"
          class=${this.getCheckboxClasses()}
          .checked=${isSelected}
          ?disabled=${this.disabled || this.loading}
          aria-label=${`${this.msg.selectRow} ${rowIndex + 1}`}
          @change=${(e) => this.handleToggleRow(rowIndex, e)}
          @input=${(e) => e.stopPropagation()}
          @click=${(e) => e.stopPropagation()}
        />
      </td>
    `;
    }
    renderOpenCell(rowIndex) {
        // No `aria-expanded`: nothing expands here. The button navigates to the record's scene.
        return html `
      <td class="w-10 px-2 py-2 ml-table-cell ml-grid-open-cell" role="cell">
        <button
          type="button"
          class=${this.getOpenBtnClasses()}
          ?disabled=${this.disabled || this.loading}
          aria-label=${`${this.msg.openRecord} ${rowIndex + 1}`}
          @click=${(e) => this.handleOpenRecord(rowIndex, e)}
        >
          ${this.renderOpenIcon()}
        </button>
      </td>
    `;
    }
    renderDataCells(cells) {
        return cells.map((cell) => html `
        <td class=${cn('px-3 py-2 ml-table-cell', cell.getAttribute('data-class') || '')} role="cell">
          ${this.renderLiveSlotFrom(cell)}
        </td>
      `);
    }
    /**
     * The scene: the open record's `<Detail>`, projected live, with a frame around it.
     *
     * The frame is only a heading and the back control — everything else is the consumer's, inside
     * the `<Detail>`, including save and cancel. The heading comes from `<Detail label="…">`: the
     * molecule cannot know which column names the record, and reading the first cell would produce
     * the composite text of an avatar plus name plus e-mail.
     *
     * Without a `<Detail>` the body stays empty, which is the right state while the consumer is
     * still fetching after `rowClick`.
     */
    renderScene(row) {
        const label = (row.detailEl?.getAttribute('label') || '').trim();
        return html `
      <section
        class=${this.getSceneClasses()}
        role="region"
        aria-label=${label || this.msg.recordDetail}
        data-scene-for=${row.index}
      >
        <header class="flex items-center gap-2 ml-grid-scene-head">
          <button
            type="button"
            class=${this.getBackBtnClasses()}
            aria-label=${this.msg.backToList}
            @click=${(e) => this.handleBackToList(e)}
          >
            ${this.renderBackIcon()}
            <span>${this.msg.backToList}</span>
          </button>
          ${label
            ? html `<h3 class="text-sm font-semibold ml-grid-scene-title">${label}</h3>`
            : nothing}
        </header>
        <div class="ml-grid-scene-body">
          ${row.detailEl ? this.renderLiveSlotFrom(row.detailEl) : nothing}
        </div>
      </section>
    `;
    }
    renderBodyRow(row, visibleIndex, selected) {
        const isSelected = selected.has(row.index);
        const isFocused = this.focusedRowIndex === visibleIndex;
        return html `
      <tr
        class=${this.getBodyRowClasses(isSelected, isFocused)}
        role="row"
        tabindex=${!this.disabled ? '0' : nothing}
        aria-selected=${this.selectable ? (isSelected ? 'true' : 'false') : nothing}
        data-row-index=${row.index}
        @click=${(e) => {
            // Ignore clicks originating from interactive controls inside the row
            const target = e.target;
            if (target.closest('button, input, a, select, textarea, [role="button"]')) {
                return;
            }
        }}
      >
        ${this.renderSelectCell(row.index, isSelected)}
        ${this.renderDataCells(row.cells)}
        ${this.renderOpenCell(row.index)}
      </tr>
    `;
    }
    renderBody(rows, headers, selected) {
        // Optional select col + data columns + the trailing open col
        const colSpan = (this.selectable ? 1 : 0) + headers.length + 1;
        if (rows.length === 0) {
            return html `
        <tbody class="ml-table-tbody" role="rowgroup">
          <tr class="ml-table-empty-row" role="row">
            <td class="px-3 py-6 text-center ml-table-cell ml-text-muted" role="cell" colspan=${colSpan}>
              ${this.renderEmptyContent()}
            </td>
          </tr>
        </tbody>
      `;
        }
        return html `
      <tbody class="ml-table-tbody" role="rowgroup">
        ${rows.map((row, i) => this.renderBodyRow(row, i, selected))}
      </tbody>
    `;
    }
    renderFooter(headers) {
        const footerRows = this.parseFooterRows();
        if (footerRows.length === 0)
            return html ``;
        // Only the selection column pads on the LEFT now; the control column is at the end, so the
        // footer closes with one empty cell instead of opening with it.
        const colPad = this.selectable ? 1 : 0;
        return html `
      <tfoot class="ml-table-tfoot" role="rowgroup">
        ${footerRows.map((row) => html `
            <tr class="ml-table-footer-row" role="row">
              ${colPad > 0
            ? html `<td class="ml-table-cell" role="cell" colspan=${colPad}></td>`
            : nothing}
              ${row.cells.map((cell) => html `
                  <td
                    class=${cn('px-3 py-2 ml-table-cell ml-table-footer-cell', cell.getAttribute('data-class') || '')}
                    role="cell"
                  >
                    ${this.renderLiveSlotFrom(cell)}
                  </td>
                `)}
              <td class="ml-table-cell ml-grid-open-cell" role="cell"></td>
            </tr>
          `)}
      </tfoot>
    `;
    }
    renderEmptyContent() {
        if (this.hasSlot('Empty')) {
            return html `
        <div class=${cn('ml-table-empty', this.getSlotClass('Empty'))}>
          ${this.renderLiveSlot('Empty')}
        </div>
      `;
        }
        return html `<span class="ml-text-muted">${this.msg.noRecords}</span>`;
    }
    renderLoading() {
        if (this.hasSlot('Loading')) {
            return html `
        <div class=${cn('w-full p-4 ml-table-loading', this.getSlotClass('Loading'))}>
          ${this.renderLiveSlot('Loading')}
        </div>
      `;
        }
        return html `
      <div class="w-full flex flex-col gap-2 p-4 ml-table-loading" aria-busy="true" aria-live="polite">
        ${[0, 1, 2].map(() => html `
            <div class="w-full h-10 rounded-md ml-skeleton"></div>
          `)}
        <span class="sr-only">${this.msg.loading}</span>
      </div>
    `;
    }
    renderError() {
        const err = String(this.error ?? '').trim();
        if (!err)
            return html ``;
        return html `
      <p class="mt-1 text-xs ml-error-text" role="alert">${unsafeHTML(err)}</p>
    `;
    }
    renderPagination() {
        const size = Number(this.pageSize) || 0;
        if (size <= 0)
            return html ``;
        const totalPages = this.getTotalPages();
        const current = Math.min(Math.max(1, Number(this.page) || 1), totalPages);
        const prevDisabled = this.disabled || this.loading || current <= 1;
        const nextDisabled = this.disabled || this.loading || current >= totalPages;
        // Build a compact page list around the current page
        const pages = [];
        const windowSize = 5;
        let start = Math.max(1, current - Math.floor(windowSize / 2));
        let end = Math.min(totalPages, start + windowSize - 1);
        start = Math.max(1, end - windowSize + 1);
        for (let p = start; p <= end; p++)
            pages.push(p);
        return html `
      <nav
        class=${this.getPaginationClasses()}
        role="navigation"
        aria-label=${this.msg.pagination}
      >
        <span class="ml-text-muted text-xs">
          ${this.msg.page} ${current} ${this.msg.of} ${totalPages}
        </span>
        <div class="flex items-center gap-1">
          <button
            type="button"
            class=${this.getPageBtnClasses(false, prevDisabled)}
            ?disabled=${prevDisabled}
            aria-label=${this.msg.previousPage}
            @click=${() => this.handlePageChange(current - 1)}
          >
            <svg class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
              ${svg `<path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />`}
            </svg>
          </button>
          ${pages.map((p) => html `
              <button
                type="button"
                class=${this.getPageBtnClasses(p === current, this.disabled || this.loading)}
                ?disabled=${this.disabled || this.loading}
                aria-label=${`${this.msg.page} ${p}`}
                aria-current=${p === current ? 'page' : nothing}
                @click=${() => this.handlePageChange(p)}
              >
                ${p}
              </button>
            `)}
          <button
            type="button"
            class=${this.getPageBtnClasses(false, nextDisabled)}
            ?disabled=${nextDisabled}
            aria-label=${this.msg.nextPage}
            @click=${() => this.handlePageChange(current + 1)}
          >
            <svg class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
              ${svg `<path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />`}
            </svg>
          </button>
        </div>
      </nav>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const headers = this.parseHeaders();
        const allRows = this.parseBodyRows();
        // Em modo EXTERNO a molécula não reordena: ela recebeu só a página corrente, e ordenar aqui
        // ordenaria 10 linhas de 60. O evento `sort` continua saindo para o consumidor reconsultar.
        // Mesma regra da ml-data-table-minimal e da ml-responsive-data-table.
        const externo = Number(this.totalItems) > allRows.length;
        const sortedRows = externo ? allRows : this.getSortedRows(allRows, headers);
        const selected = this.getSelectedSet();
        // When pageSize > 0 and totalItems is managed externally, body already holds
        // the current page's rows. Local slice only applies when totalItems is unset
        // and the full dataset is present in TableBody.
        let visibleRows = sortedRows;
        const size = Number(this.pageSize) || 0;
        const total = Number(this.totalItems) || 0;
        if (size > 0 && total <= 0 && sortedRows.length > size) {
            const current = Math.max(1, Number(this.page) || 1);
            const start = (current - 1) * size;
            visibleRows = sortedRows.slice(start, start + size);
        }
        // The open record is looked up among ALL rows, not the visible ones: the consumer may reorder
        // or repaginate while the scene is open, and the scene must keep showing the record it opened.
        const openRow = this.openIndex === null ? null : allRows.find((r) => r.index === this.openIndex) ?? null;
        return html `
      <div
        class=${this.getRootClasses()}
        @keydown=${(e) => this.handleTableKeyDown(e, visibleRows)}
      >
        ${this.loading
            ? this.renderLoading()
            : html `
              <!--
                The list is HIDDEN, never unrendered, and that is the whole point of this molecule.
                \`hidden\` keeps page, sort order, selection, focus and scroll intact, and keeps every
                nested molecule in the cells connected — unrendering would disconnect them and
                re-run the inert check when the user comes back. It must be \`hidden\`/\`display:none\`
                and not \`visibility\`/\`opacity\`, or the screen reader and Tab would still reach a
                list that is not on screen.
              -->
              <div class=${this.getTableWrapClasses()} ?hidden=${openRow !== null}>
                <table
                  class=${this.getTableClasses()}
                  role="table"
                  aria-busy=${this.loading ? 'true' : 'false'}
                  aria-disabled=${this.disabled ? 'true' : 'false'}
                >
                  ${this.renderCaption()}
                  ${this.renderHeader(headers, visibleRows)}
                  ${this.renderBody(visibleRows, headers, selected)}
                  ${this.renderFooter(headers)}
                </table>
              </div>
              <div ?hidden=${openRow !== null}>${this.renderPagination()}</div>
              ${openRow ? this.renderScene(openRow) : nothing}
            `}
        ${this.renderError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlLcrudDetailGridMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlLcrudDetailGridMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlLcrudDetailGridMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], MlLcrudDetailGridMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], MlLcrudDetailGridMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlLcrudDetailGridMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlLcrudDetailGridMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlLcrudDetailGridMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlLcrudDetailGridMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlLcrudDetailGridMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlLcrudDetailGridMolecule.prototype, "sortDirection", void 0);
__decorate([
    state()
], MlLcrudDetailGridMolecule.prototype, "openIndex", void 0);
__decorate([
    state()
], MlLcrudDetailGridMolecule.prototype, "focusedRowIndex", void 0);
MlLcrudDetailGridMolecule = __decorate([
    customElement('groupviewtable--ml-lcrud-detail-grid')
], MlLcrudDetailGridMolecule);
export { MlLcrudDetailGridMolecule };
