var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-side-detail-table.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cellSortKey, compareSortKeys } from '/_102033_/l2/shared/molecules/tableSort.js';
let DetailPanelTableMolecule = class DetailPanelTableMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-side-detail-table {
  font-family: var(--ml-font-family, system-ui);
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-0, none);
}
groupviewtable--ml-side-detail-table .ml-table-layout {
  color: var(--ml-on-surface, #1c1b1f);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-side-detail-table .ml-table-region {
  min-width: 0;
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-side-detail-table .ml-caption,
groupviewtable--ml-side-detail-table .ml-label {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
  letter-spacing: 0.02em;
}
groupviewtable--ml-side-detail-table .ml-caption {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-side-detail-table .ml-table-scroll {
  background: var(--ml-surface, #ffffff);
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-side-detail-table .ml-table {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-style: var(--ml-border-style, solid);
  border-width: var(--ml-border-width, 1px);
  border-collapse: collapse;
}
groupviewtable--ml-side-detail-table .ml-table-header {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-side-detail-table .ml-table-header th {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-side-detail-table .ml-table-body,
groupviewtable--ml-side-detail-table .ml-table-footer {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-side-detail-table .ml-table-row {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-side-detail-table .ml-table-row:not(.ml-disabled):not(.ml-selected):not(.ml-active-row):hover,
groupviewtable--ml-side-detail-table .ml-sortable-header:not(.ml-sorted):hover {
  background: var(--ml-surface-variant, #f5f5f5);
}
groupviewtable--ml-side-detail-table .ml-table-row:focus-visible,
groupviewtable--ml-side-detail-table .ml-sortable-header:focus-visible,
groupviewtable--ml-side-detail-table .ml-pagination-button:focus-visible,
groupviewtable--ml-side-detail-table .ml-detail-close:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: -1px;
}
groupviewtable--ml-side-detail-table .ml-selected {
  background: var(--ml-primary-container, #dbeafe);
  color: var(--ml-on-primary-container, #1c1b1f);
}
groupviewtable--ml-side-detail-table .ml-selected:hover {
  background: var(--ml-primary-container, #dbeafe);
}
groupviewtable--ml-side-detail-table .ml-active-row {
  background: var(--ml-surface-variant, #f5f5f5);
  box-shadow: inset 3px 0 0 var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-side-detail-table .ml-active-row.ml-selected {
  background: var(--ml-primary-container, #dbeafe);
  box-shadow: inset 3px 0 0 var(--ml-primary, #3b82f6);
}
groupviewtable--ml-side-detail-table .ml-editing {
  background: var(--ml-surface-variant, #f5f5f5);
}
groupviewtable--ml-side-detail-table .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-side-detail-table .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-side-detail-table .ml-error-text {
  color: var(--ml-error, #ef4444);
  background: var(--ml-error-dim, #fef2f2);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-error-border, #ef4444);
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-side-detail-table .ml-sortable-header {
  color: var(--ml-on-surface, #1c1b1f);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-side-detail-table .ml-sorted,
groupviewtable--ml-side-detail-table .ml-sort-indicator {
  color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-side-detail-table .ml-sort-indicator {
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-side-detail-table .ml-table-footer {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-side-detail-table .ml-table-footer td {
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-side-detail-table .ml-table-pagination {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-side-detail-table .ml-pagination-button,
groupviewtable--ml-side-detail-table .ml-detail-close {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-0, none);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-side-detail-table .ml-pagination-button:not(:disabled):hover,
groupviewtable--ml-side-detail-table .ml-detail-close:not(:disabled):hover {
  color: var(--ml-on-primary, #ffffff);
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-side-detail-table .ml-pagination-button:disabled,
groupviewtable--ml-side-detail-table .ml-detail-close:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupviewtable--ml-side-detail-table .ml-surface-bg {
  background: var(--ml-surface-overlay, #ffffff);
}
groupviewtable--ml-side-detail-table .ml-detail-panel {
  flex: 0 1 24rem;
  min-width: 16rem;
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupviewtable--ml-side-detail-table .ml-detail-content {
  color: var(--ml-on-surface, #1c1b1f);
  font-size: 1rem;
  line-height: 1.55;
}
groupviewtable--ml-side-detail-table .ml-detail-content img,
groupviewtable--ml-side-detail-table .ml-detail-content table,
groupviewtable--ml-side-detail-table .ml-detail-content video,
groupviewtable--ml-side-detail-table .ml-detail-content pre {
  max-width: 100%;
}
groupviewtable--ml-side-detail-table .ml-loading,
groupviewtable--ml-side-detail-table .ml-empty {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-side-detail-table .ml-skeleton {
  color: var(--ml-on-surface-faint, #79747e);
  background: var(--ml-surface-dim, #f5f5f5);
  transition: none;
}
groupviewtable--ml-side-detail-table .ml-loading,
groupviewtable--ml-side-detail-table .ml-empty,
groupviewtable--ml-side-detail-table .ml-detail-content,
groupviewtable--ml-side-detail-table .ml-pagination-button,
groupviewtable--ml-side-detail-table .ml-detail-close {
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-side-detail-table .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupviewtable--ml-side-detail-table .ml-detail-open .ml-detail-panel {
  box-shadow: var(--ml-shadow-2, 0 4px 6px rgba(0, 0, 0, 0.1));
}
groupviewtable--ml-side-detail-table .ml-fit-height {
  min-height: 100%;
}
@media (max-width: 700px) {
  groupviewtable--ml-side-detail-table .ml-detail-open .ml-table-region {
    display: none;
  }
  groupviewtable--ml-side-detail-table .ml-detail-open .ml-detail-panel {
    display: block;
    flex: 1 1 auto;
    min-width: 0;
  }
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [
            'Caption', 'TableHeader', 'TableBody', 'TableRow', 'TableHead', 'TableCell',
            'TableFooter', 'Empty', 'Loading', 'Detail', 'RowActions', 'RowAction', 'NewRecordRow',
        ];
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — groupViewTable contract
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        this.fitHeight = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
        this.openRow = null;
    }
    // ===========================================================================
    // STRUCTURE HELPERS
    // ===========================================================================
    bodyRows() {
        const body = this.getLiveSlot('TableBody');
        return body ? Array.from(body.querySelectorAll(':scope > TableRow')) : [];
    }
    headerCells() {
        const header = this.getLiveSlot('TableHeader');
        const row = header?.querySelector(':scope > TableRow');
        return row ? Array.from(row.querySelectorAll(':scope > TableHead')) : [];
    }
    rowCells(row) {
        return Array.from(row.querySelectorAll(':scope > TableCell'));
    }
    rowDetail(row) {
        return row?.querySelector(':scope > Detail') ?? null;
    }
    externalMode(rows) {
        return Number(this.totalItems) > rows.length;
    }
    totalPages(rowCount) {
        const size = Number(this.pageSize) || 0;
        if (!size)
            return 1;
        const total = this.externalMode(this.bodyRows()) ? Number(this.totalItems) : rowCount;
        return Math.max(1, Math.ceil(total / size));
    }
    displayedRows(rows) {
        const indexed = rows.map((row, index) => ({ row, index }));
        if (this.externalMode(rows))
            return indexed;
        let ordered = indexed;
        if (this.sortKey) {
            const column = this.headerCells().findIndex((head) => head.getAttribute('key') === this.sortKey);
            if (column >= 0) {
                ordered = [...indexed].sort((left, right) => {
                    const leftCell = this.rowCells(left.row)[column];
                    const rightCell = this.rowCells(right.row)[column];
                    const leftKey = cellSortKey(leftCell, this.getLiveText(leftCell));
                    const rightKey = cellSortKey(rightCell, this.getLiveText(rightCell));
                    const direction = this.sortDirection === 'asc' ? 1 : -1;
                    return compareSortKeys(leftKey, rightKey) * direction;
                });
            }
        }
        const size = Number(this.pageSize) || 0;
        const currentPage = Math.max(1, Number(this.page) || 1);
        const start = (currentPage - 1) * size;
        return size ? ordered.slice(start, start + size) : ordered;
    }
    selectedIndices() {
        return new Set(String(this.value ?? '').split(',').map(Number)
            .filter((index) => Number.isInteger(index) && index >= 0));
    }
    rowKey(row, index) {
        return row.getAttribute('key') || String(index);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    emit(name, detail) {
        this.dispatchEvent(new CustomEvent(name, { bubbles: true, composed: true, detail }));
    }
    handleSort(head) {
        if (this.disabled || !head.hasAttribute('sortable'))
            return;
        const key = head.getAttribute('key') || '';
        this.sortDirection = this.sortKey === key && this.sortDirection === 'asc' ? 'desc' : 'asc';
        this.sortKey = key;
        this.emit('sort', { key, direction: this.sortDirection });
    }
    handlePage(page) {
        if (this.disabled || page < 1 || page > this.totalPages(this.bodyRows().length))
            return;
        this.emit('pageChange', { page });
    }
    handleRowClick(row, index, event) {
        if (this.disabled)
            return;
        const target = event.target;
        if (target.closest('input, button, select, textarea, [data-row-action], RowAction'))
            return;
        this.openRow = row;
        this.emit('rowClick', { index });
    }
    handleRowKey(row, index, event) {
        if (event.key === 'Enter')
            this.handleRowClick(row, index, event);
        if (event.key === ' ' && this.selectable) {
            event.preventDefault();
            this.toggleSelection(index);
        }
    }
    updateSelection(indices) {
        const value = [...indices].sort((a, b) => a - b).join(',');
        this.value = value;
        this.emit('change', { value });
    }
    toggleSelection(index) {
        if (this.disabled || !this.selectable)
            return;
        const selected = this.selectedIndices();
        if (selected.has(index))
            selected.delete(index);
        else
            selected.add(index);
        this.updateSelection(selected);
    }
    toggleAll(rows) {
        if (this.disabled || !this.selectable)
            return;
        const selected = this.selectedIndices();
        const allSelected = rows.length > 0 && rows.every((_, index) => selected.has(index));
        rows.forEach((_, index) => allSelected ? selected.delete(index) : selected.add(index));
        this.updateSelection(selected);
    }
    handleClose() {
        if (this.disabled)
            return;
        this.openRow = null;
    }
    // ===========================================================================
    // EDITING PROPAGATION
    // ===========================================================================
    propagateEditing(rows) {
        const ownsEditing = this.getAttribute('is-editing') !== null
            || this.getAttribute('editing-rows') !== null
            || this.isEditing || this.editingRows !== undefined;
        if (!ownsEditing)
            return;
        const openKeys = new Set(String(this.editingRows ?? '').split(',')
            .map((key) => key.trim()).filter(Boolean));
        const mark = (root, editing) => {
            root.querySelectorAll('*').forEach((child) => {
                if (child.tagName.includes('-'))
                    child.setAttribute('is-editing', String(editing));
            });
        };
        rows.forEach((row, index) => {
            const editing = this.isEditing || openKeys.has(this.rowKey(row, index));
            mark(row, editing);
            const rendered = this.querySelector(`tr[data-source-index="${index}"]`);
            if (rendered)
                mark(rendered, editing);
        });
    }
    updated() {
        this.propagateEditing(this.bodyRows());
    }
    handleIcaStateChange(key, value) {
        const editing = this.getAttribute('is-editing');
        const rows = this.getAttribute('editing-rows');
        if (editing === `{{${key}}}` || rows === `{{${key}}}`)
            this.propagateEditing(this.bodyRows());
        this.requestUpdate();
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderHeader(heads, rows) {
        const selected = this.selectedIndices();
        const allSelected = rows.length > 0 && rows.every((_, index) => selected.has(index));
        return html `<thead class="ml-table-header"><tr role="row">
      ${this.selectable ? html `<th role="columnheader" class="p-2"><input type="checkbox"
        .checked=${allSelected} aria-label="Select all rows" ?disabled=${this.disabled}
        @input=${(event) => event.stopPropagation()}
        @change=${(event) => { event.stopPropagation(); this.toggleAll(rows); }}></th>` : nothing}
      ${heads.map((head) => {
            const key = head.getAttribute('key') || '';
            const active = this.sortKey === key;
            const direction = active && this.sortDirection === 'desc' ? 'descending' : 'ascending';
            const sortable = head.hasAttribute('sortable');
            const classes = ['p-3 text-left text-sm font-semibold ml-label', sortable ? 'ml-sortable-header cursor-pointer' : '', active ? 'ml-sorted' : ''].filter(Boolean).join(' ');
            return html `<th role="columnheader" tabindex="${sortable ? '0' : '-1'}"
          aria-sort=${sortable ? (active ? direction : 'none') : nothing} class="${classes}"
          @click=${() => this.handleSort(head)} @keydown=${(event) => {
                if (sortable && (event.key === 'Enter' || event.key === ' ')) {
                    event.preventDefault();
                    this.handleSort(head);
                }
            }}>${this.renderLiveSlotFrom(head)}${sortable ? html `<span aria-hidden="true" class="ml-sort-indicator">${active ? (this.sortDirection === 'asc' ? ' ↑' : ' ↓') : ''}</span>` : nothing}</th>`;
        })}
    </tr></thead>`;
    }
    renderBody(rows) {
        const selected = this.selectedIndices();
        return html `<tbody class="ml-table-body">${this.displayedRows(rows).map(({ row, index }) => {
            const rowEditing = this.isEditing || String(this.editingRows ?? '').split(',').map((key) => key.trim()).includes(this.rowKey(row, index));
            const classes = ['ml-table-row', selected.has(index) ? 'ml-selected' : '', this.openRow === row ? 'ml-active-row' : '', rowEditing ? 'ml-editing' : '', this.disabled ? 'ml-disabled' : ''].filter(Boolean).join(' ');
            return html `<tr role="row" tabindex="0" data-source-index="${index}" class="${classes}"
        @click=${(event) => this.handleRowClick(row, index, event)}
        @keydown=${(event) => this.handleRowKey(row, index, event)}>
        ${this.selectable ? html `<td role="cell" class="p-2"><input type="checkbox" .checked=${selected.has(index)}
          aria-label="Select row ${index + 1}" ?disabled=${this.disabled}
          @input=${(event) => event.stopPropagation()}
          @change=${(event) => { event.stopPropagation(); this.toggleSelection(index); }}></td>` : nothing}
        ${this.rowCells(row).map((cell) => html `<td role="cell" class="p-3 text-sm ml-text">${this.renderLiveSlotFrom(cell)}</td>`)}
      </tr>`;
        })}</tbody>`;
    }
    renderFooter() {
        const footer = this.getLiveSlot('TableFooter');
        if (!footer)
            return html ``;
        return html `<tfoot class="ml-table-footer">${Array.from(footer.querySelectorAll(':scope > TableRow')).map((row) => html `<tr role="row">${this.rowCells(row).map((cell) => html `<td role="cell" class="p-3 text-sm ml-text-muted">${this.renderLiveSlotFrom(cell)}</td>`)}</tr>`)}</tfoot>`;
    }
    renderPagination(pages) {
        if (pages <= 1)
            return html ``;
        const current = Math.min(Math.max(1, Number(this.page) || 1), pages);
        return html `<nav role="navigation" aria-label="Table pagination" class="ml-table-pagination inline-flex items-center gap-2 p-3">
      <button class="ml-pagination-button px-3 py-2 text-sm" ?disabled=${this.disabled || current <= 1} @click=${() => this.handlePage(current - 1)}>Previous</button>
      <span class="ml-text-muted text-sm">Page ${current} of ${pages}</span>
      <button class="ml-pagination-button px-3 py-2 text-sm" ?disabled=${this.disabled || current >= pages} @click=${() => this.handlePage(current + 1)}>Next</button>
    </nav>`;
    }
    renderDetail() {
        if (!this.openRow)
            return html ``;
        const detail = this.rowDetail(this.openRow);
        const label = detail?.getAttribute('label') || 'Record detail';
        return html `<aside class="ml-detail-panel ml-surface-bg p-4" aria-label="${label}">
      <div class="flex items-center justify-between gap-2"><span class="ml-label text-sm">${label}</span>
        <button class="ml-detail-close px-3 py-2 text-sm" aria-label="Close detail" ?disabled=${this.disabled} @click=${this.handleClose}>Close</button>
      </div>
      <div class="ml-detail-content mt-4">${detail ? this.renderLiveSlotFrom(detail) : html `<p class="ml-text-muted">No detail available.</p>`}</div>
    </aside>`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const rows = this.bodyRows();
        const layout = ['ml-table-layout flex w-full gap-4', this.fitHeight ? 'ml-fit-height' : '', this.openRow ? 'ml-detail-open' : '', this.disabled ? 'ml-disabled' : ''].filter(Boolean).join(' ');
        if (this.loading) {
            return html `<div class="${layout}"><section class="ml-table-region min-w-0 flex-1"><div class="ml-loading p-4 ml-skeleton">${this.hasSlot('Loading') ? this.renderLiveSlot('Loading') : 'Loading...'}</div></section>${this.renderDetail()}</div>`;
        }
        const tableContent = rows.length === 0
            ? html `<div class="ml-empty p-4 ml-text-muted">${this.hasSlot('Empty') ? this.renderLiveSlot('Empty') : 'No records found.'}</div>`
            : html `<div class="ml-table-scroll"><table role="table" class="ml-table w-full border" aria-label="Group table">
          ${this.renderHeader(this.headerCells(), rows)}${this.renderBody(rows)}${this.renderFooter()}
        </table></div>${this.renderPagination(this.totalPages(rows.length))}`;
        return html `<div class="${layout}"><section class="ml-table-region min-w-0 flex-1" aria-label="Group table">
      ${this.hasSlot('Caption') ? html `<div class="ml-caption p-3 text-sm ml-label">${this.renderLiveSlot('Caption')}</div>` : nothing}
      ${this.error ? html `<div role="alert" class="ml-error-text p-3 text-sm">${unsafeHTML(String(this.error))}</div>` : nothing}
      ${tableContent}
    </section>${this.renderDetail()}</div>`;
    }
};
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'selectable' })
], DetailPanelTableMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], DetailPanelTableMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'editing-rows' })
], DetailPanelTableMolecule.prototype, "editingRows", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page' })
], DetailPanelTableMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], DetailPanelTableMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], DetailPanelTableMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], DetailPanelTableMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], DetailPanelTableMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DetailPanelTableMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DetailPanelTableMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'fit-height' })
], DetailPanelTableMolecule.prototype, "fitHeight", void 0);
__decorate([
    state()
], DetailPanelTableMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], DetailPanelTableMolecule.prototype, "sortDirection", void 0);
__decorate([
    state()
], DetailPanelTableMolecule.prototype, "openRow", void 0);
DetailPanelTableMolecule = __decorate([
    customElement('groupviewtable--ml-side-detail-table')
], DetailPanelTableMolecule);
export { DetailPanelTableMolecule };
