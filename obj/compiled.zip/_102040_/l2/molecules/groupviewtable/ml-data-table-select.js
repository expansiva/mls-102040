/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-data-table-select.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GROUPVIEWTABLE – ML DATA TABLE SELECT MOLECULE
// =============================================================================
// Skill Group: groupViewTable (data display)
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing, } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    selectAll: 'Select all rows',
    selectRow: (i) => `Select row ${i}`,
    pagePrev: 'Previous page',
    pageNext: 'Next page',
    error: 'Error',
};
const messages = {
    en: message_en,
    // Add other locales as needed
};
/// **collab_i18n_end**
let MlDataTableSelectMolecule = class MlDataTableSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-data-table-select .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-select .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-select .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-select .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-data-table-select .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-select .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-select .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewtable--ml-data-table-select .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-data-table-select .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-data-table-select .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupviewtable--ml-data-table-select .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-data-table-select .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-data-table-select .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-data-table-select .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-data-table-select .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewtable--ml-data-table-select .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-data-table-select .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewtable--ml-data-table-select .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        this.uid = `dts-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = [
            'Caption',
            'TableHeader',
            'TableBody',
            'TableRow',
            'TableHead',
            'TableCell',
            'TableFooter',
            'Empty',
            'Loading',
        ];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.selectable = false;
        /**'single' — radio buttons, max 1 row.'multi' (default) — checkboxes, N rows. */
        this.selectMode = 'multi';
        this.isEditing = false;
        this.page = 1; // 1‑based
        this.pageSize = 0; // 0 = no pagination
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.sortKey = null;
        this.sortDirection = 'asc';
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.propagateEditing();
    }
    // ===========================================================================
    // STATE CHANGE HANDLER – needed for isEditing propagation
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const isEditingAttr = this.getAttribute('is-editing');
        if (isEditingAttr === `{{${key}}}`) {
            this.isEditing = Boolean(value);
            this.propagateEditing();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS – Selection handling
    // ===========================================================================
    getSelectedSet() {
        if (!this.value)
            return new Set();
        return new Set(this.value.split(',').map(v => Number(v)).filter(v => !Number.isNaN(v)));
    }
    updateValueFromSet(set) {
        const arr = Array.from(set).sort((a, b) => a - b);
        this.value = arr.join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    // ===========================================================================
    // HELPERS – Editing propagation
    // ===========================================================================
    propagateEditing() {
        const body = this.getSlot('TableBody');
        if (!body)
            return;
        const customEls = body.querySelectorAll('*');
        customEls.forEach(el => {
            if (el.tagName.includes('-')) {
                el.setAttribute('is-editing', String(this.isEditing));
            }
        });
    }
    // ===========================================================================
    // HELPERS – Sorting
    // ===========================================================================
    handleHeaderClick(e) {
        const target = e.currentTarget;
        const key = target.getAttribute('data-key');
        if (!key)
            return;
        if (this.sortKey === key) {
            this.sortDirection = this.sortDirection === 'asc' ? 'desc' : 'asc';
        }
        else {
            this.sortKey = key;
            this.sortDirection = 'asc';
        }
        this.dispatchEvent(new CustomEvent('sort', {
            bubbles: true,
            composed: true,
            detail: { key: this.sortKey, direction: this.sortDirection },
        }));
        this.requestUpdate();
    }
    getSortedRows(rows) {
        if (!this.sortKey)
            return rows;
        const headerCells = this.getHeaderCells();
        const colIndex = headerCells.findIndex(h => h.getAttribute('key') === this.sortKey);
        if (colIndex === -1)
            return rows;
        return rows.slice().sort((a, b) => {
            const aCell = a.querySelectorAll('TableCell')[colIndex];
            const bCell = b.querySelectorAll('TableCell')[colIndex];
            const aText = aCell?.textContent?.trim() ?? '';
            const bText = bCell?.textContent?.trim() ?? '';
            const cmp = aText.localeCompare(bText, undefined, { numeric: true, sensitivity: 'base' });
            return this.sortDirection === 'asc' ? cmp : -cmp;
        });
    }
    // ===========================================================================
    // HELPERS – Header cells extraction
    // ===========================================================================
    getHeaderCells() {
        const header = this.getSlot('TableHeader');
        if (!header)
            return [];
        const headRow = header.querySelector('TableRow');
        if (!headRow)
            return [];
        return Array.from(headRow.querySelectorAll('TableHead'));
    }
    // ===========================================================================
    // HELPERS – Pagination
    // ===========================================================================
    getTotalPages() {
        if (this.pageSize <= 0)
            return 1;
        const total = this.totalItems > 0 ? this.totalItems : this.getAllRows().length;
        return Math.max(1, Math.ceil(total / this.pageSize));
    }
    handlePageClick(newPage) {
        if (newPage < 1 || newPage > this.getTotalPages())
            return;
        this.page = newPage;
        this.dispatchEvent(new CustomEvent('pageChange', {
            bubbles: true,
            composed: true,
            detail: { page: this.page },
        }));
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS – Row click & selection
    // ===========================================================================
    handleRowClick(index) {
        this.dispatchEvent(new CustomEvent('rowClick', {
            bubbles: true,
            composed: true,
            detail: { index },
        }));
    }
    handleRowCheckboxChange(e, index) {
        const checked = e.target.checked;
        const selected = this.getSelectedSet();
        if (checked) {
            selected.add(index);
        }
        else {
            selected.delete(index);
        }
        this.updateValueFromSet(selected);
    }
    handleSelectAllChange(e) {
        const checked = e.target.checked;
        const rows = this.getAllRows();
        const selected = new Set();
        if (checked) {
            rows.forEach((_, idx) => selected.add(idx));
        }
        this.updateValueFromSet(selected);
    }
    handleRowRadioChange(index) {
        this.updateValueFromSet(new Set([index]));
    }
    // ===========================================================================
    // HELPERS – Row collection (raw order before pagination/sort)
    // ===========================================================================
    getAllRows() {
        const body = this.getSlot('TableBody');
        if (!body)
            return [];
        return Array.from(body.querySelectorAll('TableRow'));
    }
    // ===========================================================================
    // RENDERING HELPERS
    // ===========================================================================
    getTableClasses() {
        return [
            'w-full border-collapse',
            this.disabled ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getHeaderClasses() {
        return [
            'ml-surface-bg',
            'border-b ml-border',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCellClasses(isHeader = false) {
        const base = [
            'px-4 py-2 text-sm',
            'border ml-border',
            isHeader ? 'font-medium ml-text-muted' : 'ml-text',
        ];
        return base.filter(Boolean).join(' ');
    }
    renderSortIndicator(key) {
        if (this.sortKey !== key)
            return html ``;
        const arrow = this.sortDirection === 'asc' ? '▲' : '▼';
        return html `<span class="ml-1 text-xs">${arrow}</span>`;
    }
    renderHeader() {
        const heads = this.getHeaderCells();
        const selectable = this.selectable;
        const isSingle = this.selectMode === 'single';
        return html `
 <thead class="${this.getHeaderClasses()}">
 <tr>
 ${selectable
            ? isSingle
                ? html `<th class="${this.getCellClasses(true)}"></th>`
                : html `<th class="${this.getCellClasses(true)}">
 <input
 type="checkbox"
 ?disabled="${this.disabled}"
 aria-label="${this.msg.selectAll}"
 @change="${(e) => { e.stopPropagation(); this.handleSelectAllChange(e); }}"
 
 @input="${(e) => e.stopPropagation()}"
/>
 </th>`
            : nothing}
 ${heads.map(head => {
            const key = head.getAttribute('key') ?? '';
            const sortable = head.hasAttribute('sortable');
            const ariaSort = sortable
                ? this.sortKey === key
                    ? this.sortDirection === 'asc' ? 'ascending' : 'descending'
                    : 'none'
                : undefined;
            return html `<th
 class="${this.getCellClasses(true)} ${sortable ? 'cursor-pointer' : ''}"
 data-key="${key}"
 ?disabled="${this.disabled}"
 aria-sort="${ariaSort ?? nothing}"
 @click="${sortable ? (e) => this.handleHeaderClick(e) : nothing}"
 >
 ${unsafeHTML(head.innerHTML)}
 ${sortable ? this.renderSortIndicator(key) : nothing}
 </th>`;
        })}
 </tr>
 </thead>
 `;
    }
    renderBody() {
        const rawRows = this.getAllRows();
        const sortedRows = this.getSortedRows(rawRows);
        const startIdx = this.pageSize > 0 ? (this.page - 1) * this.pageSize : 0;
        const endIdx = this.pageSize > 0 ? startIdx + this.pageSize : sortedRows.length;
        const pagedRows = sortedRows.slice(startIdx, endIdx);
        const selectedSet = this.getSelectedSet();
        const selectable = this.selectable;
        if (pagedRows.length === 0) {
            // Empty state
            const emptyContent = this.getSlotContent('Empty') || this.msg.noResults;
            return html `
 <tr>
 <td colspan="${selectable ? this.getHeaderCells().length + 1 : this.getHeaderCells().length}" class="${this.getCellClasses()}">
 ${unsafeHTML(emptyContent)}
 </td>
 </tr>
 `;
        }
        const isSingle = this.selectMode === 'single';
        return html `
 ${pagedRows.map((rowEl) => {
            const globalIdx = rawRows.indexOf(rowEl); // original index before pagination/sort
            const cells = Array.from(rowEl.querySelectorAll('TableCell'));
            const isSelected = selectedSet.has(globalIdx);
            const rowClasses = [
                isSelected ? 'ml-primary-dim-bg' : 'ml-surface-bg',
                'hover:ml-surface-dim-bg',
                this.disabled ? 'ml-disabled' : 'cursor-pointer',
            ]
                .filter(Boolean)
                .join(' ');
            return html `
 <tr
 class="${rowClasses}"
 @click="${() => {
                if (this.disabled)
                    return;
                if (!this.selectable)
                    this.handleRowClick(globalIdx);
            }}"
 >
 ${selectable
                ? isSingle
                    ? html `<td class="${this.getCellClasses()}">
 <input
 type="radio"
 name="${this.uid}"
 ?disabled="${this.disabled}"
 .checked="${isSelected}"
 aria-label="${this.msg.selectRow(globalIdx)}"
 @click="${(e) => e.stopPropagation()}"
 @change="${(e) => { e.stopPropagation(); this.handleRowRadioChange(globalIdx); }}"
 
 @input="${(e) => e.stopPropagation()}"
/>
 </td>`
                    : html `<td class="${this.getCellClasses()}">
 <input
 type="checkbox"
 ?disabled="${this.disabled}"
 .checked="${isSelected}"
 aria-label="${this.msg.selectRow(globalIdx)}"
 @click="${(e) => e.stopPropagation()}"
 @change="${(e) => { e.stopPropagation(); this.handleRowCheckboxChange(e, globalIdx); }}"
 
 @input="${(e) => e.stopPropagation()}"
/>
 </td>`
                : nothing}
 ${cells.map(cell => html `
 <td class="${this.getCellClasses()}">
 ${unsafeHTML(cell.innerHTML)}
 </td>`)}
 </tr>`;
        })}
 `;
    }
    renderPagination() {
        const totalPages = this.getTotalPages();
        if (totalPages <= 1)
            return html ``;
        const pages = Array.from({ length: totalPages }, (_, i) => i + 1);
        return html `
 <nav class="flex items-center space-x-2 mt-2" aria-label="Table pagination">
 <button
 class="px-2 py-1 border rounded ${this.disabled ? 'ml-disabled' : ''}"
 ?disabled="${this.disabled || this.page === 1}"
 @click="${() => this.handlePageClick(this.page - 1)}"
 >${this.msg.pagePrev}</button>
 ${pages.map(p => html `
 <button
 class="px-2 py-1 border rounded ${p === this.page ? 'ml-primary-dim-bg' : ''} ${this.disabled ? 'ml-disabled' : ''}"
 ?disabled="${this.disabled}"
 @click="${() => this.handlePageClick(p)}"
 >${p}</button>`)}
 <button
 class="px-2 py-1 border rounded ${this.disabled ? 'ml-disabled' : ''}"
 ?disabled="${this.disabled || this.page === totalPages}"
 @click="${() => this.handlePageClick(this.page + 1)}"
 >${this.msg.pageNext}</button>
 </nav>
 `;
    }
    renderFooter() {
        const footer = this.getSlot('TableFooter');
        if (!footer)
            return html ``;
        const rows = Array.from(footer.querySelectorAll('TableRow'));
        if (rows.length === 0)
            return html ``;
        return html `
 <tfoot class="${cn('border-t-2 ml-border', this.getSlotClass('TableFooter'))}">
 ${rows.map(rowEl => {
            const cells = Array.from(rowEl.querySelectorAll('TableCell'));
            return html `
 <tr class="ml-surface-dim-bg">
 ${this.selectable ? html `<td class="${this.getCellClasses()}"></td>` : nothing}
 ${cells.map(cell => html `
 <td class="${this.getCellClasses()} font-semibold">
 ${unsafeHTML(cell.innerHTML)}
 </td>`)}
 </tr>`;
        })}
 </tfoot>
 `;
    }
    renderError() {
        if (!this.error)
            return html ``;
        return html `
 <p class="mt-2 text-sm ml-error-text">
 ${unsafeHTML(this.error)}
 </p>
 `;
    }
    // ===========================================================================
    // MAIN RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Loading state
        if (this.loading) {
            const loadingContent = this.getSlotContent('Loading') || this.msg.loading;
            return html `
 <div class="${cn('p-4', this.cssClass)}">
 ${unsafeHTML(loadingContent)}
 </div>
 `;
        }
        // Caption (optional)
        const captionContent = this.getSlotContent('Caption');
        const caption = captionContent
            ? html `<caption class="${cn('text-left font-medium mb-2', this.getSlotClass('Caption'))}">${unsafeHTML(captionContent)}</caption>`
            : nothing;
        return html `
 <div class="${cn('overflow-x-auto', this.cssClass)}">
 <table class="${this.getTableClasses()}" role="table">
 ${caption}
 ${this.renderHeader()}
 <tbody role="rowgroup">
 ${this.renderBody()}
 </tbody>
 ${this.renderFooter()}
 </table>
 ${this.pageSize > 0 ? this.renderPagination() : nothing}
 ${this.renderError()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'selectable' })
], MlDataTableSelectMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'select-mode' })
], MlDataTableSelectMolecule.prototype, "selectMode", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDataTableSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlDataTableSelectMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlDataTableSelectMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlDataTableSelectMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDataTableSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDataTableSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDataTableSelectMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlDataTableSelectMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], MlDataTableSelectMolecule.prototype, "sortDirection", void 0);
MlDataTableSelectMolecule = __decorate([
    customElement('groupviewtable--ml-data-table-select')
], MlDataTableSelectMolecule);
export { MlDataTableSelectMolecule };
