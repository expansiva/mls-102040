var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewtable/ml-record-form-table.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cellSortKey, compareSortKeys } from '/_102033_/l2/shared/molecules/tableSort.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
// =============================================================================
// RECORD FORM TABLE MOLECULE
// =============================================================================
// Skill Group: groupViewTable
// This molecule owns presentation and interaction mode, never record values.
let GroupViewTableMlRecordFormTableMolecule = class GroupViewTableMlRecordFormTableMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewtable--ml-record-form-table {
  font-family: var(--ml-font-family, system-ui);
  color: var(--ml-on-surface, #1c1b1f);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-record-form-table .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewtable--ml-record-form-table table.ml-surface-bg.ml-border {
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  border-collapse: separate;
  border-spacing: 0;
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupviewtable--ml-record-form-table .ml-table-head {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface-dim, #f5f5f5);
  font-weight: var(--ml-font-weight-medium, 500);
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-record-form-table .ml-table-head[tabindex="0"]:hover {
  background: var(--ml-surface-variant, #f5f5f5);
}
groupviewtable--ml-record-form-table .ml-table-head:focus-visible,
groupviewtable--ml-record-form-table .ml-pagination-button:focus-visible,
groupviewtable--ml-record-form-table .ml-back-button:focus-visible,
groupviewtable--ml-record-form-table .ml-row-action:focus-visible {
  outline: var(--ml-focus-ring-width, 2px) solid var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  outline-offset: 2px;
}
groupviewtable--ml-record-form-table .ml-table-row {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-record-form-table .ml-table-row:hover:not(.ml-row-selected):not(.ml-row-editing):not(.ml-draft-row) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewtable--ml-record-form-table .ml-table-row > td {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-record-form-table .ml-table-row:last-child > td {
  border-bottom: 0;
}
groupviewtable--ml-record-form-table .ml-table-cell {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-record-form-table .ml-row-selected {
  background: var(--ml-primary-container, #dbeafe);
}
groupviewtable--ml-record-form-table .ml-row-selected:hover {
  background: var(--ml-primary-container, #dbeafe);
}
groupviewtable--ml-record-form-table .ml-row-editing {
  background: var(--ml-surface-variant, #f5f5f5);
  box-shadow: inset 3px 0 0 var(--ml-primary, #3b82f6);
}
groupviewtable--ml-record-form-table .ml-row-editing:hover {
  background: var(--ml-surface-variant, #f5f5f5);
}
groupviewtable--ml-record-form-table .ml-draft-row {
  background: var(--ml-surface-dim, #f5f5f5);
  box-shadow: inset 3px 0 0 var(--ml-primary, #3b82f6);
}
groupviewtable--ml-record-form-table .ml-draft-row > td {
  border-bottom-color: var(--ml-outline-focus, #3b82f6);
}
groupviewtable--ml-record-form-table .ml-actions-column {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-left: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  white-space: nowrap;
}
groupviewtable--ml-record-form-table .ml-table-head.ml-actions-column {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-record-form-table .ml-row-action,
groupviewtable--ml-record-form-table .ml-pagination-button,
groupviewtable--ml-record-form-table .ml-back-button {
  color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-0, none);
  transition: var(--ml-transition, 200ms ease);
}
groupviewtable--ml-record-form-table .ml-row-action.ml-action-hidden {
  display: none;
}
groupviewtable--ml-record-form-table .ml-row-action:hover:not(.ml-disabled),
groupviewtable--ml-record-form-table .ml-pagination-button:hover:not(:disabled),
groupviewtable--ml-record-form-table .ml-back-button:hover:not(:disabled) {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-record-form-table .ml-pagination-button:disabled,
groupviewtable--ml-record-form-table .ml-back-button:disabled {
  color: var(--ml-on-surface-muted, #49454f);
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
groupviewtable--ml-record-form-table .ml-table-footer {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-top: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
groupviewtable--ml-record-form-table .ml-label {
  color: var(--ml-on-surface, #1c1b1f);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-record-form-table .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
groupviewtable--ml-record-form-table .ml-error-text {
  color: var(--ml-error, #ef4444);
}
groupviewtable--ml-record-form-table .ml-sort-indicator {
  color: var(--ml-primary, #3b82f6);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupviewtable--ml-record-form-table .ml-skeleton {
  color: var(--ml-on-surface-muted, #49454f);
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: var(--ml-radius-sm, 6px);
}
groupviewtable--ml-record-form-table .ml-record-detail {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupviewtable--ml-record-form-table .ml-detail-content {
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewtable--ml-record-form-table .ml-detail-editing {
  box-shadow: inset 3px 0 0 var(--ml-primary, #3b82f6), var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupviewtable--ml-record-form-table .ml-detail-viewing {
  box-shadow: inset 3px 0 0 var(--ml-outline-variant, #e2e8f0), var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupviewtable--ml-record-form-table input[type="checkbox"] {
  accent-color: var(--ml-primary, #3b82f6);
}
groupviewtable--ml-record-form-table .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Caption', 'TableHeader', 'TableBody', 'TableRow', 'TableHead', 'TableCell', 'TableFooter', 'Empty', 'Loading', 'Detail', 'RowActions', 'RowAction', 'NewRecordRow'];
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES
        // ===========================================================================
        this.selectable = false;
        this.isEditing = false;
        this.page = 1;
        this.pageSize = 0;
        this.totalItems = 0;
        this.value = '';
        this.error = '';
        this.disabled = false;
        this.loading = false;
        this.fitHeight = false;
        this.sortKey = null;
        this.sortDirection = 'asc';
        this.openKey = null;
        this.privateEditingKey = null;
        this.draftOpen = false;
    }
    // ===========================================================================
    // STRUCTURE READERS
    // ===========================================================================
    directRows(tag) {
        const slot = this.getLiveSlot(tag);
        return slot ? Array.from(slot.querySelectorAll(':scope > TableRow')) : [];
    }
    bodyRows() { return this.directRows('TableBody'); }
    rowKey(row, index) { return row.getAttribute('key') || String(index); }
    rowCells(row) { return Array.from(row.querySelectorAll(':scope > TableCell')); }
    rowDetail(row) { return row.querySelector(':scope > Detail'); }
    rowActions(row) {
        const group = row.querySelector(':scope > RowActions');
        return group ? Array.from(group.querySelectorAll(':scope > RowAction')) : [];
    }
    actionName(action) { return action.getAttribute('action') || ''; }
    actionWhen(action) { return action.getAttribute('when') || ''; }
    hasRowActions() {
        return this.bodyRows().some(r => this.rowActions(r).length > 0) || !!this.newRow()?.querySelector(':scope > RowActions');
    }
    newRow() { return this.getLiveSlot('NewRecordRow'); }
    ownsEditingMode() {
        return this.hasAttribute('is-editing') || this.hasAttribute('editing-rows') || !!this.privateEditingKey || this.hasRowActions() || this.draftOpen;
    }
    isRowEditing(key) {
        if (this.draftOpen && key === this.newRow()?.getAttribute('key'))
            return true;
        if (this.hasAttribute('editing-rows'))
            return String(this.editingRows ?? '').split(',').map(v => v.trim()).includes(key);
        if (this.isEditing)
            return true;
        return this.privateEditingKey === key;
    }
    selected() {
        return new Set(String(this.value ?? '').split(',').filter(v => /^\d+$/.test(v)).map(Number));
    }
    externalMode() { return Number(this.totalItems) > this.bodyRows().length; }
    // ===========================================================================
    // EVENTS AND MODE TRANSITIONS
    // ===========================================================================
    emit(name, detail = {}) {
        this.dispatchEvent(new CustomEvent(name, { bubbles: true, composed: true, detail }));
    }
    rowIdentity(row, index) { return this.rowKey(row, index); }
    handleSort(head) {
        if (this.disabled || !head.hasAttribute('sortable'))
            return;
        const key = head.getAttribute('key') || '';
        this.sortDirection = this.sortKey === key && this.sortDirection === 'asc' ? 'desc' : 'asc';
        this.sortKey = key;
        this.emit('sort', { key, direction: this.sortDirection });
    }
    handlePage(next) {
        if (this.disabled)
            return;
        const total = this.totalPages();
        if (next < 1 || next > total || next === Number(this.page))
            return;
        this.emit('pageChange', { page: next });
    }
    handleSelection(index, checked) {
        if (this.disabled || !this.selectable)
            return;
        const set = this.selected();
        checked ? set.add(index) : set.delete(index);
        const value = Array.from(set).sort((a, b) => a - b).join(',');
        this.value = value;
        this.emit('change', { value });
    }
    handleSelectAll(checked) {
        if (this.disabled || !this.selectable)
            return;
        const rows = this.bodyRows();
        const set = this.selected();
        rows.forEach((_, i) => checked ? set.add(i) : set.delete(i));
        const value = Array.from(set).sort((a, b) => a - b).join(',');
        this.value = value;
        this.emit('change', { value });
    }
    handleRowClick(e, index) {
        if (this.disabled)
            return;
        const target = e.target;
        if (target.closest('[data-ml-selection], [data-ml-action]'))
            return;
        this.emit('rowClick', { index });
    }
    handleRowKey(e, index) {
        if (e.key === 'Enter')
            this.handleRowClick(e, index);
        if (e.key === ' ' && this.selectable) {
            e.preventDefault();
            this.handleSelection(index, !this.selected().has(index));
        }
    }
    handleAction(e, action, key, isNew = false) {
        e.stopPropagation();
        if (this.disabled)
            return;
        const name = this.actionName(action);
        const editing = isNew || this.isRowEditing(key);
        if (name === 'new') {
            if (this.draftOpen)
                return;
            this.draftOpen = !!this.newRow();
            this.emit('newRecord');
        }
        else if (name === 'open' && !editing) {
            this.emit('rowAction', { key, action: name });
            if (this.bodyRows().some((r, i) => this.rowIdentity(r, i) === key && this.rowDetail(r))) {
                this.privateEditingKey = null;
                this.openKey = key;
                this.propagateEditing();
            }
        }
        else if (name === 'edit' && !editing) {
            this.emit('edit', { key });
            if (!this.hasAttribute('editing-rows'))
                this.privateEditingKey = key;
        }
        else if ((name === 'save' || name === 'cancel') && editing) {
            this.emit(name, isNew ? { key, isNew: true } : { key });
            if (isNew)
                this.draftOpen = false;
            else if (!this.hasAttribute('editing-rows'))
                this.privateEditingKey = null;
        }
        else if (name === 'delete' && !editing) {
            this.emit('delete', { key });
        }
        else if (!['edit', 'save', 'cancel', 'delete', 'new', 'open'].includes(name)) {
            this.emit('rowAction', { key, action: name });
        }
    }
    handleBack() { if (!this.disabled)
        this.openKey = null; }
    // ===========================================================================
    // PAGINATION AND ORDERING
    // ===========================================================================
    totalPages() {
        const count = this.externalMode() ? Number(this.totalItems) : this.bodyRows().length;
        return Math.max(1, this.pageSize > 0 ? Math.ceil(count / this.pageSize) : 1);
    }
    displayRows() {
        const rows = this.bodyRows().map((row, index) => ({ row, index }));
        if (!this.externalMode() && this.sortKey) {
            const heads = this.headerCells();
            const col = heads.findIndex(h => h.getAttribute('key') === this.sortKey);
            if (col >= 0)
                rows.sort((a, b) => compareSortKeys(cellSortKey(this.rowCells(a.row)[col], this.getLiveText(this.rowCells(a.row)[col])), cellSortKey(this.rowCells(b.row)[col], this.getLiveText(this.rowCells(b.row)[col]))) * (this.sortDirection === 'asc' ? 1 : -1));
        }
        return !this.externalMode() && this.pageSize > 0 ? rows.slice((Math.max(1, Number(this.page)) - 1) * this.pageSize, Number(this.page) * this.pageSize) : rows;
    }
    headerCells() {
        const header = this.getLiveSlot('TableHeader');
        return header ? Array.from(header.querySelectorAll(':scope > TableRow > TableHead')) : [];
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderAction(action, key, isNew, index) {
        const name = this.actionName(action);
        const editing = isNew || this.isRowEditing(key);
        const explicit = this.actionWhen(action);
        const inDetail = this.openKey === key;
        const available = explicit === 'always' || (explicit === 'edit' ? editing : explicit === 'view' ? !editing : name === 'edit' ? inDetail && !editing : name === 'delete' || name === 'open' ? !inDetail && !editing : name === 'save' || name === 'cancel' ? editing : true);
        const actionClasses = ['inline-flex items-center gap-2 px-2 py-1 text-sm transition', 'ml-row-action', available ? '' : 'ml-action-hidden', this.disabled ? 'ml-disabled' : ''].filter(Boolean).join(' ');
        return html `<span data-ml-action data-action-index="${index}" role="button" tabindex="${available && !this.disabled ? 0 : -1}" aria-hidden="${available ? 'false' : 'true'}" class="${actionClasses}" @click=${(e) => this.handleAction(e, action, key, isNew)} @keydown=${(e) => { if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleAction(e, action, key, isNew);
        } }}>${this.renderLiveSlotFrom(action)}</span>`;
    }
    renderCells(row, index, isNew = false) {
        return this.rowCells(row).map(cell => html `<td role="cell" class="p-3 ml-table-cell">${this.renderLiveSlotFrom(cell)}</td>`);
    }
    renderTableRow(row, index, isNew = false) {
        const key = isNew ? (row.getAttribute('key') || 'new') : this.rowIdentity(row, index);
        const actions = this.rowActions(row);
        const editing = isNew || this.isRowEditing(key);
        return html `<tr data-row-index="${index}" data-row-key="${key}" role="row" tabindex="0" class="${['ml-table-row', editing ? 'ml-row-editing' : '', isNew ? 'ml-draft-row' : '', this.selected().has(index) ? 'ml-row-selected' : ''].filter(Boolean).join(' ')}" @click=${(e) => this.handleRowClick(e, index)} @keydown=${(e) => this.handleRowKey(e, index)}>${this.selectable && !isNew ? html `<td role="cell" data-ml-selection class="p-3"><input type="checkbox" aria-label="Select row ${index + 1}" .checked=${this.selected().has(index)} ?disabled=${this.disabled} @change=${(e) => { e.stopPropagation(); this.handleSelection(index, e.target.checked); }} @input=${(e) => e.stopPropagation()} /></td>` : nothing}${this.renderCells(row, index, isNew)}${actions.length ? html `<td role="cell" class="p-3 ml-actions-column"><div class="inline-flex flex-wrap items-center gap-2">${actions.map((a, i) => this.renderAction(a, key, isNew, i))}</div></td>` : nothing}</tr>`;
    }
    renderList() {
        const rows = this.displayRows();
        const heads = this.headerCells();
        const selected = this.selected();
        const all = rows.length > 0 && rows.every(r => selected.has(r.index));
        const footer = this.getLiveSlot('TableFooter');
        const newAction = footer ? Array.from(footer.querySelectorAll(':scope > RowAction')).find(a => this.actionName(a) === 'new') : undefined;
        return html `<div class="${cn('flex w-full flex-col gap-3', this.fitHeight ? 'h-full' : '', this.disabled ? 'ml-disabled' : '', this.cssClass)}" aria-busy=${this.loading ? 'true' : 'false'}>${this.hasSlot('Caption') ? html `<div class="text-lg font-semibold ml-label">${this.renderLiveSlot('Caption')}</div>` : nothing}${this.error ? html `<div role="alert" class="ml-error-text">${this.error}</div>` : nothing}${this.loading ? html `<div class="p-4 ml-skeleton" role="status">${this.hasSlot('Loading') ? this.renderLiveSlot('Loading') : 'Loading…'}</div>` : rows.length === 0 ? html `<div class="p-4 ml-text-muted" role="status">${this.hasSlot('Empty') ? this.renderLiveSlot('Empty') : 'No records found'}</div>` : html `<div class="w-full overflow-auto ${this.fitHeight ? 'h-full' : ''}"><table role="table" class="w-full ml-surface-bg ml-border"><caption class="sr-only">Record table</caption><thead role="rowgroup"><tr role="row">${this.selectable ? html `<th role="columnheader" class="p-3"><input type="checkbox" aria-label="Select all rows" .checked=${all} ?disabled=${this.disabled} @change=${(e) => { e.stopPropagation(); this.handleSelectAll(e.target.checked); }} @input=${(e) => e.stopPropagation()} /></th>` : nothing}${heads.map((h, i) => { const active = this.sortKey === h.getAttribute('key'); return html `<th role="columnheader" tabindex="${h.hasAttribute('sortable') && !this.disabled ? 0 : -1}" aria-sort=${h.hasAttribute('sortable') ? active ? this.sortDirection === 'asc' ? 'ascending' : 'descending' : 'none' : nothing} class="p-3 text-left ml-table-head" @click=${() => this.handleSort(h)} @keydown=${(e) => { if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleSort(h);
        } }}>${this.renderLiveSlotFrom(h)}${active ? html `<span aria-hidden="true" class="ml-sort-indicator">${this.sortDirection === 'asc' ? '↑' : '↓'}</span>` : nothing}</th>`; })}${this.hasRowActions() ? html `<th role="columnheader" class="p-3 ml-actions-column">Actions</th>` : nothing}</tr></thead><tbody role="rowgroup">${rows.map(r => this.renderTableRow(r.row, r.index))}${this.draftOpen && this.newRow() ? this.renderTableRow(this.newRow(), -1, true) : nothing}</tbody></table></div>`}${footer ? html `<div class="flex items-center justify-between gap-3 p-2 ml-table-footer"><div>${newAction ? this.renderAction(newAction, 'new', false, 0) : nothing}</div><nav role="navigation" aria-label="Table pagination" class="inline-flex items-center gap-2"><button class="ml-pagination-button" ?disabled=${this.disabled || Number(this.page) <= 1} @click=${() => this.handlePage(Number(this.page) - 1)}>Previous</button><span class="ml-text-muted" aria-live="polite">Page ${Number(this.page)} of ${this.totalPages()}</span><button class="ml-pagination-button" ?disabled=${this.disabled || Number(this.page) >= this.totalPages()} @click=${() => this.handlePage(Number(this.page) + 1)}>Next</button></nav></div>` : nothing}</div>`;
    }
    renderDetail() {
        const rows = this.bodyRows();
        const index = rows.findIndex((r, i) => this.rowIdentity(r, i) === this.openKey);
        const row = index >= 0 ? rows[index] : null;
        const detail = row ? this.rowDetail(row) : null;
        if (!row || !detail)
            return this.renderList();
        const key = this.rowIdentity(row, index);
        const actions = this.rowActions(row);
        return html `<section data-row-key="${key}" class="${cn('flex w-full flex-col gap-4 p-4 ml-record-detail', this.isRowEditing(key) ? 'ml-detail-editing' : 'ml-detail-viewing', this.cssClass)}" aria-label=${detail.getAttribute('label') || 'Record details'}><div class="flex items-center justify-between gap-3"><button class="inline-flex items-center gap-2 px-3 py-2 transition ml-back-button" @click=${this.handleBack} ?disabled=${this.disabled}>Back to records</button><div class="inline-flex flex-wrap items-center gap-2">${actions.map((a, i) => this.renderAction(a, key, false, i))}</div></div><div class="w-full ml-detail-content">${this.renderLiveSlotFrom(detail)}</div></section>`;
    }
    // ===========================================================================
    // PROPAGATION AND RENDER
    // ===========================================================================
    /**
     * Escreve `is-editing` só quando o valor MUDA.
     *
     * O guard não é otimização — é o que impede um laço infinito. O MutationObserver da base observa
     * `attributes: true` em toda a subárvore e agenda re-render quando o alvo está DENTRO de uma slot
     * tag (moleculeBase, `_isInsideSlotTag`). Um `setAttribute` gera registro de mutação mesmo
     * escrevendo o mesmo valor, então marcar em todo ciclo alimenta o observer que causa o ciclo
     * seguinte. Só aparece quando há componente dentro de slot tag NÃO projetada — o `<Detail>` das
     * linhas fechadas é exatamente esse caso; as células, por serem projetadas, saem da slot tag.
     */
    marcar(el, editing) {
        const valor = String(editing);
        if (el.getAttribute('is-editing') === valor)
            return;
        el.setAttribute('is-editing', valor);
        // O `requestUpdate` NÃO é redundante — sem ele o consumidor não redesenha ao trocar de modo.
        // O conversor Boolean do Lit é `v => v !== null`, então "false" e "true" chegam ao setter como
        // o MESMO `true`: `requestUpdate(prop, oldValue)` vê true→true e cancela o render. Quem sabe
        // distinguir as duas strings é o getter do propertyDataSource, e ele só é consultado se houver
        // render. Medido em 01/09: com is-editing="true" nos 5 campos da ficha, todos seguiam em leitura.
        el.requestUpdate?.();
    }
    propagateEditing() {
        this.querySelectorAll('TableCell, Detail, [data-row-key]').forEach(el => {
            const renderedRow = el.closest('[data-row-key]');
            const sourceRow = el.closest('TableRow');
            const sourceIndex = sourceRow ? this.bodyRows().indexOf(sourceRow) : -1;
            const key = renderedRow?.getAttribute('data-row-key') || (sourceRow && sourceIndex >= 0 ? this.rowIdentity(sourceRow, sourceIndex) : '');
            if (!key)
                return;
            const editing = key === (this.newRow()?.getAttribute('key') || '') && this.draftOpen || this.isRowEditing(key);
            // `setAttribute(..., 'false')`, NUNCA `toggleAttribute`: nesta plataforma atributo AUSENTE não
            // significa falso. O getter do propertyDataSource devolve `_isEditing` quando o atributo não está
            // lá, e o inicializador de campo do consumidor já gravou o padrão dele — no ml-enter-text esse
            // padrão é `true`. Remover o atributo entrega o campo ao padrão dele, que é edição.
            if (el.tagName.includes('-'))
                this.marcar(el, editing);
            el.querySelectorAll('*').forEach(child => { if (child.tagName.includes('-'))
                this.marcar(child, editing); });
        });
    }
    updated() { this.propagateEditing(); }
    render() {
        return this.openKey ? this.renderDetail() : this.renderList();
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], GroupViewTableMlRecordFormTableMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupViewTableMlRecordFormTableMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'editing-rows' })
], GroupViewTableMlRecordFormTableMolecule.prototype, "editingRows", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupViewTableMlRecordFormTableMolecule.prototype, "page", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'page-size' })
], GroupViewTableMlRecordFormTableMolecule.prototype, "pageSize", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-items' })
], GroupViewTableMlRecordFormTableMolecule.prototype, "totalItems", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupViewTableMlRecordFormTableMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupViewTableMlRecordFormTableMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupViewTableMlRecordFormTableMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupViewTableMlRecordFormTableMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'fit-height' })
], GroupViewTableMlRecordFormTableMolecule.prototype, "fitHeight", void 0);
__decorate([
    state()
], GroupViewTableMlRecordFormTableMolecule.prototype, "sortKey", void 0);
__decorate([
    state()
], GroupViewTableMlRecordFormTableMolecule.prototype, "sortDirection", void 0);
__decorate([
    state()
], GroupViewTableMlRecordFormTableMolecule.prototype, "openKey", void 0);
__decorate([
    state()
], GroupViewTableMlRecordFormTableMolecule.prototype, "privateEditingKey", void 0);
__decorate([
    state()
], GroupViewTableMlRecordFormTableMolecule.prototype, "draftOpen", void 0);
GroupViewTableMlRecordFormTableMolecule = __decorate([
    customElement('groupviewtable--ml-record-form-table')
], GroupViewTableMlRecordFormTableMolecule);
export { GroupViewTableMlRecordFormTableMolecule };
