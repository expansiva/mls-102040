/// <mls fileReference="_102040_/l2/molecules/groupenterdate/ml-date-shortcut-picker.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATE SHORTCUT PICKER MOLECULE
// =============================================================================
// Skill Group: groupEnterDate
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    today: 'Today',
    yesterday: 'Yesterday',
    thisWeek: 'This week',
    thisMonth: 'This month',
    last30Days: 'Last 30 days',
    placeholder: 'Enter date',
    loading: 'Loading...',
    noValue: '—',
};
const messages = {
    en: message_en,
    pt: {
        today: 'Hoje',
        yesterday: 'Ontem',
        thisWeek: 'Esta semana',
        thisMonth: 'Este mês',
        last30Days: 'Últimos 30 dias',
        placeholder: 'Digite a data',
        loading: 'Carregando...',
        noValue: '—',
    },
};
let DateShortcutPickerMolecule = class DateShortcutPickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdate--ml-date-shortcut-picker .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdate--ml-date-shortcut-picker .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-date-shortcut-picker .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-date-shortcut-picker .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-date-shortcut-picker .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdate--ml-date-shortcut-picker .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut--hoverable:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-on-surface-faint, #79747e);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-active {
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: var(--ml-primary, #3b82f6);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-input {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-input:focus {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-input--focused {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-input--error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-input--error:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) rgba(239, 68, 68, 0.4);
}
groupenterdate--ml-date-shortcut-picker .ml-date-shortcut-input--readonly {
  background-color: var(--ml-surface-dim, #f5f5f5);
  cursor: default;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        // Data
        this.value = null;
        this.error = '';
        this.name = '';
        // Configuration
        this.locale = '';
        this.minDate = '';
        this.maxDate = '';
        this.placeholder = '';
        this.firstDayOfWeek = 0;
        this.showWeekNumbers = false;
        // States
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.inputValue = '';
        this.isFocused = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.syncInputValue();
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.syncInputValue();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPER METHODS
    // ===========================================================================
    syncInputValue() {
        if (this.value) {
            this.inputValue = this.formatDateForDisplay(this.value);
        }
        else {
            this.inputValue = '';
        }
    }
    getLocale() {
        return this.locale || navigator.language || 'en-US';
    }
    formatDateForDisplay(isoDate) {
        if (!isoDate)
            return '';
        try {
            const [year, month, day] = isoDate.split('-').map(Number);
            const date = new Date(year, month - 1, day);
            return date.toLocaleDateString(this.getLocale());
        }
        catch {
            return isoDate;
        }
    }
    parseDisplayToIso(displayDate) {
        if (!displayDate.trim())
            return null;
        // Try parsing as ISO first
        const isoMatch = displayDate.match(/^(\d{4})-(\d{2})-(\d{2})$/);
        if (isoMatch) {
            return displayDate;
        }
        // Try parsing based on locale patterns
        const locale = this.getLocale();
        const parts = displayDate.split(/[\/\.\-]/);
        if (parts.length !== 3)
            return null;
        let year, month, day;
        if (locale.startsWith('en-US')) {
            // MM/DD/YYYY
            [month, day, year] = parts.map(Number);
        }
        else {
            // DD/MM/YYYY or DD.MM.YYYY
            [day, month, year] = parts.map(Number);
        }
        if (isNaN(year) || isNaN(month) || isNaN(day))
            return null;
        if (year < 1000)
            year += 2000;
        if (month < 1 || month > 12)
            return null;
        if (day < 1 || day > 31)
            return null;
        return `${year.toString().padStart(4, '0')}-${month.toString().padStart(2, '0')}-${day.toString().padStart(2, '0')}`;
    }
    getTodayIso() {
        const today = new Date();
        return this.dateToIso(today);
    }
    dateToIso(date) {
        const year = date.getFullYear();
        const month = (date.getMonth() + 1).toString().padStart(2, '0');
        const day = date.getDate().toString().padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    getYesterdayIso() {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        return this.dateToIso(yesterday);
    }
    getThisWeekStartIso() {
        const today = new Date();
        const currentDay = today.getDay();
        const diff = (currentDay - this.firstDayOfWeek + 7) % 7;
        const weekStart = new Date(today);
        weekStart.setDate(today.getDate() - diff);
        return this.dateToIso(weekStart);
    }
    getThisMonthStartIso() {
        const today = new Date();
        const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
        return this.dateToIso(monthStart);
    }
    getLast30DaysIso() {
        const date = new Date();
        date.setDate(date.getDate() - 30);
        return this.dateToIso(date);
    }
    isDateInRange(isoDate) {
        if (!isoDate)
            return false;
        if (this.minDate && isoDate < this.minDate)
            return false;
        if (this.maxDate && isoDate > this.maxDate)
            return false;
        return true;
    }
    getShortcuts() {
        return [
            { key: 'today', label: this.msg.today, getDate: () => this.getTodayIso() },
            { key: 'yesterday', label: this.msg.yesterday, getDate: () => this.getYesterdayIso() },
            { key: 'thisWeek', label: this.msg.thisWeek, getDate: () => this.getThisWeekStartIso() },
            { key: 'thisMonth', label: this.msg.thisMonth, getDate: () => this.getThisMonthStartIso() },
            { key: 'last30Days', label: this.msg.last30Days, getDate: () => this.getLast30DaysIso() },
        ];
    }
    isShortcutSelected(shortcut) {
        if (!this.value)
            return false;
        return this.value === shortcut.getDate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleShortcutClick(shortcut) {
        if (this.disabled || this.readonly)
            return;
        const dateValue = shortcut.getDate();
        if (!this.isDateInRange(dateValue))
            return;
        this.value = dateValue;
        this.inputValue = this.formatDateForDisplay(dateValue);
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleInputChange(e) {
        const input = e.target;
        this.inputValue = input.value;
        if (!input.value.trim()) {
            this.value = null;
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: null },
            }));
            return;
        }
        const isoDate = this.parseDisplayToIso(input.value);
        if (isoDate && this.isDateInRange(isoDate)) {
            this.value = isoDate;
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
        }
    }
    handleInputFocus() {
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleInputBlur() {
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getContainerClasses() {
        return cn('flex flex-col gap-2 w-full', this.cssClass);
    }
    getShortcutsContainerClasses() {
        return 'flex flex-wrap gap-2';
    }
    getShortcutClasses(shortcut) {
        const isSelected = this.isShortcutSelected(shortcut);
        const isDisabled = this.disabled || !this.isDateInRange(shortcut.getDate());
        return cn('ml-date-shortcut px-3 py-1.5 rounded-full text-sm font-medium transition-all duration-150', 'border cursor-pointer select-none', 'focus:outline-none focus:ring-2 focus:ring-offset-1', isSelected ? 'ml-date-shortcut-active' : '', !isDisabled && !isSelected ? 'ml-date-shortcut--hoverable' : '', isDisabled ? 'ml-disabled' : '');
    }
    getInputClasses() {
        const hasError = !!this.error;
        return cn('ml-date-shortcut-input w-full rounded-lg px-3 py-2 text-sm border transition-all duration-150', 'focus:outline-none focus:ring-2', hasError ? 'ml-date-shortcut-input--error' : '', this.isFocused && !hasError ? 'ml-date-shortcut-input--focused' : '', this.disabled ? 'ml-disabled' : '', this.readonly ? 'ml-date-shortcut-input--readonly' : '');
    }
    // ===========================================================================
    // RENDER METHODS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        const labelId = `label-${this.name || 'date-shortcut'}`;
        return html `
      <label id="${labelId}" class="${cn('ml-label text-sm', this.getSlotClass('Label'))}">
        ${unsafeHTML(labelContent)}
        ${this.required ? html `<span class="ml-error-text ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderShortcuts() {
        const shortcuts = this.getShortcuts();
        return html `
      <div class="${this.getShortcutsContainerClasses()}" role="group" aria-label="Date shortcuts">
        ${shortcuts.map(shortcut => this.renderShortcut(shortcut))}
      </div>
    `;
    }
    renderShortcut(shortcut) {
        const isDisabled = this.disabled || !this.isDateInRange(shortcut.getDate());
        const isSelected = this.isShortcutSelected(shortcut);
        return html `
      <button
        type="button"
        class="${this.getShortcutClasses(shortcut)}"
        ?disabled="${isDisabled}"
        aria-pressed="${isSelected}"
        @click="${() => this.handleShortcutClick(shortcut)}"
      >
        ${shortcut.label}
      </button>
    `;
    }
    renderInput() {
        const placeholderText = this.placeholder || this.msg.placeholder;
        const labelId = `label-${this.name || 'date-shortcut'}`;
        const errorId = `error-${this.name || 'date-shortcut'}`;
        const hasError = !!this.error;
        return html `
      <input
        type="text"
        class="${this.getInputClasses()}"
        .value="${this.inputValue}"
        placeholder="${placeholderText}"
        ?disabled="${this.disabled}"
        ?readonly="${this.readonly}"
        aria-labelledby="${this.hasSlot('Label') ? labelId : ''}"
        aria-describedby="${hasError ? errorId : ''}"
        aria-invalid="${hasError}"
        aria-required="${this.required}"
        @input="${this.handleInputChange}"
        @focus="${this.handleInputFocus}"
        @blur="${this.handleInputBlur}"
      />
    `;
    }
    renderFeedback() {
        const errorId = `error-${this.name || 'date-shortcut'}`;
        if (this.error) {
            return html `
        <p id="${errorId}" class="ml-error-text text-xs">
          ${unsafeHTML(this.error)}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="${cn('ml-helper text-xs', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderLoading() {
        return html `
      <div class="ml-text-muted flex items-center justify-center py-4 text-sm">
        <svg class="animate-spin h-5 w-5 mr-2" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        ${this.msg.loading}
      </div>
    `;
    }
    renderViewMode() {
        const displayValue = this.value
            ? this.formatDateForDisplay(this.value)
            : this.msg.noValue;
        return html `
      <div class="${this.getContainerClasses()}">
        ${this.renderLabel()}
        <span class="ml-text text-sm">${displayValue}</span>
      </div>
    `;
    }
    renderEditMode() {
        return html `
      <div class="${this.getContainerClasses()}">
        ${this.renderLabel()}
        ${this.renderShortcuts()}
        ${this.renderInput()}
        ${this.renderFeedback()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        if (this.loading) {
            return html `
        <div class="${this.getContainerClasses()}">
          ${this.renderLabel()}
          ${this.renderLoading()}
        </div>
      `;
        }
        return this.renderEditMode();
    }
};
__decorate([
    propertyDataSource({ type: String })
], DateShortcutPickerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateShortcutPickerMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateShortcutPickerMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateShortcutPickerMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-date' })
], DateShortcutPickerMolecule.prototype, "minDate", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-date' })
], DateShortcutPickerMolecule.prototype, "maxDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateShortcutPickerMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'first-day-of-week' })
], DateShortcutPickerMolecule.prototype, "firstDayOfWeek", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-week-numbers' })
], DateShortcutPickerMolecule.prototype, "showWeekNumbers", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], DateShortcutPickerMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateShortcutPickerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateShortcutPickerMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateShortcutPickerMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateShortcutPickerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], DateShortcutPickerMolecule.prototype, "inputValue", void 0);
__decorate([
    state()
], DateShortcutPickerMolecule.prototype, "isFocused", void 0);
DateShortcutPickerMolecule = __decorate([
    customElement('groupenterdate--ml-date-shortcut-picker')
], DateShortcutPickerMolecule);
export { DateShortcutPickerMolecule };
