/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-select-dropdown.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SELECT DROPDOWN MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    noSelection: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        noSelection: '—',
    },
};
let MlSelectDropdownMolecule = class MlSelectDropdownMolecule extends MoleculeAuraElement {
    // ===========================================================================
    // CONSTRUCTOR
    // ===========================================================================
    constructor() {
        super();
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — Data
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        // ===========================================================================
        // PROPERTIES — Configuration
        // ===========================================================================
        this.placeholder = '';
        this.searchable = false;
        // ===========================================================================
        // PROPERTIES — States
        // ===========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.boundHandleOutsideClick = this.handleOutsideClick.bind(this);
        this.boundHandleKeydown = this.handleKeydown.bind(this);
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.boundHandleOutsideClick);
        document.addEventListener('keydown', this.boundHandleKeydown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.boundHandleOutsideClick);
        document.removeEventListener('keydown', this.boundHandleKeydown);
    }
    // ===========================================================================
    // PARSING HELPERS
    // ===========================================================================
    parseItems() {
        const items = [];
        const itemElements = this.getSlots('Item');
        for (const el of itemElements) {
            const value = el.getAttribute('value');
            if (value !== null) {
                items.push({
                    value,
                    label: el.innerHTML.trim(),
                    disabled: el.hasAttribute('disabled'),
                });
            }
        }
        return items;
    }
    parseGroups() {
        const groups = [];
        const groupElements = this.getSlots('Group');
        for (const groupEl of groupElements) {
            const groupLabel = groupEl.getAttribute('label') || '';
            const groupItems = [];
            const itemElements = groupEl.querySelectorAll('Item');
            for (const el of Array.from(itemElements)) {
                const value = el.getAttribute('value');
                if (value !== null) {
                    groupItems.push({
                        value,
                        label: el.innerHTML.trim(),
                        disabled: el.hasAttribute('disabled'),
                        group: groupLabel,
                    });
                }
            }
            if (groupItems.length > 0) {
                groups.push({
                    label: groupLabel,
                    items: groupItems,
                });
            }
        }
        return groups;
    }
    getAllItems() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const groupedItems = groups.flatMap(g => g.items);
        return [...standaloneItems, ...groupedItems];
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.getAllItems().find(item => item.value === value);
    }
    getFilteredItems() {
        const allItems = this.getAllItems();
        if (!this.searchable || !this.searchQuery.trim()) {
            return allItems;
        }
        const query = this.searchQuery.toLowerCase().trim();
        return allItems.filter(item => item.label.toLowerCase().includes(query));
    }
    getSelectableItems() {
        return this.getFilteredItems().filter(item => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.searchQuery = '';
            this.focusedIndex = -1;
            this.dispatchEvent(new CustomEvent('focus', {
                bubbles: true,
                composed: true,
            }));
        }
    }
    handleSelect(item) {
        if (this.disabled || this.readonly || item.disabled)
            return;
        this.value = item.value;
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleOutsideClick(e) {
        if (!this.isOpen)
            return;
        const path = e.composedPath();
        if (!path.includes(this)) {
            this.isOpen = false;
            this.searchQuery = '';
            this.focusedIndex = -1;
            this.dispatchEvent(new CustomEvent('blur', {
                bubbles: true,
                composed: true,
            }));
        }
    }
    handleKeydown(e) {
        if (!this.isOpen)
            return;
        const selectableItems = this.getSelectableItems();
        switch (e.key) {
            case 'Escape':
                e.preventDefault();
                this.isOpen = false;
                this.searchQuery = '';
                this.focusedIndex = -1;
                break;
            case 'ArrowDown':
                e.preventDefault();
                if (selectableItems.length > 0) {
                    this.focusedIndex = Math.min(this.focusedIndex + 1, selectableItems.length - 1);
                }
                break;
            case 'ArrowUp':
                e.preventDefault();
                if (selectableItems.length > 0) {
                    this.focusedIndex = Math.max(this.focusedIndex - 1, 0);
                }
                break;
            case 'Enter':
                e.preventDefault();
                if (this.focusedIndex >= 0 && this.focusedIndex < selectableItems.length) {
                    this.handleSelect(selectableItems[this.focusedIndex]);
                }
                break;
        }
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
        this.focusedIndex = -1;
    }
    // ===========================================================================
    // CSS HELPERS
    // ===========================================================================
    getTriggerClasses() {
        const hasError = this.error !== '';
        return [
            'w-full flex items-center justify-between gap-2',
            'px-3 py-2 rounded-lg border text-sm transition-all',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            hasError
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            !this.disabled && !this.readonly && !this.loading
                ? 'cursor-pointer hover:border-slate-300 dark:hover:border-slate-600'
                : '',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
            this.isOpen && !hasError
                ? 'border-sky-500 dark:border-sky-400 ring-2 ring-sky-500/20 dark:ring-sky-400/20'
                : '',
            'focus:outline-none',
        ].filter(Boolean).join(' ');
    }
    getDropdownClasses() {
        return [
            'absolute z-50 w-full mt-1',
            'bg-white dark:bg-slate-800',
            'border border-slate-200 dark:border-slate-700',
            'rounded-lg shadow-lg',
            'max-h-60 overflow-auto',
        ].join(' ');
    }
    getItemClasses(item, isSelected, isFocused) {
        return [
            'w-full px-3 py-2 text-sm text-left transition-colors',
            'cursor-pointer',
            isSelected
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300'
                : 'text-slate-900 dark:text-slate-100',
            !item.disabled && !isSelected && isFocused
                ? 'bg-slate-100 dark:bg-slate-700'
                : '',
            !item.disabled && !isSelected && !isFocused
                ? 'hover:bg-slate-50 dark:hover:bg-slate-700'
                : '',
            item.disabled
                ? 'opacity-50 cursor-not-allowed text-slate-400 dark:text-slate-600'
                : '',
        ].filter(Boolean).join(' ');
    }
    getSearchInputClasses() {
        return [
            'w-full px-3 py-2 text-sm',
            'bg-slate-50 dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            'border-b border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:bg-white dark:focus:bg-slate-800',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        const labelId = `label-${this.name || 'select'}`;
        return html `
      <label 
        id="${labelId}"
        class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1"
      >
        ${unsafeHTML(labelContent)}
        ${this.required ? html `<span class="text-red-500 dark:text-red-400 ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderTriggerContent() {
        const selectedItem = this.findItem(this.value);
        if (this.loading) {
            return html `
        <span class="flex items-center gap-2 text-slate-400 dark:text-slate-500">
          <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          ${this.msg.loading}
        </span>
      `;
        }
        if (selectedItem) {
            return html `
        <span class="truncate">${unsafeHTML(selectedItem.label)}</span>
      `;
        }
        if (this.hasSlot('Trigger')) {
            return html `<span class="text-slate-400 dark:text-slate-500 truncate">${unsafeHTML(this.getSlotContent('Trigger'))}</span>`;
        }
        const placeholderText = this.placeholder || this.msg.placeholder;
        return html `<span class="text-slate-400 dark:text-slate-500 truncate">${placeholderText}</span>`;
    }
    renderChevron() {
        const rotateClass = this.isOpen ? 'rotate-180' : '';
        return html `
      <svg 
        class="w-4 h-4 text-slate-400 dark:text-slate-500 transition-transform ${rotateClass} flex-shrink-0"
        viewBox="0 0 20 20" 
        fill="currentColor"
      >
        <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd" />
      </svg>
    `;
    }
    renderTrigger() {
        const hasError = this.error !== '';
        const labelId = this.hasSlot('Label') ? `label-${this.name || 'select'}` : undefined;
        const errorId = hasError ? `error-${this.name || 'select'}` : undefined;
        return html `
      <button
        type="button"
        role="combobox"
        aria-expanded="${this.isOpen}"
        aria-haspopup="listbox"
        aria-invalid="${hasError}"
        aria-required="${this.required}"
        aria-labelledby="${labelId || ''}"
        aria-describedby="${errorId || ''}"
        class="${this.getTriggerClasses()}"
        ?disabled="${this.disabled}"
        @click="${this.handleTriggerClick}"
      >
        ${this.renderTriggerContent()}
        ${this.renderChevron()}
      </button>
    `;
    }
    renderSearchInput() {
        if (!this.searchable)
            return html ``;
        return html `
      <div class="sticky top-0 bg-white dark:bg-slate-800">
        <input
          type="text"
          class="${this.getSearchInputClasses()}"
          placeholder="${this.msg.searchPlaceholder}"
          .value="${this.searchQuery}"
          @input="${this.handleSearchInput}"
          @click="${(e) => e.stopPropagation()}"
        />
      </div>
    `;
    }
    renderItems() {
        const filteredItems = this.getFilteredItems();
        const selectableItems = this.getSelectableItems();
        if (filteredItems.length === 0) {
            return this.renderEmpty();
        }
        const groups = this.parseGroups();
        const standaloneItems = this.parseItems();
        // Filter standalone items
        const filteredStandalone = standaloneItems.filter(item => {
            if (!this.searchable || !this.searchQuery.trim())
                return true;
            return item.label.toLowerCase().includes(this.searchQuery.toLowerCase().trim());
        });
        // Filter grouped items
        const filteredGroups = groups.map(group => ({
            ...group,
            items: group.items.filter(item => {
                if (!this.searchable || !this.searchQuery.trim())
                    return true;
                return item.label.toLowerCase().includes(this.searchQuery.toLowerCase().trim());
            }),
        })).filter(group => group.items.length > 0);
        let globalIndex = 0;
        return html `
      <div role="listbox" class="py-1">
        ${filteredStandalone.map(item => {
            const isSelected = item.value === this.value;
            const selectableIndex = selectableItems.findIndex(si => si.value === item.value);
            const isFocused = selectableIndex === this.focusedIndex;
            globalIndex++;
            return html `
            <button
              type="button"
              role="option"
              aria-selected="${isSelected}"
              aria-disabled="${item.disabled}"
              class="${this.getItemClasses(item, isSelected, isFocused)}"
              @click="${() => this.handleSelect(item)}"
            >
              ${unsafeHTML(item.label)}
            </button>
          `;
        })}
        
        ${filteredGroups.map(group => html `
          <div class="pt-2 first:pt-0">
            <div class="px-3 py-1 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">
              ${group.label}
            </div>
            ${group.items.map(item => {
            const isSelected = item.value === this.value;
            const selectableIndex = selectableItems.findIndex(si => si.value === item.value);
            const isFocused = selectableIndex === this.focusedIndex;
            globalIndex++;
            return html `
                <button
                  type="button"
                  role="option"
                  aria-selected="${isSelected}"
                  aria-disabled="${item.disabled}"
                  class="${this.getItemClasses(item, isSelected, isFocused)}"
                  @click="${() => this.handleSelect(item)}"
                >
                  ${unsafeHTML(item.label)}
                </button>
              `;
        })}
          </div>
        `)}
      </div>
    `;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty')
            ? this.getSlotContent('Empty')
            : this.msg.noResults;
        return html `
      <div class="px-3 py-4 text-sm text-slate-500 dark:text-slate-400 text-center">
        ${unsafeHTML(emptyContent)}
      </div>
    `;
    }
    renderDropdown() {
        if (!this.isOpen || this.loading)
            return html ``;
        return html `
      <div class="${this.getDropdownClasses()}">
        ${this.renderSearchInput()}
        ${this.renderItems()}
      </div>
    `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `
      <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
        ${unsafeHTML(this.getSlotContent('Helper'))}
      </p>
    `;
    }
    renderError() {
        if (this.error === '')
            return html ``;
        const errorId = `error-${this.name || 'select'}`;
        return html `
      <p id="${errorId}" class="mt-1 text-xs text-red-600 dark:text-red-400">
        ${this.error}
      </p>
    `;
    }
    renderFeedback() {
        if (this.error !== '') {
            return this.renderError();
        }
        return this.renderHelper();
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayValue = selectedItem
            ? selectedItem.label
            : this.msg.noSelection;
        return html `
      <div class="text-sm text-slate-900 dark:text-slate-100">
        ${this.hasSlot('Label') ? html `
          <span class="text-slate-500 dark:text-slate-400">
            ${unsafeHTML(this.getSlotContent('Label'))}:
          </span>
          <span class="ml-1">${unsafeHTML(displayValue)}</span>
        ` : html `
          ${unsafeHTML(displayValue)}
        `}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
      <div class="relative w-full">
        ${this.renderLabel()}
        ${this.renderTrigger()}
        ${this.renderDropdown()}
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSelectDropdownMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlSelectDropdownMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSelectDropdownMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlSelectDropdownMolecule.prototype, "focusedIndex", void 0);
MlSelectDropdownMolecule = __decorate([
    customElement('groupselectone--ml-select-dropdown')
], MlSelectDropdownMolecule);
export { MlSelectDropdownMolecule };
