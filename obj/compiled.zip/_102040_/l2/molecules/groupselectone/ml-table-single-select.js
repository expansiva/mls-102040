var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var MlTableSingleSelectMolecule_1;
/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-table-single-select.ts" enhancement="_blank"/>
// =============================================================================
// GROUPSELECTONE – ML TABLE SINGLE SELECT MOLECULE
// =============================================================================
// Skill Group: groupSelectOne (single‑select table variant)
// This molecule does NOT contain business logic – it only renders UI.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    // add other locales here if needed
};
/// **collab_i18n_end**
let MlTableSingleSelectMolecule = MlTableSingleSelectMolecule_1 = class MlTableSingleSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super();
        // ---------------------------------------------------------------------------
        // i18n
        // ---------------------------------------------------------------------------
        this.msg = messages.en;
        // ---------------------------------------------------------------------------
        // SLOT TAGS
        // ---------------------------------------------------------------------------
        this.slotTags = [
            'Label',
            'Helper',
            'Trigger', // not used in table variant but kept for contract
            'Item',
            'Cell',
            'Column',
            'Group', // not used in table variant but kept for contract
            'Empty',
        ];
        // ---------------------------------------------------------------------------
        // PROPERTIES – data contract (bound to global state)
        // ---------------------------------------------------------------------------
        this.value = null;
        this.error = '';
        this.name = '';
        this.disabled = false;
        this.readonly = false;
        this.loading = false;
        this.isEditing = true;
        // ---------------------------------------------------------------------------
        // CONFIGURATION PROPERTIES
        // ---------------------------------------------------------------------------
        this.variant = 'table'; // forced to table – kept for contract compatibility
        this.placeholder = '';
        this.searchable = false;
        // ---------------------------------------------------------------------------
        // STATE PROPERTIES – internal UI state
        // ---------------------------------------------------------------------------
        this.isOpen = false; // not used for table, kept for contract
        this.searchQuery = '';
        this._uid = `groupselectone-${MlTableSingleSelectMolecule_1._uidCounter++}`;
    }
    // ---------------------------------------------------------------------------
    // HELPERS – parsing slot content
    // ---------------------------------------------------------------------------
    getItems() {
        const itemEls = this.getSlots('Item');
        return itemEls.map((el) => {
            const value = el.getAttribute('value') ?? '';
            const disabled = el.hasAttribute('disabled');
            const cellEls = Array.from(el.children).filter((c) => this.slotTags.map((t) => t.toUpperCase()).includes(c.tagName));
            const cells = cellEls.map((c) => c.innerHTML.trim());
            return { value, disabled, cells };
        });
    }
    getHeaders() {
        const columnEls = this.getSlots('Column');
        return columnEls.map((c) => c.textContent?.trim() ?? '');
    }
    getFilteredItems() {
        if (!this.searchable || !this.searchQuery)
            return this.getItems();
        const q = this.searchQuery.toLowerCase();
        return this.getItems().filter((item) => item.cells.some((cell) => cell.toLowerCase().includes(q)));
    }
    findItem(value) {
        if (value === null)
            return null;
        return this.getItems().find((i) => i.value === value) ?? null;
    }
    // ---------------------------------------------------------------------------
    // EVENT HANDLERS
    // ---------------------------------------------------------------------------
    handleRowSelect(item) {
        if (this.disabled || this.readonly || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleSearchInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.searchQuery = input.value;
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    // ---------------------------------------------------------------------------
    // RENDER HELPERS – CSS class builders
    // ---------------------------------------------------------------------------
    getTableClasses() {
        return [
            'w-full border-collapse',
            'border ml-table-border',
        ].join(' ');
    }
    getHeaderCellClasses() {
        return [
            'px-3 py-2 text-left text-sm font-medium',
            'ml-table-header',
            'border-b',
        ].join(' ');
    }
    getRowClasses(item, isSelected) {
        return [
            'cursor-pointer',
            isSelected
                ? 'ml-table-row-selected'
                : 'ml-table-row',
            item.disabled ? 'ml-disabled' : 'ml-table-row-hover',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCellClasses() {
        return [
            'px-3 py-2 text-sm',
            'border-b ml-table-cell',
        ].join(' ');
    }
    getInputClasses() {
        return [
            'w-full rounded-md px-3 py-2 text-sm border transition',
            'ml-table-search',
            this.disabled
                ? 'ml-disabled'
                : '',
            'focus:outline-none focus:ring-2',
        ].filter(Boolean).join(' ');
    }
    // ---------------------------------------------------------------------------
    // RENDER – loading, view mode, editing mode
    // ---------------------------------------------------------------------------
    renderLoading() {
        return html `<div class="text-sm ml-text-muted">${this.msg.loading}</div>`;
    }
    renderHelperOrError() {
        if (this.error) {
            return html `<p class="mt-1 text-xs ml-error-text">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class=${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}>${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderEmpty() {
        const content = this.getSlotContent('Empty') || this.msg.noResults;
        return html `<div class=${cn('p-4 text-center ml-text-muted', this.getSlotClass('Empty'))}>${unsafeHTML(content)}</div>`;
    }
    renderViewMode() {
        const selected = this.findItem(this.value);
        if (!selected) {
            const placeholder = this.placeholder || '—';
            return html `<div class="ml-text-muted">${placeholder}</div>`;
        }
        // Render cells as a simple vertical list
        return html `
<div class="space-y-1">
${selected.cells.map((c) => html `<div class="ml-text">${unsafeHTML(c)}</div>`)}
</div>
`;
    }
    renderTable() {
        const items = this.getFilteredItems();
        const headers = this.getHeaders();
        const hasHeaders = headers.length > 0;
        const selectedValue = this.value;
        return html `
${this.searchable
            ? html `
<input
type="text"
class="${this.getInputClasses()} mb-2"
placeholder="Search..."
.value=${this.searchQuery}
@input=${this.handleSearchInput}
@focus=${this.handleFocus}
@blur=${this.handleBlur}

@change="${(e) => e.stopPropagation()}"
/>
`
            : nothing}
<table class="${this.getTableClasses()}">
${hasHeaders
            ? html `
<thead>
<tr>
<th class="${this.getHeaderCellClasses()}"></th>
${headers.map((h) => html `<th class="${this.getHeaderCellClasses()}">${unsafeHTML(h)}</th>`)}
</tr>
</thead>
`
            : nothing}
<tbody>
${items.length
            ? items.map((item) => {
                const isSelected = item.value === selectedValue;
                return html `
<tr
class="${this.getRowClasses(item, isSelected)}"
@click=${() => this.handleRowSelect(item)}
>
<td class="${this.getCellClasses()}">
<input
type="radio"
name="${this._uid}"
.checked=${isSelected}
?disabled=${item.disabled || this.disabled || this.readonly}
@click=${(e) => e.stopPropagation()}

@input="${(e) => e.stopPropagation()}"

@change="${(e) => e.stopPropagation()}"
/>
</td>
${item.cells.map((c) => html `<td class="${this.getCellClasses()}">${unsafeHTML(c)}</td>`)}
</tr>
`;
            })
            : html `<tr><td colspan="${hasHeaders ? headers.length + 1 : 1}" class="${this.getCellClasses()}">${this.renderEmpty()}</td></tr>`}
</tbody>
</table>
${this.renderHelperOrError()}
`;
    }
    render() {
        // i18n handling – pick language based on host attribute or fallback to 'en'
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Loading state takes precedence
        if (this.loading) {
            return html `<div class=${cn('p-2', this.cssClass)}>${this.renderLoading()}</div>`;
        }
        // View mode – static representation
        if (!this.isEditing) {
            return html `
<div class=${cn('groupselectone--ml-table-single-select-view', this.cssClass)}>
${this.renderViewMode()}
</div>
`;
        }
        // Editing mode – render label, table (or empty), helper/error
        return html `
<div class=${cn('groupselectone--ml-table-single-select', this.cssClass)}>
${this.hasSlot('Label')
            ? html `<label class=${cn('block mb-1 text-sm font-medium ml-label', this.getSlotClass('Label'))}>
${unsafeHTML(this.getSlotContent('Label'))}
</label>`
            : nothing}
${this.renderTable()}
</div>
`;
    }
};
// ---------------------------------------------------------------------------
// INTERNAL – unique radio group name per instance
// ---------------------------------------------------------------------------
MlTableSingleSelectMolecule._uidCounter = 0;
__decorate([
    propertyDataSource({ type: String })
], MlTableSingleSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTableSingleSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTableSingleSelectMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableSingleSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableSingleSelectMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableSingleSelectMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableSingleSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'variant' })
], MlTableSingleSelectMolecule.prototype, "variant", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTableSingleSelectMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'searchable' })
], MlTableSingleSelectMolecule.prototype, "searchable", void 0);
__decorate([
    state()
], MlTableSingleSelectMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlTableSingleSelectMolecule.prototype, "searchQuery", void 0);
MlTableSingleSelectMolecule = MlTableSingleSelectMolecule_1 = __decorate([
    customElement('groupselectone--ml-table-single-select')
], MlTableSingleSelectMolecule);
export { MlTableSingleSelectMolecule };
