/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-listbox-sidebar-select.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// LISTBOX SIDEBAR SELECT MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// A permanently open listbox for sidebar master-detail selection.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    noSelection: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Pesquisar...',
        noSelection: '—',
    },
};
let MlListboxSidebarSelectMolecule = class MlListboxSidebarSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.listboxId = `listbox-${Math.random().toString(36).substr(2, 9)}`;
        this.labelId = `label-${Math.random().toString(36).substr(2, 9)}`;
        this.errorId = `error-${Math.random().toString(36).substr(2, 9)}`;
        this.handleKeyDown = (e) => {
            if (!this.isEditing || this.disabled || this.readonly || this.loading)
                return;
            const selectableItems = this.getSelectableItems();
            if (selectableItems.length === 0)
                return;
            switch (e.key) {
                case 'ArrowDown':
                    e.preventDefault();
                    this.focusedIndex = Math.min(this.focusedIndex + 1, selectableItems.length - 1);
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    this.focusedIndex = Math.max(this.focusedIndex - 1, 0);
                    break;
                case 'Enter':
                    e.preventDefault();
                    if (this.focusedIndex >= 0 && this.focusedIndex < selectableItems.length) {
                        this.handleSelect(selectableItems[this.focusedIndex]);
                    }
                    break;
                case 'Escape':
                    e.preventDefault();
                    this.focusedIndex = -1;
                    break;
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.addEventListener('keydown', this.handleKeyDown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeEventListener('keydown', this.handleKeyDown);
    }
    // ===========================================================================
    // ITEM PARSING
    // ===========================================================================
    parseItems() {
        const items = [];
        const groups = [];
        const groupElements = this.getSlots('Group');
        const standaloneItems = this.getSlots('Item');
        // Parse grouped items
        groupElements.forEach((groupEl) => {
            const groupLabel = groupEl.getAttribute('label') || '';
            const groupItems = [];
            const itemElements = groupEl.querySelectorAll('Item');
            itemElements.forEach((itemEl) => {
                const item = {
                    value: itemEl.getAttribute('value') || '',
                    label: itemEl.innerHTML.trim(),
                    disabled: itemEl.hasAttribute('disabled'),
                    groupLabel,
                };
                groupItems.push(item);
                items.push(item);
            });
            if (groupItems.length > 0) {
                groups.push({ label: groupLabel, items: groupItems });
            }
        });
        // Parse standalone items
        standaloneItems.forEach((itemEl) => {
            const item = {
                value: itemEl.getAttribute('value') || '',
                label: itemEl.innerHTML.trim(),
                disabled: itemEl.hasAttribute('disabled'),
            };
            items.push(item);
        });
        return { items, groups };
    }
    findItem(value) {
        if (value === null)
            return undefined;
        const { items } = this.parseItems();
        return items.find((item) => item.value === value);
    }
    getFilteredItems() {
        const { items, groups } = this.parseItems();
        const query = this.searchQuery.toLowerCase().trim();
        if (!query) {
            return { items, groups };
        }
        const filteredItems = items.filter((item) => item.label.toLowerCase().includes(query));
        const filteredGroups = groups
            .map((group) => ({
            ...group,
            items: group.items.filter((item) => item.label.toLowerCase().includes(query)),
        }))
            .filter((group) => group.items.length > 0);
        return { items: filteredItems, groups: filteredGroups };
    }
    getSelectableItems() {
        const { items } = this.getFilteredItems();
        return items.filter((item) => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
        this.focusedIndex = -1;
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getContainerClasses() {
        return ['flex flex-col gap-1.5 w-full'].join(' ');
    }
    getLabelClasses() {
        return [
            'text-sm font-medium',
            'text-slate-700 dark:text-slate-300',
        ].join(' ');
    }
    getPanelClasses() {
        return [
            'w-full rounded-lg border overflow-hidden',
            'bg-white dark:bg-slate-800',
            this.error
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            this.disabled ? 'opacity-50' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSearchInputClasses() {
        return [
            'w-full px-3 py-2 text-sm border-b',
            'bg-slate-50 dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-inset focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled || this.readonly ? 'cursor-not-allowed' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getListClasses() {
        return [
            'max-h-64 overflow-y-auto',
            'divide-y divide-slate-100 dark:divide-slate-700',
        ].join(' ');
    }
    getGroupLabelClasses() {
        return [
            'px-3 py-2 text-xs font-semibold uppercase tracking-wider',
            'text-slate-500 dark:text-slate-400',
            'bg-slate-50 dark:bg-slate-900',
        ].join(' ');
    }
    getItemClasses(item, isSelected, isFocused) {
        return [
            'w-full px-3 py-2.5 text-sm text-left transition-colors',
            'flex items-center gap-2',
            isSelected
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 font-medium'
                : 'text-slate-900 dark:text-slate-100',
            isFocused && !isSelected
                ? 'bg-slate-100 dark:bg-slate-700'
                : '',
            !item.disabled && !isSelected && !isFocused
                ? 'hover:bg-slate-50 dark:hover:bg-slate-700'
                : '',
            item.disabled
                ? 'opacity-50 cursor-not-allowed text-slate-400 dark:text-slate-600'
                : 'cursor-pointer',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getHelperClasses() {
        return ['text-xs text-slate-500 dark:text-slate-400'].join(' ');
    }
    getErrorClasses() {
        return ['text-xs text-red-600 dark:text-red-400'].join(' ');
    }
    getViewModeClasses() {
        return [
            'text-sm',
            'text-slate-900 dark:text-slate-100',
        ].join(' ');
    }
    getLoadingClasses() {
        return [
            'flex items-center justify-center gap-2 py-8',
            'text-sm text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    getEmptyClasses() {
        return [
            'flex items-center justify-center py-8',
            'text-sm text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${this.labelId} class=${this.getLabelClasses()}>
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="text-red-500 dark:text-red-400 ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderSearchInput() {
        if (!this.searchable)
            return html ``;
        return html `
      <input
        type="text"
        class=${this.getSearchInputClasses()}
        placeholder=${this.msg.searchPlaceholder}
        .value=${this.searchQuery}
        @input=${this.handleSearchInput}
        ?disabled=${this.disabled || this.readonly}
        aria-label=${this.msg.searchPlaceholder}
      />
    `;
    }
    renderItem(item, index) {
        const isSelected = this.value === item.value;
        const selectableItems = this.getSelectableItems();
        const selectableIndex = selectableItems.findIndex((i) => i.value === item.value);
        const isFocused = selectableIndex === this.focusedIndex;
        return html `
      <button
        type="button"
        role="option"
        class=${this.getItemClasses(item, isSelected, isFocused)}
        aria-selected=${isSelected}
        aria-disabled=${item.disabled}
        ?disabled=${item.disabled}
        @click=${() => this.handleSelect(item)}
      >
        ${isSelected
            ? html `
              <svg
                class="w-4 h-4 text-sky-500 dark:text-sky-400 flex-shrink-0"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M5 13l4 4L19 7"
                />
              </svg>
            `
            : html `<span class="w-4 h-4 flex-shrink-0"></span>`}
        <span class="flex-1">${unsafeHTML(item.label)}</span>
      </button>
    `;
    }
    renderGroupedItems() {
        const { items, groups } = this.getFilteredItems();
        // Get standalone items (items without a group)
        const groupedValues = new Set(groups.flatMap((g) => g.items.map((i) => i.value)));
        const standaloneItems = items.filter((item) => !groupedValues.has(item.value) || !item.groupLabel);
        if (items.length === 0) {
            return this.renderEmpty();
        }
        let itemIndex = 0;
        return html `
      ${groups.map((group) => html `
          <div>
            <div class=${this.getGroupLabelClasses()}>${group.label}</div>
            ${group.items.map((item) => {
            const result = this.renderItem(item, itemIndex);
            itemIndex++;
            return result;
        })}
          </div>
        `)}
      ${standaloneItems.map((item) => {
            const result = this.renderItem(item, itemIndex);
            itemIndex++;
            return result;
        })}
    `;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty')
            ? this.getSlotContent('Empty')
            : this.msg.noResults;
        return html `
      <div class=${this.getEmptyClasses()}>
        ${unsafeHTML(emptyContent)}
      </div>
    `;
    }
    renderLoading() {
        return html `
      <div class=${this.getLoadingClasses()}>
        <svg
          class="animate-spin h-4 w-4 text-sky-500 dark:text-sky-400"
          fill="none"
          viewBox="0 0 24 24"
        >
          <circle
            class="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            stroke-width="4"
          ></circle>
          <path
            class="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          ></path>
        </svg>
        <span>${this.msg.loading}</span>
      </div>
    `;
    }
    renderHelper() {
        if (this.error) {
            return html `
        <p id=${this.errorId} class=${this.getErrorClasses()}>
          ${unsafeHTML(this.error)}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class=${this.getHelperClasses()}>
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayText = selectedItem
            ? selectedItem.label
            : this.placeholder || this.msg.noSelection;
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()}
        <span class=${this.getViewModeClasses()}>
          ${unsafeHTML(displayText)}
        </span>
      </div>
    `;
    }
    renderEditMode() {
        const hasError = !!this.error;
        const { items } = this.parseItems();
        const hasItems = items.length > 0;
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()}
        <div
          class=${this.getPanelClasses()}
          role="listbox"
          id=${this.listboxId}
          aria-labelledby=${this.hasSlot('Label') ? this.labelId : ''}
          aria-describedby=${hasError ? this.errorId : ''}
          aria-invalid=${hasError}
          aria-required=${this.required}
          aria-disabled=${this.disabled}
          tabindex=${this.disabled ? -1 : 0}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
        >
          ${this.renderSearchInput()}
          <div class=${this.getListClasses()}>
            ${this.loading
            ? this.renderLoading()
            : hasItems
                ? this.renderGroupedItems()
                : this.renderEmpty()}
          </div>
        </div>
        ${this.renderHelper()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlListboxSidebarSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlListboxSidebarSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlListboxSidebarSelectMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlListboxSidebarSelectMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlListboxSidebarSelectMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlListboxSidebarSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlListboxSidebarSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlListboxSidebarSelectMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlListboxSidebarSelectMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlListboxSidebarSelectMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlListboxSidebarSelectMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlListboxSidebarSelectMolecule.prototype, "focusedIndex", void 0);
MlListboxSidebarSelectMolecule = __decorate([
    customElement('groupselectone--ml-listbox-sidebar-select')
], MlListboxSidebarSelectMolecule);
export { MlListboxSidebarSelectMolecule };
