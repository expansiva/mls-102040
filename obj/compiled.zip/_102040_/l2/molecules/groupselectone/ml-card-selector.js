/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-card-selector.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CARD SELECTOR MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, render as litRender } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    noValue: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        noValue: '—',
    },
};
let MlCardSelectorMolecule = class MlCardSelectorMolecule extends MoleculeAuraElement {
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    constructor() {
        super();
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-card-selector .ml-select-trigger,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-trigger {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-md, 8px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupselectone--ml-card-selector .ml-select-trigger:focus-within,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-trigger:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-card-selector .ml-select-trigger-open,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-trigger-open {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-card-selector .ml-select-trigger-error,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-trigger-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupselectone--ml-card-selector .ml-combobox-input,
div[data-widget="groupselectone--ml-card-selector"] .ml-combobox-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-card-selector .ml-combobox-input::placeholder,
div[data-widget="groupselectone--ml-card-selector"] .ml-combobox-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupselectone--ml-card-selector .ml-select-panel,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-panel {
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  box-shadow: var(--ml-shadow-2, 0 4px 6px rgba(0, 0, 0, 0.1));
}
groupselectone--ml-card-selector .ml-select-empty,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-empty {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-card-selector .ml-select-checkmark,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-checkmark {
  color: var(--ml-primary, #3b82f6);
}
groupselectone--ml-card-selector .ml-select-item-highlighted,
div[data-widget="groupselectone--ml-card-selector"] .ml-select-item-highlighted {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-card-selector .ml-card-option,
div[data-widget="groupselectone--ml-card-selector"] .ml-card-option {
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  border-radius: var(--ml-radius-md, 8px);
}
groupselectone--ml-card-selector .ml-card-option:hover,
div[data-widget="groupselectone--ml-card-selector"] .ml-card-option:hover {
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-on-surface-faint, #79747e);
}
groupselectone--ml-card-selector .ml-card-option-selected,
div[data-widget="groupselectone--ml-card-selector"] .ml-card-option-selected {
  border-color: var(--ml-primary, #3b82f6);
  background: color-mix(in srgb, var(--ml-primary, #3b82f6) 10%, transparent);
}
groupselectone--ml-card-selector .ml-card-option-error,
div[data-widget="groupselectone--ml-card-selector"] .ml-card-option-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupselectone--ml-card-selector .ml-label,
div[data-widget="groupselectone--ml-card-selector"] .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectone--ml-card-selector .ml-helper,
div[data-widget="groupselectone--ml-card-selector"] .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-card-selector .ml-error-text,
div[data-widget="groupselectone--ml-card-selector"] .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-card-selector .ml-text,
div[data-widget="groupselectone--ml-card-selector"] .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-card-selector .ml-text-muted,
div[data-widget="groupselectone--ml-card-selector"] .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-card-selector .ml-disabled,
div[data-widget="groupselectone--ml-card-selector"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — Data
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        // ===========================================================================
        // PROPERTIES — Configuration
        // ===========================================================================
        this.placeholder = '';
        this.searchable = false;
        // ===========================================================================
        // PROPERTIES — States
        // ===========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.portalContainer = null;
        this.portalWidgetName = 'groupselectone--ml-card-selector';
        this.boundHandleOutsideClick = this.handleOutsideClick.bind(this);
        this.boundHandleKeydown = this.handleKeydown.bind(this);
        this.boundUpdatePosition = this.updatePanelPosition.bind(this);
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.boundHandleOutsideClick);
        document.addEventListener('keydown', this.boundHandleKeydown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.boundHandleOutsideClick);
        document.removeEventListener('keydown', this.boundHandleKeydown);
        this.destroyPortal();
    }
    updated(_changedProperties) {
        super.updated(_changedProperties);
        if (this.isOpen && this.portalContainer) {
            this.renderPortalContent();
            this.updatePanelPosition();
        }
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    parseItems() {
        const items = [];
        const itemElements = this.getSlots('Item');
        for (const el of itemElements) {
            const value = el.getAttribute('value') || '';
            const disabled = el.hasAttribute('disabled');
            const label = el.textContent?.trim() || value;
            const content = el.innerHTML;
            items.push({ value, label, disabled, content });
        }
        return items;
    }
    parseGroups() {
        const groups = [];
        const groupElements = this.getSlots('Group');
        for (const groupEl of groupElements) {
            const groupLabel = groupEl.getAttribute('label') || '';
            const groupItems = [];
            const itemElements = groupEl.querySelectorAll('Item');
            for (const el of Array.from(itemElements)) {
                const value = el.getAttribute('value') || '';
                const disabled = el.hasAttribute('disabled');
                const label = el.textContent?.trim() || value;
                const content = el.innerHTML;
                groupItems.push({ value, label, disabled, content, group: groupLabel });
            }
            if (groupItems.length > 0) {
                groups.push({ label: groupLabel, items: groupItems });
            }
        }
        return groups;
    }
    getAllItems() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const groupedItems = groups.flatMap(g => g.items);
        return [...standaloneItems, ...groupedItems];
    }
    getFilteredItems(items) {
        if (!this.searchable || !this.searchQuery.trim()) {
            return items;
        }
        const query = this.searchQuery.toLowerCase().trim();
        return items.filter(item => item.label.toLowerCase().includes(query) ||
            item.value.toLowerCase().includes(query));
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.getAllItems().find(item => item.value === value);
    }
    getSelectableItems() {
        return this.getFilteredItems(this.getAllItems()).filter(item => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleOutsideClick(e) {
        if (!this.isOpen)
            return;
        const path = e.composedPath();
        if (!path.includes(this) && (!this.portalContainer || !path.includes(this.portalContainer))) {
            this.closePanel();
        }
    }
    handleKeydown(e) {
        if (!this.isOpen)
            return;
        const selectableItems = this.getSelectableItems();
        if (selectableItems.length === 0)
            return;
        switch (e.key) {
            case 'Escape':
                e.preventDefault();
                this.closePanel();
                break;
            case 'ArrowDown':
                e.preventDefault();
                this.focusedIndex = Math.min(this.focusedIndex + 1, selectableItems.length - 1);
                break;
            case 'ArrowUp':
                e.preventDefault();
                this.focusedIndex = Math.max(this.focusedIndex - 1, 0);
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.focusedIndex = Math.min(this.focusedIndex + 1, selectableItems.length - 1);
                break;
            case 'ArrowLeft':
                e.preventDefault();
                this.focusedIndex = Math.max(this.focusedIndex - 1, 0);
                break;
            case 'Enter':
                e.preventDefault();
                if (this.focusedIndex >= 0 && this.focusedIndex < selectableItems.length) {
                    this.handleSelect(selectableItems[this.focusedIndex].value);
                }
                break;
        }
    }
    handleTriggerClick(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        if (this.isOpen) {
            this.closePanel();
        }
        else {
            this.openPanel();
        }
    }
    handleSelect(value) {
        if (this.disabled || this.readonly)
            return;
        this.value = value;
        this.closePanel();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
        this.focusedIndex = 0;
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    openPanel() {
        this.isOpen = true;
        this.searchQuery = '';
        this.focusedIndex = 0;
        this.createPortal();
        this.handleFocus();
    }
    closePanel() {
        this.isOpen = false;
        this.searchQuery = '';
        this.focusedIndex = -1;
        this.destroyPortal();
        this.handleBlur();
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getTriggerClasses() {
        const hasError = this.error !== '';
        return cn('w-full min-h-[44px] rounded-lg px-4 py-3 text-sm border transition', 'flex items-center justify-between gap-2 cursor-pointer ml-select-trigger', hasError ? 'ml-select-trigger-error' : '', this.isOpen ? 'ml-select-trigger-open' : '', this.disabled ? 'ml-disabled' : '', this.readonly ? 'cursor-default' : '', this.getSlotClass('Trigger'));
    }
    getPanelClasses() {
        return 'w-full max-h-[400px] overflow-auto rounded-lg border ml-select-panel';
    }
    getCardClasses(item, isSelected, isFocused) {
        const hasError = this.error !== '';
        return cn('rounded-lg border-2 p-4 transition cursor-pointer ml-card-option', isSelected ? 'ml-card-option-selected' : '', hasError ? 'ml-card-option-error' : '', isFocused && !isSelected ? 'ml-select-item-highlighted' : '', item.disabled ? 'ml-disabled' : '', this.getSlotClass('Item'));
    }
    getSearchInputClasses() {
        return 'w-full rounded-lg px-3 py-2 text-sm border transition focus:outline-none focus:ring-2 ml-combobox-input ml-select-trigger';
    }
    getGroupLabelClasses() {
        return 'text-xs font-semibold uppercase tracking-wider mb-2 ml-text-muted';
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        const labelId = `label-${this.name || 'card-selector'}`;
        return html `
      <label
        id="${labelId}"
        class="${cn('block text-sm font-medium mb-1.5 ml-label', this.getSlotClass('Label'))}"
      >
        ${unsafeHTML(labelContent)}
        ${this.required ? html `<span class="ml-error-text ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderTrigger() {
        const selectedItem = this.findItem(this.value);
        const placeholderText = this.placeholder || this.getSlotContent('Trigger') || this.msg.placeholder;
        const hasError = this.error !== '';
        const labelId = `label-${this.name || 'card-selector'}`;
        const errorId = `error-${this.name || 'card-selector'}`;
        return html `
      <button
        type="button"
        role="combobox"
        aria-expanded="${this.isOpen}"
        aria-haspopup="listbox"
        aria-labelledby="${this.hasSlot('Label') ? labelId : ''}"
        aria-describedby="${hasError ? errorId : ''}"
        aria-invalid="${hasError}"
        aria-required="${this.required}"
        ?disabled="${this.disabled}"
        class="${this.getTriggerClasses()}"
        @click="${this.handleTriggerClick}"
      >
        <span class="flex-1 text-left ${!selectedItem ? 'ml-text-muted' : ''}">
          ${this.loading
            ? html `<span class="flex items-center gap-2 ml-text-muted">
                <svg class="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                  <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                ${this.msg.loading}
              </span>`
            : selectedItem
                ? selectedItem.label
                : unsafeHTML(placeholderText)}
        </span>
        <svg
          class="w-5 h-5 ml-text-muted transition-transform ${this.isOpen ? 'rotate-180' : ''}"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
        </svg>
      </button>
    `;
    }
    renderSearch() {
        if (!this.searchable)
            return html ``;
        return html `
      <div class="p-3 border-b ml-select-panel">
        <input
          type="text"
          class="${this.getSearchInputClasses()}"
          placeholder="${this.msg.searchPlaceholder}"
          .value="${this.searchQuery}"
          @input="${this.handleSearchInput}"
        />
      </div>
    `;
    }
    renderCard(item, index) {
        const isSelected = this.value === item.value;
        const selectableItems = this.getSelectableItems();
        const selectableIndex = selectableItems.findIndex(i => i.value === item.value);
        const isFocused = selectableIndex === this.focusedIndex;
        return html `
      <div
        role="option"
        aria-selected="${isSelected}"
        aria-disabled="${item.disabled}"
        class="${this.getCardClasses(item, isSelected, isFocused)}"
        @click="${() => !item.disabled && this.handleSelect(item.value)}"
      >
        <div class="flex items-start gap-3">
          <div class="flex-1">
            ${unsafeHTML(item.content)}
          </div>
          ${isSelected ? html `
            <div class="flex-shrink-0">
              <svg class="w-5 h-5 ml-select-checkmark" fill="currentColor" viewBox="0 0 20 20">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path>
              </svg>
            </div>
          ` : html ``}
        </div>
      </div>
    `;
    }
    renderCardGrid() {
        const standaloneItems = this.getFilteredItems(this.parseItems());
        const groups = this.parseGroups();
        const hasItems = standaloneItems.length > 0 || groups.some(g => this.getFilteredItems(g.items).length > 0);
        if (!hasItems) {
            return this.renderEmpty();
        }
        let itemIndex = 0;
        return html `
      <div class="p-4">
        ${groups.map(group => {
            const filteredGroupItems = this.getFilteredItems(group.items);
            if (filteredGroupItems.length === 0)
                return html ``;
            return html `
            <div class="mb-4 last:mb-0">
              <div class="${this.getGroupLabelClasses()}">${group.label}</div>
              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                ${filteredGroupItems.map(item => {
                const card = this.renderCard(item, itemIndex);
                itemIndex++;
                return card;
            })}
              </div>
            </div>
          `;
        })}
        ${standaloneItems.length > 0 ? html `
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            ${standaloneItems.map(item => {
            const card = this.renderCard(item, itemIndex);
            itemIndex++;
            return card;
        })}
          </div>
        ` : html ``}
      </div>
    `;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty')
            ? this.getSlotContent('Empty')
            : this.msg.noResults;
        return html `
      <div class="p-8 text-center ml-select-empty">
        ${unsafeHTML(emptyContent)}
      </div>
    `;
    }
    createPortal() {
        if (this.portalContainer)
            return;
        this.portalContainer = document.createElement('div');
        if (this.portalWidgetName) {
            this.portalContainer.setAttribute('data-widget', this.portalWidgetName);
        }
        document.body.appendChild(this.portalContainer);
        this.updatePanelPosition();
        this.renderPortalContent();
        window.addEventListener('scroll', this.boundUpdatePosition, true);
        window.addEventListener('resize', this.boundUpdatePosition);
    }
    destroyPortal() {
        if (!this.portalContainer)
            return;
        window.removeEventListener('scroll', this.boundUpdatePosition, true);
        window.removeEventListener('resize', this.boundUpdatePosition);
        this.portalContainer.remove();
        this.portalContainer = null;
    }
    updatePanelPosition() {
        if (!this.portalContainer)
            return;
        const trigger = this.querySelector('button[role="combobox"]');
        if (!trigger)
            return;
        const rect = trigger.getBoundingClientRect();
        Object.assign(this.portalContainer.style, {
            position: 'fixed',
            top: `${rect.bottom + 8}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            zIndex: '9999',
        });
    }
    renderPortalContent() {
        if (!this.portalContainer)
            return;
        litRender(this.getPortalTemplate(), this.portalContainer, { host: this });
    }
    getPortalTemplate() {
        return html `
      <div role="listbox" class="${this.getPanelClasses()}">
        ${this.renderSearch()}
        ${this.renderCardGrid()}
      </div>
    `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        const helperContent = this.getSlotContent('Helper');
        return html `
      <p class="${cn('mt-1.5 text-xs ml-helper', this.getSlotClass('Helper'))}">
        ${unsafeHTML(helperContent)}
      </p>
    `;
    }
    renderError() {
        if (!this.error)
            return html ``;
        const errorId = `error-${this.name || 'card-selector'}`;
        return html `
      <p id="${errorId}" class="mt-1.5 text-xs ml-error-text">
        ${unsafeHTML(this.error)}
      </p>
    `;
    }
    renderFeedback() {
        if (this.error) {
            return this.renderError();
        }
        return this.renderHelper();
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayValue = selectedItem
            ? selectedItem.label
            : (this.placeholder || this.msg.noValue);
        return html `
      <div class="${cn('text-sm ml-text', this.cssClass)}">
        ${this.hasSlot('Label') ? html `
          <span class="${cn('ml-text-muted', this.getSlotClass('Label'))}">
            ${unsafeHTML(this.getSlotContent('Label'))}:
          </span>
          <span class="ml-1">${displayValue}</span>
        ` : html `
          <span>${displayValue}</span>
        `}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
      <div class="${cn('relative w-full', this.cssClass)}">
        ${this.renderLabel()}
        ${this.renderTrigger()}
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlCardSelectorMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlCardSelectorMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardSelectorMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlCardSelectorMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlCardSelectorMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlCardSelectorMolecule.prototype, "focusedIndex", void 0);
MlCardSelectorMolecule = __decorate([
    customElement('groupselectone--ml-card-selector')
], MlCardSelectorMolecule);
export { MlCardSelectorMolecule };
