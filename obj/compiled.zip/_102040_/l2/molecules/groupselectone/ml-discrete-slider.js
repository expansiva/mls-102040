/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-discrete-slider.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// DISCRETE SLIDER MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noSelection: '—',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        noSelection: '—',
        loading: 'Carregando...',
    },
};
let MlDiscreteSliderMolecule = class MlDiscreteSliderMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-discrete-slider .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectone--ml-discrete-slider .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-discrete-slider .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-discrete-slider .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-discrete-slider .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-discrete-slider .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-discrete-slider .ml-slider-track {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-discrete-slider .ml-slider-track-error {
  background-color: color-mix(in srgb, var(--ml-error, #ef4444) 15%, var(--ml-surface, #ffffff));
}
groupselectone--ml-discrete-slider .ml-slider-thumb {
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupselectone--ml-discrete-slider .ml-slider-thumb-arrow::after {
  border-top-color: var(--ml-primary, #3b82f6);
}
groupselectone--ml-discrete-slider .ml-slider-mark {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectone--ml-discrete-slider .ml-slider-mark-active {
  background-color: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupselectone--ml-discrete-slider .ml-slider-mark-focus {
  box-shadow: 0 0 0 2px var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-discrete-slider .ml-slider-label {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectone--ml-discrete-slider .ml-slider-label-active {
  color: var(--ml-primary, #3b82f6);
  font-weight: var(--ml-font-weight-medium, 500);
}
groupselectone--ml-discrete-slider .ml-slider-label-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupselectone--ml-discrete-slider .ml-slider-indicator-idle {
  background-color: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectone--ml-discrete-slider .ml-slider-filled {
  background-color: var(--ml-primary, #3b82f6);
}
groupselectone--ml-discrete-slider .ml-slider-drag-thumb {
  background-color: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
  box-shadow: 0 0 0 9px color-mix(in srgb, var(--ml-primary, #3b82f6) 18%, transparent);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        this.fillPrevious = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isActive = false;
        this.focusedIndex = -1;
        this.isDragging = false;
        this.dragRatio = 0;
        this.parsedItems = [];
        this.parsedGroups = [];
        this.boundHandleOutsideClick = this.handleOutsideClick.bind(this);
        this.boundHandleKeydown = this.handleKeydown.bind(this);
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.boundHandleOutsideClick);
        document.addEventListener('keydown', this.boundHandleKeydown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.boundHandleOutsideClick);
        document.removeEventListener('keydown', this.boundHandleKeydown);
    }
    firstUpdated() {
        this.parseSlotContent();
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            this.updateFocusedIndexFromValue();
        }
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    parseSlotContent() {
        const items = [];
        const groups = [];
        let currentGroup;
        let groupStartIndex = 0;
        const groupElements = this.getSlots('Group');
        const itemElements = this.getSlots('Item');
        // Parse groups and their items
        groupElements.forEach((groupEl) => {
            const groupLabel = groupEl.getAttribute('label') || '';
            const groupItems = Array.from(groupEl.querySelectorAll('Item'));
            if (groupItems.length > 0) {
                groupStartIndex = items.length;
                groupItems.forEach((itemEl) => {
                    const itemValue = itemEl.getAttribute('value');
                    if (itemValue) {
                        items.push({
                            value: itemValue,
                            label: itemEl.innerHTML.trim(),
                            disabled: itemEl.hasAttribute('disabled'),
                            group: groupLabel,
                        });
                    }
                });
                groups.push({
                    label: groupLabel,
                    startIndex: groupStartIndex,
                    endIndex: items.length - 1,
                });
            }
        });
        // Parse standalone items
        itemElements.forEach((itemEl) => {
            const itemValue = itemEl.getAttribute('value');
            if (itemValue) {
                items.push({
                    value: itemValue,
                    label: itemEl.innerHTML.trim(),
                    disabled: itemEl.hasAttribute('disabled'),
                });
            }
        });
        // Limit to 7 items max
        this.parsedItems = items.slice(0, 7);
        this.parsedGroups = groups.filter(g => g.endIndex < 7);
        this.updateFocusedIndexFromValue();
    }
    updateFocusedIndexFromValue() {
        if (this.isDragging)
            return;
        if (this.value !== null) {
            const index = this.parsedItems.findIndex(item => item.value === this.value);
            this.focusedIndex = index >= 0 ? index : -1;
        }
        else {
            this.focusedIndex = -1;
        }
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.parsedItems.find(item => item.value === value);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleOutsideClick(e) {
        if (!this.isActive)
            return;
        const path = e.composedPath();
        if (!path.includes(this)) {
            this.isActive = false;
        }
    }
    handleKeydown(e) {
        if (!this.isActive || !this.isEditing)
            return;
        if (this.disabled || this.readonly || this.loading)
            return;
        const enabledIndices = this.parsedItems
            .map((item, index) => ({ item, index }))
            .filter(({ item }) => !item.disabled)
            .map(({ index }) => index);
        if (enabledIndices.length === 0)
            return;
        switch (e.key) {
            case 'ArrowRight':
            case 'ArrowDown': {
                e.preventDefault();
                const currentPos = enabledIndices.indexOf(this.focusedIndex);
                const nextPos = currentPos < enabledIndices.length - 1 ? currentPos + 1 : 0;
                this.focusedIndex = enabledIndices[nextPos >= 0 ? nextPos : 0];
                break;
            }
            case 'ArrowLeft':
            case 'ArrowUp': {
                e.preventDefault();
                const currentPos = enabledIndices.indexOf(this.focusedIndex);
                const prevPos = currentPos > 0 ? currentPos - 1 : enabledIndices.length - 1;
                this.focusedIndex = enabledIndices[prevPos];
                break;
            }
            case 'Enter':
            case ' ': {
                e.preventDefault();
                if (this.focusedIndex >= 0 && !this.parsedItems[this.focusedIndex]?.disabled) {
                    this.selectItem(this.parsedItems[this.focusedIndex].value);
                }
                break;
            }
            case 'Escape': {
                e.preventDefault();
                this.isActive = false;
                this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
                break;
            }
        }
    }
    handleTrackClick(e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (this.parsedItems.length < 2)
            return;
        if (e.target.closest('button'))
            return;
        if (!this.isActive) {
            this.isActive = true;
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
        const index = this.getIndexFromPointerX(e.clientX);
        if (index >= 0 && !this.parsedItems[index]?.disabled) {
            this.selectItem(this.parsedItems[index].value);
        }
    }
    handleStopPointerDown(index, e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (this.parsedItems[index]?.disabled)
            return;
        e.preventDefault();
        e.stopPropagation();
        e.currentTarget.setPointerCapture(e.pointerId);
        this.isDragging = true;
        this.focusedIndex = index;
        this.dragRatio = this.calculateStopPosition(index) / 100;
        if (!this.isActive) {
            this.isActive = true;
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
    }
    handleDragPointerMove(e) {
        if (!this.isDragging)
            return;
        e.preventDefault();
        const track = this.renderRoot.querySelector('[data-track]');
        if (!track)
            return;
        const rect = track.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width));
        this.dragRatio = ratio;
        const index = Math.round(ratio * (this.parsedItems.length - 1));
        if (index >= 0 && !this.parsedItems[index]?.disabled) {
            this.focusedIndex = index;
        }
    }
    handleDragPointerUp(_e) {
        if (!this.isDragging)
            return;
        this.isDragging = false;
        if (this.focusedIndex >= 0 && !this.parsedItems[this.focusedIndex]?.disabled) {
            this.selectItem(this.parsedItems[this.focusedIndex].value);
        }
    }
    selectItem(value) {
        this.value = value;
        this.isActive = false;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value },
        }));
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getContainerClasses() {
        return [
            'w-full',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getSliderTrackClasses() {
        return [
            'relative w-full h-2 rounded-full transition-colors',
            'ml-slider-track',
            this.error ? 'ml-slider-track-error' : '',
            !this.disabled && !this.readonly && !this.loading && this.isEditing
                ? 'cursor-pointer'
                : '',
        ].filter(Boolean).join(' ');
    }
    getStopClasses(index, isSelected, isPending, isPassed) {
        const item = this.parsedItems[index];
        const isFocused = this.focusedIndex === index && this.isActive && !this.isDragging;
        const isBlue = isSelected || isPending || isPassed;
        return [
            'absolute -translate-y-1/2 -translate-x-1/2',
            'w-4 h-4 rounded-full border-2 touch-none',
            !this.isDragging ? 'transition-all' : '',
            isBlue
                ? 'ml-slider-mark-active'
                : 'ml-slider-mark',
            isSelected || isPending ? 'scale-125' : '',
            isFocused && !isBlue
                ? 'ml-slider-mark-focus'
                : '',
            item?.disabled
                ? 'ml-disabled'
                : !this.disabled && !this.readonly && !this.loading && this.isEditing
                    ? 'cursor-grab hover:scale-110'
                    : '',
        ].filter(Boolean).join(' ');
    }
    getLabelClasses(index, isActiveStop) {
        const item = this.parsedItems[index];
        return [
            'absolute top-6 -translate-x-1/2 text-xs text-center whitespace-nowrap transition-colors',
            isActiveStop
                ? 'ml-slider-label-active'
                : 'ml-slider-label',
            item?.disabled ? 'ml-slider-label-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getIndicatorClasses() {
        return [
            'absolute -top-8 -translate-x-1/2 px-2 py-1 rounded text-xs font-medium transition-all',
            'ml-slider-thumb',
            'after:content-[""] after:absolute after:top-full after:left-1/2 after:-translate-x-1/2',
            'after:border-4 after:border-transparent ml-slider-thumb-arrow',
        ].join(' ');
    }
    getGroupLabelClasses() {
        return [
            'absolute -bottom-8 text-xs font-medium text-center',
            'ml-text-muted',
        ].join(' ');
    }
    calculateStopPosition(index) {
        if (this.parsedItems.length <= 1)
            return 50;
        return (index / (this.parsedItems.length - 1)) * 100;
    }
    getIndexFromPointerX(clientX) {
        const track = this.renderRoot.querySelector('[data-track]');
        if (!track || this.parsedItems.length < 2)
            return -1;
        const rect = track.getBoundingClientRect();
        const ratio = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
        return Math.round(ratio * (this.parsedItems.length - 1));
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Parse slot content on each render to catch dynamic changes
        this.parseSlotContent();
        // View mode
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        // Not enough items
        if (this.parsedItems.length < 2) {
            return this.renderEmptyState();
        }
        return html `
      <div class=${cn(this.getContainerClasses(), this.cssClass)}>
        ${this.renderLabel()}
        ${this.renderSlider()}
        ${this.renderFeedback()}
      </div>
    `;
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayText = selectedItem
            ? selectedItem.label
            : (this.placeholder || this.msg.noSelection);
        return html `
      <div class=${cn('ml-text', this.cssClass)}>
        ${unsafeHTML(displayText)}
      </div>
    `;
    }
    renderEmptyState() {
        if (this.hasSlot('Empty')) {
            return html `
        <div class=${cn('ml-text-muted text-sm', this.getSlotClass('Empty'))}>
          ${unsafeHTML(this.getSlotContent('Empty'))}
        </div>
      `;
        }
        return html ``;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label
        id="slider-label"
        class=${cn('block text-sm font-medium ml-label mb-3', this.getSlotClass('Label'))}
      >
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="ml-error-text ml-1">*</span>` : html ``}
      </label>
    `;
    }
    renderSlider() {
        const selectedIndex = this.value !== null
            ? this.parsedItems.findIndex(item => item.value === this.value)
            : -1;
        const activeIndex = this.isDragging ? this.focusedIndex : selectedIndex;
        // Visual position: continuous during drag, discrete otherwise
        const visualPos = this.isDragging
            ? this.dragRatio * 100
            : (activeIndex >= 0 ? this.calculateStopPosition(activeIndex) : -1);
        return html `
      <div
        class="relative pt-10 pb-12"
        role="slider"
        aria-labelledby=${this.hasSlot('Label') ? 'slider-label' : ''}
        aria-valuemin="0"
        aria-valuemax=${this.parsedItems.length - 1}
        aria-valuenow=${selectedIndex >= 0 ? selectedIndex : ''}
        aria-valuetext=${selectedIndex >= 0 ? this.parsedItems[selectedIndex]?.label : ''}
        aria-required=${this.required}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-describedby=${this.error ? 'slider-error' : this.hasSlot('Helper') ? 'slider-helper' : ''}
        tabindex=${this.disabled || this.readonly || this.loading ? -1 : 0}
        @focus=${() => !this.isActive && this.isEditing && !this.disabled && !this.readonly && !this.loading && (this.isActive = true)}
        @pointermove=${this.handleDragPointerMove}
        @pointerup=${this.handleDragPointerUp}
        @pointercancel=${this.handleDragPointerUp}
      >
        ${this.renderIndicator(activeIndex, visualPos)}
        <div class=${this.getSliderTrackClasses()} data-track @click=${this.handleTrackClick}>
          ${this.renderFilledTrack(visualPos)}
          ${this.isDragging ? this.renderDragThumb(visualPos) : html ``}
          ${this.parsedItems.map((_item, index) => this.renderStop(index, activeIndex, selectedIndex))}
        </div>
        ${this.renderGroupLabels()}
      </div>
    `;
    }
    renderIndicator(activeIndex, visualPos) {
        if (this.loading) {
            return html `
        <div
          class="absolute left-1/2 -top-2 -translate-x-1/2 px-2 py-1 rounded text-xs font-medium ml-slider-indicator-idle"
        >
          ${this.msg.loading}
        </div>
      `;
        }
        if (activeIndex < 0) {
            const triggerContent = this.hasSlot('Trigger')
                ? this.getSlotContent('Trigger')
                : (this.placeholder || this.msg.placeholder);
            return html `
        <div
          class=${cn('absolute left-1/2 -top-2 -translate-x-1/2 px-2 py-1 rounded text-xs font-medium ml-slider-indicator-idle', this.getSlotClass('Trigger'))}
        >
          ${unsafeHTML(triggerContent)}
        </div>
      `;
        }
        const activeItem = this.parsedItems[activeIndex];
        return html `
      <div
        class=${this.getIndicatorClasses()}
        style="left: ${visualPos >= 0 ? visualPos : this.calculateStopPosition(activeIndex)}%"
      >
        ${unsafeHTML(activeItem.label)}
      </div>
    `;
    }
    renderFilledTrack(visualPos) {
        if (visualPos < 0)
            return html ``;
        return html `
      <div
        class="absolute top-0 left-0 h-full rounded-full ml-slider-filled pointer-events-none ${this.isDragging ? '' : 'transition-all'}"
        style="width: ${visualPos}%"
      ></div>
    `;
    }
    renderDragThumb(visualPos) {
        return html `
      <div
        class="absolute top-1/2 w-4 h-4 rounded-full -translate-x-1/2 -translate-y-1/2 scale-150 pointer-events-none z-10 ml-slider-drag-thumb border-2"
        style="left: ${visualPos}%"
      ></div>
    `;
    }
    renderStop(index, activeIndex, selectedIndex) {
        const position = this.calculateStopPosition(index);
        const item = this.parsedItems[index];
        const isSelected = index === selectedIndex;
        const isPending = this.isDragging && index === activeIndex;
        const isPassed = this.fillPrevious && !item.disabled && activeIndex >= 0 && index < activeIndex;
        return html `
      <div
        class="absolute top-1/2"
        style="left: ${position}%"
      >
        <button
          type="button"
          class=${this.getStopClasses(index, isSelected, isPending, isPassed)}
          role="option"
          aria-selected=${isSelected}
          aria-disabled=${item.disabled}
          tabindex="-1"
          @pointerdown=${(e) => this.handleStopPointerDown(index, e)}
        ></button>
        <span class=${this.getLabelClasses(index, index === activeIndex)}>
          ${unsafeHTML(item.label)}
        </span>
      </div>
    `;
    }
    renderGroupLabels() {
        if (this.parsedGroups.length === 0)
            return html ``;
        return html `
      ${this.parsedGroups.map(group => {
            const startPos = this.calculateStopPosition(group.startIndex);
            const endPos = this.calculateStopPosition(group.endIndex);
            const centerPos = (startPos + endPos) / 2;
            const width = endPos - startPos;
            return html `
          <div
            class=${this.getGroupLabelClasses()}
            style="left: ${centerPos}%; width: ${width}%; transform: translateX(-50%)"
          >
            ${group.label}
          </div>
        `;
        })}
    `;
    }
    renderFeedback() {
        if (this.error) {
            return html `
        <p id="slider-error" class="mt-2 text-xs ml-error-text">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p id="slider-helper" class=${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}>
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlDiscreteSliderMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDiscreteSliderMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDiscreteSliderMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDiscreteSliderMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDiscreteSliderMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDiscreteSliderMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDiscreteSliderMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDiscreteSliderMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDiscreteSliderMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'fill-previous' })
], MlDiscreteSliderMolecule.prototype, "fillPrevious", void 0);
__decorate([
    state()
], MlDiscreteSliderMolecule.prototype, "isActive", void 0);
__decorate([
    state()
], MlDiscreteSliderMolecule.prototype, "focusedIndex", void 0);
__decorate([
    state()
], MlDiscreteSliderMolecule.prototype, "isDragging", void 0);
__decorate([
    state()
], MlDiscreteSliderMolecule.prototype, "dragRatio", void 0);
__decorate([
    state()
], MlDiscreteSliderMolecule.prototype, "parsedItems", void 0);
__decorate([
    state()
], MlDiscreteSliderMolecule.prototype, "parsedGroups", void 0);
MlDiscreteSliderMolecule = __decorate([
    customElement('groupselectone--ml-discrete-slider')
], MlDiscreteSliderMolecule);
export { MlDiscreteSliderMolecule };
