/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-dial-select.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DIAL SELECT MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    empty: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione uma opção',
        empty: 'Nenhuma opção disponível',
        loading: 'Carregando...',
    },
};
let DialSelectMolecule = class DialSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-dial-select .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectone--ml-dial-select .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-dial-select .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-dial-select .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-dial-select .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-dial-select .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-dial-select .ml-dial-track {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectone--ml-dial-select .ml-dial-track-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupselectone--ml-dial-select .ml-dial-focus:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-dial-select .ml-dial-option {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectone--ml-dial-select .ml-dial-option-selected {
  border-color: var(--ml-primary, #3b82f6);
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 8%, var(--ml-surface, #ffffff));
  color: var(--ml-primary, #3b82f6);
}
groupselectone--ml-dial-select .ml-dial-option-hover:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupselectone--ml-dial-select .ml-dial-ring {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectone--ml-dial-select .ml-dial-search {
  border-color: var(--ml-outline-variant, #e2e8f0);
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectone--ml-dial-select .ml-dial-search::placeholder {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectone--ml-dial-select .ml-dial-search:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.activeIndex = -1;
        this.uid = `dial-${Math.random().toString(36).slice(2)}`;
        this.lastVisibleItems = [];
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        this.handleDocumentClick = this.handleDocumentClick.bind(this);
        document.addEventListener('click', this.handleDocumentClick);
    }
    disconnectedCallback() {
        document.removeEventListener('click', this.handleDocumentClick);
        super.disconnectedCallback();
    }
    updated() {
        if (!this.isOpen)
            return;
        const items = this.lastVisibleItems;
        if (items.length === 0) {
            if (this.activeIndex !== -1)
                this.activeIndex = -1;
            return;
        }
        const current = items[this.activeIndex];
        if (this.activeIndex === -1 || !current || current.disabled) {
            const selectedIndex = items.findIndex(i => i.value === this.value && !i.disabled);
            const next = selectedIndex >= 0 ? selectedIndex : this.getNextEnabledIndex(items, -1, 1);
            if (next !== this.activeIndex)
                this.activeIndex = next;
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleDocumentClick(event) {
        if (!this.isOpen)
            return;
        const target = event.target;
        if (target && !this.contains(target)) {
            this.isOpen = false;
        }
    }
    handleTriggerClick() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.activeIndex = this.getNextEnabledIndex(this.lastVisibleItems, -1, 1);
        }
    }
    handleKeyDown(event) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const items = this.lastVisibleItems;
        if (event.key === 'Escape') {
            this.isOpen = false;
            this.activeIndex = -1;
            event.preventDefault();
            return;
        }
        if (!this.isOpen && (event.key === 'ArrowDown' || event.key === 'Enter' || event.key === ' ')) {
            this.isOpen = true;
            this.activeIndex = this.getNextEnabledIndex(items, -1, 1);
            event.preventDefault();
            return;
        }
        if (!this.isOpen)
            return;
        if (event.key === 'ArrowDown') {
            this.activeIndex = this.getNextEnabledIndex(items, this.activeIndex, 1);
            event.preventDefault();
            return;
        }
        if (event.key === 'ArrowUp') {
            this.activeIndex = this.getNextEnabledIndex(items, this.activeIndex, -1);
            event.preventDefault();
            return;
        }
        if (event.key === 'Enter') {
            const item = items[this.activeIndex];
            if (item && !item.disabled) {
                this.selectItem(item);
            }
            event.preventDefault();
        }
    }
    handleSearchInput(event) {
        event.stopPropagation();
        const input = event.target;
        this.searchQuery = input.value;
        this.activeIndex = -1;
    }
    selectItem(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleFocus() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getPlainText(content) {
        return content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
    }
    getNextEnabledIndex(items, start, step) {
        if (items.length === 0)
            return -1;
        let index = start;
        for (let i = 0; i < items.length; i += 1) {
            index = (index + step + items.length) % items.length;
            if (!items[index].disabled)
                return index;
        }
        return -1;
    }
    getTriggerClasses(hasError) {
        return [
            'relative flex items-center justify-center rounded-full border transition focus:outline-none focus:ring-2',
            'ml-dial-track',
            hasError ? 'ml-dial-track-error' : '',
            'ml-dial-focus',
            (this.disabled || this.readonly || this.loading) ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getItemClasses(item, isSelected) {
        return [
            'absolute flex items-center justify-center rounded-full border text-[11px] leading-tight text-center transition',
            'ml-dial-option',
            isSelected
                ? 'ml-dial-option-selected'
                : '',
            !item.disabled && !isSelected ? 'ml-dial-option-hover' : '',
            item.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelId = `${this.uid}-label`;
        const errorId = `${this.uid}-error`;
        const panelId = `${this.uid}-panel`;
        const standaloneItemEls = this.getSlots('Item').filter(el => !el.closest('Group'));
        const standaloneItems = standaloneItemEls.map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
            disabled: el.hasAttribute('disabled'),
        }));
        const groups = this.getSlots('Group').map(group => ({
            label: group.getAttribute('label') || '',
            items: Array.from(group.querySelectorAll('Item')).map(el => ({
                value: el.getAttribute('value') || '',
                label: el.innerHTML,
                disabled: el.hasAttribute('disabled'),
            })),
        }));
        const allItems = [
            ...standaloneItems,
            ...groups.flatMap(group => group.items)
        ];
        const selectedItem = allItems.find(item => item.value === this.value) || null;
        const selectedLabel = selectedItem ? selectedItem.label : null;
        const hasError = (!!this.error && this.error.length > 0) || (this.required && !this.value);
        const placeholderText = this.placeholder || this.msg.placeholder || '—';
        const triggerContent = this.hasSlot('Trigger') ? this.getSlotContent('Trigger') : '';
        const query = this.searchQuery.trim().toLowerCase();
        const filterItem = (item) => {
            if (!query)
                return true;
            return this.getPlainText(item.label).toLowerCase().includes(query);
        };
        const filteredStandalone = standaloneItems.filter(filterItem);
        const filteredGroups = groups
            .map(group => ({
            label: group.label,
            items: group.items.filter(filterItem)
        }))
            .filter(group => group.items.length > 0);
        const rings = [
            ...filteredGroups.map(group => ({ label: group.label, items: group.items })),
            ...(filteredStandalone.length > 0 ? [{ label: '', items: filteredStandalone }] : [])
        ];
        const visibleItems = rings.flatMap(ring => ring.items);
        this.lastVisibleItems = visibleItems;
        const ringCount = Math.max(1, rings.length || 1);
        const baseRadius = 64;
        const ringGap = 40;
        const itemSize = 44;
        const maxRadius = baseRadius + (ringCount - 1) * ringGap;
        const dialSize = maxRadius * 2 + itemSize;
        if (!this.isEditing) {
            const viewTextClass = selectedLabel || triggerContent
                ? 'ml-text'
                : 'ml-text-muted';
            return html `
<div class=${cn('w-full', this.cssClass)}>
${this.hasSlot('Label')
                ? html `<div id=${labelId} class=${cn('mb-1 text-sm ml-label', this.getSlotClass('Label'))}>${unsafeHTML(this.getSlotContent('Label'))}</div>`
                : nothing}
<div class="text-sm ${viewTextClass}">
${selectedLabel
                ? unsafeHTML(selectedLabel)
                : triggerContent
                    ? unsafeHTML(triggerContent)
                    : placeholderText}
</div>
${this.name
                ? html `<input type="hidden" name=${this.name} value=${this.value ?? ''} />`
                : nothing}
</div>
`;
        }
        const renderCenterContent = () => {
            if (this.loading) {
                return html `<span class="text-xs ml-text-muted">${this.msg.loading}</span>`;
            }
            if (selectedLabel) {
                return html `<span class="text-xs ml-text">${unsafeHTML(selectedLabel)}</span>`;
            }
            if (triggerContent) {
                return html `<span class=${cn('text-xs ml-text', this.getSlotClass('Trigger'))}>${unsafeHTML(triggerContent)}</span>`;
            }
            return html `<span class="text-xs ml-text-muted">${placeholderText}</span>`;
        };
        return html `
<div class=${cn('w-full', this.cssClass)}>
${this.hasSlot('Label')
            ? html `<div id=${labelId} class=${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}>${unsafeHTML(this.getSlotContent('Label'))}</div>`
            : nothing}

<div class="flex flex-col items-center">
${this.searchable && this.isOpen
            ? html `
<input
class="mb-3 w-full max-w-xs rounded-lg border ml-dial-search px-3 py-2 text-sm focus:outline-none focus:ring-2"
placeholder=${this.msg.placeholder}
.value=${this.searchQuery}
@input=${this.handleSearchInput}

@change=${(e) => e.stopPropagation()}
/>
`
            : nothing}

<div class="relative mx-auto" style="width:${dialSize}px;height:${dialSize}px;">
${this.isOpen
            ? rings.map((ring, ringIndex) => {
                const radius = baseRadius + ringIndex * ringGap;
                return html `
<div
class="absolute rounded-full border ml-dial-ring"
style="width:${radius * 2}px;height:${radius * 2}px;left:50%;top:50%;transform:translate(-50%, -50%);"
></div>
${ring.items.map((item, itemIndex) => {
                    const angle = (360 / Math.max(1, ring.items.length)) * itemIndex - 90;
                    const isSelected = item.value === this.value;
                    const optionId = `${this.uid}-option-${ringIndex}-${itemIndex}`;
                    return html `
<button
id=${optionId}
role="option"
aria-selected=${isSelected ? 'true' : 'false'}
aria-disabled=${item.disabled ? 'true' : 'false'}
class=${this.getItemClasses(item, isSelected)}
style="width:${itemSize}px;height:${itemSize}px;left:50%;top:50%;transform:translate(-50%, -50%) rotate(${angle}deg) translateY(-${radius}px) rotate(${-angle}deg);"
@click=${() => this.selectItem(item)}
?disabled=${item.disabled}
>
<span class="px-1">${unsafeHTML(item.label)}</span>
</button>
`;
                })}
`;
            })
            : nothing}

<button
class=${cn(this.getTriggerClasses(hasError), this.getSlotClass('Trigger'))}
style="width:84px;height:84px;left:50%;top:50%;transform:translate(-50%, -50%);"
role="combobox"
aria-expanded=${this.isOpen ? 'true' : 'false'}
aria-haspopup="listbox"
aria-controls=${panelId}
aria-labelledby=${ifDefined(this.hasSlot('Label') ? labelId : undefined)}
aria-describedby=${ifDefined(this.error ? errorId : undefined)}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
@click=${this.handleTriggerClick}
@keydown=${this.handleKeyDown}
?disabled=${this.disabled || this.loading}
>
${renderCenterContent()}
</button>

${this.isOpen
            ? html `
<div
id=${panelId}
role="listbox"
class="sr-only"
aria-activedescendant=${ifDefined(this.activeIndex >= 0 ? `${this.uid}-option-0-${this.activeIndex}` : undefined)}
></div>
`
            : nothing}
</div>
</div>

${this.name
            ? html `<input type="hidden" name=${this.name} value=${this.value ?? ''} />`
            : nothing}

${this.error
            ? html `<p id=${errorId} class="mt-2 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`
            : !hasError && this.hasSlot('Helper')
                ? html `<p class=${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}>${unsafeHTML(this.getSlotContent('Helper'))}</p>`
                : nothing}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], DialSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], DialSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], DialSelectMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], DialSelectMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'searchable' })
], DialSelectMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], DialSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DialSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DialSelectMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DialSelectMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DialSelectMolecule.prototype, "loading", void 0);
__decorate([
    state()
], DialSelectMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], DialSelectMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], DialSelectMolecule.prototype, "activeIndex", void 0);
DialSelectMolecule = __decorate([
    customElement('groupselectone--ml-dial-select')
], DialSelectMolecule);
export { DialSelectMolecule };
