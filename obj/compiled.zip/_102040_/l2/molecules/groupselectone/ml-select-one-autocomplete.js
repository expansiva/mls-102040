var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-select-one-autocomplete.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SELECT ONE AUTOCOMPLETE MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Type to search',
    noResults: 'No results found',
    loading: 'Loading...',
    required: 'Selection required',
    clear: 'Clear selection',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Digite para pesquisar',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        required: 'Seleção obrigatória',
        clear: 'Limpar seleção',
    },
};
let SelectOneAutocompleteMolecule = class SelectOneAutocompleteMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = true;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        this.clearable = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.highlightedIndex = -1;
        this.labelId = `mlso-label-${Math.random().toString(36).slice(2, 8)}`;
        this.inputId = `mlso-input-${Math.random().toString(36).slice(2, 8)}`;
        this.listId = `mlso-list-${Math.random().toString(36).slice(2, 8)}`;
        this.errorId = `mlso-error-${Math.random().toString(36).slice(2, 8)}`;
        this.helperId = `mlso-helper-${Math.random().toString(36).slice(2, 8)}`;
        // ===========================================================================
        // EVENT HANDLERS
        // ===========================================================================
        this.handleDocumentClick = (event) => {
            if (!this.contains(event.target)) {
                this.closePanel();
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    createRenderRoot() {
        return this;
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.handleDocumentClick);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.handleDocumentClick);
    }
    firstUpdated() {
        this.searchQuery = this.getLabelByValue(this.value) || '';
    }
    updated(changedProps) {
        if (changedProps.has('value')) {
            if (!this.value) {
                this.searchQuery = '';
            }
            else {
                const label = this.getLabelByValue(this.value);
                if (label)
                    this.searchQuery = label;
            }
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.searchQuery = this.getLabelByValue(value) || '';
            this.highlightedIndex = -1;
        }
        this.requestUpdate();
    }
    handleInputFocus() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.openPanel();
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleFocusOut(event) {
        const nextTarget = event.relatedTarget;
        if (!nextTarget || !this.contains(nextTarget)) {
            this.closePanel();
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        }
    }
    handleInput(event) {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (!this.searchable)
            return;
        const input = event.target;
        this.searchQuery = input.value;
        this.openPanel();
        this.highlightedIndex = this.getFilteredItems().length > 0 ? 0 : -1;
    }
    handleKeyDown(event) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const items = this.getFilteredItems();
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            if (!this.isOpen)
                this.openPanel();
            this.highlightedIndex = Math.min(items.length - 1, this.highlightedIndex + 1);
        }
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            if (!this.isOpen)
                this.openPanel();
            this.highlightedIndex = Math.max(0, this.highlightedIndex - 1);
        }
        if (event.key === 'Enter') {
            event.preventDefault();
            const item = items[this.highlightedIndex];
            if (item && !item.disabled) {
                this.applySelection(item);
            }
        }
        if (event.key === 'Escape') {
            event.preventDefault();
            this.closePanel();
        }
    }
    handleItemSelect(item) {
        if (item.disabled || this.disabled || this.readonly || this.loading)
            return;
        this.applySelection(item);
    }
    handleClear(event) {
        event.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        this.value = null;
        this.searchQuery = '';
        this.highlightedIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleMouseDown(event) {
        if (this.disabled || this.readonly || this.loading) {
            event.preventDefault();
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    openPanel() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = true;
    }
    closePanel() {
        this.isOpen = false;
        this.highlightedIndex = -1;
    }
    applySelection(item) {
        this.value = item.value;
        this.searchQuery = item.labelText;
        this.closePanel();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    parseItem(el) {
        return {
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
            labelText: (el.textContent || '').trim(),
            disabled: el.hasAttribute('disabled'),
        };
    }
    getParsedData() {
        const itemSlots = this.getSlots('Item');
        const groupSlots = this.getSlots('Group');
        const standaloneItems = itemSlots
            .filter((el) => !el.closest('Group'))
            .map((el) => this.parseItem(el));
        const groups = groupSlots.map((group) => {
            const label = group.getAttribute('label') || '';
            const items = Array.from(group.querySelectorAll('Item')).map((el) => this.parseItem(el));
            return { label, items };
        });
        const allItems = [...standaloneItems, ...groups.flatMap((g) => g.items)];
        return { standaloneItems, groups, allItems };
    }
    getFilteredItems() {
        const { standaloneItems, groups } = this.getParsedData();
        const query = this.searchQuery.trim().toLowerCase();
        const filter = (item) => !query || item.labelText.toLowerCase().includes(query);
        const flatFromGroups = groups.flatMap((g) => g.items.filter(filter));
        const flatStandalone = standaloneItems.filter(filter);
        return [...flatFromGroups, ...flatStandalone];
    }
    getLabelByValue(value) {
        if (!value)
            return '';
        const { allItems } = this.getParsedData();
        return allItems.find((item) => item.value === value)?.labelText || '';
    }
    getTriggerText() {
        const trigger = this.getSlot('Trigger');
        return trigger?.textContent?.trim() || '';
    }
    getInputClasses(hasError) {
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            hasError
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            (this.disabled || this.readonly) ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    getOptionClasses(item, isHighlighted, isSelected) {
        return [
            'flex w-full items-center rounded-md px-3 py-2 text-sm transition border',
            isSelected
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border-sky-500 dark:border-sky-400'
                : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border-transparent',
            !item.disabled && !isSelected ? 'hover:bg-slate-50 dark:hover:bg-slate-700' : '',
            isHighlighted && !item.disabled ? 'ring-2 ring-sky-500 dark:ring-sky-400' : '',
            item.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const { standaloneItems, groups } = this.getParsedData();
        const query = this.searchQuery.trim().toLowerCase();
        const filter = (item) => !query || item.labelText.toLowerCase().includes(query);
        const filteredGroups = groups
            .map((group) => ({
            label: group.label,
            items: group.items.filter(filter),
        }))
            .filter((group) => group.items.length > 0);
        const filteredStandalone = standaloneItems.filter(filter);
        const filteredFlat = [...filteredGroups.flatMap((g) => g.items), ...filteredStandalone];
        const selectedLabelText = this.getLabelByValue(this.value);
        const placeholderText = this.placeholder || this.getTriggerText() || this.msg.placeholder;
        const hasError = !!this.error || (this.required && !this.value);
        const errorMessage = this.error || (this.required && !this.value ? this.msg.required : '');
        if (!this.isEditing) {
            return html `
<div class="flex flex-col gap-1">
${this.hasSlot('Label')
                ? html `<label id=${this.labelId} class="text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Label'))}</label>`
                : html ``}
<div class="text-sm text-slate-900 dark:text-slate-100">
${selectedLabelText || placeholderText || '—'}
</div>
</div>
`;
        }
        return html `
<div class="flex flex-col gap-1" @focusout=${this.handleFocusOut}>
${this.hasSlot('Label')
            ? html `<label id=${this.labelId} for=${this.inputId} class="text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Label'))}</label>`
            : html ``}
<div class="relative">
<input
id=${this.inputId}
name=${this.name}
class=${this.getInputClasses(hasError)}
.value=${this.searchQuery}
placeholder=${placeholderText}
?disabled=${this.disabled}
?readonly=${this.readonly}
role="combobox"
aria-expanded=${this.isOpen ? 'true' : 'false'}
aria-haspopup="listbox"
aria-controls=${this.listId}
aria-labelledby=${this.hasSlot('Label') ? this.labelId : ''}
aria-describedby=${hasError ? this.errorId : (this.hasSlot('Helper') ? this.helperId : '')}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@focus=${this.handleInputFocus}
@input=${this.handleInput}
@keydown=${this.handleKeyDown}
@mousedown=${this.handleMouseDown}
autocomplete="off"
/>
<div class="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500">
${this.loading ? html `${this.msg.loading}` : html `
<svg width="16" height="16" viewBox="0 0 20 20" fill="none" aria-hidden="true">
${svg `<path d="M5 7l5 5 5-5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" />`}
</svg>`}
</div>
${this.clearable && this.value && !this.disabled && !this.readonly
            ? html `
<button
class="absolute right-8 top-1/2 -translate-y-1/2 text-slate-400 dark:text-slate-500 hover:text-slate-600 dark:hover:text-slate-300"
@mousedown=${(e) => e.preventDefault()}
@click=${this.handleClear}
aria-label=${this.msg.clear}
>
<svg width="14" height="14" viewBox="0 0 20 20" fill="none" aria-hidden="true">
${svg `<path d="M6 6l8 8M14 6l-8 8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" />`}
</svg>
</button>
` : html ``}
</div>

${this.isOpen && !this.loading
            ? html `
<div
id=${this.listId}
role="listbox"
class="mt-2 max-h-64 overflow-auto rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-2"
>
${filteredFlat.length === 0
                ? html `
<div class="px-3 py-2 text-sm text-slate-500 dark:text-slate-400">
${this.hasSlot('Empty') ? unsafeHTML(this.getSlotContent('Empty')) : this.msg.noResults}
</div>
`
                : html `
${filteredGroups.map((group) => html `
<div class="mb-2">
<div class="px-3 py-1 text-xs font-semibold uppercase text-slate-500 dark:text-slate-400">
${group.label}
</div>
${group.items.map((item) => {
                    const flatIndex = filteredFlat.findIndex((i) => i.value === item.value);
                    return html `
<div
role="option"
aria-selected=${this.value === item.value ? 'true' : 'false'}
aria-disabled=${item.disabled ? 'true' : 'false'}
class=${this.getOptionClasses(item, this.highlightedIndex === flatIndex, this.value === item.value)}
@click=${() => this.handleItemSelect(item)}
@mousedown=${(e) => e.preventDefault()}
>
${unsafeHTML(item.label)}
</div>
`;
                })}
</div>
`)}
${filteredStandalone.map((item) => {
                    const flatIndex = filteredFlat.findIndex((i) => i.value === item.value);
                    return html `
<div
role="option"
aria-selected=${this.value === item.value ? 'true' : 'false'}
aria-disabled=${item.disabled ? 'true' : 'false'}
class=${this.getOptionClasses(item, this.highlightedIndex === flatIndex, this.value === item.value)}
@click=${() => this.handleItemSelect(item)}
@mousedown=${(e) => e.preventDefault()}
>
${unsafeHTML(item.label)}
</div>
`;
                })}
`}
</div>
`
            : html ``}

${hasError
            ? html `<p id=${this.errorId} class="mt-1 text-xs text-red-600 dark:text-red-400">${errorMessage}</p>`
            : this.hasSlot('Helper')
                ? html `<p id=${this.helperId} class="mt-1 text-xs text-slate-500 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Helper'))}</p>`
                : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], SelectOneAutocompleteMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], SelectOneAutocompleteMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], SelectOneAutocompleteMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], SelectOneAutocompleteMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'searchable' })
], SelectOneAutocompleteMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], SelectOneAutocompleteMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SelectOneAutocompleteMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SelectOneAutocompleteMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SelectOneAutocompleteMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SelectOneAutocompleteMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'clearable' })
], SelectOneAutocompleteMolecule.prototype, "clearable", void 0);
__decorate([
    state()
], SelectOneAutocompleteMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], SelectOneAutocompleteMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], SelectOneAutocompleteMolecule.prototype, "highlightedIndex", void 0);
SelectOneAutocompleteMolecule = __decorate([
    customElement('groupselectone--ml-select-one-autocomplete')
], SelectOneAutocompleteMolecule);
export { SelectOneAutocompleteMolecule };
