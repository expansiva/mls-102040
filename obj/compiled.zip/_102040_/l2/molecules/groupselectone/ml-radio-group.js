var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectone/ml-radio-group.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// RADIO GROUP MOLECULE
// =============================================================================
// Skill Group: groupSelectOne
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'No selection',
    noOptions: 'No options available',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Nenhuma seleção',
        noOptions: 'Nenhuma opção disponível',
        loading: 'Carregando...',
    },
};
let MlRadioGroupMolecule = class MlRadioGroupMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectone--ml-radio-group .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupselectone--ml-radio-group .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-radio-group .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-radio-group .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-radio-group .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-radio-group .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectone--ml-radio-group .ml-radio-option {
  background: var(--surface-bg, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-medium, 8px);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-radio-group .ml-radio-option:hover {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupselectone--ml-radio-group .ml-radio-option-selected {
  border-color: var(--selected-border, #3b82f6);
  background: var(--selected-bg, #f5f5f5);
}
groupselectone--ml-radio-group .ml-radio-option-focused {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupselectone--ml-radio-group .ml-radio-option-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupselectone--ml-radio-group .ml-radio-dot {
  border: 2px var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  background: var(--surface-bg, #ffffff);
}
groupselectone--ml-radio-group .ml-radio-dot-selected {
  border-color: var(--selected-border, #3b82f6);
  background: var(--button-primary-bg, #3b82f6);
}
groupselectone--ml-radio-group .ml-radio-dot-inner {
  background: var(--button-primary-text, #ffffff);
}
groupselectone--ml-radio-group .ml-radio-label-selected {
  color: var(--selected-text, #3b82f6);
}
groupselectone--ml-radio-group .ml-select-group-label {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectone--ml-radio-group .ml-spinner {
  border-color: var(--ml-primary, #3b82f6);
  border-top-color: transparent;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedValue = null;
        this.labelId = `label-${Math.random().toString(36).slice(2, 9)}`;
        this.errorId = `error-${Math.random().toString(36).slice(2, 9)}`;
        this.handleKeyDown = (e) => {
            if (this.disabled || this.readonly || this.loading || !this.isEditing)
                return;
            const selectableItems = this.getSelectableItems();
            if (selectableItems.length === 0)
                return;
            const currentIndex = this.focusedValue
                ? selectableItems.findIndex((item) => item.value === this.focusedValue)
                : this.value
                    ? selectableItems.findIndex((item) => item.value === this.value)
                    : -1;
            switch (e.key) {
                case 'ArrowDown':
                case 'ArrowRight': {
                    e.preventDefault();
                    const nextIndex = currentIndex < selectableItems.length - 1 ? currentIndex + 1 : 0;
                    this.focusedValue = selectableItems[nextIndex].value;
                    break;
                }
                case 'ArrowUp':
                case 'ArrowLeft': {
                    e.preventDefault();
                    const prevIndex = currentIndex > 0 ? currentIndex - 1 : selectableItems.length - 1;
                    this.focusedValue = selectableItems[prevIndex].value;
                    break;
                }
                case 'Enter':
                case ' ': {
                    e.preventDefault();
                    if (this.focusedValue) {
                        const item = this.findItem(this.focusedValue);
                        if (item && !item.disabled) {
                            this.handleSelect(item);
                        }
                    }
                    break;
                }
                case 'Escape': {
                    e.preventDefault();
                    this.focusedValue = null;
                    this.blur();
                    break;
                }
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.addEventListener('keydown', this.handleKeyDown);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeEventListener('keydown', this.handleKeyDown);
    }
    // ===========================================================================
    // PARSING HELPERS
    // ===========================================================================
    parseItems() {
        return this.getSlots('Item')
            .filter((el) => el.closest('Group') === null)
            .map((el) => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML.trim(),
            disabled: el.hasAttribute('disabled'),
        }));
    }
    parseGroups() {
        const groupElements = this.getSlots('Group');
        return groupElements.map((groupEl) => {
            const groupLabel = groupEl.getAttribute('label') || '';
            const itemElements = Array.from(groupEl.querySelectorAll('Item'));
            const items = itemElements.map((el) => ({
                value: el.getAttribute('value') || '',
                label: el.innerHTML.trim(),
                disabled: el.hasAttribute('disabled'),
            }));
            return { label: groupLabel, items };
        });
    }
    getAllItems() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const groupedItems = groups.flatMap((g) => g.items);
        return [...standaloneItems, ...groupedItems];
    }
    findItem(value) {
        if (value === null)
            return undefined;
        return this.getAllItems().find((item) => item.value === value);
    }
    getSelectableItems() {
        return this.getAllItems().filter((item) => !item.disabled);
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(item) {
        if (this.disabled || this.readonly || this.loading || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.focusedValue = null;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // CSS HELPERS
    // ===========================================================================
    getContainerClasses() {
        return cn('flex flex-col gap-2', this.disabled ? 'ml-disabled' : '');
    }
    getOptionClasses(item) {
        const isSelected = this.value === item.value;
        const isFocused = this.focusedValue === item.value;
        const hasError = this.error !== '';
        return cn('flex items-center gap-3 px-3 py-2 transition-all cursor-pointer ml-radio-option', isSelected ? 'ml-radio-option-selected' : '', isFocused && !isSelected ? 'ml-radio-option-focused' : '', hasError && !isSelected ? 'ml-radio-option-error' : '', item.disabled ? 'ml-disabled' : '', this.disabled || this.readonly || this.loading ? 'cursor-not-allowed' : '', this.getSlotClass('Item'));
    }
    getRadioClasses(item) {
        const isSelected = this.value === item.value;
        return cn('w-4 h-4 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-all ml-radio-dot', isSelected ? 'ml-radio-dot-selected' : '', item.disabled ? 'ml-disabled' : '');
    }
    getLabelTextClasses(item) {
        const isSelected = this.value === item.value;
        return cn('text-sm transition-colors ml-text', isSelected ? 'font-medium ml-radio-label-selected' : '', item.disabled ? 'ml-text-muted' : '');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label
id=${this.labelId}
class="${cn('text-sm font-medium ml-label', this.getSlotClass('Label'))}"
>
${unsafeHTML(this.getSlotContent('Label'))}
${this.required
            ? html `<span class="ml-error-text ml-0.5">*</span>`
            : html ``}
</label>
`;
    }
    renderRadioIndicator(item) {
        const isSelected = this.value === item.value;
        return html `
<span class=${this.getRadioClasses(item)}>
${isSelected
            ? html `<span class="w-2 h-2 rounded-full ml-radio-dot-inner"></span>`
            : html ``}
</span>
`;
    }
    renderOption(item) {
        const isSelected = this.value === item.value;
        return html `
<div
role="radio"
aria-checked=${isSelected ? 'true' : 'false'}
aria-disabled=${item.disabled || this.disabled || this.readonly || this.loading
            ? 'true'
            : 'false'}
tabindex=${item.disabled || this.disabled || this.readonly || this.loading
            ? '-1'
            : '0'}
class=${this.getOptionClasses(item)}
@click=${() => this.handleSelect(item)}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
>
${this.renderRadioIndicator(item)}
<span class=${this.getLabelTextClasses(item)}>
${unsafeHTML(item.label)}
</span>
</div>
`;
    }
    renderGroup(group) {
        if (group.items.length === 0)
            return html ``;
        return html `
<div class="flex flex-col gap-1">
<span class="${cn('text-xs font-semibold uppercase tracking-wide px-1 ml-select-group-label', this.getSlotClass('Group'))}">
${group.label}
</span>
<div class="flex flex-col gap-1">
${group.items.map((item) => this.renderOption(item))}
</div>
</div>
`;
    }
    renderRadioOptions() {
        const standaloneItems = this.parseItems();
        const groups = this.parseGroups();
        const hasItems = standaloneItems.length > 0 || groups.some((g) => g.items.length > 0);
        if (!hasItems) {
            if (this.hasSlot('Empty')) {
                return html `
<div class="${cn('text-sm py-2 ml-text-muted', this.getSlotClass('Empty'))}">
${unsafeHTML(this.getSlotContent('Empty'))}
</div>
`;
            }
            return html `
<div class="text-sm py-2 ml-text-muted">
${this.msg.noOptions}
</div>
`;
        }
        return html `
<div
role="radiogroup"
aria-labelledby=${this.hasSlot('Label') ? this.labelId : ''}
aria-required=${this.required ? 'true' : 'false'}
aria-invalid=${this.error ? 'true' : 'false'}
aria-describedby=${this.error ? this.errorId : ''}
class="flex flex-col gap-2"
>
${standaloneItems.map((item) => this.renderOption(item))}
${groups.map((group) => this.renderGroup(group))}
</div>
`;
    }
    renderLoading() {
        return html `
<div class="flex items-center gap-2 py-2">
<div class="w-4 h-4 border-2 border-t-transparent rounded-full animate-spin ml-spinner"></div>
<span class="text-sm ml-text-muted">${this.msg.loading}</span>
</div>
`;
    }
    renderFeedback() {
        if (this.error) {
            return html `
<p
id=${this.errorId}
class="text-xs ml-error-text"
>
${unsafeHTML(this.error)}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p class="${cn('text-xs ml-helper', this.getSlotClass('Helper'))}">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderViewMode() {
        const selectedItem = this.findItem(this.value);
        const displayText = selectedItem
            ? selectedItem.label
            : this.placeholder || this.msg.placeholder;
        return html `
<div class="flex flex-col gap-1">
${this.renderLabel()}
<span class="text-sm ml-text">
${selectedItem ? unsafeHTML(displayText) : displayText}
</span>
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
<div class="${cn(this.getContainerClasses(), this.cssClass)}">
${this.renderLabel()}
${this.loading ? this.renderLoading() : this.renderRadioOptions()}
${this.renderFeedback()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRadioGroupMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlRadioGroupMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRadioGroupMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlRadioGroupMolecule.prototype, "focusedValue", void 0);
MlRadioGroupMolecule = __decorate([
    customElement('groupselectone--ml-radio-group')
], MlRadioGroupMolecule);
export { MlRadioGroupMolecule };
