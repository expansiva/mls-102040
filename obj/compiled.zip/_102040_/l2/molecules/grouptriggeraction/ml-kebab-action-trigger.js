var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouptriggeraction/ml-kebab-action-trigger.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML KEBAB ACTION TRIGGER MOLECULE
// =============================================================================
// Skill Group: groupTriggerAction
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    moreActions: 'More actions',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlKebabActionTriggerMolecule = class MlKebabActionTriggerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-kebab-action-trigger .ml-kebab-trigger {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-weight: var(--ml-font-weight-medium, 500);
  transition: background var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease);
}
grouptriggeraction--ml-kebab-action-trigger .ml-kebab-trigger:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouptriggeraction--ml-kebab-action-trigger .ml-kebab-trigger:active {
  filter: brightness(0.95);
}
grouptriggeraction--ml-kebab-action-trigger .ml-kebab-trigger:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
grouptriggeraction--ml-kebab-action-trigger .ml-label {
  color: var(--ml-on-surface, #1c1b1f);
}
grouptriggeraction--ml-kebab-action-trigger .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
}
grouptriggeraction--ml-kebab-action-trigger .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Icon'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleActionClick() {
        if (this.disabled || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getButtonClasses() {
        const sizeClasses = this.getSizeClasses();
        return [
            'inline-flex items-center justify-center gap-2',
            'ml-kebab-trigger',
            this.disabled || this.loading ? 'ml-disabled' : 'cursor-pointer',
            sizeClasses,
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSizeClasses() {
        switch (this.size) {
            case 'xs':
                return 'h-7 px-2 text-xs';
            case 'sm':
                return 'h-8 px-2.5 text-xs';
            case 'lg':
                return 'h-11 px-3.5 text-sm';
            case 'md':
            default:
                return 'h-9 px-3 text-sm';
        }
    }
    getIconSizeClasses() {
        switch (this.size) {
            case 'xs':
                return 'h-3.5 w-3.5';
            case 'sm':
                return 'h-4 w-4';
            case 'lg':
                return 'h-5 w-5';
            case 'md':
            default:
                return 'h-4.5 w-4.5';
        }
    }
    getLabelText() {
        const labelContent = this.getSlotContent('Label');
        if (labelContent) {
            return labelContent.replace(/<[^>]*>/g, '').trim();
        }
        return this.msg.moreActions;
    }
    renderLoadingIndicator() {
        const iconClasses = [
            'animate-spin',
            this.getIconSizeClasses(),
            'ml-text-muted',
        ].join(' ');
        return html `
      <span class="${iconClasses}" aria-hidden="true">
        <svg viewBox="0 0 24 24">
          ${svg `<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="3" fill="none" opacity="0.2"></circle>`}
          ${svg `<path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="3" fill="none"></path>`}
        </svg>
      </span>
      ${this.hasSlot('Label')
            ? html `<span class="ml-text-muted">${this.msg.loading}</span>`
            : html ``}
    `;
    }
    renderDefaultIcon() {
        const iconClasses = [
            'inline-flex items-center justify-center',
            this.getIconSizeClasses(),
            'ml-text-muted',
        ].join(' ');
        return html `
      <span class="${iconClasses}" aria-hidden="true">
        <svg viewBox="0 0 24 24">
          ${svg `<circle cx="6" cy="12" r="2" fill="currentColor"></circle>`}
          ${svg `<circle cx="12" cy="12" r="2" fill="currentColor"></circle>`}
          ${svg `<circle cx="18" cy="12" r="2" fill="currentColor"></circle>`}
        </svg>
      </span>
    `;
    }
    renderIcon() {
        if (this.hasSlot('Icon')) {
            const content = this.getSlotContent('Icon');
            return html `<span class="${cn(`inline-flex ${this.getIconSizeClasses()}`, this.getSlotClass('Icon'))}" aria-hidden="true">${unsafeHTML(content)}</span>`;
        }
        return this.renderDefaultIcon();
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const content = this.getSlotContent('Label');
        return html `<span class="${cn('ml-label', this.getSlotClass('Label'))}">${unsafeHTML(content)}</span>`;
    }
    renderContent() {
        if (this.loading) {
            return this.renderLoadingIndicator();
        }
        const icon = this.renderIcon();
        const label = this.renderLabel();
        const parts = this.iconPosition === 'end' ? [label, icon] : [icon, label];
        return html `${parts}`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const isIconOnly = !this.hasSlot('Label');
        const ariaLabel = isIconOnly ? this.getLabelText() : undefined;
        return html `
      <button
        class="${cn(this.getButtonClasses(), this.cssClass)}"
        type="${this.type}"
        ?disabled=${this.disabled || this.loading}
        aria-label=${ariaLabel || ''}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${this.disabled || this.loading ? 'true' : 'false'}
        @click=${this.handleActionClick}
      >
        ${this.renderContent()}
      </button>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlKebabActionTriggerMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlKebabActionTriggerMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlKebabActionTriggerMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlKebabActionTriggerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlKebabActionTriggerMolecule.prototype, "loading", void 0);
MlKebabActionTriggerMolecule = __decorate([
    customElement('grouptriggeraction--ml-kebab-action-trigger')
], MlKebabActionTriggerMolecule);
export { MlKebabActionTriggerMolecule };
