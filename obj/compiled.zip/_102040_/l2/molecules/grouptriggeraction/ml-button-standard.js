var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouptriggeraction/ml-button-standard.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BUTTON STANDARD MOLECULE
// =============================================================================
// Skill Group: groupTriggerAction
// This molecule does NOT contain business logic.
import { html, nothing, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let ButtonStandardMolecule = class ButtonStandardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Icon'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleActionClick(e) {
        const isDisabled = this.isDisabled();
        if (isDisabled) {
            e.preventDefault();
            e.stopPropagation();
            return;
        }
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    isDisabled() {
        return this.disabled || this.loading;
    }
    getVariant() {
        const variant = (this.getAttribute('data-variant') || 'primary').toLowerCase();
        if (variant === 'secondary' || variant === 'danger' || variant === 'ghost' || variant === 'link') {
            return variant;
        }
        return 'primary';
    }
    getSizeKey() {
        if (this.size === 'xs' || this.size === 'sm' || this.size === 'lg')
            return this.size;
        return 'md';
    }
    getSizeClasses(hasLabel) {
        const sizeKey = this.getSizeKey();
        const iconOnly = !hasLabel;
        const paddingMap = {
            xs: iconOnly ? 'p-1.5' : 'px-2 py-1',
            sm: iconOnly ? 'p-2' : 'px-3 py-1.5',
            md: iconOnly ? 'p-2.5' : 'px-4 py-2',
            lg: iconOnly ? 'p-3' : 'px-5 py-2.5',
        };
        const iconMap = {
            xs: 'h-3 w-3',
            sm: 'h-4 w-4',
            md: 'h-5 w-5',
            lg: 'h-6 w-6',
        };
        const gapMap = {
            xs: 'gap-1.5 text-xs',
            sm: 'gap-2 text-sm',
            md: 'gap-2 text-sm',
            lg: 'gap-2.5 text-base',
        };
        return {
            button: paddingMap[sizeKey],
            icon: iconMap[sizeKey],
            spinner: iconMap[sizeKey],
            gap: gapMap[sizeKey],
        };
    }
    getVariantClasses(variant, isDisabled) {
        const hoverActive = !isDisabled;
        const baseMap = {
            primary: [
                'bg-sky-600 dark:bg-sky-500 text-white',
                'border border-sky-600 dark:border-sky-500',
                hoverActive ? 'hover:bg-sky-700 dark:hover:bg-sky-400 active:bg-sky-800 dark:active:bg-sky-600' : '',
            ].filter(Boolean).join(' '),
            secondary: [
                'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100',
                'border border-slate-200 dark:border-slate-700',
                hoverActive ? 'hover:bg-slate-50 dark:hover:bg-slate-700 active:bg-slate-100 dark:active:bg-slate-600' : '',
            ].filter(Boolean).join(' '),
            danger: [
                'bg-red-600 dark:bg-red-500 text-white',
                'border border-red-600 dark:border-red-500',
                hoverActive ? 'hover:bg-red-700 dark:hover:bg-red-400 active:bg-red-800 dark:active:bg-red-600' : '',
            ].filter(Boolean).join(' '),
            ghost: [
                'bg-transparent text-slate-700 dark:text-slate-300',
                'border border-transparent',
                hoverActive ? 'hover:bg-slate-50 dark:hover:bg-slate-700 active:bg-slate-100 dark:active:bg-slate-600' : '',
            ].filter(Boolean).join(' '),
            link: [
                'bg-transparent text-sky-600 dark:text-sky-400',
                'border border-transparent',
                hoverActive ? 'hover:underline active:text-sky-700 dark:active:text-sky-300' : '',
            ].filter(Boolean).join(' '),
        };
        return baseMap[variant] || baseMap.primary;
    }
    getButtonClasses(hasLabel) {
        const isDisabled = this.isDisabled();
        const variant = this.getVariant();
        const sizeClasses = this.getSizeClasses(hasLabel);
        return [
            'inline-flex items-center justify-center rounded-md font-medium transition',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            'focus:ring-offset-2 focus:ring-offset-white dark:focus:ring-offset-slate-900',
            sizeClasses.button,
            sizeClasses.gap,
            this.getVariantClasses(variant, isDisabled),
            isDisabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getIconClasses(sizeClass) {
        return [
            'inline-flex items-center justify-center',
            sizeClass,
        ].join(' ');
    }
    renderSpinner(sizeClass) {
        return html `
      <svg
        class="animate-spin ${sizeClass}"
        viewBox="0 0 24 24"
        fill="none"
        aria-hidden="true"
      >
        ${svg `<circle cx="12" cy="12" r="10" stroke="currentColor" stroke-opacity="0.25" stroke-width="4"></circle>`}
        ${svg `<path d="M22 12a10 10 0 0 1-10 10" stroke="currentColor" stroke-width="4" stroke-linecap="round"></path>`}
      </svg>
    `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const labelContent = (this.getSlotContent('Label') || '').trim();
        const iconContent = (this.getSlotContent('Icon') || '').trim();
        const hasLabel = labelContent.length > 0;
        const hasIcon = iconContent.length > 0;
        const isDisabled = this.isDisabled();
        const sizeClasses = this.getSizeClasses(hasLabel);
        const iconPosition = this.iconPosition === 'end' ? 'end' : 'start';
        const ariaLabel = !hasLabel && hasIcon ? labelContent : undefined;
        const iconTemplate = hasIcon
            ? html `<span class="${this.getIconClasses(sizeClasses.icon)}">${unsafeHTML(iconContent)}</span>`
            : nothing;
        const spinnerTemplate = html `<span class="${this.getIconClasses(sizeClasses.spinner)}">${this.renderSpinner(sizeClasses.spinner)}</span>`;
        const labelTemplate = hasLabel
            ? html `<span class="${this.loading && !hasIcon ? 'opacity-0' : ''}">${unsafeHTML(labelContent)}</span>`
            : nothing;
        const labelWithSpinner = html `
      <span class="relative inline-flex items-center justify-center">
        ${labelTemplate}
        ${this.loading && !hasIcon ? html `<span class="absolute">${spinnerTemplate}</span>` : nothing}
      </span>
    `;
        const contentTemplate = html `
      ${iconPosition === 'start'
            ? html `
            ${this.loading && hasIcon ? spinnerTemplate : iconTemplate}
            ${labelWithSpinner}
          `
            : html `
            ${labelWithSpinner}
            ${this.loading && hasIcon ? spinnerTemplate : iconTemplate}
          `}
    `;
        return html `
      <button
        class="${this.getButtonClasses(hasLabel)}"
        type="${this.type}"
        ?disabled=${isDisabled}
        aria-busy=${this.loading ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        aria-label=${ariaLabel || nothing}
        @click=${this.handleActionClick}
      >
        ${contentTemplate}
      </button>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], ButtonStandardMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], ButtonStandardMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], ButtonStandardMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ButtonStandardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ButtonStandardMolecule.prototype, "loading", void 0);
ButtonStandardMolecule = __decorate([
    customElement('grouptriggeraction--ml-button-standard')
], ButtonStandardMolecule);
export { ButtonStandardMolecule };
