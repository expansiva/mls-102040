var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouptriggeraction/ml-button-group.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML BUTTON GROUP MOLECULE
// =============================================================================
// Skill Group: groupTriggerAction
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    action: 'Action',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        action: 'Ação',
    },
};
/// **collab_i18n_end**
let MlButtonGroupMolecule = class MlButtonGroupMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-button-group .ml-button-group {
  display: inline-flex;
}
grouptriggeraction--ml-button-group .ml-button {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  border-radius: 0;
  transition: background var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease), border-color var(--transition-fast, 200ms ease);
  cursor: pointer;
}
grouptriggeraction--ml-button-group .ml-button:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
grouptriggeraction--ml-button-group .ml-button-primary {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--button-primary-bg, #3b82f6);
  box-shadow: var(--shadow-small, 0 1px 3px rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-button-group .ml-button-primary:hover {
  background: var(--button-primary-bg-hover, #408fff);
  border-color: var(--button-primary-bg-hover, #408fff);
  box-shadow: var(--shadow-medium, 0 4px 6px rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-button-group .ml-button-primary:active {
  filter: brightness(0.9);
  box-shadow: none;
}
grouptriggeraction--ml-button-group .ml-button-secondary {
  background: var(--button-secondary-bg, #ffffff);
  color: var(--button-secondary-text, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--button-secondary-border, #e2e8f0);
}
grouptriggeraction--ml-button-group .ml-button-secondary:hover {
  background: var(--button-secondary-bg-hover, #f5f5f5);
  border-color: var(--button-secondary-border-hover, #e2e8f0);
}
grouptriggeraction--ml-button-group .ml-button-secondary:active {
  filter: brightness(0.95);
}
grouptriggeraction--ml-button-group .ml-button-ghost {
  background: transparent;
  color: var(--button-secondary-text, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) transparent;
}
grouptriggeraction--ml-button-group .ml-button-ghost:hover {
  background: var(--button-secondary-bg-hover, #f5f5f5);
}
grouptriggeraction--ml-button-group .ml-button-ghost:active {
  filter: brightness(0.95);
}
grouptriggeraction--ml-button-group .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Icon'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleButtonClick(index) {
        if (this.disabled || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getDirection() {
        const dirAttr = this.getAttribute('direction');
        return dirAttr === 'vertical' ? 'vertical' : 'horizontal';
    }
    getGroupClasses(isVertical) {
        return [
            'inline-flex',
            isVertical ? 'flex-col' : 'flex-row',
            'items-stretch',
        ].join(' ');
    }
    getSizeClasses() {
        switch (this.size) {
            case 'xs':
                return 'text-xs px-2 py-1';
            case 'sm':
                return 'text-sm px-3 py-1.5';
            case 'lg':
                return 'text-base px-5 py-2.5';
            case 'md':
            default:
                return 'text-sm px-4 py-2';
        }
    }
    getVariantClasses(variant) {
        const baseMap = {
            primary: 'ml-button-primary',
            ghost: 'ml-button-ghost',
            secondary: 'ml-button-secondary',
        };
        return baseMap[variant] || baseMap.secondary;
    }
    getButtonClasses(index, total, variant, isVertical) {
        const isFirst = index === 0;
        const isLast = index === total - 1;
        const rounding = isVertical
            ? [isFirst ? 'rounded-t-lg' : '', isLast ? 'rounded-b-lg' : '']
            : [isFirst ? 'rounded-l-lg' : '', isLast ? 'rounded-r-lg' : ''];
        const overlap = isVertical ? (isFirst ? '' : '-mt-px') : (isFirst ? '' : '-ml-px');
        return [
            'relative',
            'inline-flex',
            'items-center',
            'justify-center',
            'gap-2',
            'ml-button',
            'focus:z-10',
            this.getSizeClasses(),
            this.getVariantClasses(variant),
            rounding.join(' '),
            overlap,
            (this.disabled || this.loading) ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderSpinner() {
        return html `
<svg class="h-4 w-4 animate-spin" viewBox="0 0 24 24" aria-hidden="true">
${svg `<circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none"></circle>`}
${svg `<path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v4a4 4 0 00-4 4H4z"></path>`}
</svg>
`;
    }
    renderButtonContent(labelHtml, iconHtml) {
        if (this.loading) {
            return html `${this.renderSpinner()}`;
        }
        const hasIcon = iconHtml.trim().length > 0;
        const hasLabel = labelHtml.trim().length > 0;
        if (!hasIcon && !hasLabel) {
            return html ``;
        }
        if (hasIcon && hasLabel) {
            return this.iconPosition === 'end'
                ? html `<span class="${cn('inline-flex items-center gap-2', this.getSlotClass('Label'))}">${unsafeHTML(labelHtml)}${unsafeHTML(iconHtml)}</span>`
                : html `<span class="${cn('inline-flex items-center gap-2', this.getSlotClass('Label'))}">${unsafeHTML(iconHtml)}${unsafeHTML(labelHtml)}</span>`;
        }
        return hasLabel
            ? html `${unsafeHTML(labelHtml)}`
            : html `${unsafeHTML(iconHtml)}`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelSlots = this.getSlots('Label');
        const iconSlots = this.getSlots('Icon');
        const items = labelSlots.map((labelEl, index) => {
            const labelHtml = (labelEl?.innerHTML || '').trim();
            if (!labelHtml)
                return null;
            const iconEl = iconSlots[index];
            const iconHtml = (iconEl?.innerHTML || '').trim();
            const variant = labelEl.getAttribute('variant') || 'secondary';
            const ariaLabel = (labelEl.textContent || '').trim() || this.msg.action;
            return { labelHtml, iconHtml, variant, ariaLabel, index };
        }).filter(Boolean);
        const isVertical = this.getDirection() === 'vertical';
        if (items.length === 0) {
            return html `<div class="${cn(this.getGroupClasses(isVertical), this.cssClass)}"></div>`;
        }
        return html `
<div class="${cn(this.getGroupClasses(isVertical), 'ml-button-group', this.cssClass)}" role="group">
${items.map((item, idx) => html `
<button
class="${this.getButtonClasses(idx, items.length, item.variant, isVertical)}"
type="${this.type}"
?disabled=${this.disabled || this.loading}
aria-busy="${this.loading ? 'true' : 'false'}"
aria-disabled="${this.disabled || this.loading ? 'true' : 'false'}"
aria-label="${item.ariaLabel}"
@click=${() => this.handleButtonClick(item.index)}
>
${this.renderButtonContent(item.labelHtml, item.iconHtml)}
</button>
`)}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlButtonGroupMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlButtonGroupMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], MlButtonGroupMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlButtonGroupMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlButtonGroupMolecule.prototype, "loading", void 0);
MlButtonGroupMolecule = __decorate([
    customElement('grouptriggeraction--ml-button-group')
], MlButtonGroupMolecule);
export { MlButtonGroupMolecule };
