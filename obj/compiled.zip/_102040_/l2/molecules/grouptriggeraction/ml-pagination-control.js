var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouptriggeraction/ml-pagination-control.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    firstPage: 'First page',
    previousPage: 'Previous page',
    nextPage: 'Next page',
    lastPage: 'Last page',
    page: 'Page',
    goToPage: 'Go to page',
    pagination: 'Pagination',
    currentPageAnnounce: 'Page {current} of {total}',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        firstPage: 'Primeira página',
        previousPage: 'Página anterior',
        nextPage: 'Próxima página',
        lastPage: 'Última página',
        page: 'Página',
        goToPage: 'Ir para página',
        pagination: 'Paginação',
        currentPageAnnounce: 'Página {current} de {total}',
    },
};
/// **collab_i18n_end**
// =============================================================================
// PAGINATION CONTROL MOLECULE
// =============================================================================
// Skill Group: groupTriggerAction
// This molecule does NOT contain business logic.
let MlPaginationControlMolecule = class MlPaginationControlMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouptriggeraction--ml-pagination-control {
  display: inline-flex;
  align-items: center;
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouptriggeraction--ml-pagination-control .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  pointer-events: none;
  cursor: not-allowed;
}
grouptriggeraction--ml-pagination-control .ml-loading {
  opacity: var(--ml-disabled-opacity, 0.5);
  pointer-events: none;
  cursor: default;
}
grouptriggeraction--ml-pagination-control .ml-pagination {
  display: inline-flex;
  align-items: center;
}
grouptriggeraction--ml-pagination-control .ml-pagination-pages {
  display: inline-flex;
  align-items: center;
}
grouptriggeraction--ml-pagination-control .ml-pagination-nav,
grouptriggeraction--ml-pagination-control .ml-pagination-page {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 2rem;
  height: 2rem;
  padding: 0 0.4rem;
  font-size: 0.875rem;
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  border-radius: var(--radius-small, 6px);
  border-width: var(--ml-border-width, 1px);
  border-style: var(--ml-border-style, solid);
  transition: background var(--transition-fast, 200ms ease), border-color var(--transition-fast, 200ms ease), color var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
  outline: none;
  user-select: none;
  line-height: 1;
  box-sizing: border-box;
}
grouptriggeraction--ml-pagination-control .ml-pagination-nav:focus-visible,
grouptriggeraction--ml-pagination-control .ml-pagination-page:focus-visible {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
grouptriggeraction--ml-pagination-control .ml-pagination-nav {
  color: var(--text-muted, #49454f);
  background: transparent;
  border-color: var(--border-default, #e2e8f0);
  font-weight: var(--font-weight-bold, 500);
}
grouptriggeraction--ml-pagination-control .ml-pagination-nav:hover:not(:disabled):not(.ml-pagination-nav-disabled) {
  background: var(--surface-alt-bg, #f5f5f5);
  border-color: var(--border-default-hover, #e2e8f0);
  color: var(--text-strong, #1c1b1f);
}
grouptriggeraction--ml-pagination-control .ml-pagination-nav:active:not(:disabled):not(.ml-pagination-nav-disabled) {
  background: var(--surface-alt-bg, #f5f5f5);
  border-color: var(--border-default-focus, #e2e8f0);
  color: var(--text-strong, #1c1b1f);
  box-shadow: inset 0 1px 3px var(--ml-pagination-press-shadow, rgba(0, 0, 0, 0.08));
}
grouptriggeraction--ml-pagination-control .ml-pagination-nav-disabled,
grouptriggeraction--ml-pagination-control .ml-pagination-nav:disabled {
  color: var(--text-muted-disabled, #79747e);
  background: transparent;
  border-color: var(--border-default-disabled, #e2e8f0);
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
grouptriggeraction--ml-pagination-control .ml-pagination-page {
  color: var(--text-strong, #1c1b1f);
  background: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
  font-weight: var(--font-weight-bold, 500);
}
grouptriggeraction--ml-pagination-control .ml-pagination-page:hover:not(:disabled):not(.ml-pagination-page-current) {
  background: var(--selected-bg, #f5f5f5);
  border-color: var(--selected-border, #3b82f6);
  color: var(--selected-text, #3b82f6);
}
grouptriggeraction--ml-pagination-control .ml-pagination-page:active:not(:disabled):not(.ml-pagination-page-current) {
  background: var(--selected-bg-hover, #f5f5f5);
  border-color: var(--selected-border-hover, #3b82f6);
  color: var(--selected-text-hover, #3b82f6);
  box-shadow: inset 0 1px 3px var(--ml-pagination-press-shadow, rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-pagination-control .ml-pagination-page-current {
  background: var(--button-primary-bg, #3b82f6) !important;
  border-color: var(--button-primary-bg, #3b82f6) !important;
  color: var(--button-primary-text, #ffffff) !important;
  font-weight: 700;
  cursor: default;
  pointer-events: none;
  box-shadow: var(--shadow-small, 0 1px 3px rgba(0, 0, 0, 0.1));
}
grouptriggeraction--ml-pagination-control .ml-pagination-ellipsis {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 2rem;
  height: 2rem;
  padding: 0 0.25rem;
  font-size: 0.875rem;
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  line-height: 1;
  box-sizing: border-box;
}
grouptriggeraction--ml-pagination-control .ml-text-muted {
  color: var(--text-muted-disabled, #79747e);
}
grouptriggeraction--ml-pagination-control .ml-spinner {
  display: inline-block;
  width: 1rem;
  height: 1rem;
  border-radius: 50%;
  border-width: 2px;
  border-style: solid;
  border-color: currentColor;
  border-top-color: transparent;
  animation: ml-pagination-spin 0.7s linear infinite;
  flex-shrink: 0;
}
@keyframes ml-pagination-spin {
  to {
    transform: rotate(360deg);
  }
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Icon'];
        // ===========================================================================
        // PROPERTIES — From groupTriggerAction contract
        // ===========================================================================
        this.size = 'md';
        this.type = 'button';
        this.iconPosition = 'start';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // PROPERTIES — Pagination-specific
        // ===========================================================================
        this.currentPage = 1;
        this.totalPages = 1;
        this.visiblePages = 5;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.announcedText = '';
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    updated(changedProps) {
        if (changedProps.has('currentPage') || changedProps.has('totalPages')) {
            this.updateAnnouncement();
        }
    }
    handleIcaStateChange(key, _value) {
        const currentPageAttr = this.getAttribute('current-page');
        const totalPagesAttr = this.getAttribute('total-pages');
        if (currentPageAttr === `{{${key}}}` ||
            totalPagesAttr === `{{${key}}}`) {
            this.updateAnnouncement();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    normalizePage(page) {
        const n = Number(page);
        if (!Number.isFinite(n) || n < 1)
            return 1;
        return Math.floor(n);
    }
    normalizeTotal(total) {
        const n = Number(total);
        if (!Number.isFinite(n) || n < 1)
            return 1;
        return Math.floor(n);
    }
    normalizeVisible(visible) {
        const n = Number(visible);
        if (!Number.isFinite(n) || n < 1)
            return 5;
        return Math.floor(n);
    }
    getSafeCurrent() {
        const total = this.normalizeTotal(this.totalPages);
        const current = this.normalizePage(this.currentPage);
        return Math.min(current, total);
    }
    updateAnnouncement() {
        const current = this.getSafeCurrent();
        const total = this.normalizeTotal(this.totalPages);
        this.announcedText = this.msg.currentPageAnnounce
            .replace('{current}', String(current))
            .replace('{total}', String(total));
    }
    /**
     * Builds the visible page window, always including the current page.
     * Returns a mixed list of page numbers and ellipsis markers.
     */
    buildPageItems() {
        const total = this.normalizeTotal(this.totalPages);
        const current = this.getSafeCurrent();
        const maxVisible = this.normalizeVisible(this.visiblePages);
        if (total <= maxVisible) {
            return Array.from({ length: total }, (_, i) => i + 1);
        }
        // Reserve slots for first/last when ellipsis is shown
        const items = [];
        // Window size for the sliding range around current
        // Always try to show: [1] … [window] … [total]
        const sideCount = Math.max(1, maxVisible - 2); // pages in the middle window
        let start = Math.max(2, current - Math.floor((sideCount - 1) / 2));
        let end = start + sideCount - 1;
        if (end >= total) {
            end = total - 1;
            start = Math.max(2, end - sideCount + 1);
        }
        // Ensure current is inside the window
        if (current < start)
            start = Math.max(2, current);
        if (current > end)
            end = Math.min(total - 1, current);
        // First page always
        items.push(1);
        if (start > 2) {
            items.push('ellipsis-start');
        }
        else if (start === 2) {
            // no ellipsis, page 2 will be included in the loop
        }
        for (let p = start; p <= end; p++) {
            items.push(p);
        }
        if (end < total - 1) {
            items.push('ellipsis-end');
        }
        // Last page always (if more than 1)
        if (total > 1) {
            items.push(total);
        }
        return items;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handlePageAction(targetPage) {
        console.log('clicou em handlePageAction');
        if (this.disabled || this.loading)
            return;
        const total = this.normalizeTotal(this.totalPages);
        const current = this.getSafeCurrent();
        const page = Math.min(Math.max(1, targetPage), total);
        if (page === current)
            return;
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: { page },
        }));
    }
    handleFirst() {
        this.handlePageAction(1);
    }
    handlePrevious() {
        this.handlePageAction(this.getSafeCurrent() - 1);
    }
    handleNext() {
        this.handlePageAction(this.getSafeCurrent() + 1);
    }
    handleLast() {
        this.handlePageAction(this.normalizeTotal(this.totalPages));
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getRootClasses() {
        return [
            'inline-flex items-center gap-1',
            'ml-pagination',
            this.disabled ? 'ml-disabled' : '',
            this.loading ? 'ml-loading' : '',
            `ml-size-${this.size || 'md'}`,
        ].filter(Boolean).join(' ');
    }
    getNavButtonClasses(isDisabled) {
        return [
            'inline-flex items-center justify-center',
            'min-w-[2rem] h-8 px-2 text-sm',
            'rounded-md border transition',
            'ml-pagination-nav',
            isDisabled ? 'ml-pagination-nav-disabled ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getPageButtonClasses(isCurrent) {
        return [
            'inline-flex items-center justify-center',
            'min-w-[2rem] h-8 px-2 text-sm font-semibold',
            'rounded-md border transition',
            'ml-pagination-page',
            isCurrent ? 'ml-pagination-page-current' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getEllipsisClasses() {
        return [
            'inline-flex items-center justify-center',
            'min-w-[2rem] h-8 px-1 text-sm',
            'ml-pagination-ellipsis',
            'ml-text-muted',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLoading() {
        return html `
      <div
        class="${cn(this.getRootClasses(), this.cssClass)}"
        role="navigation"
        aria-label=${this.msg.pagination}
        aria-busy="true"
        aria-disabled="true"
      >
        <span class="inline-flex items-center gap-2 text-sm ml-text-muted" aria-live="polite">
          <span class="inline-block w-4 h-4 rounded-full border-2 border-current border-t-transparent animate-spin ml-spinner" aria-hidden="true"></span>
          ${this.msg.loading}
        </span>
      </div>
    `;
    }
    renderNavButton(kind, label, symbol, isDisabled, onClick) {
        return html `
      <button
        type="button"
        class=${this.getNavButtonClasses(isDisabled)}
        ?disabled=${isDisabled || this.disabled}
        aria-label=${label}
        aria-disabled=${isDisabled || this.disabled ? 'true' : nothing}
        @click=${onClick}
        data-nav=${kind}
      >
        <span aria-hidden="true">${symbol}</span>
      </button>
    `;
    }
    renderPageButton(page, isCurrent) {
        const label = isCurrent
            ? `${this.msg.page} ${page}`
            : `${this.msg.goToPage} ${page}`;
        return html `
      <button
        type="button"
        class=${this.getPageButtonClasses(isCurrent)}
        ?disabled=${this.disabled || isCurrent}
        aria-label=${label}
        aria-current=${isCurrent ? 'page' : nothing}
        @click=${() => this.handlePageAction(page)}
        data-page=${page}
      >
        ${page}
      </button>
    `;
    }
    renderEllipsis(key) {
        return html `
      <span class=${this.getEllipsisClasses()} aria-hidden="true" data-ellipsis=${key}>
        …
      </span>
    `;
    }
    renderPageItems() {
        const current = this.getSafeCurrent();
        const items = this.buildPageItems();
        return items.map((item) => {
            if (item === 'ellipsis-start')
                return this.renderEllipsis('start');
            if (item === 'ellipsis-end')
                return this.renderEllipsis('end');
            return this.renderPageButton(item, item === current);
        });
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        const current = this.getSafeCurrent();
        const total = this.normalizeTotal(this.totalPages);
        const isFirst = current <= 1;
        const isLast = current >= total;
        const navDisabled = this.disabled;
        const announce = this.announcedText || this.msg.currentPageAnnounce
            .replace('{current}', String(current))
            .replace('{total}', String(total));
        return html `
      <nav
        class="${cn(this.getRootClasses(), this.cssClass)}"
        role="navigation"
        aria-label=${this.msg.pagination}
        aria-disabled=${this.disabled ? 'true' : nothing}
      >
        ${this.renderNavButton('first', this.msg.firstPage, '«', isFirst || navDisabled, () => this.handleFirst())}
        ${this.renderNavButton('previous', this.msg.previousPage, '‹', isFirst || navDisabled, () => this.handlePrevious())}

        <div class="inline-flex items-center gap-1 ml-pagination-pages" role="list">
          ${this.renderPageItems()}
        </div>

        ${this.renderNavButton('next', this.msg.nextPage, '›', isLast || navDisabled, () => this.handleNext())}
        ${this.renderNavButton('last', this.msg.lastPage, '»', isLast || navDisabled, () => this.handleLast())}

        <span class="sr-only" aria-live="polite" aria-atomic="true">${announce}</span>
      </nav>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlPaginationControlMolecule.prototype, "size", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlPaginationControlMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'icon-position' })
], MlPaginationControlMolecule.prototype, "iconPosition", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPaginationControlMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPaginationControlMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'current-page' })
], MlPaginationControlMolecule.prototype, "currentPage", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'total-pages' })
], MlPaginationControlMolecule.prototype, "totalPages", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'visible-pages' })
], MlPaginationControlMolecule.prototype, "visiblePages", void 0);
__decorate([
    state()
], MlPaginationControlMolecule.prototype, "announcedText", void 0);
MlPaginationControlMolecule = __decorate([
    customElement('grouptriggeraction--ml-pagination-control')
], MlPaginationControlMolecule);
export { MlPaginationControlMolecule };
