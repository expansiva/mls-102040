/// <mls fileReference="_102040_/l2/molecules/groupnavigatemain/ml-sidebar-nav.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML SIDEBAR NAV MOLECULE
// =============================================================================
// Skill Group: groupNavigateMain
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    collapse: 'Collapse sidebar',
    expand: 'Expand sidebar',
    navigation: 'Sidebar navigation',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        collapse: 'Recolher menu',
        expand: 'Expandir menu',
        navigation: 'Menu lateral',
    },
};
let MlSidebarNavMolecule = class MlSidebarNavMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatemain--ml-sidebar-nav .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatemain--ml-sidebar-nav .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatemain--ml-sidebar-nav .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatemain--ml-sidebar-nav .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatemain--ml-sidebar-nav .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupnavigatemain--ml-sidebar-nav .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupnavigatemain--ml-sidebar-nav .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
groupnavigatemain--ml-sidebar-nav .ml-error-dim-bg {
  background: var(--ml-error-dim, #fef2f2);
}
groupnavigatemain--ml-sidebar-nav .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupnavigatemain--ml-sidebar-nav .hover\:ml-surface-dim-bg:hover {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupnavigatemain--ml-sidebar-nav .hover\:ml-text:hover {
  color: var(--text-strong, #1c1b1f);
}
groupnavigatemain--ml-sidebar-nav .hover\:ml-text-muted:hover {
  color: var(--text-muted, #49454f);
}
groupnavigatemain--ml-sidebar-nav .group:hover .group-hover\:ml-text-muted {
  color: var(--text-muted, #49454f);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Item', 'Group', 'Footer'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.collapsed = false;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.collapsedGroups = new Set();
    }
    // ===========================================================================
    // PARSERS
    // ===========================================================================
    parseItem(el) {
        return {
            value: el.getAttribute('value') || '',
            label: el.textContent?.trim() || '',
            icon: el.getAttribute('icon') || '',
            badge: el.getAttribute('badge'),
            disabled: el.hasAttribute('disabled'),
        };
    }
    parseTopItems() {
        return this.getSlots('Item')
            .filter(el => {
            const parentTag = el.parentElement?.tagName?.toLowerCase();
            return parentTag !== 'group' && parentTag !== 'footer';
        })
            .map(el => this.parseItem(el));
    }
    parseGroups() {
        return this.getSlots('Group').map(el => ({
            label: el.getAttribute('label') || '',
            items: Array.from(el.querySelectorAll('Item')).map(item => this.parseItem(item)),
        }));
    }
    parseFooterItems() {
        const footerEl = this.getSlot('Footer');
        if (!footerEl)
            return [];
        return Array.from(footerEl.querySelectorAll('Item')).map(item => this.parseItem(item));
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleItemClick(item) {
        if (this.disabled || item.disabled)
            return;
        this.value = item.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: item.value, label: item.label, badge: item.badge },
        }));
    }
    handleToggleCollapse() {
        this.collapsed = !this.collapsed;
        this.dispatchEvent(new CustomEvent('collapse', {
            bubbles: true,
            composed: true,
            detail: { collapsed: this.collapsed },
        }));
    }
    handleToggleGroup(groupLabel) {
        const next = new Set(this.collapsedGroups);
        if (next.has(groupLabel))
            next.delete(groupLabel);
        else
            next.add(groupLabel);
        this.collapsedGroups = next;
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getItemClasses(item) {
        const isActive = this.value === item.value;
        const isDisabled = this.disabled || item.disabled;
        return [
            'group relative flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition',
            '',
            isActive
                ? 'ml-primary-dim-bg ml-primary-text'
                : 'ml-text',
            !isActive && !isDisabled
                ? 'hover:ml-surface-dim-bg hover:ml-text'
                : '',
            isDisabled ? 'cursor-not-allowed opacity-50' : 'cursor-pointer',
            this.collapsed ? 'justify-center' : '',
        ].filter(Boolean).join(' ');
    }
    getIconClasses(item) {
        const isActive = this.value === item.value;
        return [
            'flex h-5 w-5 flex-shrink-0 items-center justify-center',
            isActive
                ? 'ml-primary-text'
                : 'ml-text-faint group-hover:ml-text-muted',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderItemIcon(item) {
        if (item.icon) {
            return html `<span class=${this.getIconClasses(item)}>${unsafeHTML(item.icon)}</span>`;
        }
        // Fallback: initials when no icon provided
        const initials = item.label.trim().slice(0, 2).toUpperCase();
        return html `
 <span class="${this.getIconClasses(item)} rounded-md ml-surface-dim-bg text-xs font-bold">
 ${initials}
 </span>
 `;
    }
    renderNavItem(item) {
        const isActive = this.value === item.value;
        const isDisabled = this.disabled || item.disabled;
        return html `
 <button
 class=${this.getItemClasses(item)}
 type="button"
 title=${this.collapsed ? item.label : ''}
 aria-current=${isActive ? 'page' : nothing}
 aria-disabled=${isDisabled ? 'true' : 'false'}
 @click=${() => this.handleItemClick(item)}
 >
 ${this.renderItemIcon(item)}

 ${!this.collapsed ? html `
 <span class="flex-1 truncate text-left">${item.label}</span>
 ${item.badge ? html `
 <span class="ml-auto inline-flex items-center rounded-full ml-primary-dim-bg px-2 py-0.5 text-xs font-semibold ml-primary-text">
 ${item.badge}
 </span>
 ` : nothing}
 ` : html `
 ${item.badge ? html `
 <span class="absolute right-1.5 top-1.5 h-2 w-2 rounded-full ml-error-dim-bg"></span>
 ` : nothing}
 `}
 </button>
 `;
    }
    renderGroup(group) {
        if (this.collapsed) {
            return html `
 <div class="space-y-1">
 <div class="mx-3 my-2 h-px ml-surface-dim-bg"></div>
 ${group.items.map(item => this.renderNavItem(item))}
 </div>
 `;
        }
        const isGroupCollapsed = this.collapsedGroups.has(group.label);
        return html `
 <div class="space-y-1">
 ${group.label ? html `
 <button
 class="flex w-full items-center justify-between px-3 py-1.5 text-xs font-semibold uppercase tracking-wider ml-text-faint hover:ml-text-muted transition"
 type="button"
 @click=${() => this.handleToggleGroup(group.label)}
 >
 <span class="truncate">${group.label}</span>
 <svg
 class="ml-2 h-3 w-3 flex-shrink-0 transition-transform ${isGroupCollapsed ? '' : 'rotate-90'}"
 viewBox="0 0 20 20"
 fill="currentColor"
 aria-hidden="true"
 >
 <path fill-rule="evenodd" d="M7.21 14.77a.75.75 0 01.02-1.06L11.168 10 7.23 6.29a.75.75 0 111.04-1.08l4.5 4.25a.75.75 0 010 1.08l-4.5 4.25a.75.75 0 01-1.06-.02z" clip-rule="evenodd" />
 </svg>
 </button>
 ${!isGroupCollapsed
            ? html `<div class="space-y-1">${group.items.map(item => this.renderNavItem(item))}</div>`
            : nothing}
 ` : html `
 <div class="space-y-1">${group.items.map(item => this.renderNavItem(item))}</div>
 `}
 </div>
 `;
    }
    renderCollapseToggle() {
        return html `
 <button
 class="flex items-center justify-center rounded-lg p-1.5 ml-text-faint hover:ml-surface-dim-bg hover:ml-text-muted transition"
 type="button"
 aria-label=${this.collapsed ? this.msg.expand : this.msg.collapse}
 @click=${this.handleToggleCollapse}
 >
 <svg
 class="h-4 w-4 transition-transform ${this.collapsed ? 'rotate-180' : ''}"
 fill="none"
 viewBox="0 0 24 24"
 stroke="currentColor"
 stroke-width="2"
 aria-hidden="true"
 >
 <path stroke-linecap="round" stroke-linejoin="round" d="M11 19l-7-7 7-7m8 14l-7-7 7-7" />
 </svg>
 </button>
 `;
    }
    renderLoading() {
        return html `
 <div class="space-y-1 animate-pulse">
 ${[1, 2, 3, 4].map(() => html `
 <div class="flex items-center gap-3 rounded-lg px-3 py-2">
 <div class="h-5 w-5 flex-shrink-0 rounded ml-surface-dim-bg"></div>
 ${!this.collapsed ? html `
 <div class="h-3 w-28 rounded ml-surface-dim-bg"></div>
 ` : nothing}
 </div>
 `)}
 <div class="mx-3 my-3 h-px ml-surface-dim-bg"></div>
 ${[1, 2].map(() => html `
 <div class="flex items-center gap-3 rounded-lg px-3 py-2">
 <div class="h-5 w-5 flex-shrink-0 rounded ml-surface-dim-bg"></div>
 ${!this.collapsed ? html `
 <div class="h-3 w-20 rounded ml-surface-dim-bg"></div>
 ` : nothing}
 </div>
 `)}
 </div>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelContent = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const topItems = this.parseTopItems();
        const groups = this.parseGroups();
        const footerItems = this.parseFooterItems();
        const sidebarWidth = this.collapsed ? 'w-16' : 'w-64';
        return html `
 <nav
 class="${cn(`${sidebarWidth} flex h-full flex-col overflow-hidden border-r ml-border ml-surface-bg transition-all duration-200`, this.cssClass)}"
 aria-label=${labelContent || this.msg.navigation}
 >
 <!-- Header: label + collapse toggle -->
 <div class="flex min-h-[56px] items-center justify-between border-b ml-border px-3 py-3">
 ${!this.collapsed && labelContent ? html `
 <span class="${cn('truncate text-sm font-semibold ml-text', this.getSlotClass('Label'))}">
 ${unsafeHTML(labelContent)}
 </span>
 ` : html `<span></span>`}
 ${this.renderCollapseToggle()}
 </div>

 <!-- Main nav items -->
 <div class="flex-1 overflow-y-auto px-2 py-3 space-y-1">
 ${this.loading
            ? this.renderLoading()
            : html `
 ${topItems.map(item => this.renderNavItem(item))}
 ${groups.map(group => this.renderGroup(group))}
 `}
 </div>

 <!-- Footer items -->
 ${footerItems.length > 0 ? html `
 <div class="border-t ml-border px-2 py-3 space-y-1">
 ${footerItems.map(item => this.renderNavItem(item))}
 </div>
 ` : nothing}
 </nav>
 `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSidebarNavMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSidebarNavMolecule.prototype, "collapsed", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSidebarNavMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSidebarNavMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSidebarNavMolecule.prototype, "collapsedGroups", void 0);
MlSidebarNavMolecule = __decorate([
    customElement('groupnavigatemain--ml-sidebar-nav')
], MlSidebarNavMolecule);
export { MlSidebarNavMolecule };
