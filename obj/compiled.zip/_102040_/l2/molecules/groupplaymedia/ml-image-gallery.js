var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupplaymedia/ml-image-gallery.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// IMAGE GALLERY MOLECULE
// =============================================================================
// Skill Group: groupPlayMedia
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    labelFallback: 'Image gallery',
    previous: 'Previous image',
    next: 'Next image',
    loading: 'Loading...',
    noSources: 'No image sources were provided.',
    openExpanded: 'Open expanded view',
    closeExpanded: 'Close expanded view',
    image: 'Image',
};
const messages = {
    en: message_en,
};
let ImageGalleryMolecule = class ImageGalleryMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupplaymedia--ml-image-gallery .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-image-gallery .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-image-gallery .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-image-gallery .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupplaymedia--ml-image-gallery .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-image-gallery .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-image-gallery .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-image-gallery .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupplaymedia--ml-image-gallery .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-image-gallery .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupplaymedia--ml-image-gallery .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-image-gallery .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-image-gallery .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupplaymedia--ml-image-gallery .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupplaymedia--ml-image-gallery .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupplaymedia--ml-image-gallery .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-image-gallery .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupplaymedia--ml-image-gallery .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupplaymedia--ml-image-gallery .hover\:ml-surface-dim-bg:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-image-gallery .hover\:ml-border:hover {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Source', 'Track'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.disabled = false;
        this.loading = false;
        this.error = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.activeIndex = 0;
        this.isExpanded = false;
        this.lastErrorMessage = '';
    }
    // ===========================================================================
    // EVENT HELPERS
    // ===========================================================================
    notifyIndexChange() {
        const sources = this.getSources();
        this.dispatchEvent(new CustomEvent('timeUpdate', {
            bubbles: true,
            composed: true,
            detail: { currentTime: this.activeIndex, duration: sources.length },
        }));
    }
    dispatchPlayEvent() {
        this.dispatchEvent(new CustomEvent('play', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    dispatchPauseEvent() {
        this.dispatchEvent(new CustomEvent('pause', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    dispatchErrorEvent(message) {
        this.dispatchEvent(new CustomEvent('error', {
            bubbles: true,
            composed: true,
            detail: { message },
        }));
    }
    // ===========================================================================
    // DATA HELPERS
    // ===========================================================================
    getSources() {
        return this.getSlots('Source').map((el) => ({
            src: el.getAttribute('src') || '',
            type: el.getAttribute('type') || '',
        })).filter((item) => item.src);
    }
    getTracks() {
        return this.getSlots('Track').map((el) => ({
            src: el.getAttribute('src') || '',
            kind: el.getAttribute('kind') || 'subtitles',
            lang: el.getAttribute('lang') || '',
            label: el.getAttribute('label') || '',
        }));
    }
    getCaption(tracks, index) {
        return tracks[index]?.label || '';
    }
    getAltText(tracks, index) {
        const caption = this.getCaption(tracks, index);
        if (caption)
            return caption;
        return `${this.msg.image} ${index + 1}`;
    }
    getLabelText() {
        const labelContent = this.getSlotContent('Label');
        return labelContent ? labelContent.replace(/<[^>]*>/g, '').trim() : this.msg.labelFallback;
    }
    getComputedError(sources) {
        if (this.error && this.error.trim())
            return this.error;
        if (sources.length === 0)
            return this.msg.noSources;
        return '';
    }
    syncActiveIndex(sources) {
        if (sources.length === 0) {
            this.activeIndex = 0;
            return;
        }
        if (this.activeIndex >= sources.length) {
            this.activeIndex = sources.length - 1;
        }
    }
    trackError(message) {
        if (message && message !== this.lastErrorMessage) {
            this.lastErrorMessage = message;
            this.dispatchErrorEvent(message);
            return;
        }
        if (!message && this.lastErrorMessage) {
            this.lastErrorMessage = '';
        }
    }
    // ===========================================================================
    // INTERACTION HANDLERS
    // ===========================================================================
    handlePrev() {
        if (this.disabled || this.loading || this.lastErrorMessage)
            return;
        if (this.activeIndex > 0) {
            this.activeIndex -= 1;
            this.notifyIndexChange();
        }
    }
    handleNext() {
        if (this.disabled || this.loading || this.lastErrorMessage)
            return;
        const sources = this.getSources();
        if (this.activeIndex < sources.length - 1) {
            this.activeIndex += 1;
            this.notifyIndexChange();
        }
    }
    handleThumbnailSelect(index) {
        if (this.disabled || this.loading || this.lastErrorMessage)
            return;
        if (index === this.activeIndex)
            return;
        this.activeIndex = index;
        this.notifyIndexChange();
    }
    handleToggleExpanded() {
        if (this.disabled || this.loading || this.lastErrorMessage)
            return;
        if (this.isExpanded) {
            this.isExpanded = false;
            this.dispatchPauseEvent();
        }
        else {
            this.isExpanded = true;
            this.dispatchPlayEvent();
        }
    }
    handleKeyDown(event) {
        if (this.disabled || this.loading || this.lastErrorMessage)
            return;
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            this.handlePrev();
            return;
        }
        if (event.key === 'ArrowRight') {
            event.preventDefault();
            this.handleNext();
            return;
        }
        if (event.key === '' && this.isExpanded) {
            event.preventDefault();
            this.isExpanded = false;
            this.dispatchPauseEvent();
        }
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getControlButtonClasses(disabled) {
        return [
            'inline-flex items-center justify-center rounded-md px-3 py-2 text-sm font-medium border transition',
            'ml-surface-bg',
            'ml-border',
            'ml-text',
            '',
            !disabled ? 'hover:ml-surface-dim-bg' : 'ml-disabled',
        ].filter(Boolean).join(' ');
    }
    getThumbnailClasses(isActive, disabled) {
        return [
            'h-16 w-16 shrink-0 rounded-md border overflow-hidden transition',
            'ml-surface-bg',
            isActive
                ? 'ml-border-focus ml-focus-ring'
                : 'ml-border',
            !disabled ? 'hover:ml-border' : 'ml-disabled',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const sources = this.getSources();
        const tracks = this.getTracks();
        const total = sources.length;
        const labelContent = this.getSlotContent('Label');
        const ariaLabel = this.getLabelText();
        this.syncActiveIndex(sources);
        const computedError = this.getComputedError(sources);
        this.trackError(computedError);
        const mainSource = sources[this.activeIndex];
        const caption = this.getCaption(tracks, this.activeIndex);
        const rootClasses = [
            'relative w-full rounded-xl border p-4 transition',
            'ml-surface-bg',
            'ml-border',
            (this.disabled || this.loading) ? 'opacity-70' : '',
        ].filter(Boolean).join(' ');
        if (computedError) {
            return html `
<div class="${cn(rootClasses, this.cssClass)}" tabindex="0" aria-label="${ariaLabel}">
${labelContent
                ? html `<div class="${cn('mb-3 text-sm ml-text-muted', this.getSlotClass('Label'))}">${unsafeHTML(labelContent)}</div>`
                : ''}
<div class="flex min-h-[220px] items-center justify-center rounded-lg border ml-border-error ml-surface-dim-bg">
<p class="text-sm ml-error-text">${computedError}</p>
</div>
</div>
`;
        }
        return html `
<div
class="${cn(rootClasses, this.cssClass)}"
tabindex="0"
aria-label="${ariaLabel}"
@keydown=${this.handleKeyDown}
>
${labelContent
            ? html `<div class="${cn('mb-3 text-sm ml-text-muted', this.getSlotClass('Label'))}">${unsafeHTML(labelContent)}</div>`
            : ''}
<div class="relative">
<button
class="w-full rounded-lg border ml-border ml-surface-dim-bg overflow-hidden"
?disabled=${this.disabled || this.loading}
@click=${this.handleToggleExpanded}
aria-label="${this.isExpanded ? this.msg.closeExpanded : this.msg.openExpanded}"
>
${mainSource
            ? html `<img
class="h-64 w-full object-cover"
src="${mainSource.src}"
alt="${this.getAltText(tracks, this.activeIndex)}"
loading="lazy"
/>`
            : html `<div class="h-64"></div>`}
</button>
${caption
            ? html `<div class="mt-2 text-sm ml-text-muted">${caption}</div>`
            : ''}
${this.loading
            ? html `<div class="absolute inset-0 flex items-center justify-center rounded-lg ml-surface-bg/70">
<span class="text-sm ml-text-muted">${this.msg.loading}</span>
</div>`
            : ''}
</div>
<div class="mt-4 flex items-center justify-between gap-3">
<button
class="${this.getControlButtonClasses(this.disabled || this.loading || this.activeIndex === 0)}"
?disabled=${this.disabled || this.loading || this.activeIndex === 0}
@mousedown=${(event) => event.preventDefault()}
@click=${this.handlePrev}
aria-label="${this.msg.previous}"
>
${this.msg.previous}
</button>
<div class="text-xs ml-text-muted">
${total > 0 ? `${this.activeIndex + 1} / ${total}` : '0 / 0'}
</div>
<button
class="${this.getControlButtonClasses(this.disabled || this.loading || this.activeIndex === total - 1)}"
?disabled=${this.disabled || this.loading || this.activeIndex === total - 1}
@mousedown=${(event) => event.preventDefault()}
@click=${this.handleNext}
aria-label="${this.msg.next}"
>
${this.msg.next}
</button>
</div>
<div class="mt-4 flex gap-2 overflow-x-auto">
${sources.map((source, index) => html `
<button
class="${this.getThumbnailClasses(index === this.activeIndex, this.disabled || this.loading)}"
?disabled=${this.disabled || this.loading}
@click=${() => this.handleThumbnailSelect(index)}
aria-label="${this.getAltText(tracks, index)}"
>
<img
class="h-full w-full object-cover"
src="${source.src}"
alt="${this.getAltText(tracks, index)}"
loading="lazy"
/>
</button>
`)}
</div>
${this.isExpanded
            ? html `
<div
class="absolute inset-0 z-10 flex items-center justify-center rounded-xl bg-black/70"
@click=${this.handleToggleExpanded}
>
<div class="max-h-[90%] max-w-[90%]">
${mainSource
                ? html `<img
class="max-h-[90vh] w-auto rounded-lg border ml-border"
src="${mainSource.src}"
alt="${this.getAltText(tracks, this.activeIndex)}"
/>`
                : html ``}
</div>
</div>
`
            : ''}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], ImageGalleryMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ImageGalleryMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: String })
], ImageGalleryMolecule.prototype, "error", void 0);
__decorate([
    state()
], ImageGalleryMolecule.prototype, "activeIndex", void 0);
__decorate([
    state()
], ImageGalleryMolecule.prototype, "isExpanded", void 0);
__decorate([
    state()
], ImageGalleryMolecule.prototype, "lastErrorMessage", void 0);
ImageGalleryMolecule = __decorate([
    customElement('groupplaymedia--ml-image-gallery')
], ImageGalleryMolecule);
export { ImageGalleryMolecule };
