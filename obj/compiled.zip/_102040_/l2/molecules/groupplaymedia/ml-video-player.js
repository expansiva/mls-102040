/// <mls fileReference="_102040_/l2/molecules/groupplaymedia/ml-video-player.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// VIDEO PLAYER MOLECULE
// =============================================================================
// Skill Group: play + media
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    play: 'Play',
    pause: 'Pause',
    replay: 'Replay',
    loading: 'Loading media...',
    noSource: 'No media source provided',
    error: 'Unable to play media',
    mute: 'Mute',
    unmute: 'Unmute',
    captionsOn: 'Captions on',
    captionsOff: 'Captions off',
    fullscreen: 'Fullscreen',
    volume: 'Volume',
    progress: 'Progress',
    player: 'Media player',
};
const messages = {
    en: message_en,
    pt: {
        play: 'Reproduzir',
        pause: 'Pausar',
        replay: 'Reproduzir novamente',
        loading: 'Carregando mídia...',
        noSource: 'Nenhuma fonte de mídia fornecida',
        error: 'Não foi possível reproduzir a mídia',
        mute: 'Silenciar',
        unmute: 'Ativar som',
        captionsOn: 'Legendas ativadas',
        captionsOff: 'Legendas desativadas',
        fullscreen: 'Tela cheia',
        volume: 'Volume',
        progress: 'Progresso',
        player: 'Reprodutor de mídia',
    },
};
/// **collab_i18n_end**
let VideoPlayerMolecule = class VideoPlayerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupplaymedia--ml-video-player .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-video-player .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-video-player .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-video-player .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupplaymedia--ml-video-player .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-video-player .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-video-player .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-video-player .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupplaymedia--ml-video-player .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-video-player .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupplaymedia--ml-video-player .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-video-player .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-video-player .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupplaymedia--ml-video-player .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupplaymedia--ml-video-player .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupplaymedia--ml-video-player .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-video-player .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupplaymedia--ml-video-player .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Source', 'Track'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.poster = '';
        this.autoplay = false;
        this.loop = false;
        this.muted = false;
        this.preload = 'metadata';
        this.disabled = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.isPlaying = false;
        this.currentTime = 0;
        this.duration = 0;
        this.volume = 1;
        this.isMuted = false;
        this.hasEnded = false;
        this.captionsEnabled = false;
    }
    // =========================================================================
    // STATE CHANGE HANDLER (derived values)
    // =========================================================================
    handleIcaStateChange(key, value) {
        const mutedAttr = this.getAttribute('muted');
        if (mutedAttr === `{{${key}}}`) {
            this.isMuted = Boolean(value);
            const media = this.getMediaElement();
            if (media)
                media.muted = this.isMuted;
        }
        this.requestUpdate();
    }
    // =========================================================================
    // PUBLIC METHODS — Playback Controls
    // =========================================================================
    playMedia() {
        if (this.isBlocked())
            return;
        const media = this.getMediaElement();
        if (!media || !this.hasSources()) {
            this.emitError(this.msg.noSource);
            return;
        }
        media.play().catch(() => this.emitError(this.msg.error));
    }
    pauseMedia() {
        if (this.isBlocked())
            return;
        const media = this.getMediaElement();
        if (!media)
            return;
        media.pause();
    }
    togglePlay() {
        if (this.isPlaying)
            this.pauseMedia();
        else
            this.playMedia();
    }
    seekTo(seconds) {
        if (this.isBlocked())
            return;
        const media = this.getMediaElement();
        if (!media || !this.duration)
            return;
        media.currentTime = Math.max(0, Math.min(this.duration, seconds));
    }
    setVolume(value) {
        if (this.isBlocked())
            return;
        const media = this.getMediaElement();
        if (!media)
            return;
        const clamped = Math.max(0, Math.min(1, value));
        media.volume = clamped;
        this.volume = clamped;
        if (clamped === 0) {
            media.muted = true;
            this.isMuted = true;
        }
    }
    toggleMute() {
        if (this.isBlocked())
            return;
        const media = this.getMediaElement();
        if (!media)
            return;
        media.muted = !media.muted;
        this.isMuted = media.muted;
    }
    enterFullscreen() {
        if (this.isBlocked())
            return;
        const media = this.getMediaElement();
        if (!media)
            return;
        if (media.requestFullscreen)
            media.requestFullscreen();
    }
    toggleCaptions() {
        if (this.isBlocked())
            return;
        const media = this.getMediaElement();
        if (!media || !media.textTracks)
            return;
        const enable = !this.captionsEnabled;
        Array.from(media.textTracks).forEach(track => {
            track.mode = enable ? 'showing' : 'disabled';
        });
        this.captionsEnabled = enable;
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handlePlay() {
        this.isPlaying = true;
        this.hasEnded = false;
        this.dispatchEvent(new CustomEvent('play', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handlePause() {
        this.isPlaying = false;
        this.dispatchEvent(new CustomEvent('pause', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleEnded() {
        this.isPlaying = false;
        this.hasEnded = true;
        this.dispatchEvent(new CustomEvent('ended', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleTimeUpdate() {
        const media = this.getMediaElement();
        if (!media)
            return;
        this.currentTime = media.currentTime || 0;
        this.duration = media.duration || 0;
        this.dispatchEvent(new CustomEvent('timeUpdate', {
            bubbles: true,
            composed: true,
            detail: { currentTime: this.currentTime, duration: this.duration },
        }));
    }
    handleLoadedMetadata() {
        const media = this.getMediaElement();
        if (!media)
            return;
        this.duration = media.duration || 0;
        this.volume = media.volume || 1;
        this.isMuted = media.muted || false;
    }
    handleVolumeChange() {
        const media = this.getMediaElement();
        if (!media)
            return;
        this.volume = media.volume || 1;
        this.isMuted = media.muted || false;
    }
    handleMediaError() {
        this.emitError(this.msg.error);
    }
    handleSeekInput(e) {
        if (this.isBlocked())
            return;
        const input = e.target;
        const value = Number(input.value);
        this.seekTo(value);
    }
    handleVolumeInput(e) {
        if (this.isBlocked())
            return;
        const input = e.target;
        const value = Number(input.value);
        this.setVolume(value);
    }
    handleKeyDown(e) {
        if (this.isBlocked())
            return;
        if (e.code === 'Space') {
            e.preventDefault();
            this.togglePlay();
            return;
        }
        if (e.code === 'ArrowLeft') {
            e.preventDefault();
            this.seekTo(this.currentTime - 5);
            return;
        }
        if (e.code === 'ArrowRight') {
            e.preventDefault();
            this.seekTo(this.currentTime + 5);
            return;
        }
        if (e.code === 'ArrowUp') {
            e.preventDefault();
            this.setVolume(this.volume + 0.05);
            return;
        }
        if (e.code === 'ArrowDown') {
            e.preventDefault();
            this.setVolume(this.volume - 0.05);
        }
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelContent = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const ariaLabel = this.getSlot('Label')?.textContent?.trim() || this.msg.player;
        if (this.loading) {
            return html `
 <div class="${cn('w-full rounded-lg border ml-border ml-surface-dim-bg p-4 text-sm ml-text-muted', this.cssClass)}">
 ${this.msg.loading}
 </div>
 `;
        }
        const sources = this.readSources();
        const tracks = this.readTracks();
        if (sources.length === 0) {
            return html `
 <div class="${cn('w-full rounded-lg border ml-border ml-surface-dim-bg p-4 text-sm ml-error-text', this.cssClass)}">
 ${this.msg.noSource}
 </div>
 `;
        }
        const isBlocked = this.isBlocked();
        return html `
 <div class="${cn('w-full', this.cssClass)}">
 ${this.renderLabel(labelContent)}
 <div
 class="w-full rounded-lg border ml-border ml-surface-bg p-3"
 tabindex="0"
 aria-label="${ariaLabel}"
 @keydown=${this.handleKeyDown}
 >
 <div class="relative w-full overflow-hidden rounded-md bg-black">
 <video
 class="w-full h-auto"
 ?autoplay=${this.autoplay}
 ?loop=${this.loop}
 ?muted=${this.isMuted || this.muted}
 preload=${ifDefined(this.preload || undefined)}
 poster=${ifDefined(this.poster || undefined)}
 @play=${this.handlePlay}
 @pause=${this.handlePause}
 @ended=${this.handleEnded}
 @timeupdate=${this.handleTimeUpdate}
 @error=${this.handleMediaError}
 @loadedmetadata=${this.handleLoadedMetadata}
 @volumechange=${this.handleVolumeChange}
 >
 ${sources.map(item => html `<source src=${item.src} type=${ifDefined(item.type || undefined)} />`)}
 ${tracks.map(track => html `<track src=${track.src} kind=${track.kind} srclang=${track.lang} label=${track.label} />`)}
 </video>
 </div>

 <div class="mt-3 flex flex-col gap-3">
 ${this.renderControls(isBlocked, tracks.length > 0)}
 </div>
 </div>
 </div>
 `;
    }
    // =========================================================================
    // RENDER HELPERS
    // =========================================================================
    renderLabel(content) {
        if (!content)
            return html `${nothing}`;
        return html `
 <div class="${cn('mb-2 text-sm ml-text-muted', this.getSlotClass('Label'))}">
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderControls(isBlocked, hasTracks) {
        const playLabel = this.hasEnded ? this.msg.replay : this.isPlaying ? this.msg.pause : this.msg.play;
        const timeLabel = `${this.formatTime(this.currentTime)} / ${this.formatTime(this.duration)}`;
        return html `
 <div class="flex flex-wrap items-center gap-3">
 <button
 class="${this.getButtonClasses(isBlocked)}"
 type="button"
 aria-label="${playLabel}"
 ?disabled=${isBlocked}
 @click=${this.togglePlay}
 >
 ${playLabel}
 </button>

 <div class="flex items-center gap-2 flex-1 min-w-[160px]">
 <input
 class="${this.getRangeClasses(isBlocked)}"
 type="range"
 min="0"
 max="${this.duration || 0}"
 step="0.1"
 .value=${String(this.currentTime)}
 aria-label="${this.msg.progress}"
 role="slider"
 aria-valuemin="0"
 aria-valuemax="${this.duration || 0}"
 aria-valuenow="${this.currentTime}"
 ?disabled=${isBlocked}
 @input=${this.handleSeekInput}
 />
 <span class="text-xs ml-text-muted whitespace-nowrap">${timeLabel}</span>
 </div>

 <div class="flex items-center gap-2">
 <button
 class="${this.getButtonClasses(isBlocked)}"
 type="button"
 aria-label="${this.isMuted ? this.msg.unmute : this.msg.mute}"
 ?disabled=${isBlocked}
 @click=${this.toggleMute}
 >
 ${this.isMuted ? this.msg.unmute : this.msg.mute}
 </button>
 <input
 class="${this.getRangeClasses(isBlocked)} w-24"
 type="range"
 min="0"
 max="1"
 step="0.01"
 .value=${String(this.volume)}
 aria-label="${this.msg.volume}"
 role="slider"
 aria-valuemin="0"
 aria-valuemax="1"
 aria-valuenow="${this.volume}"
 ?disabled=${isBlocked}
 @input=${this.handleVolumeInput}
 />
 </div>

 ${hasTracks
            ? html `
 <button
 class="${this.getButtonClasses(isBlocked)}"
 type="button"
 aria-label="${this.captionsEnabled ? this.msg.captionsOn : this.msg.captionsOff}"
 ?disabled=${isBlocked}
 @click=${this.toggleCaptions}
 >
 ${this.captionsEnabled ? this.msg.captionsOn : this.msg.captionsOff}
 </button>
 `
            : html `${nothing}`}

 <button
 class="${this.getButtonClasses(isBlocked)}"
 type="button"
 aria-label="${this.msg.fullscreen}"
 ?disabled=${isBlocked}
 @click=${this.enterFullscreen}
 >
 ${this.msg.fullscreen}
 </button>
 </div>
 `;
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    readSources() {
        return this.getSlots('Source')
            .map(el => ({
            src: el.getAttribute('src') || '',
            type: el.getAttribute('type') || '',
        }))
            .filter(item => Boolean(item.src));
    }
    readTracks() {
        return this.getSlots('Track')
            .map(el => ({
            src: el.getAttribute('src') || '',
            kind: el.getAttribute('kind') || 'subtitles',
            lang: el.getAttribute('lang') || '',
            label: el.getAttribute('label') || '',
        }))
            .filter(item => Boolean(item.src));
    }
    hasSources() {
        return this.readSources().length > 0;
    }
    getMediaElement() {
        return this.querySelector('video');
    }
    formatTime(value) {
        if (!value || Number.isNaN(value))
            return '00:00';
        const minutes = Math.floor(value / 60);
        const seconds = Math.floor(value % 60);
        const mm = String(minutes).padStart(2, '0');
        const ss = String(seconds).padStart(2, '0');
        return `${mm}:${ss}`;
    }
    emitError(message) {
        this.dispatchEvent(new CustomEvent('error', {
            bubbles: true,
            composed: true,
            detail: { message },
        }));
    }
    isBlocked() {
        return this.disabled || this.loading;
    }
    getButtonClasses(disabled) {
        return [
            'px-3 py-1.5 rounded-md text-xs font-medium border transition',
            'ml-surface-bg',
            'ml-text',
            'ml-border',
            '',
            !disabled ? 'hover:ml-surface-dim-bg' : 'ml-disabled',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getRangeClasses(disabled) {
        return [
            'h-2 rounded-lg appearance-none cursor-pointer w-full',
            'ml-surface-dim-bg',
            '',
            disabled ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
};
__decorate([
    propertyDataSource({ type: String })
], VideoPlayerMolecule.prototype, "poster", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], VideoPlayerMolecule.prototype, "autoplay", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], VideoPlayerMolecule.prototype, "loop", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], VideoPlayerMolecule.prototype, "muted", void 0);
__decorate([
    propertyDataSource({ type: String })
], VideoPlayerMolecule.prototype, "preload", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], VideoPlayerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], VideoPlayerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], VideoPlayerMolecule.prototype, "isPlaying", void 0);
__decorate([
    state()
], VideoPlayerMolecule.prototype, "currentTime", void 0);
__decorate([
    state()
], VideoPlayerMolecule.prototype, "duration", void 0);
__decorate([
    state()
], VideoPlayerMolecule.prototype, "volume", void 0);
__decorate([
    state()
], VideoPlayerMolecule.prototype, "isMuted", void 0);
__decorate([
    state()
], VideoPlayerMolecule.prototype, "hasEnded", void 0);
__decorate([
    state()
], VideoPlayerMolecule.prototype, "captionsEnabled", void 0);
VideoPlayerMolecule = __decorate([
    customElement('groupplaymedia--ml-video-player')
], VideoPlayerMolecule);
export { VideoPlayerMolecule };
