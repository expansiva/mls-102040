/// <mls fileReference="_102040_/l2/molecules/groupplaymedia/ml-pdf-viewer.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PDF VIEWER MOLECULE
// =============================================================================
// Skill Group: groupPlayMedia
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading document...',
    error: 'Failed to load document',
    noSource: 'No document source provided',
    page: 'Page',
    of: 'of',
    previousPage: 'Previous page',
    nextPage: 'Next page',
    zoomIn: 'Zoom in',
    zoomOut: 'Zoom out',
    fitWidth: 'Fit to width',
    goToPage: 'Go to page',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando documento...',
        error: 'Falha ao carregar documento',
        noSource: 'Nenhuma fonte de documento fornecida',
        page: 'Página',
        of: 'de',
        previousPage: 'Página anterior',
        nextPage: 'Próxima página',
        zoomIn: 'Aumentar zoom',
        zoomOut: 'Diminuir zoom',
        fitWidth: 'Ajustar à largura',
        goToPage: 'Ir para página',
    },
};
let MlPdfViewerMolecule = class MlPdfViewerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupplaymedia--ml-pdf-viewer .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-pdf-viewer .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-pdf-viewer .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-pdf-viewer .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupplaymedia--ml-pdf-viewer .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-pdf-viewer .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-pdf-viewer .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-pdf-viewer .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupplaymedia--ml-pdf-viewer .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-pdf-viewer .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupplaymedia--ml-pdf-viewer .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-pdf-viewer .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-pdf-viewer .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupplaymedia--ml-pdf-viewer .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupplaymedia--ml-pdf-viewer .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupplaymedia--ml-pdf-viewer .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupplaymedia--ml-pdf-viewer .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupplaymedia--ml-pdf-viewer .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Source', 'Track'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.disabled = false;
        this.loading = false;
        this.autoplay = false;
        this.loop = false;
        this.muted = false;
        this.preload = 'metadata';
        this.poster = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.currentPage = 1;
        this.totalPages = 0;
        this.scale = 1;
        this.fitToWidth = false;
        this.hasError = false;
        this.errorMessage = '';
        this.documentSrc = '';
        this.isScaleIncreasing = true;
        // ===========================================================================
        // KEYBOARD HANDLING
        // ===========================================================================
        this.keyboardHandler = (e) => {
            if (this.disabled || this.loading || this.hasError)
                return;
            switch (e.key) {
                case 'ArrowLeft':
                    e.preventDefault();
                    this.goToPreviousPage();
                    break;
                case 'ArrowRight':
                    e.preventDefault();
                    this.goToNextPage();
                    break;
                case 'ArrowUp':
                    e.preventDefault();
                    this.increaseScale();
                    break;
                case 'ArrowDown':
                    e.preventDefault();
                    this.decreaseScale();
                    break;
                case '':
                    e.preventDefault();
                    this.toggleScaleDirection();
                    break;
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.initializeDocument();
        this.setupKeyboardListeners();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.removeKeyboardListeners();
    }
    // ===========================================================================
    // INITIALIZATION
    // ===========================================================================
    initializeDocument() {
        const sources = this.getSlots('Source').map(el => ({
            src: el.getAttribute('src') || '',
            type: el.getAttribute('type') || '',
        }));
        const validSource = sources.find(s => s.src.trim() !== '');
        if (!validSource) {
            this.hasError = true;
            this.errorMessage = this.msg.noSource;
            this.dispatchErrorEvent(this.msg.noSource);
            return;
        }
        this.documentSrc = validSource.src;
        this.totalPages = 10; // Simulated total pages
        this.currentPage = 1;
    }
    setupKeyboardListeners() {
        this.addEventListener('keydown', this.keyboardHandler);
        this.setAttribute('tabindex', '0');
    }
    removeKeyboardListeners() {
        this.removeEventListener('keydown', this.keyboardHandler);
    }
    // ===========================================================================
    // NAVIGATION HANDLERS
    // ===========================================================================
    goToPreviousPage() {
        if (this.disabled || this.loading || this.currentPage <= 1)
            return;
        this.currentPage--;
        this.dispatchTimeUpdateEvent();
    }
    goToNextPage() {
        if (this.disabled || this.loading || this.currentPage >= this.totalPages)
            return;
        this.currentPage++;
        this.dispatchTimeUpdateEvent();
    }
    goToPage(page) {
        if (this.disabled || this.loading)
            return;
        if (page < 1 || page > this.totalPages)
            return;
        this.currentPage = page;
        this.dispatchTimeUpdateEvent();
    }
    handleSliderChange(e) {
        const input = e.target;
        const page = parseInt(input.value, 10);
        this.goToPage(page);
    }
    handlePageInputChange(e) {
        const input = e.target;
        const page = parseInt(input.value, 10);
        if (!isNaN(page)) {
            this.goToPage(page);
        }
    }
    // ===========================================================================
    // SCALE HANDLERS
    // ===========================================================================
    increaseScale() {
        if (this.disabled || this.loading)
            return;
        this.fitToWidth = false;
        this.scale = Math.min(this.scale + 0.25, 3);
        this.dispatchPlayEvent();
    }
    decreaseScale() {
        if (this.disabled || this.loading)
            return;
        this.fitToWidth = false;
        this.scale = Math.max(this.scale - 0.25, 0.5);
        this.dispatchPauseEvent();
    }
    toggleFitToWidth() {
        if (this.disabled || this.loading)
            return;
        this.fitToWidth = !this.fitToWidth;
        if (this.fitToWidth) {
            this.scale = 1;
        }
        this.dispatchEndedEvent();
    }
    toggleScaleDirection() {
        if (this.isScaleIncreasing) {
            this.increaseScale();
        }
        else {
            this.decreaseScale();
        }
        this.isScaleIncreasing = !this.isScaleIncreasing;
    }
    // ===========================================================================
    // EVENT DISPATCHERS
    // ===========================================================================
    dispatchTimeUpdateEvent() {
        this.dispatchEvent(new CustomEvent('timeUpdate', {
            bubbles: true,
            composed: true,
            detail: { currentTime: this.currentPage, duration: this.totalPages }
        }));
    }
    dispatchPlayEvent() {
        this.dispatchEvent(new CustomEvent('play', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    dispatchPauseEvent() {
        this.dispatchEvent(new CustomEvent('pause', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    dispatchEndedEvent() {
        this.dispatchEvent(new CustomEvent('ended', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    dispatchErrorEvent(message) {
        this.dispatchEvent(new CustomEvent('error', {
            bubbles: true,
            composed: true,
            detail: { message }
        }));
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getContainerClasses() {
        return [
            'flex flex-col w-full rounded-lg border overflow-hidden',
            'ml-surface-bg',
            'ml-border',
            this.disabled ? 'opacity-50' : '',
        ].filter(Boolean).join(' ');
    }
    getToolbarClasses() {
        return [
            'flex items-center justify-between gap-2 px-3 py-2 border-b',
            'ml-surface-dim-bg',
            'ml-border',
        ].join(' ');
    }
    getButtonClasses(isDisabled) {
        return [
            'flex items-center justify-center w-8 h-8 rounded-md transition',
            'ml-text-muted',
            'border ml-border',
            isDisabled
                ? 'ml-disabled ml-surface-dim-bg'
                : 'hover:ml-surface-dim-bg cursor-pointer ml-surface-bg',
            '',
        ].filter(Boolean).join(' ');
    }
    getActiveButtonClasses(isActive) {
        return [
            'flex items-center justify-center w-8 h-8 rounded-md transition',
            'border',
            isActive
                ? 'ml-primary-dim-bg ml-primary-text ml-border-focus'
                : 'ml-text-muted ml-border ml-surface-bg',
            this.disabled || this.loading
                ? 'ml-disabled'
                : 'hover:ml-surface-dim-bg cursor-pointer',
            '',
        ].filter(Boolean).join(' ');
    }
    getViewerClasses() {
        return [
            'flex-1 flex items-center justify-center min-h-[400px] overflow-auto',
            'ml-surface-dim-bg',
        ].join(' ');
    }
    getPageInputClasses() {
        return [
            'w-12 text-center text-sm rounded-md border px-1 py-1',
            'ml-surface-bg',
            'ml-text',
            'ml-border',
            '',
            this.disabled || this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getSliderClasses() {
        return [
            'flex-1 h-2 rounded-full appearance-none cursor-pointer',
            'ml-surface-dim-bg',
            this.disabled || this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getLoadingOverlayClasses() {
        return [
            'absolute inset-0 flex items-center justify-center',
            'ml-surface-bg/80',
        ].join(' ');
    }
    getErrorClasses() {
        return [
            'flex flex-col items-center justify-center gap-4 p-8',
            'ml-error-text',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER METHODS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        return html `
 <div class="${cn('px-3 py-2 text-sm font-medium ml-text border-b ml-border', this.getSlotClass('Label'))}">
 ${unsafeHTML(labelContent)}
 </div>
 `;
    }
    renderNavigationControls() {
        const isPrevDisabled = this.disabled || this.loading || this.currentPage <= 1;
        const isNextDisabled = this.disabled || this.loading || this.currentPage >= this.totalPages;
        return html `
 <div class="flex items-center gap-1">
 <button
 type="button"
 class=${this.getButtonClasses(isPrevDisabled)}
 ?disabled=${isPrevDisabled}
 @click=${this.goToPreviousPage}
 aria-label=${this.msg.previousPage}
 >
 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
 </svg>
 </button>
 <button
 type="button"
 class=${this.getButtonClasses(isNextDisabled)}
 ?disabled=${isNextDisabled}
 @click=${this.goToNextPage}
 aria-label=${this.msg.nextPage}
 >
 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
 </svg>
 </button>
 </div>
 `;
    }
    renderPageIndicator() {
        return html `
 <div class="flex items-center gap-2 text-sm ml-text-muted">
 <span>${this.msg.page}</span>
 <input
 type="number"
 class=${this.getPageInputClasses()}
 .value=${String(this.currentPage)}
 min="1"
 max=${this.totalPages}
 ?disabled=${this.disabled || this.loading}
 @change=${this.handlePageInputChange}
 aria-label=${this.msg.goToPage}
 />
 <span>${this.msg.of} ${this.totalPages}</span>
 </div>
 `;
    }
    renderScaleControls() {
        const isScaleDisabled = this.disabled || this.loading;
        return html `
 <div class="flex items-center gap-1">
 <button
 type="button"
 class=${this.getButtonClasses(isScaleDisabled || this.scale <= 0.5)}
 ?disabled=${isScaleDisabled || this.scale <= 0.5}
 @click=${this.decreaseScale}
 aria-label=${this.msg.zoomOut}
 >
 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 12H4"></path>
 </svg>
 </button>
 <span class="text-sm ml-text-muted min-w-[3rem] text-center">
 ${Math.round(this.scale * 100)}%
 </span>
 <button
 type="button"
 class=${this.getButtonClasses(isScaleDisabled || this.scale >= 3)}
 ?disabled=${isScaleDisabled || this.scale >= 3}
 @click=${this.increaseScale}
 aria-label=${this.msg.zoomIn}
 >
 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
 </svg>
 </button>
 <button
 type="button"
 class=${this.getActiveButtonClasses(this.fitToWidth)}
 ?disabled=${isScaleDisabled}
 @click=${this.toggleFitToWidth}
 aria-label=${this.msg.fitWidth}
 >
 <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path>
 </svg>
 </button>
 </div>
 `;
    }
    renderToolbar() {
        return html `
 <div class=${this.getToolbarClasses()}>
 ${this.renderNavigationControls()}
 ${this.renderPageIndicator()}
 ${this.renderScaleControls()}
 </div>
 `;
    }
    renderProgressBar() {
        return html `
 <div class="px-3 py-2 border-t ml-border ml-surface-dim-bg">
 <input
 type="range"
 class=${this.getSliderClasses()}
 min="1"
 max=${this.totalPages}
 .value=${String(this.currentPage)}
 ?disabled=${this.disabled || this.loading}
 @input=${this.handleSliderChange}
 role="slider"
 aria-valuenow=${this.currentPage}
 aria-valuemin="1"
 aria-valuemax=${this.totalPages}
 aria-label="${this.msg.page} ${this.currentPage} ${this.msg.of} ${this.totalPages}"
 />
 </div>
 `;
    }
    renderDocumentViewer() {
        const scaleStyle = this.fitToWidth ? 'width: 100%;' : `transform: scale(${this.scale}); transform-origin: top center;`;
        return html `
 <div class=${this.getViewerClasses()}>
 <div class="relative" style=${scaleStyle}>
 <iframe
 src=${this.documentSrc}
 class="w-full h-[600px] border-0"
 title=${this.hasSlot('Label') ? this.getSlotContent('Label') : 'Document viewer'}
 ></iframe>
 </div>
 </div>
 `;
    }
    renderLoading() {
        return html `
 <div class=${this.getLoadingOverlayClasses()}>
 <div class="flex flex-col items-center gap-3">
 <div class="w-8 h-8 border-2 ml-border-focus border-t-transparent rounded-full animate-spin"></div>
 <span class="text-sm ml-text-muted">${this.msg.loading}</span>
 </div>
 </div>
 `;
    }
    renderError() {
        return html `
 <div class=${this.getErrorClasses()}>
 <svg class="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
 <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path>
 </svg>
 <span class="text-sm font-medium">${this.errorMessage || this.msg.error}</span>
 </div>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelContent = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        return html `
 <div
 class=${cn(this.getContainerClasses(), this.cssClass)}
 role="document"
 aria-label=${labelContent || 'PDF Viewer'}
 >
 ${this.renderLabel()}
 ${this.hasError ? html `` : this.renderToolbar()}
 <div class="relative flex-1">
 ${this.hasError
            ? this.renderError()
            : this.renderDocumentViewer()}
 ${this.loading && !this.hasError ? this.renderLoading() : html ``}
 </div>
 ${this.hasError ? html `` : this.renderProgressBar()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlPdfViewerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPdfViewerMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPdfViewerMolecule.prototype, "autoplay", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPdfViewerMolecule.prototype, "loop", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlPdfViewerMolecule.prototype, "muted", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlPdfViewerMolecule.prototype, "preload", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlPdfViewerMolecule.prototype, "poster", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "currentPage", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "totalPages", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "scale", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "fitToWidth", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "hasError", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "errorMessage", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "documentSrc", void 0);
__decorate([
    state()
], MlPdfViewerMolecule.prototype, "isScaleIncreasing", void 0);
MlPdfViewerMolecule = __decorate([
    customElement('groupplaymedia--ml-pdf-viewer')
], MlPdfViewerMolecule);
export { MlPdfViewerMolecule };
