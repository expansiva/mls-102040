var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupplaymedia/ml-audio-player.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// AUDIO PLAYER MOLECULE
// =============================================================================
// Skill Group: groupPlayMedia
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    play: 'Play',
    pause: 'Pause',
    replay: 'Replay',
    mute: 'Mute',
    unmute: 'Unmute',
    loading: 'Loading audio...',
    error: 'Unable to load audio.',
    currentTime: 'Current time',
    duration: 'Duration',
    volume: 'Volume',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let AudioPlayerMolecule = class AudioPlayerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupplaymedia--ml-audio-player .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-audio-player .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-audio-player .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-audio-player .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupplaymedia--ml-audio-player .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupplaymedia--ml-audio-player .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupplaymedia--ml-audio-player .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
groupplaymedia--ml-audio-player .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupplaymedia--ml-audio-player .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupplaymedia--ml-audio-player .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupplaymedia--ml-audio-player .hover\:ml-surface-dim-bg:hover {
  background: var(--surface-alt-bg, #f5f5f5);
}
`);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Source', 'Track'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.poster = '';
        this.autoplay = false;
        this.loop = false;
        this.muted = false;
        this.preload = 'metadata';
        this.disabled = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.isPlaying = false;
        this.currentTime = 0;
        this.duration = 0;
        this.volume = 1;
        this.isMuted = false;
        this.isBuffering = false;
        this.errorMessage = null;
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    firstUpdated() {
        this.syncInitialState();
    }
    updated() {
        if (this.audioEl) {
            this.audioEl.loop = this.loop;
            this.audioEl.autoplay = this.autoplay;
            this.audioEl.muted = this.muted || this.isMuted;
            this.audioEl.preload = this.preload;
        }
    }
    // ==========================================================================
    // PUBLIC CONTROL METHODS
    // ==========================================================================
    playMedia() {
        if (this.disabled || !this.audioEl)
            return;
        this.audioEl.play().catch((err) => this.handleMediaError(err));
    }
    pauseMedia() {
        if (this.disabled || !this.audioEl)
            return;
        this.audioEl.pause();
    }
    togglePlay() {
        if (this.disabled)
            return;
        if (this.isPlaying) {
            this.pauseMedia();
            return;
        }
        this.playMedia();
    }
    seekTo(time) {
        if (this.disabled || !this.audioEl)
            return;
        const nextTime = Math.max(0, Math.min(time, this.duration || 0));
        this.audioEl.currentTime = nextTime;
    }
    setVolume(level) {
        if (this.disabled || !this.audioEl)
            return;
        const nextVolume = Math.max(0, Math.min(level, 1));
        this.volume = nextVolume;
        this.audioEl.volume = nextVolume;
        if (nextVolume > 0 && this.isMuted) {
            this.isMuted = false;
            this.audioEl.muted = false;
        }
    }
    toggleMute() {
        if (this.disabled || !this.audioEl)
            return;
        this.isMuted = !this.isMuted;
        this.audioEl.muted = this.isMuted;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handlePlay() {
        this.isPlaying = true;
        this.dispatchEvent(new CustomEvent('play', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handlePause() {
        this.isPlaying = false;
        this.dispatchEvent(new CustomEvent('pause', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleEnded() {
        this.isPlaying = false;
        this.dispatchEvent(new CustomEvent('ended', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleTimeUpdate() {
        if (!this.audioEl)
            return;
        this.currentTime = this.audioEl.currentTime || 0;
        this.duration = this.audioEl.duration || 0;
        this.dispatchEvent(new CustomEvent('timeUpdate', {
            bubbles: true,
            composed: true,
            detail: { currentTime: this.currentTime, duration: this.duration },
        }));
    }
    handleLoadedMetadata() {
        if (!this.audioEl)
            return;
        this.duration = this.audioEl.duration || 0;
        this.volume = this.audioEl.volume || 1;
        this.isMuted = this.audioEl.muted || this.muted;
    }
    handleWaiting() {
        this.isBuffering = true;
    }
    handleCanPlay() {
        this.isBuffering = false;
    }
    handleMediaError(err) {
        this.errorMessage = this.msg.error;
        if (err instanceof Error && err.message) {
            this.errorMessage = err.message;
        }
        this.dispatchEvent(new CustomEvent('error', {
            bubbles: true,
            composed: true,
            detail: { message: this.errorMessage || this.msg.error },
        }));
    }
    handleSeekInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.seekTo(parseFloat(input.value));
    }
    handleVolumeInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.setVolume(parseFloat(input.value));
    }
    handleKeyboard(e) {
        if (this.disabled || this.errorMessage)
            return;
        if (e.code === 'Space') {
            e.preventDefault();
            this.togglePlay();
            return;
        }
        if (e.code === 'ArrowLeft') {
            e.preventDefault();
            this.seekTo(this.currentTime - 5);
            return;
        }
        if (e.code === 'ArrowRight') {
            e.preventDefault();
            this.seekTo(this.currentTime + 5);
            return;
        }
        if (e.code === 'ArrowUp') {
            e.preventDefault();
            this.setVolume(this.volume + 0.05);
            return;
        }
        if (e.code === 'ArrowDown') {
            e.preventDefault();
            this.setVolume(this.volume - 0.05);
        }
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    syncInitialState() {
        this.isMuted = this.muted;
        if (this.audioEl) {
            this.audioEl.loop = this.loop;
            this.audioEl.autoplay = this.autoplay;
            this.audioEl.preload = this.preload;
            this.audioEl.muted = this.muted;
        }
    }
    getLabelText() {
        const labelContent = this.getSlotContent('Label');
        if (!labelContent)
            return 'Audio player';
        const temp = document.createElement('div');
        temp.innerHTML = labelContent;
        return temp.textContent?.trim() || 'Audio player';
    }
    formatTime(totalSeconds) {
        if (!totalSeconds || Number.isNaN(totalSeconds))
            return '0:00';
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = Math.floor(totalSeconds % 60);
        return `${minutes}:${seconds.toString().padStart(2, '0')}`;
    }
    getButtonClasses() {
        return [
            'inline-flex items-center justify-center rounded-md px-3 py-2 text-sm font-medium border transition',
            'ml-surface-bg',
            'ml-border',
            'ml-text',
            'hover:ml-surface-dim-bg',
            '',
            (this.disabled || this.errorMessage) ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getRangeClasses() {
        return [
            'w-full h-2 rounded-lg appearance-none cursor-pointer',
            'ml-surface-dim-bg',
            '',
            (this.disabled || this.errorMessage) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const sources = this.getSlots('Source').map((el) => ({
            src: el.getAttribute('src') || '',
            type: el.getAttribute('type') || '',
        }));
        const tracks = this.getSlots('Track').map((el) => ({
            src: el.getAttribute('src') || '',
            kind: el.getAttribute('kind') || 'subtitles',
            lang: el.getAttribute('lang') || '',
            label: el.getAttribute('label') || '',
        }));
        const labelContent = this.getSlotContent('Label');
        const isLoading = this.loading || this.isBuffering;
        return html `
<div
class=${cn([
            'w-full rounded-xl border p-4 space-y-3',
            'ml-surface-bg',
            'ml-border',
            (this.disabled || this.errorMessage) ? 'opacity-70' : '',
        ].filter(Boolean).join(' '), this.cssClass)}
role="group"
aria-label=${this.getLabelText()}
@keydown=${this.handleKeyboard}
>
${labelContent
            ? html `<div class="${cn('text-sm font-medium ml-text', this.getSlotClass('Label'))}">${unsafeHTML(labelContent)}</div>`
            : html ``}

<div class="relative">
${isLoading
            ? html `<div class="absolute inset-0 flex items-center justify-center rounded-lg ml-surface-bg/80 ml-text-muted text-sm">${this.msg.loading}</div>`
            : html ``}

${this.errorMessage
            ? html `<div class="rounded-lg border ml-border-error ml-error-dim-bg px-3 py-2 text-sm ml-error-text">${this.errorMessage}</div>`
            : html `<audio
@play=${this.handlePlay}
@pause=${this.handlePause}
@ended=${this.handleEnded}
@timeupdate=${this.handleTimeUpdate}
@loadedmetadata=${this.handleLoadedMetadata}
@waiting=${this.handleWaiting}
@canplay=${this.handleCanPlay}
@error=${() => this.handleMediaError()}
?muted=${this.muted || this.isMuted}
?autoplay=${this.autoplay}
?loop=${this.loop}
preload=${this.preload}
>
${sources.map((source) => html `<source src=${source.src} type=${source.type} />`)}
${tracks.map((track) => html `<track src=${track.src} kind=${track.kind} srclang=${track.lang} label=${track.label} />`)}
</audio>`}
</div>

${this.errorMessage
            ? html ``
            : html `
<div class="flex flex-wrap items-center gap-3">
<button
class=${this.getButtonClasses()}
@click=${this.togglePlay}
?disabled=${this.disabled}
aria-label=${this.isPlaying ? this.msg.pause : this.msg.play}
>
${this.isPlaying ? this.msg.pause : this.msg.play}
</button>

<button
class=${this.getButtonClasses()}
@click=${this.toggleMute}
?disabled=${this.disabled}
aria-label=${this.isMuted ? this.msg.unmute : this.msg.mute}
>
${this.isMuted ? this.msg.unmute : this.msg.mute}
</button>

<div class="flex-1 min-w-[180px]">
<input
class=${this.getRangeClasses()}
type="range"
min="0"
max=${this.duration || 0}
step="0.1"
.value=${String(this.currentTime)}
@input=${this.handleSeekInput}
role="slider"
aria-label=${this.msg.currentTime}
aria-valuemin="0"
aria-valuemax=${String(this.duration || 0)}
aria-valuenow=${String(this.currentTime)}
?disabled=${this.disabled}

@change=${(e) => e.stopPropagation()}
/>
</div>

<div class="text-xs ml-text-muted min-w-[90px] text-right">
${this.formatTime(this.currentTime)} / ${this.formatTime(this.duration)}
</div>
</div>

<div class="flex items-center gap-3">
<span class="text-xs ml-text-muted">${this.msg.volume}</span>
<input
class=${this.getRangeClasses()}
type="range"
min="0"
max="1"
step="0.01"
.value=${String(this.volume)}
@input=${this.handleVolumeInput}
role="slider"
aria-label=${this.msg.volume}
aria-valuemin="0"
aria-valuemax="1"
aria-valuenow=${String(this.volume)}
?disabled=${this.disabled}

@change=${(e) => e.stopPropagation()}
/>
</div>
`}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], AudioPlayerMolecule.prototype, "poster", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AudioPlayerMolecule.prototype, "autoplay", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AudioPlayerMolecule.prototype, "loop", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AudioPlayerMolecule.prototype, "muted", void 0);
__decorate([
    propertyDataSource({ type: String })
], AudioPlayerMolecule.prototype, "preload", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AudioPlayerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AudioPlayerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], AudioPlayerMolecule.prototype, "isPlaying", void 0);
__decorate([
    state()
], AudioPlayerMolecule.prototype, "currentTime", void 0);
__decorate([
    state()
], AudioPlayerMolecule.prototype, "duration", void 0);
__decorate([
    state()
], AudioPlayerMolecule.prototype, "volume", void 0);
__decorate([
    state()
], AudioPlayerMolecule.prototype, "isMuted", void 0);
__decorate([
    state()
], AudioPlayerMolecule.prototype, "isBuffering", void 0);
__decorate([
    state()
], AudioPlayerMolecule.prototype, "errorMessage", void 0);
__decorate([
    query('audio')
], AudioPlayerMolecule.prototype, "audioEl", void 0);
AudioPlayerMolecule = __decorate([
    customElement('groupplaymedia--ml-audio-player')
], AudioPlayerMolecule);
export { AudioPlayerMolecule };
