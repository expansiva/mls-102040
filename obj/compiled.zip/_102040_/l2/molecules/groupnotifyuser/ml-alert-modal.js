var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupnotifyuser/ml-alert-modal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML-ALERT-MODAL MOLECULE
// =============================================================================
// Skill Group: groupNotifyUser
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    dismiss: 'Dismiss notification',
    defaultMessage: 'Notification',
};
const messages = {
    en: message_en,
    pt: {
        dismiss: 'Dispensar notificação',
        defaultMessage: 'Notificação',
    },
};
/// **collab_i18n_end**
let MlAlertModalMolecule = class MlAlertModalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-alert-modal .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-alert-modal .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-alert-modal .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-alert-modal .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupnotifyuser--ml-alert-modal .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-alert-modal .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-alert-modal .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-alert-modal .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupnotifyuser--ml-alert-modal .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-alert-modal .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupnotifyuser--ml-alert-modal .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-alert-modal .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-alert-modal .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupnotifyuser--ml-alert-modal .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupnotifyuser--ml-alert-modal .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupnotifyuser--ml-alert-modal .ml-border-info {
  border-color: var(--ml-info-border, #bae6fd);
}
groupnotifyuser--ml-alert-modal .ml-border-success {
  border-color: var(--ml-success-border, #a7f3d0);
}
groupnotifyuser--ml-alert-modal .ml-border-warning {
  border-color: var(--ml-warning-border, #fde68a);
}
groupnotifyuser--ml-alert-modal .ml-success-text {
  color: var(--ml-success, #16a34a);
}
groupnotifyuser--ml-alert-modal .ml-success-dim-bg {
  background: var(--ml-success-dim, #ecfdf5);
}
groupnotifyuser--ml-alert-modal .ml-warning-text {
  color: var(--ml-warning, #d97706);
}
groupnotifyuser--ml-alert-modal .ml-warning-dim-bg {
  background: var(--ml-warning-dim, #fffbeb);
}
groupnotifyuser--ml-alert-modal .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-alert-modal .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupnotifyuser--ml-alert-modal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnotifyuser--ml-alert-modal .hover\:ml-text:hover {
  color: var(--ml-on-surface, #1c1b1f);
}
`);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Title', 'Message', 'Action', 'Icon'];
        // O slot Action carrega CONTROLES do consumidor (cancelar/confirmar), não conteúdo
        // decorativo — então precisa de nó vivo, com handler e componente preservados. Title,
        // Message e Icon continuam vindo pelo caminho de snapshot: são conteúdo.
        this.usesLiveSlots = true;
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.type = 'info';
        this.visible = false;
        this.dismissible = true;
        this.duration = 0;
        this.position = '';
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.autoDismissId = null;
    }
    // =========================================================================
    // STATE CHANGE HANDLER
    // =========================================================================
    handleIcaStateChange(key) {
        const visibleAttr = this.getAttribute('visible');
        const durationAttr = this.getAttribute('duration');
        if (visibleAttr === `{{${key}}}` || durationAttr === `{{${key}}}`) {
            this.manageAutoDismiss();
        }
        this.requestUpdate();
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    updated(changedProps) {
        if (changedProps.has('visible') || changedProps.has('duration')) {
            this.manageAutoDismiss();
        }
    }
    // =========================================================================
    // AUTO DISMISS
    // =========================================================================
    manageAutoDismiss() {
        this.clearAutoDismiss();
        if (!this.visible || this.duration <= 0)
            return;
        this.autoDismissId = window.setTimeout(() => {
            this.handleDismiss();
        }, this.duration);
    }
    clearAutoDismiss() {
        if (this.autoDismissId !== null) {
            window.clearTimeout(this.autoDismissId);
            this.autoDismissId = null;
        }
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleDismiss() {
        if (!this.visible)
            return;
        this.visible = false;
        this.clearAutoDismiss();
        this.dispatchEvent(new CustomEvent('dismiss', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleActionClick() {
        if (!this.visible)
            return;
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    getNormalizedType() {
        const raw = (this.type || 'info').toLowerCase();
        if (raw === 'danger')
            return 'error';
        if (raw === 'success' || raw === 'warning' || raw === 'error')
            return raw;
        return 'info';
    }
    getRole() {
        const t = this.getNormalizedType();
        return t === 'error' || t === 'warning' ? 'alert' : 'status';
    }
    getAriaLive() {
        const t = this.getNormalizedType();
        return t === 'error' ? 'assertive' : 'polite';
    }
    getPositionClasses() {
        const pos = (this.position || '').toLowerCase();
        const base = 'items-center justify-center';
        if (!pos || pos === 'center')
            return base;
        if (pos === 'top')
            return 'items-start justify-center';
        if (pos === 'bottom')
            return 'items-end justify-center';
        if (pos === 'top-right')
            return 'items-start justify-end';
        if (pos === 'bottom-right')
            return 'items-end justify-end';
        if (pos === 'top-left')
            return 'items-start justify-start';
        if (pos === 'bottom-left')
            return 'items-end justify-start';
        return base;
    }
    getContainerClasses() {
        const type = this.getNormalizedType();
        const typeBorder = {
            info: 'ml-border-info',
            success: 'ml-border-success',
            warning: 'ml-border-warning',
            error: 'ml-border-error',
        }[type];
        return [
            'w-full max-w-xl rounded-xl border shadow-lg',
            'ml-surface-bg',
            'ml-text',
            'p-6',
            typeBorder,
        ].join(' ');
    }
    getIconWrapperClasses() {
        const type = this.getNormalizedType();
        const styles = {
            info: 'ml-primary-text ml-primary-dim-bg',
            success: 'ml-success-text ml-success-dim-bg',
            warning: 'ml-warning-text ml-warning-dim-bg',
            error: 'ml-error-text ml-error-dim-bg',
        }[type];
        return [
            'h-12 w-12 rounded-full flex items-center justify-center',
            styles,
        ].join(' ');
    }
    renderDefaultIcon() {
        const type = this.getNormalizedType();
        if (type === 'success') {
            return html `
 <svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path>`}
 </svg>
 `;
        }
        if (type === 'warning') {
            return html `
 <svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01"></path>`}
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"></path>`}
 </svg>
 `;
        }
        if (type === 'error') {
            return html `
 <svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 9v4m0 4h.01"></path>`}
 ${svg `<circle cx="12" cy="12" r="9"></circle>`}
 </svg>
 `;
        }
        return html `
 <svg viewBox="0 0 24 24" class="h-6 w-6" fill="none" stroke="currentColor" stroke-width="2">
 ${svg `<circle cx="12" cy="12" r="9"></circle>`}
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M12 8h.01M11 12h2v4h-2z"></path>`}
 </svg>
 `;
    }
    renderIcon() {
        if (this.hasSlot('Icon')) {
            return html `<div class="${cn(this.getIconWrapperClasses(), this.getSlotClass('Icon'))}">${unsafeHTML(this.getSlotContent('Icon'))}</div>`;
        }
        return html `<div class="${this.getIconWrapperClasses()}">${this.renderDefaultIcon()}</div>`;
    }
    renderTitle() {
        if (!this.hasSlot('Title'))
            return html ``;
        return html `
 <h3 class="${cn('text-lg font-semibold ml-text', this.getSlotClass('Title'))}">
 ${unsafeHTML(this.getSlotContent('Title'))}
 </h3>
 `;
    }
    renderMessage() {
        const message = this.getSlotContent('Message') || this.msg.defaultMessage;
        return html `
 <div class="${cn('text-sm ml-text', this.getSlotClass('Message'))}">
 ${unsafeHTML(message)}
 </div>
 `;
    }
    renderActions() {
        if (!this.hasSlot('Action'))
            return html ``;
        // Slot VIVO: o conteúdo é movido para a âncora, não serializado. É o que permite o
        // consumidor pôr botões de verdade aqui — com os handlers dele e como componentes —
        // que é o caso de uso de um modal de confirmação: cancelar e confirmar são ações do
        // consumidor, e a molécula não tem como saber o que cada uma faz.
        //
        // O `action` do wrapper continua sendo emitido, para quem só quer saber que houve
        // clique na área de ações; mas ele não é mais a única saída.
        return html `
 <div class="${cn('mt-6 flex items-center justify-end gap-3', this.getSlotClass('Action'))}" @click=${this.handleActionClick}>
 ${this.renderLiveSlot('Action')}
 </div>
 `;
    }
    renderDismiss() {
        if (!this.dismissible)
            return html ``;
        return html `
 <button
 type="button"
 class="ml-text-muted hover:ml-text"
 aria-label="${this.msg.dismiss}"
 @click=${this.handleDismiss}
 >
 <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="2">
 ${svg `<path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12"></path>`}
 </svg>
 </button>
 `;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.visible)
            return html ``;
        return html `
 <div class="${cn(`fixed inset-0 z-50 flex ${this.getPositionClasses()} p-6`, this.cssClass)}">
 <div class="absolute inset-0 ml-surface-bg/40" aria-hidden="true"></div>
 <div
 class="relative z-10 w-full ${this.getContainerClasses()}"
 role="${this.getRole()}"
 aria-live="${this.getAriaLive()}"
 aria-modal="true"
 >
 <div class="flex items-start justify-between gap-4">
 <div class="flex items-start gap-4">
 ${this.renderIcon()}
 <div class="space-y-2">
 ${this.renderTitle()}
 ${this.renderMessage()}
 </div>
 </div>
 ${this.renderDismiss()}
 </div>
 ${this.renderActions()}
 </div>
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlAlertModalMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAlertModalMolecule.prototype, "visible", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAlertModalMolecule.prototype, "dismissible", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlAlertModalMolecule.prototype, "duration", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAlertModalMolecule.prototype, "position", void 0);
__decorate([
    state()
], MlAlertModalMolecule.prototype, "autoDismissId", void 0);
MlAlertModalMolecule = __decorate([
    customElement('groupnotifyuser--ml-alert-modal')
], MlAlertModalMolecule);
export { MlAlertModalMolecule };
