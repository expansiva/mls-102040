/// <mls fileReference="_102040_/l2/molecules/groupnotifyuser/ml-toast-notification.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TOAST NOTIFICATION MOLECULE
// =============================================================================
// Skill Group: groupNotifyUser
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    dismissLabel: 'Dismiss notification',
};
const messages = {
    en: message_en,
    pt: {
        dismissLabel: 'Dispensar notificação',
    },
};
let ToastNotificationMolecule = class ToastNotificationMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnotifyuser--ml-toast-notification .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-toast-notification .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-toast-notification .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-toast-notification .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupnotifyuser--ml-toast-notification .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-toast-notification .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-toast-notification .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnotifyuser--ml-toast-notification .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupnotifyuser--ml-toast-notification .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-toast-notification .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupnotifyuser--ml-toast-notification .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-toast-notification .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-toast-notification .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupnotifyuser--ml-toast-notification .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupnotifyuser--ml-toast-notification .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupnotifyuser--ml-toast-notification .ml-border-info {
  border-color: var(--ml-info-border, #bae6fd);
}
groupnotifyuser--ml-toast-notification .ml-border-success {
  border-color: var(--ml-success-border, #a7f3d0);
}
groupnotifyuser--ml-toast-notification .ml-border-warning {
  border-color: var(--ml-warning-border, #fde68a);
}
groupnotifyuser--ml-toast-notification .ml-success-text {
  color: var(--ml-success, #16a34a);
}
groupnotifyuser--ml-toast-notification .ml-success-dim-bg {
  background: var(--ml-success-dim, #ecfdf5);
}
groupnotifyuser--ml-toast-notification .ml-warning-text {
  color: var(--ml-warning, #d97706);
}
groupnotifyuser--ml-toast-notification .ml-warning-dim-bg {
  background: var(--ml-warning-dim, #fffbeb);
}
groupnotifyuser--ml-toast-notification .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupnotifyuser--ml-toast-notification .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupnotifyuser--ml-toast-notification .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnotifyuser--ml-toast-notification .hover\:ml-text-muted:hover {
  color: var(--ml-on-surface-muted, #49454f);
}
groupnotifyuser--ml-toast-notification .hover\:ml-surface-dim-bg:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Title', 'Message', 'Action', 'Icon'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.type = 'info';
        this.visible = false;
        this.dismissible = true;
        this.duration = 0;
        this.position = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isAnimatingOut = false;
        this.autoCloseTimer = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        this.clearAutoCloseTimer();
    }
    updated(changedProperties) {
        if (changedProperties.has('visible')) {
            if (this.visible) {
                this.isAnimatingOut = false;
                this.startAutoCloseTimer();
            }
            else {
                this.clearAutoCloseTimer();
            }
        }
        if (changedProperties.has('duration') && this.visible) {
            this.clearAutoCloseTimer();
            this.startAutoCloseTimer();
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const visibleAttr = this.getAttribute('visible');
        if (visibleAttr === `{{${key}}}`) {
            if (value === true) {
                this.isAnimatingOut = false;
                this.startAutoCloseTimer();
            }
            else {
                this.clearAutoCloseTimer();
            }
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // TIMER MANAGEMENT
    // ===========================================================================
    startAutoCloseTimer() {
        this.clearAutoCloseTimer();
        if (this.duration > 0) {
            this.autoCloseTimer = window.setTimeout(() => {
                this.handleDismiss();
            }, this.duration);
        }
    }
    clearAutoCloseTimer() {
        if (this.autoCloseTimer !== null) {
            window.clearTimeout(this.autoCloseTimer);
            this.autoCloseTimer = null;
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleDismiss() {
        this.clearAutoCloseTimer();
        this.isAnimatingOut = true;
        setTimeout(() => {
            this.visible = false;
            this.isAnimatingOut = false;
            this.dispatchEvent(new CustomEvent('dismiss', {
                bubbles: true,
                composed: true,
                detail: {}
            }));
        }, 300);
    }
    handleActionClick(e) {
        e.stopPropagation();
        this.dispatchEvent(new CustomEvent('action', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    // ===========================================================================
    // STYLING HELPERS
    // ===========================================================================
    getContainerClasses() {
        const baseClasses = [
            'flex items-start gap-3 p-4 rounded-lg shadow-lg border max-w-sm w-full',
            'transition-all duration-300 ease-in-out',
        ];
        const typeClasses = this.getTypeClasses();
        const positionClasses = this.getPositionClasses();
        const animationClasses = this.getAnimationClasses();
        return [...baseClasses, typeClasses, positionClasses, animationClasses].filter(Boolean).join(' ');
    }
    getTypeClasses() {
        switch (this.type) {
            case 'success':
                return 'ml-success-dim-bg ml-border-success';
            case 'warning':
                return 'ml-warning-dim-bg ml-border-warning';
            case 'error':
                return 'ml-error-dim-bg ml-border-error';
            case 'info':
            default:
                return 'ml-primary-dim-bg ml-border-info';
        }
    }
    getPositionClasses() {
        if (!this.position)
            return '';
        const positionMap = {
            'top': 'fixed top-4 left-1/2 -translate-x-1/2 z-50',
            'bottom': 'fixed bottom-4 left-1/2 -translate-x-1/2 z-50',
            'top-right': 'fixed top-4 right-4 z-50',
            'bottom-right': 'fixed bottom-4 right-4 z-50',
            'top-left': 'fixed top-4 left-4 z-50',
            'bottom-left': 'fixed bottom-4 left-4 z-50',
        };
        return positionMap[this.position] || '';
    }
    getAnimationClasses() {
        if (this.isAnimatingOut) {
            return this.getExitAnimationClass();
        }
        return this.getEntryAnimationClass();
    }
    getEntryAnimationClass() {
        if (!this.position)
            return 'opacity-100 translate-y-0';
        switch (this.position) {
            case 'top':
            case 'top-left':
            case 'top-right':
                return 'animate-slide-in-top';
            case 'bottom':
            case 'bottom-left':
            case 'bottom-right':
                return 'animate-slide-in-bottom';
            default:
                return 'opacity-100';
        }
    }
    getExitAnimationClass() {
        if (!this.position)
            return 'opacity-0 translate-y-2';
        switch (this.position) {
            case 'top':
            case 'top-left':
            case 'top-right':
                return 'opacity-0 -translate-y-4';
            case 'bottom':
            case 'bottom-left':
            case 'bottom-right':
                return 'opacity-0 translate-y-4';
            default:
                return 'opacity-0';
        }
    }
    getIconColorClasses() {
        switch (this.type) {
            case 'success':
                return 'ml-success-text';
            case 'warning':
                return 'ml-warning-text';
            case 'error':
                return 'ml-error-text';
            case 'info':
            default:
                return 'ml-primary-text';
        }
    }
    getTitleClasses() {
        return 'text-sm font-semibold ml-text';
    }
    getMessageClasses() {
        return 'text-sm ml-text';
    }
    getActionClasses() {
        return [
            'mt-2 text-sm font-medium cursor-pointer transition-colors',
            this.getActionColorClasses(),
        ].join(' ');
    }
    getActionColorClasses() {
        switch (this.type) {
            case 'success':
                return 'ml-success-text';
            case 'warning':
                return 'ml-warning-text';
            case 'error':
                return 'ml-error-text';
            case 'info':
            default:
                return 'ml-primary-text';
        }
    }
    getCloseButtonClasses() {
        return [
            'flex-shrink-0 p-1 rounded-md transition-colors',
            'ml-text-faint',
            'hover:ml-text-muted',
            'hover:ml-surface-dim-bg',
            '',
        ].join(' ');
    }
    // ===========================================================================
    // ACCESSIBILITY HELPERS
    // ===========================================================================
    getAriaRole() {
        return this.type === 'error' || this.type === 'warning' ? 'alert' : 'status';
    }
    getAriaLive() {
        return this.type === 'error' ? 'assertive' : 'polite';
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderIcon() {
        if (this.hasSlot('Icon')) {
            return html `
 <div class="${cn(`flex-shrink-0 ${this.getIconColorClasses()}`, this.getSlotClass('Icon'))}">
 ${unsafeHTML(this.getSlotContent('Icon'))}
 </div>
 `;
        }
        return html `
 <div class="flex-shrink-0 ${this.getIconColorClasses()}">
 ${this.renderDefaultIcon()}
 </div>
 `;
    }
    renderDefaultIcon() {
        const iconClasses = 'w-5 h-5';
        switch (this.type) {
            case 'success':
                return html `
 <svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">
 ${svg `
 <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clip-rule="evenodd" />
 `}
 </svg>
 `;
            case 'warning':
                return html `
 <svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">
 ${svg `
 <path fill-rule="evenodd" d="M8.485 2.495c.673-1.167 2.357-1.167 3.03 0l6.28 10.875c.673 1.167-.17 2.625-1.516 2.625H3.72c-1.347 0-2.189-1.458-1.515-2.625L8.485 2.495zM10 5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 5zm0 9a1 1 0 100-2 1 1 0 000 2z" clip-rule="evenodd" />
 `}
 </svg>
 `;
            case 'error':
                return html `
 <svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">
 ${svg `
 <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.28 7.22a.75.75 0 00-1.06 1.06L8.94 10l-1.72 1.72a.75.75 0 101.06 1.06L10 11.06l1.72 1.72a.75.75 0 101.06-1.06L11.06 10l1.72-1.72a.75.75 0 00-1.06-1.06L10 8.94 8.28 7.22z" clip-rule="evenodd" />
 `}
 </svg>
 `;
            case 'info':
            default:
                return html `
 <svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor">
 ${svg `
 <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a.75.75 0 000 1.5h.253a.25.25 0 01.244.304l-.459 2.066A1.75 1.75 0 0010.747 15H11a.75.75 0 000-1.5h-.253a.25.25 0 01-.244-.304l.459-2.066A1.75 1.75 0 009.253 9H9z" clip-rule="evenodd" />
 `}
 </svg>
 `;
        }
    }
    renderTitle() {
        if (!this.hasSlot('Title')) {
            return html ``;
        }
        return html `
 <div class="${cn(this.getTitleClasses(), this.getSlotClass('Title'))}">
 ${unsafeHTML(this.getSlotContent('Title'))}
 </div>
 `;
    }
    renderMessage() {
        return html `
 <div class="${cn(this.getMessageClasses(), this.getSlotClass('Message'))}">
 ${unsafeHTML(this.getSlotContent('Message'))}
 </div>
 `;
    }
    renderAction() {
        if (!this.hasSlot('Action')) {
            return html ``;
        }
        return html `
 <div
 class="${cn(this.getActionClasses(), this.getSlotClass('Action'))}"
 @click=${this.handleActionClick}
 >
 ${unsafeHTML(this.getSlotContent('Action'))}
 </div>
 `;
    }
    renderCloseButton() {
        if (!this.dismissible) {
            return html ``;
        }
        return html `
 <button
 type="button"
 class="${this.getCloseButtonClasses()}"
 aria-label="${this.msg.dismissLabel}"
 @click=${this.handleDismiss}
 >
 <svg class="w-4 h-4" viewBox="0 0 20 20" fill="currentColor">
 ${svg `
 <path d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z" />
 `}
 </svg>
 </button>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.visible && !this.isAnimatingOut) {
            return html ``;
        }
        return html `
 <div
 class="${cn(this.getContainerClasses(), this.cssClass)}"
 role="${this.getAriaRole()}"
 aria-live="${this.getAriaLive()}"
 >
 ${this.renderIcon()}
 
 <div class="flex-1 min-w-0">
 ${this.renderTitle()}
 ${this.renderMessage()}
 ${this.renderAction()}
 </div>
 
 ${this.renderCloseButton()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], ToastNotificationMolecule.prototype, "type", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ToastNotificationMolecule.prototype, "visible", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ToastNotificationMolecule.prototype, "dismissible", void 0);
__decorate([
    propertyDataSource({ type: Number })
], ToastNotificationMolecule.prototype, "duration", void 0);
__decorate([
    propertyDataSource({ type: String })
], ToastNotificationMolecule.prototype, "position", void 0);
__decorate([
    state()
], ToastNotificationMolecule.prototype, "isAnimatingOut", void 0);
ToastNotificationMolecule = __decorate([
    customElement('groupnotifyuser--ml-toast-notification')
], ToastNotificationMolecule);
export { ToastNotificationMolecule };
