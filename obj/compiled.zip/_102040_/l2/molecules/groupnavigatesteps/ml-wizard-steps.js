var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// WIZARD STEPS MOLECULE
// =============================================================================
// Skill Group: groupNavigateSteps
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    labelFallback: 'Steps',
    loading: 'Loading steps...',
    completed: 'completed',
};
const messages = {
    en: message_en,
    pt: {
        labelFallback: 'Etapas',
        loading: 'Carregando etapas...',
        completed: 'concluída',
    },
};
let MlWizardStepsMolecule = class MlWizardStepsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Step'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = 0;
        this.linear = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedIndex = -1;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleStepClick(step) {
        if (!this.canNavigateTo(step.index))
            return;
        this.focusedIndex = step.index;
        this.value = step.index;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: step.index, title: step.title }
        }));
    }
    handleContainerKeyDown(event) {
        if (this.disabled || this.loading)
            return;
        const steps = this.parseSteps();
        const currentFocus = this.getInitialFocusIndex(steps);
        if (steps.length === 0)
            return;
        const key = event.key;
        if (key === 'ArrowRight' || key === 'ArrowLeft') {
            event.preventDefault();
            const direction = key === 'ArrowRight' ? 1 : -1;
            const nextIndex = this.findNextFocusableIndex(steps, currentFocus, direction);
            if (nextIndex !== currentFocus) {
                this.focusedIndex = nextIndex;
            }
            return;
        }
        if (key === 'Enter' || key === ' ') {
            event.preventDefault();
            const step = steps[currentFocus];
            if (step) {
                this.handleStepClick(step);
            }
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    parseSteps() {
        const stepElements = this.getSlots('Step');
        return stepElements.map((el, index) => {
            const title = el.getAttribute('title') || '';
            const description = el.getAttribute('description') || '';
            const completed = el.hasAttribute('completed');
            const disabled = el.hasAttribute('disabled');
            return { index, title, description, completed, disabled };
        });
    }
    canNavigateTo(targetIndex) {
        if (this.disabled || this.loading)
            return false;
        const steps = this.parseSteps();
        const target = steps[targetIndex];
        const current = steps[this.value];
        if (!target || target.disabled)
            return false;
        if (!this.linear)
            return true;
        if (!current)
            return false;
        const currentCompleted = current.completed;
        if (targetIndex <= this.value) {
            return target.completed || targetIndex === this.value;
        }
        if (targetIndex === this.value + 1) {
            return currentCompleted;
        }
        return currentCompleted && target.completed;
    }
    getInitialFocusIndex(steps) {
        const baseIndex = this.focusedIndex >= 0 ? this.focusedIndex : this.value;
        const clampedIndex = Math.max(0, Math.min(baseIndex, steps.length - 1));
        const target = steps[clampedIndex];
        if (target && !target.disabled)
            return clampedIndex;
        return this.findNextFocusableIndex(steps, clampedIndex, 1);
    }
    findNextFocusableIndex(steps, start, direction) {
        if (steps.length === 0)
            return 0;
        let index = start;
        for (let i = 0; i < steps.length; i += 1) {
            index = (index + direction + steps.length) % steps.length;
            const step = steps[index];
            if (step && !step.disabled)
                return index;
        }
        return start;
    }
    getStepClasses(step, isActive) {
        const isClickable = this.canNavigateTo(step.index);
        const isCompleted = step.completed;
        return [
            'flex-1 min-w-0',
            'rounded-lg border px-3 py-3 text-left transition',
            'bg-white dark:bg-slate-800',
            'is-active',
            isActive
                ? 'border-sky-500 dark:border-sky-400 bg-sky-50 dark:bg-sky-900/40'
                : 'border-slate-200 dark:border-slate-700',
            !isActive ? 'hover:bg-slate-50 dark:hover:bg-slate-700' : '',
            step.disabled || !isClickable ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
            isCompleted && !isActive
                ? 'text-slate-900 dark:text-slate-100'
                : 'text-slate-900 dark:text-slate-100',
        ].filter(Boolean).join(' ');
    }
    getLabelText() {
        const raw = this.getSlotContent('Label');
        if (!raw)
            return this.msg.labelFallback;
        return raw.replace(/<[^>]*>/g, '').trim() || this.msg.labelFallback;
    }
    renderLoading() {
        return html `
<div class="flex items-center gap-2 rounded-lg border border-slate-200 bg-white px-4 py-3 text-sm text-slate-600 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300">
<span class="inline-flex h-4 w-4 items-center justify-center">
<svg class="h-4 w-4 animate-spin" viewBox="0 0 24 24" aria-hidden="true">
${svg `<circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="3" opacity="0.3"></circle>`}
${svg `<path d="M22 12a10 10 0 0 1-10 10" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>`}
</svg>
</span>
<span>${this.msg.loading}</span>
</div>
`;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div class="mb-3 text-sm font-medium text-slate-700 dark:text-slate-300">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderStep(step, isActive, tabIndex) {
        const isClickable = this.canNavigateTo(step.index);
        const ariaLabel = step.completed ? `${step.title} ${this.msg.completed}` : step.title;
        return html `
<button
class="${this.getStepClasses(step, isActive)}"
role="tab"
aria-selected="${isActive ? 'true' : 'false'}"
aria-disabled="${step.disabled ? 'true' : 'false'}"
aria-label="${ariaLabel}"
?disabled=${this.disabled || this.loading || step.disabled || !isClickable}
tabindex="${tabIndex}"
@click=${() => this.handleStepClick(step)}
>
<div class="flex items-center gap-2">
<span class="flex h-6 w-6 items-center justify-center rounded-full border text-xs font-semibold ${isActive
            ? 'border-sky-500 text-sky-700 dark:border-sky-400 dark:text-sky-300'
            : step.completed
                ? 'border-emerald-500 text-emerald-600 dark:border-emerald-400 dark:text-emerald-300'
                : 'border-slate-300 text-slate-500 dark:border-slate-600 dark:text-slate-400'}">
${step.completed
            ? html `<span aria-hidden="true">✓</span>`
            : html `${step.index + 1}`}
</span>
<div class="min-w-0">
<div class="truncate text-sm font-semibold text-slate-900 dark:text-slate-100">${step.title}</div>
${step.description
            ? html `<div class="truncate text-xs text-slate-500 dark:text-slate-400">${step.description}</div>`
            : html ``}
</div>
</div>
</button>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `${this.renderLoading()}`;
        }
        const steps = this.parseSteps();
        const focusIndex = this.getInitialFocusIndex(steps);
        const ariaLabel = this.getLabelText();
        return html `
<div class="w-full">
${this.renderLabel()}
<div
class="flex items-start gap-2"
role="tablist"
aria-label="${ariaLabel}"
@keydown=${this.handleContainerKeyDown}
>
${steps.map((step, index) => this.renderStep(step, index === this.value, index === focusIndex ? 0 : -1))}
</div>
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], MlWizardStepsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "linear", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlWizardStepsMolecule.prototype, "focusedIndex", void 0);
MlWizardStepsMolecule = __decorate([
    customElement('groupnavigatesteps--ml-wizard-steps')
], MlWizardStepsMolecule);
export { MlWizardStepsMolecule };
