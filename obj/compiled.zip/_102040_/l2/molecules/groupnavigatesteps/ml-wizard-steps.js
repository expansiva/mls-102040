var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupnavigatesteps/ml-wizard-steps.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// WIZARD STEPS MOLECULE
// =============================================================================
// Skill Group: groupNavigateSteps
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    labelFallback: 'Steps',
    loading: 'Loading steps...',
    completed: 'completed',
};
const messages = {
    en: message_en,
    pt: {
        labelFallback: 'Etapas',
        loading: 'Carregando etapas...',
        completed: 'concluída',
    },
};
let MlWizardStepsMolecule = class MlWizardStepsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-wizard-steps .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupnavigatesteps--ml-wizard-steps .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesteps--ml-wizard-steps .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesteps--ml-wizard-steps .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesteps--ml-wizard-steps .ml-step {
  background-color: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  transition: border-color var(--ml-transition, 200ms ease), background-color var(--ml-transition, 200ms ease);
}
groupnavigatesteps--ml-wizard-steps .ml-step:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupnavigatesteps--ml-wizard-steps .ml-step-active {
  border-color: var(--ml-primary, #3b82f6);
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 8%, var(--ml-surface, #ffffff));
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupnavigatesteps--ml-wizard-steps .ml-step-container {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface-muted, #49454f);
}
groupnavigatesteps--ml-wizard-steps .ml-step-badge {
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface-muted, #49454f);
}
groupnavigatesteps--ml-wizard-steps .ml-step-badge-active {
  border-color: var(--ml-primary, #3b82f6);
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupnavigatesteps--ml-wizard-steps .ml-step-badge-done {
  border-color: var(--ml-success, #22c55e);
  background-color: var(--ml-success, #22c55e);
  color: var(--ml-on-primary, #ffffff);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Step'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = 0;
        this.linear = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.focusedIndex = -1;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleStepClick(step) {
        if (!this.canNavigateTo(step.index))
            return;
        this.focusedIndex = step.index;
        this.value = step.index;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: step.index, title: step.title }
        }));
    }
    handleContainerKeyDown(event) {
        if (this.disabled || this.loading)
            return;
        const steps = this.parseSteps();
        const currentFocus = this.getInitialFocusIndex(steps);
        if (steps.length === 0)
            return;
        const key = event.key;
        if (key === 'ArrowRight' || key === 'ArrowLeft') {
            event.preventDefault();
            const direction = key === 'ArrowRight' ? 1 : -1;
            const nextIndex = this.findNextFocusableIndex(steps, currentFocus, direction);
            if (nextIndex !== currentFocus) {
                this.focusedIndex = nextIndex;
            }
            return;
        }
        if (key === 'Enter' || key === ' ') {
            event.preventDefault();
            const step = steps[currentFocus];
            if (step) {
                this.handleStepClick(step);
            }
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    parseSteps() {
        const stepElements = this.getSlots('Step');
        return stepElements.map((el, index) => {
            const title = el.getAttribute('title') || '';
            const description = el.getAttribute('description') || '';
            const completed = el.hasAttribute('completed');
            const disabled = el.hasAttribute('disabled');
            return { index, title, description, completed, disabled };
        });
    }
    canNavigateTo(targetIndex) {
        if (this.disabled || this.loading)
            return false;
        const steps = this.parseSteps();
        const target = steps[targetIndex];
        const current = steps[this.value];
        if (!target || target.disabled)
            return false;
        if (!this.linear)
            return true;
        if (!current)
            return false;
        const currentCompleted = current.completed;
        if (targetIndex <= this.value) {
            return target.completed || targetIndex === this.value;
        }
        if (targetIndex === this.value + 1) {
            return currentCompleted;
        }
        return currentCompleted && target.completed;
    }
    getInitialFocusIndex(steps) {
        const baseIndex = this.focusedIndex >= 0 ? this.focusedIndex : this.value;
        const clampedIndex = Math.max(0, Math.min(baseIndex, steps.length - 1));
        const target = steps[clampedIndex];
        if (target && !target.disabled)
            return clampedIndex;
        return this.findNextFocusableIndex(steps, clampedIndex, 1);
    }
    findNextFocusableIndex(steps, start, direction) {
        if (steps.length === 0)
            return 0;
        let index = start;
        for (let i = 0; i < steps.length; i += 1) {
            index = (index + direction + steps.length) % steps.length;
            const step = steps[index];
            if (step && !step.disabled)
                return index;
        }
        return start;
    }
    getStepClasses(step, isActive) {
        const isClickable = this.canNavigateTo(step.index);
        return [
            'flex-1 min-w-0',
            'rounded-lg border px-3 py-3 text-left transition',
            'ml-step',
            isActive ? 'ml-step-active' : '',
            step.disabled || !isClickable ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getLabelText() {
        const raw = this.getSlotContent('Label');
        if (!raw)
            return this.msg.labelFallback;
        return raw.replace(/<[^>]*>/g, '').trim() || this.msg.labelFallback;
    }
    renderLoading() {
        return html `
<div class="${cn('flex items-center gap-2 rounded-lg border px-4 py-3 text-sm ml-step-container', this.cssClass)}">
<span class="inline-flex h-4 w-4 items-center justify-center">
<svg class="h-4 w-4 animate-spin" viewBox="0 0 24 24" aria-hidden="true">
${svg `<circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" stroke-width="3" opacity="0.3"></circle>`}
${svg `<path d="M22 12a10 10 0 0 1-10 10" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"></path>`}
</svg>
</span>
<span>${this.msg.loading}</span>
</div>
`;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div class="${cn('mb-3 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderStep(step, isActive, tabIndex) {
        const isClickable = this.canNavigateTo(step.index);
        const ariaLabel = step.completed ? `${step.title} ${this.msg.completed}` : step.title;
        return html `
<button
class="${this.getStepClasses(step, isActive)}"
role="tab"
aria-selected="${isActive ? 'true' : 'false'}"
aria-disabled="${step.disabled ? 'true' : 'false'}"
aria-label="${ariaLabel}"
?disabled=${this.disabled || this.loading || step.disabled || !isClickable}
tabindex="${tabIndex}"
@click=${() => this.handleStepClick(step)}
>
<div class="flex items-center gap-2">
<span class="flex h-6 w-6 items-center justify-center rounded-full border text-xs font-semibold ${isActive
            ? 'ml-step-badge-active'
            : step.completed
                ? 'ml-step-badge-done'
                : 'ml-step-badge'}">
${step.completed
            ? html `<span aria-hidden="true">✓</span>`
            : html `${step.index + 1}`}
</span>
<div class="min-w-0">
<div class="truncate text-sm font-semibold ml-text">${step.title}</div>
${step.description
            ? html `<div class="truncate text-xs ml-text-muted">${step.description}</div>`
            : html ``}
</div>
</div>
</button>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `${this.renderLoading()}`;
        }
        const steps = this.parseSteps();
        const focusIndex = this.getInitialFocusIndex(steps);
        const ariaLabel = this.getLabelText();
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div
class="flex items-start gap-2"
role="tablist"
aria-label="${ariaLabel}"
@keydown=${this.handleContainerKeyDown}
>
${steps.map((step, index) => this.renderStep(step, index === this.value, index === focusIndex ? 0 : -1))}
</div>
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], MlWizardStepsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "linear", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlWizardStepsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlWizardStepsMolecule.prototype, "focusedIndex", void 0);
MlWizardStepsMolecule = __decorate([
    customElement('groupnavigatesteps--ml-wizard-steps')
], MlWizardStepsMolecule);
export { MlWizardStepsMolecule };
