var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupnavigatesteps/ml-compact-step-indicator.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COMPACT STEP INDICATOR MOLECULE
// =============================================================================
// Skill Group: groupNavigateSteps
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    stepsLabel: 'Steps',
    completed: 'completed',
    current: 'current',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        stepsLabel: 'Etapas',
        completed: 'concluído',
        current: 'atual',
        loading: 'Carregando...',
    },
};
let CompactStepIndicatorMolecule = class CompactStepIndicatorMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesteps--ml-compact-step-indicator .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupnavigatesteps--ml-compact-step-indicator .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesteps--ml-compact-step-indicator .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesteps--ml-compact-step-indicator .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesteps--ml-compact-step-indicator .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesteps--ml-compact-step-indicator .ml-step-number {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface-muted, #49454f);
  border-color: var(--ml-outline-variant, #e2e8f0);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesteps--ml-compact-step-indicator .ml-step-active {
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 10%, transparent);
  color: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupnavigatesteps--ml-compact-step-indicator .ml-step-completed {
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 10%, transparent);
  color: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupnavigatesteps--ml-compact-step-indicator .ml-step-loading-dot {
  background-color: var(--ml-on-surface-muted, #49454f);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Step'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = 0;
        this.linear = true;
        this.disabled = false;
        this.loading = false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleStepClick(step, steps) {
        if (!this.canSelectStep(step, steps))
            return;
        this.value = step.index;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: step.index, title: step.title },
        }));
    }
    handleStepKeyDown(event, step, steps) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleStepClick(step, steps);
            return;
        }
        if (event.key === 'ArrowRight') {
            event.preventDefault();
            this.focusNextSelectable(step.index, 1, steps);
            return;
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            this.focusNextSelectable(step.index, -1, steps);
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getSteps() {
        const steps = this.getSlots('Step');
        return steps.map((el, index) => {
            const title = el.getAttribute('title') || `${this.msg.stepsLabel} ${index + 1}`;
            const description = el.getAttribute('description') || '';
            const disabled = el.hasAttribute('disabled');
            const completed = el.hasAttribute('completed');
            return { index, title, description, disabled, completed };
        });
    }
    canSelectStep(step, steps) {
        if (this.loading || this.disabled)
            return false;
        if (step.disabled)
            return false;
        if (!this.linear)
            return true;
        const currentIndex = this.value;
        const currentStep = steps[currentIndex];
        if (step.index === currentIndex)
            return true;
        if (step.index < currentIndex)
            return step.completed;
        if (step.index === currentIndex + 1)
            return currentStep?.completed === true;
        return false;
    }
    focusNextSelectable(startIndex, direction, steps) {
        let idx = startIndex + direction;
        while (idx >= 0 && idx < steps.length) {
            const step = steps[idx];
            if (this.canSelectStep(step, steps)) {
                const target = this.querySelector(`[data-step-index="${idx}"]`);
                if (target)
                    target.focus();
                return;
            }
            idx += direction;
        }
    }
    getIndicatorSizeClasses() {
        const size = this.getAttribute('size') || 'md';
        const sizeMap = {
            sm: 'h-6 w-6 text-xs',
            md: 'h-7 w-7 text-sm',
            lg: 'h-8 w-8 text-sm',
        };
        return sizeMap[size] || sizeMap.md;
    }
    getIndicatorClasses(step, isActive, isSelectable) {
        const disabled = step.disabled || this.disabled;
        return [
            'flex items-center justify-center rounded-full border transition',
            this.getIndicatorSizeClasses(),
            'ml-step-number',
            isActive ? 'ml-step-active' : '',
            step.completed ? 'ml-step-completed' : '',
            disabled ? 'ml-disabled' : '',
            isSelectable ? 'cursor-pointer' : 'cursor-not-allowed',
        ].filter(Boolean).join(' ');
    }
    getStepAriaLabel(step, isActive) {
        const details = step.description ? ` - ${step.description}` : '';
        const completedLabel = step.completed ? `, ${this.msg.completed}` : '';
        const currentLabel = isActive ? `, ${this.msg.current}` : '';
        return `${step.title}${details}${completedLabel}${currentLabel}`;
    }
    getLabelText() {
        const content = this.getSlotContent('Label');
        const text = this.stripHtml(content).trim();
        return text || this.msg.stepsLabel;
    }
    stripHtml(content) {
        const div = document.createElement('div');
        div.innerHTML = content;
        return div.textContent || '';
    }
    renderLoading() {
        return html `
<div
class="flex items-center justify-center gap-2"
aria-live="polite"
aria-busy="true"
>
<span class="sr-only">${this.msg.loading}</span>
<div class="h-2 w-2 rounded-full ml-step-loading-dot animate-pulse"></div>
<div class="h-2 w-2 rounded-full ml-step-loading-dot animate-pulse"></div>
<div class="h-2 w-2 rounded-full ml-step-loading-dot animate-pulse"></div>
</div>
`;
    }
    renderStepItem(step, steps) {
        const isActive = step.index === this.value;
        const isSelectable = this.canSelectStep(step, steps);
        const classes = this.getIndicatorClasses(step, isActive, isSelectable);
        return html `
<button
class="${classes}"
role="tab"
aria-selected="${isActive}"
aria-disabled="${!isSelectable}"
aria-label="${this.getStepAriaLabel(step, isActive)}"
tabindex="${isActive ? '0' : '-1'}"
data-step-index="${step.index}"
@click="${() => this.handleStepClick(step, steps)}"
@keydown="${(event) => this.handleStepKeyDown(event, step, steps)}"
>
${step.completed
            ? html `
<svg class="h-4 w-4" viewBox="0 0 20 20" fill="none" aria-hidden="true">
${svg `<path d="M5 10.5l3 3 7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>`}
</svg>
`
            : html `<span>${step.index + 1}</span>`}
</button>
`;
    }
    renderSteps(steps) {
        return html `
<div
class="flex items-center justify-between gap-2"
role="tablist"
aria-label="${this.getLabelText()}"
>
${steps.map((step) => this.renderStepItem(step, steps))}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        const steps = this.getSteps();
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderSteps(steps)}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], CompactStepIndicatorMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CompactStepIndicatorMolecule.prototype, "linear", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CompactStepIndicatorMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CompactStepIndicatorMolecule.prototype, "loading", void 0);
CompactStepIndicatorMolecule = __decorate([
    customElement('groupnavigatesteps--ml-compact-step-indicator')
], CompactStepIndicatorMolecule);
export { CompactStepIndicatorMolecule };
