/// <mls fileReference="_102040_/l2/molecules/groupenternumberinterval/ml-number-range-slider.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML NUMBER RANGE SLIDER MOLECULE
// =============================================================================
// Skill Group: groupEnterNumberInterval
// Dual-handle horizontal range slider for selecting a numeric interval.
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    emptyValue: '—',
    rangeSeparator: '–',
    startHandle: 'Minimum value',
    endHandle: 'Maximum value',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        emptyValue: '—',
        rangeSeparator: '–',
        startHandle: 'Valor mínimo',
        endHandle: 'Valor máximo',
    },
};
/// **collab_i18n_end**
let MlNumberRangeSliderMolecule = class MlNumberRangeSliderMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenternumberinterval--ml-number-range-slider {
  display: block;
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-root {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-view {
  cursor: default;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-loading {
  cursor: wait;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-readonly .ml-nrs-track-area,
groupenternumberinterval--ml-number-range-slider .ml-nrs-readonly .ml-nrs-handle {
  cursor: default;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-error .ml-nrs-track-fill {
  background: var(--ml-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-error .ml-nrs-handle-knob {
  background: var(--ml-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-error .ml-nrs-handle-focused .ml-nrs-handle-knob {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-error-color, rgba(239, 68, 68, 0.4));
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-track-area {
  touch-action: pan-y;
  user-select: none;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-track {
  height: var(--ml-nrs-handle-size, 20px);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-track-base {
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: var(--ml-nrs-track-height, 6px);
  transform: translateY(-50%);
  background: var(--ml-surface-dim, #f5f5f5);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-full, 9999px);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-track-fill {
  position: absolute;
  top: 50%;
  height: var(--ml-nrs-track-height, 6px);
  transform: translateY(-50%);
  background: var(--ml-primary, #3b82f6);
  border-radius: var(--ml-radius-full, 9999px);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle {
  width: var(--ml-nrs-handle-size, 20px);
  height: var(--ml-nrs-handle-size, 20px);
  touch-action: none;
  user-select: none;
  outline: none;
  -webkit-tap-highlight-color: transparent;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle-start {
  z-index: 1;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle-end {
  z-index: 1;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle-active {
  z-index: 2;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle-active .ml-nrs-handle-knob {
  transform: scale(var(--ml-nrs-knob-active-scale, 1.15));
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle-focused {
  z-index: 2;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle-focused .ml-nrs-handle-knob {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4)), var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-handle-knob {
  width: var(--ml-nrs-knob-size, 16px);
  height: var(--ml-nrs-knob-size, 16px);
  background: var(--ml-primary, #3b82f6);
  border: var(--ml-nrs-knob-border-width, 2px) var(--ml-border-style, solid) var(--ml-surface, #ffffff);
  border-radius: var(--ml-radius-full, 9999px);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
  transition: transform var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease), background-color var(--ml-transition, 200ms ease);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-tooltip {
  position: absolute;
  bottom: calc(100% + var(--ml-nrs-tooltip-offset, 6px));
  left: 50%;
  transform: translateX(-50%);
  padding: var(--ml-nrs-tooltip-padding, 2px 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-size: var(--ml-nrs-tooltip-font-size, 12px);
  line-height: var(--ml-nrs-tooltip-line-height, 1.4);
  white-space: nowrap;
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
  pointer-events: none;
  z-index: 3;
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-readout {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-placeholder {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-view-value {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-loading-block {
  color: var(--ml-on-surface-muted, #49454f);
}
groupenternumberinterval--ml-number-range-slider .ml-nrs-skeleton-track {
  height: var(--ml-nrs-track-height, 6px);
  border-radius: var(--ml-radius-full, 9999px);
}
groupenternumberinterval--ml-number-range-slider .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider .ml-helper {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface-muted, #49454f);
}
groupenternumberinterval--ml-number-range-slider .ml-error-text {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-error, #ef4444);
}
groupenternumberinterval--ml-number-range-slider .ml-text {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenternumberinterval--ml-number-range-slider .ml-text-muted {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface-muted, #49454f);
}
groupenternumberinterval--ml-number-range-slider .ml-text-faint {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  color: var(--ml-on-surface-faint, #79747e);
}
groupenternumberinterval--ml-number-range-slider .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenternumberinterval--ml-number-range-slider .ml-spinner {
  display: inline-block;
  width: var(--ml-spinner-size, 16px);
  height: var(--ml-spinner-size, 16px);
  border: var(--ml-spinner-border-width, 2px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-primary, #3b82f6);
  border-radius: var(--ml-radius-full, 9999px);
  animation: ml-nrs-spin var(--ml-spinner-duration, 0.8s) linear infinite;
}
groupenternumberinterval--ml-number-range-slider .ml-skeleton {
  background: linear-gradient(90deg, var(--ml-surface-dim, #f5f5f5) 25%, var(--ml-outline-variant, #e2e8f0) 50%, var(--ml-surface-dim, #f5f5f5) 75%);
  background-size: 200% 100%;
  border-radius: var(--ml-radius-sm, 6px);
  animation: ml-nrs-skeleton-shimmer var(--ml-skeleton-duration, 1.5s) ease infinite;
}
@keyframes ml-nrs-spin {
  to {
    transform: rotate(360deg);
  }
}
@keyframes ml-nrs-skeleton-shimmer {
  0% {
    background-position: 200% 0;
  }
  100% {
    background-position: -200% 0;
  }
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — Data
        // ===========================================================================
        this.startValue = null;
        this.endValue = null;
        this.error = '';
        this.name = '';
        // ===========================================================================
        // PROPERTIES — Configuration
        // ===========================================================================
        this.min = null;
        this.max = null;
        this.step = 1;
        this.decimals = 0;
        this.locale = '';
        this.placeholder = '';
        this.minGap = 0;
        this.maxGap = 0;
        // ===========================================================================
        // PROPERTIES — States
        // ===========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.activeHandle = null;
        this.focusedHandle = null;
        this.hasFocus = false;
        this.trackEl = null;
        this.boundPointerMove = null;
        this.boundPointerUp = null;
        this.dragging = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        this.teardownPointerListeners();
    }
    // ===========================================================================
    // BOUNDS HELPERS
    // ===========================================================================
    getEffectiveMin() {
        return this.min !== null && this.min !== undefined ? Number(this.min) : 0;
    }
    getEffectiveMax() {
        return this.max !== null && this.max !== undefined ? Number(this.max) : 100;
    }
    getEffectiveStep() {
        const s = Number(this.step);
        return !s || s <= 0 ? 1 : s;
    }
    getEffectiveDecimals() {
        const d = Number(this.decimals);
        return !d || d < 0 ? 0 : Math.floor(d);
    }
    getEffectiveMinGap() {
        const g = Number(this.minGap);
        return !g || g < 0 ? 0 : g;
    }
    getEffectiveMaxGap() {
        const g = Number(this.maxGap);
        return !g || g < 0 ? 0 : g;
    }
    getRangeSpan() {
        const span = this.getEffectiveMax() - this.getEffectiveMin();
        return span <= 0 ? 1 : span;
    }
    roundToDecimals(value) {
        const d = this.getEffectiveDecimals();
        const factor = Math.pow(10, d);
        return Math.round(value * factor) / factor;
    }
    snapToStep(value) {
        const min = this.getEffectiveMin();
        const step = this.getEffectiveStep();
        const snapped = min + Math.round((value - min) / step) * step;
        return this.roundToDecimals(snapped);
    }
    clampToBounds(value) {
        let next = value;
        const min = this.getEffectiveMin();
        const max = this.getEffectiveMax();
        next = Math.max(next, min);
        next = Math.min(next, max);
        return this.roundToDecimals(next);
    }
    clampPair(start, end, moving = 'both') {
        const minGap = this.getEffectiveMinGap();
        const maxGap = this.getEffectiveMaxGap();
        let s = this.clampToBounds(start);
        let e = this.clampToBounds(end);
        if (s > e) {
            if (moving === 'start') {
                s = e;
            }
            else if (moving === 'end') {
                e = s;
            }
            else {
                e = s;
            }
        }
        if (minGap > 0 && e - s < minGap) {
            if (moving === 'start') {
                s = this.clampToBounds(e - minGap);
                if (e - s < minGap) {
                    e = this.clampToBounds(s + minGap);
                }
            }
            else if (moving === 'end') {
                e = this.clampToBounds(s + minGap);
                if (e - s < minGap) {
                    s = this.clampToBounds(e - minGap);
                }
            }
            else {
                e = this.clampToBounds(s + minGap);
                if (e - s < minGap) {
                    s = this.clampToBounds(e - minGap);
                }
            }
        }
        if (maxGap > 0 && e - s > maxGap) {
            if (moving === 'start') {
                s = this.clampToBounds(e - maxGap);
            }
            else if (moving === 'end') {
                e = this.clampToBounds(s + maxGap);
            }
            else {
                e = this.clampToBounds(s + maxGap);
            }
        }
        s = this.roundToDecimals(s);
        e = this.roundToDecimals(e);
        return { start: s, end: e };
    }
    getResolvedStart() {
        if (this.startValue === null || this.startValue === undefined) {
            return this.getEffectiveMin();
        }
        return this.clampToBounds(Number(this.startValue));
    }
    getResolvedEnd() {
        if (this.endValue === null || this.endValue === undefined) {
            return this.getEffectiveMax();
        }
        return this.clampToBounds(Number(this.endValue));
    }
    valueToPercent(value) {
        const min = this.getEffectiveMin();
        const span = this.getRangeSpan();
        const pct = ((value - min) / span) * 100;
        return Math.max(0, Math.min(100, pct));
    }
    percentToValue(percent) {
        const min = this.getEffectiveMin();
        const span = this.getRangeSpan();
        const raw = min + (percent / 100) * span;
        return this.snapToStep(raw);
    }
    clientXToPercent(clientX) {
        if (!this.trackEl)
            return 0;
        const rect = this.trackEl.getBoundingClientRect();
        if (rect.width <= 0)
            return 0;
        const x = clientX - rect.left;
        const pct = (x / rect.width) * 100;
        return Math.max(0, Math.min(100, pct));
    }
    // ===========================================================================
    // FORMATTING
    // ===========================================================================
    formatNumber(value) {
        if (value === null || value === undefined || Number.isNaN(Number(value))) {
            return this.msg.emptyValue;
        }
        const num = Number(value);
        const decimals = this.getEffectiveDecimals();
        const locale = this.locale && String(this.locale).trim() ? String(this.locale) : undefined;
        try {
            return num.toLocaleString(locale, {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals,
            });
        }
        catch {
            return num.toFixed(decimals);
        }
    }
    wrapWithAffixes(formatted) {
        const prefix = this.getSlotContent('Prefix') || '';
        const suffix = this.getSlotContent('Suffix') || '';
        return `${prefix}${formatted}${suffix}`;
    }
    formatBound(value) {
        if (value === null || value === undefined || Number.isNaN(Number(value))) {
            return this.msg.emptyValue;
        }
        return this.wrapWithAffixes(this.formatNumber(value));
    }
    formatIntervalText() {
        const hasStart = this.startValue !== null && this.startValue !== undefined;
        const hasEnd = this.endValue !== null && this.endValue !== undefined;
        const sep = ` ${this.msg.rangeSeparator} `;
        if (!hasStart && !hasEnd) {
            return this.msg.emptyValue;
        }
        if (hasStart && !hasEnd) {
            return `${this.formatBound(this.startValue)}${sep}${this.msg.emptyValue}`;
        }
        if (!hasStart && hasEnd) {
            return `${this.msg.emptyValue}${sep}${this.formatBound(this.endValue)}`;
        }
        return `${this.formatBound(this.startValue)}${sep}${this.formatBound(this.endValue)}`;
    }
    // ===========================================================================
    // INTERACTION GUARDS
    // ===========================================================================
    isInteractive() {
        return (!!this.isEditing &&
            !this.disabled &&
            !this.readonly &&
            !this.loading);
    }
    hasError() {
        if (this.error && String(this.error).trim())
            return true;
        if (this.required) {
            const missingStart = this.startValue === null || this.startValue === undefined;
            const missingEnd = this.endValue === null || this.endValue === undefined;
            return missingStart || missingEnd;
        }
        return false;
    }
    // ===========================================================================
    // VALUE COMMIT
    // ===========================================================================
    applyPair(start, end, moving, emitInput) {
        const pair = this.clampPair(start, end, moving);
        this.startValue = pair.start;
        this.endValue = pair.end;
        if (emitInput) {
            this.emitInput();
        }
    }
    emitInput() {
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: {
                startValue: this.startValue,
                endValue: this.endValue,
            },
        }));
    }
    emitChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: {
                startValue: this.startValue,
                endValue: this.endValue,
            },
        }));
    }
    emitFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    emitBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // ===========================================================================
    // POINTER HANDLERS
    // ===========================================================================
    teardownPointerListeners() {
        if (this.boundPointerMove) {
            window.removeEventListener('pointermove', this.boundPointerMove);
            this.boundPointerMove = null;
        }
        if (this.boundPointerUp) {
            window.removeEventListener('pointerup', this.boundPointerUp);
            window.removeEventListener('pointercancel', this.boundPointerUp);
            this.boundPointerUp = null;
        }
        this.dragging = false;
    }
    handleHandlePointerDown(e, handle) {
        if (!this.isInteractive())
            return;
        e.preventDefault();
        e.stopPropagation();
        this.trackEl = e.currentTarget.closest('.ml-nrs-track-area')
            || this.renderRoot?.querySelector?.('.ml-nrs-track-area')
            || this.querySelector('.ml-nrs-track-area');
        this.activeHandle = handle;
        this.focusedHandle = handle;
        this.dragging = true;
        if (!this.hasFocus) {
            this.hasFocus = true;
            this.emitFocus();
        }
        const target = e.currentTarget;
        try {
            target.setPointerCapture(e.pointerId);
        }
        catch {
            // ignore capture errors
        }
        this.boundPointerMove = (ev) => this.handlePointerMove(ev);
        this.boundPointerUp = (ev) => this.handlePointerUp(ev);
        window.addEventListener('pointermove', this.boundPointerMove);
        window.addEventListener('pointerup', this.boundPointerUp);
        window.addEventListener('pointercancel', this.boundPointerUp);
        this.requestUpdate();
    }
    handlePointerMove(e) {
        if (!this.dragging || !this.activeHandle || !this.isInteractive())
            return;
        e.preventDefault();
        const pct = this.clientXToPercent(e.clientX);
        const nextVal = this.percentToValue(pct);
        const currentStart = this.getResolvedStart();
        const currentEnd = this.getResolvedEnd();
        if (this.activeHandle === 'start') {
            this.applyPair(nextVal, currentEnd, 'start', true);
        }
        else {
            this.applyPair(currentStart, nextVal, 'end', true);
        }
    }
    handlePointerUp(_e) {
        if (!this.dragging)
            return;
        this.teardownPointerListeners();
        this.activeHandle = null;
        this.emitChange();
        this.requestUpdate();
    }
    handleTrackPointerDown(e) {
        if (!this.isInteractive())
            return;
        const target = e.target;
        if (target.closest('.ml-nrs-handle'))
            return;
        e.preventDefault();
        this.trackEl = e.currentTarget;
        const pct = this.clientXToPercent(e.clientX);
        const clickVal = this.percentToValue(pct);
        const currentStart = this.getResolvedStart();
        const currentEnd = this.getResolvedEnd();
        // Ignore clicks on the selected segment between handles
        if (clickVal > currentStart && clickVal < currentEnd) {
            return;
        }
        const distStart = Math.abs(clickVal - currentStart);
        const distEnd = Math.abs(clickVal - currentEnd);
        const moving = distStart <= distEnd ? 'start' : 'end';
        this.activeHandle = moving;
        this.focusedHandle = moving;
        this.dragging = true;
        if (!this.hasFocus) {
            this.hasFocus = true;
            this.emitFocus();
        }
        if (moving === 'start') {
            this.applyPair(clickVal, currentEnd, 'start', true);
        }
        else {
            this.applyPair(currentStart, clickVal, 'end', true);
        }
        this.boundPointerMove = (ev) => this.handlePointerMove(ev);
        this.boundPointerUp = (ev) => this.handlePointerUp(ev);
        window.addEventListener('pointermove', this.boundPointerMove);
        window.addEventListener('pointerup', this.boundPointerUp);
        window.addEventListener('pointercancel', this.boundPointerUp);
        this.requestUpdate();
    }
    // ===========================================================================
    // KEYBOARD HANDLERS
    // ===========================================================================
    handleHandleKeyDown(e, handle) {
        if (!this.isInteractive())
            return;
        const step = this.getEffectiveStep();
        const min = this.getEffectiveMin();
        const max = this.getEffectiveMax();
        const currentStart = this.getResolvedStart();
        const currentEnd = this.getResolvedEnd();
        let nextStart = currentStart;
        let nextEnd = currentEnd;
        let handled = false;
        switch (e.key) {
            case 'ArrowLeft':
            case 'ArrowDown': {
                handled = true;
                if (handle === 'start') {
                    nextStart = currentStart - step;
                }
                else {
                    nextEnd = currentEnd - step;
                }
                break;
            }
            case 'ArrowRight':
            case 'ArrowUp': {
                handled = true;
                if (handle === 'start') {
                    nextStart = currentStart + step;
                }
                else {
                    nextEnd = currentEnd + step;
                }
                break;
            }
            case 'Home': {
                handled = true;
                if (handle === 'start') {
                    nextStart = min;
                }
                else {
                    nextEnd = min;
                }
                break;
            }
            case 'End': {
                handled = true;
                if (handle === 'start') {
                    nextStart = max;
                }
                else {
                    nextEnd = max;
                }
                break;
            }
            default:
                break;
        }
        if (!handled)
            return;
        e.preventDefault();
        e.stopPropagation();
        nextStart = this.snapToStep(nextStart);
        nextEnd = this.snapToStep(nextEnd);
        this.applyPair(nextStart, nextEnd, handle, true);
        this.emitChange();
    }
    handleHandleFocus(handle) {
        if (!this.isInteractive())
            return;
        this.focusedHandle = handle;
        if (!this.hasFocus) {
            this.hasFocus = true;
            this.emitFocus();
        }
        this.requestUpdate();
    }
    handleHandleBlur(e) {
        const related = e.relatedTarget;
        const root = e.currentTarget;
        const container = root.closest('.ml-nrs-root') || this;
        // Defer to allow focus to move to the other handle
        requestAnimationFrame(() => {
            const active = document.activeElement;
            if (active && container.contains(active)) {
                return;
            }
            if (related && container.contains(related)) {
                return;
            }
            this.focusedHandle = null;
            this.activeHandle = null;
            if (this.hasFocus) {
                this.hasFocus = false;
                this.emitBlur();
            }
            this.requestUpdate();
        });
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getRootClasses() {
        return [
            'flex w-full flex-col gap-1',
            'ml-nrs-root',
            this.disabled ? 'ml-disabled' : '',
            this.readonly ? 'ml-nrs-readonly' : '',
            this.loading ? 'ml-nrs-loading' : '',
            this.hasError() && this.isEditing ? 'ml-nrs-error' : '',
            !this.isEditing ? 'ml-nrs-view' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getTrackClasses() {
        return [
            'relative w-full flex items-center',
            'ml-nrs-track-area',
            this.isInteractive() ? 'cursor-pointer' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getHandleClasses(handle) {
        const isActive = this.activeHandle === handle;
        const isFocused = this.focusedHandle === handle;
        return [
            'absolute top-1/2 -translate-y-1/2 -translate-x-1/2',
            'flex items-center justify-center',
            'ml-nrs-handle',
            handle === 'start' ? 'ml-nrs-handle-start' : 'ml-nrs-handle-end',
            isActive ? 'ml-nrs-handle-active' : '',
            isFocused ? 'ml-nrs-handle-focused' : '',
            this.isInteractive() ? 'cursor-grab' : '',
            isActive && this.isInteractive() ? 'cursor-grabbing' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div class="${cn('mb-1 text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderSubLabels() {
        const hasStart = this.hasSlot('LabelStart');
        const hasEnd = this.hasSlot('LabelEnd');
        if (!hasStart && !hasEnd)
            return html ``;
        return html `
      <div class="mb-1 flex w-full items-center justify-between gap-2">
        ${hasStart
            ? html `
              <span class="${cn('text-xs ml-text-muted', this.getSlotClass('LabelStart'))}">
                ${unsafeHTML(this.getSlotContent('LabelStart'))}
              </span>
            `
            : html `<span></span>`}
        ${hasEnd
            ? html `
              <span class="${cn('text-xs ml-text-muted', this.getSlotClass('LabelEnd'))}">
                ${unsafeHTML(this.getSlotContent('LabelEnd'))}
              </span>
            `
            : html `<span></span>`}
      </div>
    `;
    }
    renderFeedback() {
        if (!this.isEditing)
            return html ``;
        if (this.hasError() && this.error && String(this.error).trim()) {
            return html `
        <p class="${cn('mt-1 text-xs ml-error-text')}" id="nrs-error" role="alert">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}" id="nrs-helper">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderTooltip(handle, value) {
        const show = this.activeHandle === handle || this.focusedHandle === handle;
        if (!show)
            return html ``;
        return html `
      <div class="ml-nrs-tooltip" aria-hidden="true">
        ${unsafeHTML(this.formatBound(value))}
      </div>
    `;
    }
    renderHandle(handle, value, percent) {
        const label = handle === 'start'
            ? this.getSlotContent('LabelStart') || this.msg.startHandle
            : this.getSlotContent('LabelEnd') || this.msg.endHandle;
        const describedBy = this.hasError() && this.error && String(this.error).trim()
            ? 'nrs-error'
            : this.hasSlot('Helper')
                ? 'nrs-helper'
                : nothingAttr();
        return html `
      <div
        class="${this.getHandleClasses(handle)}"
        style="left: ${percent}%;"
        role="slider"
        tabindex="${this.isInteractive() ? 0 : -1}"
        aria-label="${label.replace(/<[^>]*>/g, '').trim() || (handle === 'start' ? this.msg.startHandle : this.msg.endHandle)}"
        aria-valuemin="${this.getEffectiveMin()}"
        aria-valuemax="${this.getEffectiveMax()}"
        aria-valuenow="${value}"
        aria-valuetext="${this.formatNumber(value)}"
        aria-disabled="${this.disabled ? 'true' : 'false'}"
        aria-readonly="${this.readonly ? 'true' : 'false'}"
        aria-required="${this.required ? 'true' : 'false'}"
        aria-invalid="${this.hasError() ? 'true' : 'false'}"
        aria-describedby="${describedBy}"
        @pointerdown=${(e) => this.handleHandlePointerDown(e, handle)}
        @keydown=${(e) => this.handleHandleKeyDown(e, handle)}
        @focus=${() => this.handleHandleFocus(handle)}
        @blur=${(e) => this.handleHandleBlur(e)}
      >
        ${this.renderTooltip(handle, value)}
        <span class="ml-nrs-handle-knob"></span>
      </div>
    `;
    }
    renderViewMode() {
        return html `
      <div class="${cn(this.getRootClasses(), this.cssClass)}">
        ${this.renderLabel()}
        <div class="ml-nrs-view-value ml-text">
          ${unsafeHTML(this.formatIntervalText())}
        </div>
      </div>
    `;
    }
    renderLoading() {
        return html `
      <div class="${cn(this.getRootClasses(), this.cssClass)}">
        ${this.renderLabel()}
        <div class="flex w-full flex-col gap-2 ml-nrs-loading-block" aria-busy="true">
          <div class="flex items-center gap-2">
            <span class="ml-spinner" aria-hidden="true"></span>
            <span class="text-sm ml-text-muted">${this.msg.loading}</span>
          </div>
          <div class="w-full ml-skeleton ml-nrs-skeleton-track"></div>
        </div>
      </div>
    `;
    }
    renderPlaceholderHint() {
        const hasStart = this.startValue !== null && this.startValue !== undefined;
        const hasEnd = this.endValue !== null && this.endValue !== undefined;
        if (hasStart || hasEnd)
            return html ``;
        if (!this.placeholder || !String(this.placeholder).trim())
            return html ``;
        return html `
      <div class="mb-1 text-xs ml-text-faint ml-nrs-placeholder">
        ${this.placeholder}
      </div>
    `;
    }
    renderValueReadout() {
        return html `
      <div class="mt-2 flex w-full items-center justify-between gap-2 text-xs ml-nrs-readout">
        <span class="ml-text">${unsafeHTML(this.formatBound(this.startValue))}</span>
        <span class="ml-text-faint">${this.msg.rangeSeparator}</span>
        <span class="ml-text">${unsafeHTML(this.formatBound(this.endValue))}</span>
      </div>
    `;
    }
    renderSlider() {
        const start = this.getResolvedStart();
        const end = this.getResolvedEnd();
        const startPct = this.valueToPercent(start);
        const endPct = this.valueToPercent(end);
        return html `
      <div
        class="${this.getTrackClasses()}"
        @pointerdown=${(e) => this.handleTrackPointerDown(e)}
      >
        <div class="relative w-full ml-nrs-track">
          <div class="ml-nrs-track-base"></div>
          <div
            class="ml-nrs-track-fill"
            style="left: ${startPct}%; width: ${Math.max(0, endPct - startPct)}%;"
          ></div>
          ${this.renderHandle('start', start, startPct)}
          ${this.renderHandle('end', end, endPct)}
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang] || messages.en;
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        if (this.loading) {
            return this.renderLoading();
        }
        return html `
      <div
        class="${cn(this.getRootClasses(), this.cssClass)}"
        data-name="${this.name || ''}"
      >
        ${this.renderLabel()}
        ${this.renderSubLabels()}
        ${this.renderPlaceholderHint()}
        ${this.renderSlider()}
        ${this.renderValueReadout()}
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number, attribute: 'start-value' })
], MlNumberRangeSliderMolecule.prototype, "startValue", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'end-value' })
], MlNumberRangeSliderMolecule.prototype, "endValue", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlNumberRangeSliderMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNumberRangeSliderMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-gap' })
], MlNumberRangeSliderMolecule.prototype, "minGap", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-gap' })
], MlNumberRangeSliderMolecule.prototype, "maxGap", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlNumberRangeSliderMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNumberRangeSliderMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlNumberRangeSliderMolecule.prototype, "activeHandle", void 0);
__decorate([
    state()
], MlNumberRangeSliderMolecule.prototype, "focusedHandle", void 0);
__decorate([
    state()
], MlNumberRangeSliderMolecule.prototype, "hasFocus", void 0);
MlNumberRangeSliderMolecule = __decorate([
    customElement('groupenternumberinterval--ml-number-range-slider')
], MlNumberRangeSliderMolecule);
export { MlNumberRangeSliderMolecule };
function nothingAttr() {
    return '';
}
