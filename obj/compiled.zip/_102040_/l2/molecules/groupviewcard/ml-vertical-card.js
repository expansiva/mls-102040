var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewcard/ml-vertical-card.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML VERTICAL CARD MOLECULE
// =============================================================================
// Skill Group: groupViewCard
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
let MlVerticalCardMolecule = class MlVerticalCardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-vertical-card .ml-card {
  background: var(--ml-surface, #fff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-width: var(--ml-border-width, 1px);
  border-style: var(--ml-border-style, solid);
  border-radius: var(--ml-radius-md, 8px);
}
groupviewcard--ml-vertical-card .ml-card-header {
  border-color: var(--ml-primary, #3b82f6);
}
groupviewcard--ml-vertical-card .ml-card-hover:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewcard--ml-vertical-card .ml-card-divider {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewcard--ml-vertical-card .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewcard--ml-vertical-card .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewcard--ml-vertical-card .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewcard--ml-vertical-card .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupviewcard--ml-vertical-card .ml-skeleton {
  background: var(--ml-outline-variant, #e2e8f0);
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.clickable = false;
        this.selected = false;
        this.disabled = false;
        this.loading = false;
        this.isEditing = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================
    updated(changed) {
        if (changed.has('isEditing')) {
            this.applyEditingAttribute();
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleCardClick() {
        if (!this.isInteractive())
            return;
        this.dispatchEvent(new CustomEvent('cardClick', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    handleKeyDown(e) {
        if (!this.isInteractive())
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleCardClick();
        }
    }
    // ===========================================================================
    // INTERNAL HELPERS
    // ==========================================================================
    isInteractive() {
        return this.clickable && !this.disabled && !this.loading;
    }
    applyEditingAttribute() {
        const elements = Array.from(this.querySelectorAll('*'));
        elements.forEach((el) => {
            const tag = el.tagName.toLowerCase();
            if (!tag.includes('-'))
                return;
            if (this.isEditing) {
                el.setAttribute('is-editing', '');
            }
            else {
                el.removeAttribute('is-editing');
            }
        });
    }
    getRootClasses() {
        const interactive = this.isInteractive();
        return cn('w-full rounded-xl border transition p-4 flex flex-col gap-4', 'ml-card', this.selected ? 'ml-card-header' : '', interactive ? 'cursor-pointer ml-card-hover' : '', this.disabled ? 'ml-disabled' : '', this.cssClass);
    }
    renderHeader() {
        const hasHeader = this.hasSlot('CardHeader');
        const hasTitle = this.hasSlot('CardTitle');
        const hasDescription = this.hasSlot('CardDescription');
        if (!hasHeader && !hasTitle && !hasDescription) {
            return html ``;
        }
        if (hasHeader) {
            return html `
<div class="flex flex-col gap-1">
${unsafeHTML(this.getSlotContent('CardHeader'))}
</div>
`;
        }
        return html `
<div class="flex flex-col gap-1">
${hasTitle
            ? html `<div class="${cn('text-base font-semibold ml-label', this.getSlotClass('CardTitle'))}">${unsafeHTML(this.getSlotContent('CardTitle'))}</div>`
            : html ``}
${hasDescription
            ? html `<div class="${cn('text-sm ml-text-muted', this.getSlotClass('CardDescription'))}">${unsafeHTML(this.getSlotContent('CardDescription'))}</div>`
            : html ``}
</div>
`;
    }
    renderContent() {
        if (!this.hasSlot('CardContent'))
            return html ``;
        return html `
<div class="${cn('text-sm ml-text', this.getSlotClass('CardContent'))}">
${unsafeHTML(this.getSlotContent('CardContent'))}
</div>
`;
    }
    renderFooter() {
        if (!this.hasSlot('CardFooter'))
            return html ``;
        return html `
<div class="${cn('text-xs ml-text-muted', this.getSlotClass('CardFooter'))}">
${unsafeHTML(this.getSlotContent('CardFooter'))}
</div>
`;
    }
    renderAction() {
        if (!this.hasSlot('CardAction'))
            return html ``;
        return html `
<div class="${cn('pt-3 border-t ml-card-divider', this.getSlotClass('CardAction'))}">
${unsafeHTML(this.getSlotContent('CardAction'))}
</div>
`;
    }
    renderLoading() {
        return html `
<div class="flex flex-col gap-4 animate-pulse">
<div class="h-4 w-2/3 rounded ml-skeleton"></div>
<div class="h-3 w-1/2 rounded ml-skeleton"></div>
<div class="h-20 w-full rounded ml-skeleton"></div>
<div class="h-3 w-1/3 rounded ml-skeleton"></div>
<div class="h-9 w-28 rounded ml-skeleton"></div>
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const interactive = this.isInteractive();
        return html `
<div
class=${this.getRootClasses()}
role=${ifDefined(interactive ? 'button' : undefined)}
tabindex=${ifDefined(interactive ? '0' : undefined)}
aria-disabled=${ifDefined(this.disabled ? 'true' : undefined)}
aria-selected=${ifDefined(this.selected ? 'true' : undefined)}
@click=${this.handleCardClick}
@keydown=${this.handleKeyDown}
>
${this.loading
            ? this.renderLoading()
            : html `
${this.renderHeader()}
${this.renderContent()}
${this.renderFooter()}
${this.renderAction()}
`}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "clickable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "selected", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlVerticalCardMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlVerticalCardMolecule.prototype, "isEditing", void 0);
MlVerticalCardMolecule = __decorate([
    customElement('groupviewcard--ml-vertical-card')
], MlVerticalCardMolecule);
export { MlVerticalCardMolecule };
