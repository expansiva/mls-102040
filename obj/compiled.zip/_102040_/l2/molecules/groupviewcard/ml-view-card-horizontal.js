var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewcard/ml-view-card-horizontal.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// VIEW CARD HORIZONTAL MOLECULE
// =============================================================================
// Skill Group: view + card
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
let ViewCardHorizontalMolecule = class ViewCardHorizontalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-view-card-horizontal .ml-card {
  background: var(--ml-surface, #fff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-width: var(--ml-border-width, 1px);
  border-style: var(--ml-border-style, solid);
  border-radius: var(--ml-radius-md, 8px);
}
groupviewcard--ml-view-card-horizontal .ml-card-header {
  border-color: var(--ml-primary, #3b82f6);
}
groupviewcard--ml-view-card-horizontal .ml-card-media {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewcard--ml-view-card-horizontal .ml-card:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewcard--ml-view-card-horizontal .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewcard--ml-view-card-horizontal .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewcard--ml-view-card-horizontal .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewcard--ml-view-card-horizontal .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupviewcard--ml-view-card-horizontal .ml-skeleton {
  background: var(--ml-outline-variant, #e2e8f0);
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];
        // O slot CardFooter e o CardAction carregam CONTROLES do consumidor, não conteúdo
        // decorativo — precisam de nó vivo, com handler e componente preservados.
        // Os demais slots continuam vindo pelo caminho de snapshot: são conteúdo.
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.clickable = false;
        this.selected = false;
        this.disabled = false;
        this.loading = false;
        this.isEditing = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    updated() {
        this.applyEditingAttribute();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleCardClick() {
        if (!this.clickable || this.disabled || this.loading)
            return;
        this.dispatchEvent(new CustomEvent('cardClick', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleKeyDown(e) {
        if (!this.clickable || this.disabled || this.loading)
            return;
        const key = e.key;
        if (key === 'Enter' || key === ' ') {
            e.preventDefault();
            this.handleCardClick();
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    applyEditingAttribute() {
        const nodes = this.querySelectorAll('*');
        nodes.forEach((el) => {
            if (this.isEditing) {
                el.setAttribute('is-editing', 'true');
            }
            else {
                el.removeAttribute('is-editing');
            }
        });
    }
    getContainerClasses() {
        return cn('w-full rounded-lg border p-4 flex gap-4 items-start transition', 'ml-card', this.selected ? 'ml-card-header' : '', this.clickable && !this.disabled
            ? 'cursor-pointer focus:outline-none focus:ring-2'
            : '', this.disabled ? 'ml-disabled' : '', this.cssClass);
    }
    renderHeader() {
        const hasTitle = this.hasSlot('CardTitle');
        const hasDescription = this.hasSlot('CardDescription');
        const hasHeader = this.hasSlot('CardHeader');
        if (!hasHeader && !hasTitle && !hasDescription) {
            return html ``;
        }
        const headerContent = this.getSlotContent('CardHeader');
        return html `
      <div class="mb-2">
        ${hasTitle
            ? html `<div class="${cn('text-sm font-semibold ml-label', this.getSlotClass('CardTitle'))}">${unsafeHTML(this.getSlotContent('CardTitle'))}</div>`
            : ''}
        ${hasDescription
            ? html `<div class="${cn('mt-1 text-xs ml-text-muted', this.getSlotClass('CardDescription'))}">${unsafeHTML(this.getSlotContent('CardDescription'))}</div>`
            : ''}
        ${!hasTitle && !hasDescription && hasHeader
            ? html `<div class="${cn('text-sm ml-text', this.getSlotClass('CardHeader'))}">${unsafeHTML(headerContent)}</div>`
            : ''}
      </div>
    `;
    }
    renderContentLeft() {
        if (!this.hasSlot('CardContent'))
            return html ``;
        return html `
      <div class="${cn('w-20 h-20 flex-shrink-0 rounded-md overflow-hidden ml-card-media', this.getSlotClass('CardContent'))}">
        ${unsafeHTML(this.getSlotContent('CardContent'))}
      </div>
    `;
    }
    renderFooter() {
        if (!this.hasSlot('CardFooter'))
            return html ``;
        return html `
      <div class="${cn('mt-2 text-xs ml-text-muted', this.getSlotClass('CardFooter'))}">
        ${this.renderLiveSlot('CardFooter')}
      </div>
    `;
    }
    renderAction() {
        if (!this.hasSlot('CardAction'))
            return html ``;
        return html `
      <div class="mt-3">
        ${this.renderLiveSlot('CardAction')}
      </div>
    `;
    }
    renderSkeleton() {
        return html `
      <div class="w-full rounded-lg border ml-card p-4 flex gap-4 items-start animate-pulse">
        <div class="w-20 h-20 ml-skeleton rounded-md"></div>
        <div class="flex-1 min-w-0">
          <div class="h-4 w-2/3 ml-skeleton rounded"></div>
          <div class="mt-2 h-3 w-4/5 ml-skeleton rounded"></div>
          <div class="mt-3 h-3 w-1/3 ml-skeleton rounded"></div>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        if (this.loading) {
            return this.renderSkeleton();
        }
        const role = this.clickable && !this.disabled ? 'button' : undefined;
        const tabIndex = this.clickable && !this.disabled ? 0 : undefined;
        return html `
      <div
        class="${this.getContainerClasses()}"
        role=${role || ''}
        tabindex=${tabIndex ?? ''}
        aria-selected=${this.selected ? 'true' : 'false'}
        aria-disabled=${this.disabled ? 'true' : 'false'}
        @click=${this.handleCardClick}
        @keydown=${this.handleKeyDown}
      >
        ${this.renderContentLeft()}
        <div class="flex-1 min-w-0">
          ${this.renderHeader()}
          ${this.renderFooter()}
          ${this.renderAction()}
        </div>
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], ViewCardHorizontalMolecule.prototype, "clickable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ViewCardHorizontalMolecule.prototype, "selected", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ViewCardHorizontalMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], ViewCardHorizontalMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], ViewCardHorizontalMolecule.prototype, "isEditing", void 0);
ViewCardHorizontalMolecule = __decorate([
    customElement('groupviewcard--ml-view-card-horizontal')
], ViewCardHorizontalMolecule);
export { ViewCardHorizontalMolecule };
