var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewcard/ml-profile-card.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML PROFILE CARD MOLECULE
// =============================================================================
// Skill Group: groupViewCard
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
let MlProfileCardMolecule = class MlProfileCardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-profile-card .ml-card {
  background: var(--ml-surface, #fff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-width: var(--ml-border-width, 1px);
  border-style: var(--ml-border-style, solid);
  border-radius: var(--ml-radius-md, 8px);
}
groupviewcard--ml-profile-card .ml-card-hover:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewcard--ml-profile-card .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewcard--ml-profile-card .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewcard--ml-profile-card .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewcard--ml-profile-card .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupviewcard--ml-profile-card .ml-skeleton {
  background: var(--ml-outline-variant, #e2e8f0);
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];
        // O slot CardFooter e o CardAction carregam CONTROLES do consumidor, não conteúdo
        // decorativo — precisam de nó vivo, com handler e componente preservados.
        // Os demais slots continuam vindo pelo caminho de snapshot: são conteúdo.
        this.usesLiveSlots = true;
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.clickable = false;
        this.selected = false;
        this.disabled = false;
        this.loading = false;
        this.isEditing = false;
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    firstUpdated() {
        this.syncEditingAttribute();
    }
    updated(changedProperties) {
        if (changedProperties.has('isEditing')) {
            this.syncEditingAttribute();
        }
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleCardClick() {
        if (!this.isInteractive())
            return;
        this.dispatchEvent(new CustomEvent('cardClick', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    handleCardKeydown(event) {
        if (!this.isInteractive())
            return;
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleCardClick();
        }
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    isInteractive() {
        return this.clickable && !this.disabled && !this.loading;
    }
    getCardClasses() {
        return cn('w-full rounded-xl border p-4 transition-colors', 'ml-card', this.selected ? 'ml-card-hover' : '', this.isInteractive()
            ? 'cursor-pointer ml-card-hover focus:outline-none focus:ring-2'
            : '', (this.disabled || this.loading) ? 'ml-disabled' : '', this.cssClass);
    }
    syncEditingAttribute() {
        const elements = Array.from(this.querySelectorAll('*'));
        for (const el of elements) {
            if (!el.tagName.includes('-'))
                continue;
            if (this.isEditing) {
                el.setAttribute('is-editing', '');
            }
            else {
                el.removeAttribute('is-editing');
            }
        }
    }
    renderHeader() {
        const hasHeader = this.hasSlot('CardHeader');
        const hasTitle = this.hasSlot('CardTitle');
        const hasDescription = this.hasSlot('CardDescription');
        if (!hasHeader && !hasTitle && !hasDescription)
            return nothing;
        if (hasHeader) {
            return html `
<div class="${cn('card-header ml-text', this.getSlotClass('CardHeader'))}">
${unsafeHTML(this.getSlotContent('CardHeader'))}
</div>
`;
        }
        return html `
<div class="card-header">
${hasTitle ? html `
<div class="${cn('text-lg font-semibold ml-label', this.getSlotClass('CardTitle'))}">
${unsafeHTML(this.getSlotContent('CardTitle'))}
</div>
` : nothing}
${hasDescription ? html `
<div class="${cn('mt-1 text-sm ml-text-muted', this.getSlotClass('CardDescription'))}">
${unsafeHTML(this.getSlotContent('CardDescription'))}
</div>
` : nothing}
</div>
`;
    }
    renderContent() {
        if (!this.hasSlot('CardContent'))
            return nothing;
        return html `
<div class="${cn('card-content ml-text', this.getSlotClass('CardContent'))}">
${unsafeHTML(this.getSlotContent('CardContent'))}
</div>
`;
    }
    renderFooter() {
        if (!this.hasSlot('CardFooter'))
            return nothing;
        return html `
<div class="${cn('card-footer ml-text-muted', this.getSlotClass('CardFooter'))}">
${this.renderLiveSlot('CardFooter')}
</div>
`;
    }
    renderAction() {
        if (!this.hasSlot('CardAction'))
            return nothing;
        return html `
<div class="card-action flex flex-wrap items-center gap-2">
${this.renderLiveSlot('CardAction')}
</div>
`;
    }
    renderLoadingSkeleton() {
        return html `
<div class="animate-pulse space-y-4">
<div class="space-y-2">
<div class="h-4 w-2/3 rounded ml-skeleton"></div>
<div class="h-3 w-1/2 rounded ml-skeleton"></div>
</div>
<div class="h-16 w-full rounded ml-skeleton"></div>
<div class="flex gap-2">
<div class="h-8 w-24 rounded ml-skeleton"></div>
<div class="h-8 w-20 rounded ml-skeleton"></div>
</div>
</div>
`;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const roleAttr = this.isInteractive() ? 'button' : nothing;
        const tabIndexAttr = this.isInteractive() ? 0 : nothing;
        const ariaDisabled = (this.disabled || this.loading) ? 'true' : nothing;
        const ariaSelected = this.selected ? 'true' : nothing;
        return html `
<div
class="${this.getCardClasses()}"
role=${roleAttr}
tabindex=${tabIndexAttr}
aria-disabled=${ariaDisabled}
aria-selected=${ariaSelected}
@click=${this.handleCardClick}
@keydown=${this.handleCardKeydown}
>
${this.loading
            ? this.renderLoadingSkeleton()
            : html `
<div class="space-y-4">
${this.renderHeader()}
${this.renderContent()}
${this.renderFooter()}
${this.renderAction()}
</div>
`}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "clickable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "selected", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlProfileCardMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlProfileCardMolecule.prototype, "isEditing", void 0);
MlProfileCardMolecule = __decorate([
    customElement('groupviewcard--ml-profile-card')
], MlProfileCardMolecule);
export { MlProfileCardMolecule };
