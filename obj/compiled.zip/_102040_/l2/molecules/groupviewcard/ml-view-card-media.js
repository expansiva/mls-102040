var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewcard/ml-view-card-media.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML VIEW CARD MEDIA MOLECULE
// =============================================================================
// Skill Group: groupViewCard
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
let MlViewCardMediaMolecule = class MlViewCardMediaMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewcard--ml-view-card-media .ml-card {
  background: var(--surface-bg, #fff);
  color: var(--text-strong, #1c1b1f);
  border-color: var(--border-default, #e2e8f0);
  border-width: var(--ml-border-width, 1px);
  border-style: var(--ml-border-style, solid);
  border-radius: var(--radius-medium, 8px);
}
groupviewcard--ml-view-card-media .ml-card-header {
  border-color: var(--selected-border, #3b82f6);
}
groupviewcard--ml-view-card-media .ml-card-media {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewcard--ml-view-card-media .ml-card:hover {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewcard--ml-view-card-media .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupviewcard--ml-view-card-media .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewcard--ml-view-card-media .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupviewcard--ml-view-card-media .ml-skeleton {
  background: var(--ml-outline-variant, #e2e8f0);
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];
        /**
         * Onda 3 — mista: `CardFooter` e `CardAction` são CONTROLE e viraram vivos; os demais são
         * conteúdo/dado e seguem no snapshot. Sem migração total: a Etapa 0 tirou o atalho de inércia do
         * `_checkIfInert`, e a projeção dá precisão por slot sozinha, então os dois caminhos convivem na
         * mesma molécula (verificado em 2026-08-06 na `ml-scan-code`, que tem `Trigger` vivo e `Result`
         * serializado sem duplicar nada).
         */
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.clickable = false;
        this.selected = false;
        this.disabled = false;
        this.loading = false;
        this.isEditing = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.mediaFailed = false;
        this.handledMediaElements = new WeakSet();
        this.handleMediaError = () => {
            this.mediaFailed = true;
            this.requestUpdate();
        };
        this.handleMediaLoad = () => {
            this.mediaFailed = false;
            this.requestUpdate();
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    updated(changedProps) {
        if (changedProps.has('isEditing')) {
            this.applyEditingState();
        }
        this.attachMediaListeners();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleCardClick() {
        if (!this.isInteractive())
            return;
        this.dispatchEvent(new CustomEvent('cardClick', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    handleKeyDown(event) {
        if (!this.isInteractive())
            return;
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleCardClick();
        }
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        if (this.loading) {
            return this.renderSkeleton();
        }
        const cardClasses = this.getCardClasses();
        const interactive = this.isInteractive();
        return html `
<div
class="${cardClasses}"
role=${ifDefined(interactive ? 'button' : undefined)}
tabindex=${ifDefined(interactive ? '0' : undefined)}
aria-disabled=${ifDefined(this.disabled ? 'true' : undefined)}
aria-selected=${ifDefined(this.selected ? 'true' : undefined)}
@click=${this.handleCardClick}
@keydown=${this.handleKeyDown}
>
${this.renderMediaSection()}
${this.renderBodySection()}
</div>
`;
    }
    // ===========================================================================
    // RENDER SECTIONS
    // ===========================================================================
    renderMediaSection() {
        const ratioClass = this.getMediaRatioClass();
        const mediaContent = this.getSlotContent('CardHeader').trim();
        const hasMedia = mediaContent.length > 0;
        const showPlaceholder = !hasMedia || this.mediaFailed;
        const placeholderClasses = cn('absolute inset-0', 'ml-card-media');
        const mediaContentClasses = [
            'absolute inset-0 w-full h-full',
            '[&_img]:w-full [&_img]:h-full [&_img]:object-cover',
            '[&_video]:w-full [&_video]:h-full [&_video]:object-cover',
        ].join(' ');
        return html `
<div class="w-full ${ratioClass} relative overflow-hidden">
<div class="${placeholderClasses} ${showPlaceholder ? '' : 'hidden'}" aria-hidden="true"></div>
${showPlaceholder
            ? html ``
            : html `<div data-media-slot class="${mediaContentClasses}">${unsafeHTML(mediaContent)}</div>`}
</div>
`;
    }
    renderBodySection() {
        const hasHeader = this.hasSlotContent('CardTitle') || this.hasSlotContent('CardDescription');
        const hasContent = this.hasSlotContent('CardContent');
        // `hasSlot`, e não `hasSlotContent`: estes dois são VIVOS, a origem esvazia depois da projeção e
        // o `hasSlotContent` passaria a devolver falso — a seção inteira do corpo sumiria da tela a
        // partir do segundo render, levando junto a âncora do rodapé. Os de cima continuam por conteúdo
        // porque seguem serializados.
        const hasFooter = this.hasSlot('CardFooter') || this.hasSlot('CardAction');
        if (!hasHeader && !hasContent && !hasFooter) {
            return html ``;
        }
        return html `
<div class="p-4 space-y-4">
${this.renderHeaderText()}
${this.renderContentSection()}
${this.renderFooterSection()}
</div>
`;
    }
    renderHeaderText() {
        const title = this.getSlotContent('CardTitle').trim();
        const description = this.getSlotContent('CardDescription').trim();
        if (!title && !description)
            return html ``;
        return html `
<div class="space-y-1">
${title
            ? html `<div class="${cn('text-base font-semibold ml-label', this.getSlotClass('CardTitle'))}">${unsafeHTML(title)}</div>`
            : html ``}
${description
            ? html `<div class="${cn('text-sm ml-text-muted', this.getSlotClass('CardDescription'))}">${unsafeHTML(description)}</div>`
            : html ``}
</div>
`;
    }
    renderContentSection() {
        const content = this.getSlotContent('CardContent').trim();
        if (!content)
            return html ``;
        return html `
<div class="${cn('text-sm ml-text-muted', this.getSlotClass('CardContent'))}">${unsafeHTML(content)}</div>
`;
    }
    /**
     * Rodapé e ação: os DOIS slots de controle desta molécula, agora VIVOS (Onda 3).
     *
     * ⚠️ A presença passou a ser lida por `hasSlot`, e a troca é obrigatória, não estilo: com slot
     * vivo os nós são MOVIDOS para a âncora e a origem fica VAZIA, então `getSlotContent('CardFooter')`
     * devolve string vazia a partir do segundo render — o ternário deixaria de emitir a âncora e o
     * conteúdo do consumidor sumiria da tela. `hasSlot` olha se o slot TAG existe, não o conteúdo
     * dele, e por isso continua verdadeiro depois da projeção.
     *
     * Os slots de DADO (`CardHeader` com o `ratio`, `CardTitle`, `CardDescription`, `CardContent`)
     * seguem no snapshot de propósito — é a régua DADO × CONTROLE da TASK.
     */
    renderFooterSection() {
        const hasFooter = this.hasSlot('CardFooter');
        const hasAction = this.hasSlot('CardAction');
        if (!hasFooter && !hasAction)
            return html ``;
        const containerClasses = [
            'flex flex-wrap items-center gap-3',
            hasFooter ? 'justify-between' : 'justify-end',
        ].join(' ');
        return html `
<div class="${containerClasses}">
${hasFooter ? html `<div class="${cn('text-sm ml-text-muted', this.getSlotClass('CardFooter'))}">${this.renderLiveSlot('CardFooter')}</div>` : html ``}
${hasAction ? html `<div class="shrink-0">${this.renderLiveSlot('CardAction')}</div>` : html ``}
</div>
`;
    }
    renderSkeleton() {
        const ratioClass = this.getMediaRatioClass();
        const skeletonClasses = cn('animate-pulse', 'w-full rounded-xl border overflow-hidden', 'ml-card');
        const blockClasses = 'ml-skeleton rounded';
        return html `
<div class="${skeletonClasses}" aria-hidden="true">
<div class="w-full ${ratioClass} ${blockClasses}"></div>
<div class="p-4 space-y-3">
<div class="h-4 w-3/4 ${blockClasses}"></div>
<div class="h-3 w-2/3 ${blockClasses}"></div>
<div class="h-20 w-full ${blockClasses}"></div>
</div>
</div>
`;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getMediaRatioClass() {
        const ratio = (this.getSlotAttr('CardHeader', 'ratio') || '16:9').trim();
        if (ratio === '4:3')
            return 'aspect-[4/3]';
        if (ratio === '1:1')
            return 'aspect-square';
        return 'aspect-[16/9]';
    }
    hasSlotContent(tag) {
        const content = this.getSlotContent(tag).trim();
        return content.length > 0;
    }
    isInteractive() {
        return this.clickable && !this.disabled && !this.loading;
    }
    getCardClasses() {
        const isSelected = this.selected && !this.disabled && !this.loading;
        return cn('w-full rounded-xl border overflow-hidden transition', 'ml-card', isSelected ? 'ml-card-header' : '', this.isInteractive()
            ? 'cursor-pointer focus:outline-none focus:ring-2'
            : '', this.disabled ? 'ml-disabled' : '', this.cssClass);
    }
    attachMediaListeners() {
        const container = this.querySelector('[data-media-slot]');
        if (!container)
            return;
        const mediaElements = container.querySelectorAll('img, video');
        mediaElements.forEach((el) => {
            if (this.handledMediaElements.has(el))
                return;
            this.handledMediaElements.add(el);
            el.addEventListener('error', this.handleMediaError);
            el.addEventListener('load', this.handleMediaLoad);
        });
    }
    applyEditingState() {
        const elements = Array.from(this.querySelectorAll('*'));
        for (const el of elements) {
            if (el === this)
                continue;
            if (!el.tagName.includes('-'))
                continue;
            if (this.isEditing) {
                el.setAttribute('is-editing', '');
            }
            else {
                el.removeAttribute('is-editing');
            }
        }
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "clickable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "selected", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlViewCardMediaMolecule.prototype, "isEditing", void 0);
__decorate([
    state()
], MlViewCardMediaMolecule.prototype, "mediaFailed", void 0);
MlViewCardMediaMolecule = __decorate([
    customElement('groupviewcard--ml-view-card-media')
], MlViewCardMediaMolecule);
export { MlViewCardMediaMolecule };
