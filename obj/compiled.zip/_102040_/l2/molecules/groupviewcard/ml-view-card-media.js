var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewcard/ml-view-card-media.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML VIEW CARD MEDIA MOLECULE
// =============================================================================
// Skill Group: groupViewCard
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let MlViewCardMediaMolecule = class MlViewCardMediaMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['CardHeader', 'CardTitle', 'CardDescription', 'CardContent', 'CardFooter', 'CardAction'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.clickable = false;
        this.selected = false;
        this.disabled = false;
        this.loading = false;
        this.isEditing = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.mediaFailed = false;
        this.handledMediaElements = new WeakSet();
        this.handleMediaError = () => {
            this.mediaFailed = true;
            this.requestUpdate();
        };
        this.handleMediaLoad = () => {
            this.mediaFailed = false;
            this.requestUpdate();
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    updated(changedProps) {
        if (changedProps.has('isEditing')) {
            this.applyEditingState();
        }
        this.attachMediaListeners();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleCardClick() {
        if (!this.isInteractive())
            return;
        this.dispatchEvent(new CustomEvent('cardClick', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    handleKeyDown(event) {
        if (!this.isInteractive())
            return;
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handleCardClick();
        }
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        if (this.loading) {
            return this.renderSkeleton();
        }
        const cardClasses = this.getCardClasses();
        const interactive = this.isInteractive();
        return html `
<div
class="${cardClasses}"
role=${ifDefined(interactive ? 'button' : undefined)}
tabindex=${ifDefined(interactive ? '0' : undefined)}
aria-disabled=${ifDefined(this.disabled ? 'true' : undefined)}
aria-selected=${ifDefined(this.selected ? 'true' : undefined)}
@click=${this.handleCardClick}
@keydown=${this.handleKeyDown}
>
${this.renderMediaSection()}
${this.renderBodySection()}
</div>
`;
    }
    // ===========================================================================
    // RENDER SECTIONS
    // ===========================================================================
    renderMediaSection() {
        const ratioClass = this.getMediaRatioClass();
        const mediaContent = this.getSlotContent('CardHeader').trim();
        const hasMedia = mediaContent.length > 0;
        const showPlaceholder = !hasMedia || this.mediaFailed;
        const placeholderClasses = [
            'absolute inset-0',
            'bg-slate-100 dark:bg-slate-700',
        ].join(' ');
        const mediaContentClasses = [
            'absolute inset-0 w-full h-full',
            '[&_img]:w-full [&_img]:h-full [&_img]:object-cover',
            '[&_video]:w-full [&_video]:h-full [&_video]:object-cover',
        ].join(' ');
        return html `
<div class="w-full ${ratioClass} relative overflow-hidden">
<div class="${placeholderClasses} ${showPlaceholder ? '' : 'hidden'}" aria-hidden="true"></div>
${showPlaceholder
            ? html ``
            : html `<div data-media-slot class="${mediaContentClasses}">${unsafeHTML(mediaContent)}</div>`}
</div>
`;
    }
    renderBodySection() {
        const hasHeader = this.hasSlotContent('CardTitle') || this.hasSlotContent('CardDescription');
        const hasContent = this.hasSlotContent('CardContent');
        const hasFooter = this.hasSlotContent('CardFooter') || this.hasSlotContent('CardAction');
        if (!hasHeader && !hasContent && !hasFooter) {
            return html ``;
        }
        return html `
<div class="p-4 space-y-4">
${this.renderHeaderText()}
${this.renderContentSection()}
${this.renderFooterSection()}
</div>
`;
    }
    renderHeaderText() {
        const title = this.getSlotContent('CardTitle').trim();
        const description = this.getSlotContent('CardDescription').trim();
        if (!title && !description)
            return html ``;
        return html `
<div class="space-y-1">
${title
            ? html `<div class="text-base font-semibold text-slate-900 dark:text-slate-100">${unsafeHTML(title)}</div>`
            : html ``}
${description
            ? html `<div class="text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(description)}</div>`
            : html ``}
</div>
`;
    }
    renderContentSection() {
        const content = this.getSlotContent('CardContent').trim();
        if (!content)
            return html ``;
        return html `
<div class="text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(content)}</div>
`;
    }
    renderFooterSection() {
        const footer = this.getSlotContent('CardFooter').trim();
        const action = this.getSlotContent('CardAction').trim();
        if (!footer && !action)
            return html ``;
        const containerClasses = [
            'flex flex-wrap items-center gap-3',
            footer ? 'justify-between' : 'justify-end',
        ].join(' ');
        return html `
<div class="${containerClasses}">
${footer ? html `<div class="text-sm text-slate-500 dark:text-slate-400">${unsafeHTML(footer)}</div>` : html ``}
${action ? html `<div class="shrink-0">${unsafeHTML(action)}</div>` : html ``}
</div>
`;
    }
    renderSkeleton() {
        const ratioClass = this.getMediaRatioClass();
        const skeletonClasses = [
            'animate-pulse',
            'w-full rounded-xl border overflow-hidden',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
        ].join(' ');
        const blockClasses = 'bg-slate-200 dark:bg-slate-700 rounded';
        return html `
<div class="${skeletonClasses}" aria-hidden="true">
<div class="w-full ${ratioClass} ${blockClasses}"></div>
<div class="p-4 space-y-3">
<div class="h-4 w-3/4 ${blockClasses}"></div>
<div class="h-3 w-2/3 ${blockClasses}"></div>
<div class="h-20 w-full ${blockClasses}"></div>
</div>
</div>
`;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getMediaRatioClass() {
        const ratio = (this.getSlotAttr('CardHeader', 'ratio') || '16:9').trim();
        if (ratio === '4:3')
            return 'aspect-[4/3]';
        if (ratio === '1:1')
            return 'aspect-square';
        return 'aspect-[16/9]';
    }
    hasSlotContent(tag) {
        const content = this.getSlotContent(tag).trim();
        return content.length > 0;
    }
    isInteractive() {
        return this.clickable && !this.disabled && !this.loading;
    }
    getCardClasses() {
        const isSelected = this.selected && !this.disabled && !this.loading;
        return [
            'w-full rounded-xl border overflow-hidden transition',
            'bg-white dark:bg-slate-800',
            'text-slate-900 dark:text-slate-100',
            isSelected ? 'border-sky-500 dark:border-sky-400' : 'border-slate-200 dark:border-slate-700',
            this.isInteractive()
                ? 'cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-700 focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400'
                : '',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    attachMediaListeners() {
        const container = this.querySelector('[data-media-slot]');
        if (!container)
            return;
        const mediaElements = container.querySelectorAll('img, video');
        mediaElements.forEach((el) => {
            if (this.handledMediaElements.has(el))
                return;
            this.handledMediaElements.add(el);
            el.addEventListener('error', this.handleMediaError);
            el.addEventListener('load', this.handleMediaLoad);
        });
    }
    applyEditingState() {
        const elements = Array.from(this.querySelectorAll('*'));
        for (const el of elements) {
            if (el === this)
                continue;
            if (!el.tagName.includes('-'))
                continue;
            if (this.isEditing) {
                el.setAttribute('is-editing', '');
            }
            else {
                el.removeAttribute('is-editing');
            }
        }
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "clickable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "selected", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlViewCardMediaMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlViewCardMediaMolecule.prototype, "isEditing", void 0);
__decorate([
    state()
], MlViewCardMediaMolecule.prototype, "mediaFailed", void 0);
MlViewCardMediaMolecule = __decorate([
    customElement('groupviewcard--ml-view-card-media')
], MlViewCardMediaMolecule);
export { MlViewCardMediaMolecule };
