var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouprateitem/ml-qualitative-feedback-tags.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// QUALITATIVE FEEDBACK TAGS MOLECULE
// =============================================================================
// Skill Group: groupRateItem
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
/// **collab_i18n_start**
const message_en = {
    required: 'Required',
};
const messages = {
    en: message_en,
    pt: {
        required: 'Obrigatório',
    },
};
/// **collab_i18n_end**
let QualitativeFeedbackTagsMolecule = class QualitativeFeedbackTagsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-qualitative-feedback-tags .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-qualitative-feedback-tags .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-qualitative-feedback-tags .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-qualitative-feedback-tags .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
grouprateitem--ml-qualitative-feedback-tags .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-qualitative-feedback-tags .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-qualitative-feedback-tags .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-qualitative-feedback-tags .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
grouprateitem--ml-qualitative-feedback-tags .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouprateitem--ml-qualitative-feedback-tags .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
grouprateitem--ml-qualitative-feedback-tags .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
grouprateitem--ml-qualitative-feedback-tags .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
grouprateitem--ml-qualitative-feedback-tags .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
grouprateitem--ml-qualitative-feedback-tags .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
grouprateitem--ml-qualitative-feedback-tags .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
grouprateitem--ml-qualitative-feedback-tags .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouprateitem--ml-qualitative-feedback-tags .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
grouprateitem--ml-qualitative-feedback-tags .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = 0;
        this.max = 5;
        this.step = 1;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.hoverValue = null;
        this.labelId = `label-${Math.floor(Math.random() * 1000000)}`;
        this.errorId = `error-${Math.floor(Math.random() * 1000000)}`;
        this.hasFocus = false;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleSelect(value) {
        if (this.disabled || this.readonly)
            return;
        this.value = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleFocusIn() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        if (this.hasFocus)
            return;
        this.hasFocus = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleFocusOut(e) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        const related = e.relatedTarget;
        if (related && this.contains(related))
            return;
        this.hasFocus = false;
        this.hoverValue = null;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleKeydown(e, items) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        if (!items.length)
            return;
        const keys = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Enter', ''];
        if (!keys.includes(e.key))
            return;
        e.preventDefault();
        const target = e.target;
        const targetIndex = target?.getAttribute('data-option-index');
        const currentIndex = targetIndex ? Number(targetIndex) : this.getActiveIndex(items);
        if (e.key === 'Enter' || e.key === '') {
            const item = items[currentIndex] ?? items[0];
            if (item)
                this.handleSelect(item.value);
            return;
        }
        const delta = e.key === 'ArrowRight' || e.key === 'ArrowDown' ? 1 : -1;
        const nextIndex = Math.min(items.length - 1, Math.max(0, currentIndex + delta));
        const nextItem = items[nextIndex];
        const nextEl = this.querySelector(`[data-option-index="${nextIndex}"]`);
        if (nextItem) {
            this.hoverValue = nextItem.value;
        }
        nextEl?.focus();
    }
    handleOptionEnter(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = value;
    }
    handleOptionLeave() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = null;
    }
    handleOptionFocus(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = value;
    }
    handleOptionBlur() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = null;
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    getItems() {
        const slotItems = this.getSlots('Item');
        if (slotItems.length > 0) {
            const items = slotItems
                .map((el) => {
                const value = Number(el.getAttribute('value'));
                if (Number.isNaN(value))
                    return null;
                const label = el.innerHTML;
                const ariaLabel = el.getAttribute('aria-label') || el.textContent?.trim() || String(value);
                return { value, label, ariaLabel };
            })
                .filter((item) => item !== null);
            return { items, isCustom: true };
        }
        const items = [];
        for (let v = this.min; v <= this.max; v += this.step) {
            items.push({ value: v, label: String(v), ariaLabel: String(v) });
        }
        return { items, isCustom: false };
    }
    getActiveIndex(items) {
        if (!items.length)
            return 0;
        const activeValue = this.value ?? items[0].value;
        const index = items.findIndex((item) => item.value === activeValue);
        return index >= 0 ? index : 0;
    }
    getDisplayValue(items) {
        if (this.value === null) {
            return html `<span class="ml-text-faint">—</span>`;
        }
        if (items.isCustom) {
            const selected = items.items.find((item) => item.value === this.value);
            if (selected) {
                return html `<span class="ml-text">${unsafeHTML(selected.label)}</span>`;
            }
        }
        return html `<span class="ml-text">${String(this.value)}</span>`;
    }
    getOptionClasses(isActive, isSelected, hasError) {
        return [
            'flex items-center justify-center rounded-md px-3 py-2 text-sm border transition cursor-pointer',
            'ml-surface-bg',
            'ml-text',
            hasError ? 'ml-border-error' : 'ml-border',
            isActive || isSelected
                ? 'ml-primary-dim-bg ml-primary-text ml-border-focus'
                : 'hover:ml-surface-dim-bg',
            this.disabled || this.readonly ? 'ml-disabled' : '',
            !this.disabled && !this.readonly ? '' : '',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
 <div id="${this.labelId}" class="${cn('mb-2 text-sm font-medium ml-text-muted', this.getSlotClass('Label'))}">
 ${unsafeHTML(this.getSlotContent('Label'))}
 </div>
 `;
    }
    renderFeedback(hasError, errorMessage) {
        if (!this.isEditing)
            return html ``;
        if (hasError) {
            return html `<p id="${this.errorId}" class="mt-1 text-xs ml-error-text">${unsafeHTML(errorMessage)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="${cn('mt-1 text-xs ml-text-muted', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderViewMode(items) {
        return html `
 <div class="${cn('flex flex-col', this.cssClass)}">
 ${this.renderLabel()}
 <div class="text-sm ml-text">
 ${this.getDisplayValue(items)}
 </div>
 </div>
 `;
    }
    renderEditMode(itemsSet) {
        const items = itemsSet.items;
        const requiredError = this.required && this.value === null;
        const errorMessage = this.error || (requiredError ? this.msg.required : '');
        const hasError = errorMessage !== '';
        const activeValue = this.hoverValue !== null ? this.hoverValue : this.value;
        return html `
 <div class="${cn('flex flex-col', this.cssClass)}">
 ${this.renderLabel()}
 <div
 class="flex flex-row items-center gap-2"
 role="radiogroup"
 aria-labelledby="${this.hasSlot('Label') ? this.labelId : ''}"
 aria-describedby="${hasError ? this.errorId : ''}"
 aria-invalid="${hasError ? 'true' : 'false'}"
 aria-required="${this.required ? 'true' : 'false'}"
 aria-readonly="${this.readonly ? 'true' : 'false'}"
 @focusin=${this.handleFocusIn}
 @focusout=${this.handleFocusOut}
 @keydown=${(e) => this.handleKeydown(e, items)}
 >
 ${items.map((item, index) => {
            const isSelected = this.value === item.value;
            const isActive = activeValue === item.value;
            const isTabbable = index === this.getActiveIndex(items);
            const content = itemsSet.isCustom ? unsafeHTML(item.label) : item.label;
            return html `
 <button
 type="button"
 class="${this.getOptionClasses(isActive, isSelected, hasError)}"
 role="radio"
 aria-checked="${isSelected ? 'true' : 'false'}"
 aria-label="${item.ariaLabel}"
 aria-disabled="${this.disabled ? 'true' : 'false'}"
 tabindex="${isTabbable ? 0 : -1}"
 data-option-index="${index}"
 @mouseenter=${() => this.handleOptionEnter(item.value)}
 @mouseleave=${this.handleOptionLeave}
 @focus=${() => this.handleOptionFocus(item.value)}
 @blur=${this.handleOptionBlur}
 @click=${() => this.handleSelect(item.value)}
 >
 ${content}
 </button>
 `;
        })}
 </div>
 ${this.renderFeedback(hasError, errorMessage)}
 </div>
 `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const itemsSet = this.getItems();
        if (!this.isEditing) {
            return this.renderViewMode(itemsSet);
        }
        return this.renderEditMode(itemsSet);
    }
};
__decorate([
    propertyDataSource({ type: Number })
], QualitativeFeedbackTagsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], QualitativeFeedbackTagsMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], QualitativeFeedbackTagsMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], QualitativeFeedbackTagsMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], QualitativeFeedbackTagsMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], QualitativeFeedbackTagsMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], QualitativeFeedbackTagsMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], QualitativeFeedbackTagsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], QualitativeFeedbackTagsMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], QualitativeFeedbackTagsMolecule.prototype, "required", void 0);
__decorate([
    state()
], QualitativeFeedbackTagsMolecule.prototype, "hoverValue", void 0);
QualitativeFeedbackTagsMolecule = __decorate([
    customElement('grouprateitem--ml-qualitative-feedback-tags')
], QualitativeFeedbackTagsMolecule);
export { QualitativeFeedbackTagsMolecule };
