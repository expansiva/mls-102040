/// <mls fileReference="_102040_/l2/molecules/grouprateitem/ml-csat-rating.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CSAT RATING MOLECULE
// =============================================================================
// Skill Group: groupRateItem
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    noSelection: '—',
    score: 'Score',
};
const messages = {
    en: message_en,
    pt: {
        noSelection: '—',
        score: 'Pontuação',
    },
};
let CsatRatingMolecule = class CsatRatingMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-csat-rating .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-csat-rating .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-csat-rating .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-csat-rating .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
grouprateitem--ml-csat-rating .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-csat-rating .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-csat-rating .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-csat-rating .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
grouprateitem--ml-csat-rating .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouprateitem--ml-csat-rating .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
grouprateitem--ml-csat-rating .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
grouprateitem--ml-csat-rating .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
grouprateitem--ml-csat-rating .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
grouprateitem--ml-csat-rating .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
grouprateitem--ml-csat-rating .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
grouprateitem--ml-csat-rating .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouprateitem--ml-csat-rating .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
grouprateitem--ml-csat-rating .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        // Data
        this.value = null;
        this.error = '';
        this.name = '';
        // Configuration
        this.min = 1;
        this.max = 5;
        this.step = 1;
        // States
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.hoverValue = null;
        this.focusedIndex = -1;
        // ===========================================================================
        // LIFECYCLE
        // ===========================================================================
        this.labelId = `csat-label-${Math.random().toString(36).slice(2, 9)}`;
        this.errorId = `csat-error-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // ITEM PARSING
    // ===========================================================================
    getItems() {
        const slotItems = this.getSlots('Item');
        if (slotItems.length > 0) {
            return slotItems.map(el => ({
                value: Number(el.getAttribute('value')),
                label: el.innerHTML,
            }));
        }
        // Auto-generate from min to max
        const items = [];
        for (let v = this.min; v <= this.max; v += this.step) {
            items.push({ value: v, label: String(v) });
        }
        return items;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleSelect(itemValue) {
        if (this.disabled || this.readonly || !this.isEditing)
            return;
        this.value = itemValue;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleMouseEnter(itemValue) {
        if (this.disabled || this.readonly || !this.isEditing)
            return;
        this.hoverValue = itemValue;
    }
    handleMouseLeave() {
        if (!this.isEditing)
            return;
        this.hoverValue = null;
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.focusedIndex = -1;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    handleKeyDown(e, items, index) {
        if (this.disabled || this.readonly || !this.isEditing)
            return;
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            e.preventDefault();
            const nextIndex = Math.min(index + 1, items.length - 1);
            this.focusedIndex = nextIndex;
            this.focusOption(nextIndex);
        }
        else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            e.preventDefault();
            const prevIndex = Math.max(index - 1, 0);
            this.focusedIndex = prevIndex;
            this.focusOption(prevIndex);
        }
        else if (e.key === 'Enter' || e.key === '') {
            e.preventDefault();
            this.handleSelect(items[index].value);
        }
    }
    focusOption(index) {
        const options = this.querySelectorAll('[role="radio"]');
        if (options[index]) {
            options[index].focus();
        }
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getContainerClasses() {
        return [
            'flex flex-col gap-2',
        ].join(' ');
    }
    getOptionsContainerClasses() {
        return [
            'flex items-center gap-2',
        ].join(' ');
    }
    getOptionClasses(item, index) {
        const isSelected = this.value === item.value;
        const isHovered = this.hoverValue === item.value;
        const isInteractive = this.isEditing && !this.disabled && !this.readonly;
        return [
            'flex flex-col items-center justify-center gap-1 p-3 rounded-lg border-2 transition-all duration-200',
            'min-w-[72px] text-center',
            // Base colors
            'ml-surface-bg',
            // Selection state
            isSelected
                ? 'ml-border-focus ml-primary-dim-bg'
                : 'ml-border',
            // Hover state (only in edit mode)
            isInteractive && isHovered && !isSelected
                ? 'ml-border-focus ml-surface-dim-bg'
                : '',
            // Interactive states
            isInteractive
                ? 'cursor-pointer hover:shadow-md'
                : '',
            // Disabled state
            this.disabled
                ? 'ml-disabled'
                : '',
            // Readonly state
            this.readonly && !this.disabled
                ? 'cursor-default'
                : '',
            '',
            // Error state
            this.error && this.isEditing && !isSelected
                ? 'ml-border-error'
                : '',
        ].filter(Boolean).join(' ');
    }
    getIconClasses(item) {
        const isSelected = this.value === item.value;
        const isHovered = this.hoverValue === item.value;
        return [
            'text-2xl transition-transform duration-200',
            isSelected || isHovered ? 'scale-110' : '',
        ].filter(Boolean).join(' ');
    }
    getLabelTextClasses(item) {
        const isSelected = this.value === item.value;
        return [
            'text-xs font-medium transition-colors',
            isSelected
                ? 'ml-primary-text'
                : 'ml-text-muted',
        ].join(' ');
    }
    getScoreClasses() {
        return [
            'flex items-center gap-2 px-3 py-2 rounded-lg',
            'ml-surface-dim-bg',
            'text-sm font-semibold',
            'ml-text',
        ].join(' ');
    }
    getLabelClasses() {
        return [
            'text-sm font-medium',
            'ml-text',
        ].join(' ');
    }
    getHelperClasses() {
        return [
            'text-xs',
            'ml-text-muted',
        ].join(' ');
    }
    getErrorClasses() {
        return [
            'text-xs',
            'ml-error-text',
        ].join(' ');
    }
    getViewModeClasses() {
        return [
            'ml-text-muted',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label')) {
            return html ``;
        }
        return html `
 <div id="${this.labelId}" class="${cn(this.getLabelClasses(), this.getSlotClass('Label'))}">
 ${unsafeHTML(this.getSlotContent('Label'))}
 ${this.required && this.isEditing ? html `<span class="ml-error-text ml-1">*</span>` : html ``}
 </div>
 `;
    }
    renderHelper() {
        if (!this.isEditing || !this.hasSlot('Helper')) {
            return html ``;
        }
        return html `
 <div class="${cn(this.getHelperClasses(), this.getSlotClass('Helper'))}">
 ${unsafeHTML(this.getSlotContent('Helper'))}
 </div>
 `;
    }
    renderError() {
        if (!this.isEditing || !this.error) {
            return html ``;
        }
        return html `
 <div id="${this.errorId}" class="${this.getErrorClasses()}" role="alert">
 ${this.error}
 </div>
 `;
    }
    renderScore() {
        if (this.value === null) {
            return html ``;
        }
        return html `
 <div class="${this.getScoreClasses()}">
 <span>${this.msg.score}:</span>
 <span class="ml-primary-text">${this.value}</span>
 </div>
 `;
    }
    renderOption(item, index, items) {
        const isSelected = this.value === item.value;
        const isInteractive = this.isEditing && !this.disabled && !this.readonly;
        return html `
 <div
 role="radio"
 aria-checked="${isSelected}"
 aria-label="${item.value}"
 tabindex="${isInteractive ? (isSelected || (this.value === null && index === 0) ? '0' : '-1') : '-1'}"
 class="${this.getOptionClasses(item, index)}"
 @click="${() => this.handleSelect(item.value)}"
 @mouseenter="${() => this.handleMouseEnter(item.value)}"
 @mouseleave="${this.handleMouseLeave}"
 @keydown="${(e) => this.handleKeyDown(e, items, index)}"
 @focus="${this.handleFocus}"
 @blur="${this.handleBlur}"
 >
 <span class="${this.getIconClasses(item)}">
 ${unsafeHTML(item.label)}
 </span>
 </div>
 `;
    }
    renderViewMode() {
        if (this.value === null) {
            return html `
 <div class="${cn(this.getContainerClasses(), this.cssClass)}">
 ${this.renderLabel()}
 <div class="${this.getViewModeClasses()}">
 ${this.msg.noSelection}
 </div>
 </div>
 `;
        }
        const items = this.getItems();
        const selectedItem = items.find(item => item.value === this.value);
        return html `
 <div class="${cn(this.getContainerClasses(), this.cssClass)}">
 ${this.renderLabel()}
 <div class="${this.getOptionsContainerClasses()}">
 ${selectedItem ? html `
 <div class="flex flex-col items-center justify-center gap-1 p-3 rounded-lg border-2 ml-border-focus ml-primary-dim-bg min-w-[72px]">
 <span class="text-2xl">
 ${unsafeHTML(selectedItem.label)}
 </span>
 </div>
 ` : html ``}
 ${this.renderScore()}
 </div>
 </div>
 `;
    }
    renderEditMode() {
        const items = this.getItems();
        const hasError = !!this.error;
        return html `
 <div class="${cn(this.getContainerClasses(), this.cssClass)}">
 ${this.renderLabel()}
 <div
 role="radiogroup"
 aria-labelledby="${this.hasSlot('Label') ? this.labelId : ''}"
 aria-describedby="${hasError ? this.errorId : ''}"
 aria-invalid="${hasError}"
 aria-required="${this.required}"
 class="${this.getOptionsContainerClasses()}"
 >
 ${items.map((item, index) => this.renderOption(item, index, items))}
 ${this.renderScore()}
 </div>
 ${this.renderError()}
 ${!this.error ? this.renderHelper() : html ``}
 </div>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
};
__decorate([
    propertyDataSource({ type: Number })
], CsatRatingMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], CsatRatingMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], CsatRatingMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], CsatRatingMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], CsatRatingMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], CsatRatingMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], CsatRatingMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CsatRatingMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CsatRatingMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CsatRatingMolecule.prototype, "required", void 0);
__decorate([
    state()
], CsatRatingMolecule.prototype, "hoverValue", void 0);
__decorate([
    state()
], CsatRatingMolecule.prototype, "focusedIndex", void 0);
CsatRatingMolecule = __decorate([
    customElement('grouprateitem--ml-csat-rating')
], CsatRatingMolecule);
export { CsatRatingMolecule };
