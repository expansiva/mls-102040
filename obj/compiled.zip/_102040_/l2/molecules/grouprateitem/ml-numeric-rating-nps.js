var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouprateitem/ml-numeric-rating-nps.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NUMERIC RATING NPS MOLECULE
// =============================================================================
// Skill Group: groupRateItem
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    emptyValue: '—',
};
const messages = {
    en: message_en,
    pt: {
        emptyValue: '—',
    },
};
let NumericRatingNpsMolecule = class NumericRatingNpsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-numeric-rating-nps .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
grouprateitem--ml-numeric-rating-nps .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-numeric-rating-nps .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-numeric-rating-nps .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-numeric-rating-nps .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-numeric-rating-nps .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
grouprateitem--ml-numeric-rating-nps .ml-surface {
  background: var(--surface-bg, #ffffff);
}
grouprateitem--ml-numeric-rating-nps .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
grouprateitem--ml-numeric-rating-nps .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
grouprateitem--ml-numeric-rating-nps .ml-focus-ring:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
grouprateitem--ml-numeric-rating-nps .ml-nps-option:hover {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouprateitem--ml-numeric-rating-nps .ml-nps-option-selected {
  background: var(--selected-bg, #f5f5f5);
  color: var(--selected-text, #3b82f6);
  border-color: var(--selected-border, #3b82f6);
}
`);
        this.msg = messages.en;
        this.uid = `nps-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = 0;
        this.max = 5;
        this.step = 1;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.hoverValue = null;
        this.focusedIndex = null;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleOptionClick(item) {
        if (this.disabled || this.readonly || !this.isEditing)
            return;
        const nextValue = this.value === item.value ? null : item.value;
        this.value = nextValue;
        this.hoverValue = null;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleOptionFocus(index) {
        if (!this.isEditing)
            return;
        this.focusedIndex = index;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleOptionBlur() {
        if (!this.isEditing)
            return;
        this.focusedIndex = null;
        this.hoverValue = null;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleOptionMouseEnter(item) {
        if (this.disabled || this.readonly || !this.isEditing)
            return;
        this.hoverValue = item.value;
    }
    handleOptionMouseLeave() {
        if (this.disabled || this.readonly || !this.isEditing)
            return;
        this.hoverValue = null;
    }
    handleKeyDown(event, items) {
        if (this.disabled || this.readonly || !this.isEditing)
            return;
        if (items.length === 0)
            return;
        const key = event.key;
        const isArrow = key === 'ArrowRight' || key === 'ArrowLeft' || key === 'ArrowDown' || key === 'ArrowUp';
        const isSelect = key === 'Enter' || key === ' ';
        if (!isArrow && !isSelect)
            return;
        event.preventDefault();
        let index = this.focusedIndex;
        if (index === null) {
            index = this.getSelectedIndex(items);
        }
        if (index === null)
            index = 0;
        if (isArrow) {
            const dir = key === 'ArrowRight' || key === 'ArrowDown' ? 1 : -1;
            const nextIndex = Math.min(items.length - 1, Math.max(0, index + dir));
            this.focusedIndex = nextIndex;
            this.focusOption(nextIndex);
            return;
        }
        if (isSelect && index !== null) {
            this.handleOptionClick(items[index]);
        }
    }
    focusOption(index) {
        const el = this.querySelector(`[data-index="${index}"]`);
        if (el)
            el.focus();
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getItems() {
        const slotItems = this.getSlots('Item');
        if (slotItems.length > 0) {
            return slotItems
                .map((el) => ({
                value: Number(el.getAttribute('value')),
                label: el.innerHTML || '',
                fromSlot: true,
            }))
                .filter((item) => !Number.isNaN(item.value));
        }
        const items = [];
        const step = this.step || 1;
        if (step <= 0)
            return items;
        let count = 0;
        for (let v = this.min; v <= this.max; v += step) {
            items.push({ value: v, label: String(v), fromSlot: false });
            count += 1;
            if (count > 200)
                break;
        }
        return items;
    }
    getSelectedIndex(items) {
        if (this.value === null)
            return null;
        const idx = items.findIndex((i) => i.value === this.value);
        return idx >= 0 ? idx : null;
    }
    getGroupClasses(hasError) {
        return [
            'rounded-lg border p-2',
            'ml-surface',
            'ml-border',
            hasError ? 'ml-border-error' : '',
            (this.disabled || this.readonly) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getOptionClasses(isActive) {
        return [
            'h-10 w-10 rounded-md border text-sm font-medium transition',
            'ml-focus-ring',
            isActive
                ? 'ml-nps-option-selected'
                : 'ml-surface ml-text ml-border',
            (!this.disabled && !this.readonly) ? 'ml-nps-option cursor-pointer' : 'cursor-not-allowed',
        ].filter(Boolean).join(' ');
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        const content = this.getSlotContent('Label');
        return html `
<div id=${labelId} class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(content)}
</div>
`;
    }
    renderHelperOrError(hasError, errorMessage, helperId, errorId) {
        if (hasError && errorMessage) {
            return html `
<p id=${errorId} class="mt-2 text-xs ml-error-text">
${unsafeHTML(errorMessage)}
</p>
`;
        }
        if (!hasError && this.hasSlot('Helper')) {
            return html `
<p id=${helperId} class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderOptionLabel(item) {
        if (item.fromSlot) {
            const content = item.label || String(item.value);
            return html `${unsafeHTML(content)}`;
        }
        return html `${item.label}`;
    }
    renderViewMode(items) {
        const labelId = `${this.uid}-label`;
        const display = this.getViewDisplayValue(items);
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel(labelId)}
<div class="text-sm ml-text">
${display}
</div>
</div>
`;
    }
    getViewDisplayValue(items) {
        if (this.value === null || this.value === undefined) {
            return html `<span class="ml-text-muted">${this.msg.emptyValue}</span>`;
        }
        const matched = items.find((i) => i.value === this.value);
        if (matched && matched.fromSlot) {
            const content = matched.label || String(this.value);
            return html `${unsafeHTML(content)}`;
        }
        return html `${String(this.value)}`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const items = this.getItems();
        if (!this.isEditing) {
            return this.renderViewMode(items);
        }
        const labelId = `${this.uid}-label`;
        const helperId = `${this.uid}-helper`;
        const errorId = `${this.uid}-error`;
        const hasError = this.error !== '' || (this.required && this.value === null);
        const errorMessage = this.error;
        const describedBy = hasError && errorMessage ? errorId : (!hasError && this.hasSlot('Helper') ? helperId : '');
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel(labelId)}
<div
class=${this.getGroupClasses(hasError)}
role="radiogroup"
aria-labelledby=${this.hasSlot('Label') ? labelId : ''}
aria-describedby=${describedBy}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@keydown=${(e) => this.handleKeyDown(e, items)}
>
${this.name ? html `<input type="hidden" name=${this.name} value=${this.value ?? ''} />` : html ``}
<div class="flex flex-wrap gap-2">
${items.map((item, index) => {
            const isActive = this.hoverValue !== null
                ? item.value === this.hoverValue
                : item.value === this.value;
            const isDisabled = this.disabled || this.readonly;
            return html `
<button
class=${this.getOptionClasses(isActive)}
role="radio"
aria-checked=${item.value === this.value ? 'true' : 'false'}
aria-label=${String(item.value)}
tabindex=${isDisabled ? -1 : (this.focusedIndex === index || (this.focusedIndex === null && item.value === this.value) ? 0 : -1)}
?disabled=${isDisabled}
data-index=${index}
@focus=${() => this.handleOptionFocus(index)}
@blur=${() => this.handleOptionBlur()}
@mouseenter=${() => this.handleOptionMouseEnter(item)}
@mouseleave=${() => this.handleOptionMouseLeave()}
@click=${() => this.handleOptionClick(item)}
>
${this.renderOptionLabel(item)}
</button>
`;
        })}
</div>
</div>
${this.renderHelperOrError(hasError, errorMessage, helperId, errorId)}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], NumericRatingNpsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], NumericRatingNpsMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], NumericRatingNpsMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NumericRatingNpsMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NumericRatingNpsMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], NumericRatingNpsMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], NumericRatingNpsMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NumericRatingNpsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NumericRatingNpsMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NumericRatingNpsMolecule.prototype, "required", void 0);
__decorate([
    state()
], NumericRatingNpsMolecule.prototype, "hoverValue", void 0);
__decorate([
    state()
], NumericRatingNpsMolecule.prototype, "focusedIndex", void 0);
NumericRatingNpsMolecule = __decorate([
    customElement('grouprateitem--ml-numeric-rating-nps')
], NumericRatingNpsMolecule);
export { NumericRatingNpsMolecule };
