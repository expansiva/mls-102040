var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouprateitem/ml-rating-slider.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML RATING SLIDER MOLECULE
// =============================================================================
// Skill Group: groupRateItem
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let MlRatingSliderMolecule = class MlRatingSliderMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = 0;
        this.max = 5;
        this.step = 1;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.hoverValue = null;
        this.uid = `ml-rating-slider-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleOptionClick(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.value = value;
        this.hoverValue = null;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleOptionMouseEnter(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = value;
    }
    handleOptionMouseLeave() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = null;
    }
    handleGroupMouseLeave() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = null;
    }
    handleOptionFocus() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleOptionBlur() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    handleKeyDown(event) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        const options = Array.from(this.querySelectorAll('button[data-role="option"]'));
        if (options.length === 0)
            return;
        const currentIndex = options.findIndex(opt => opt === event.target);
        const valueIndex = this.getIndexFromValue(options, this.value);
        let index = currentIndex >= 0 ? currentIndex : (valueIndex >= 0 ? valueIndex : 0);
        if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
            event.preventDefault();
            const next = Math.min(options.length - 1, index + 1);
            options[next].focus();
            this.previewHoverFromOption(options[next]);
        }
        if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
            event.preventDefault();
            const prev = Math.max(0, index - 1);
            options[prev].focus();
            this.previewHoverFromOption(options[prev]);
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            const option = options[index];
            this.selectValueFromOption(option);
        }
    }
    previewHoverFromOption(option) {
        const value = this.getOptionValue(option);
        if (value === null)
            return;
        this.hoverValue = value;
    }
    selectValueFromOption(option) {
        const value = this.getOptionValue(option);
        if (value === null)
            return;
        this.handleOptionClick(value);
    }
    getOptionValue(option) {
        const raw = option.getAttribute('data-value');
        const num = raw ? Number(raw) : NaN;
        return Number.isFinite(num) ? num : null;
    }
    getIndexFromValue(options, value) {
        if (value === null || value === undefined)
            return -1;
        return options.findIndex(opt => Number(opt.getAttribute('data-value')) === value);
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    getItems() {
        const slotItems = this.getSlots('Item');
        if (slotItems.length > 0) {
            return slotItems
                .map((el) => ({
                value: Number(el.getAttribute('value')),
                label: el.innerHTML,
                fromSlot: true,
            }))
                .filter(item => Number.isFinite(item.value));
        }
        const items = [];
        const rawMin = Number(this.min);
        const rawMax = Number(this.max);
        const rawStep = Number(this.step);
        const step = rawStep > 0 ? rawStep : 1;
        const min = rawMin <= rawMax ? rawMin : rawMax;
        const max = rawMax >= rawMin ? rawMax : rawMin;
        for (let v = min; v <= max + 1e-9; v += step) {
            const value = Number(v.toFixed(10));
            items.push({ value, label: String(value), fromSlot: false });
        }
        return items;
    }
    getActiveValue() {
        return this.hoverValue !== null ? this.hoverValue : this.value;
    }
    isHighlighted(itemValue, activeValue) {
        if (activeValue === null || activeValue === undefined)
            return false;
        return itemValue <= activeValue;
    }
    getGroupClasses(hasError) {
        return [
            'relative rounded-lg border px-2 py-3',
            'bg-white dark:bg-slate-800',
            hasError
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'opacity-70' : '',
        ].filter(Boolean).join(' ');
    }
    getOptionButtonClasses(isHighlighted) {
        return [
            'w-7 h-7 rounded-full border flex items-center justify-center text-xs font-medium transition',
            'bg-white dark:bg-slate-800',
            isHighlighted
                ? 'bg-sky-500 dark:bg-sky-600 border-sky-500 dark:border-sky-400 text-white'
                : 'border-slate-300 dark:border-slate-600 text-slate-700 dark:text-slate-300',
            !this.disabled && !this.readonly ? 'hover:bg-slate-50 dark:hover:bg-slate-700' : '',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled || this.readonly ? 'cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelId = `label-${this.uid}`;
        return html `
<div id=${labelId} class="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderHelperOrError(hasError) {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            const errorId = `error-${this.uid}`;
            return html `<p id=${errorId} class="mt-2 text-xs text-red-600 dark:text-red-400">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="mt-2 text-xs text-slate-500 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderRatingOptions(items, hasCustomItems) {
        const activeValue = this.getActiveValue();
        return html `
<div class="relative flex items-start justify-between gap-3" @mouseleave=${this.handleGroupMouseLeave}>
<div class="absolute left-3 right-3 top-3 h-1 rounded-full bg-slate-200 dark:bg-slate-700"></div>
${items.map((item, index) => {
            const highlighted = this.isHighlighted(item.value, activeValue);
            const buttonClasses = this.getOptionButtonClasses(highlighted);
            const labelBelow = item.fromSlot
                ? html ``
                : html `<span class="text-xs text-slate-600 dark:text-slate-400">${item.label}</span>`;
            const innerContent = item.fromSlot
                ? unsafeHTML(item.label)
                : html `<span class="w-2 h-2 rounded-full bg-current"></span>`;
            return html `
<div class="relative z-10 flex flex-1 flex-col items-center gap-1">
<button
class=${buttonClasses}
role="radio"
aria-checked=${this.value === item.value}
aria-label=${String(item.value)}
data-role="option"
data-index=${index}
data-value=${item.value}
type="button"
?disabled=${this.disabled}
@mouseenter=${() => this.handleOptionMouseEnter(item.value)}
@mouseleave=${this.handleOptionMouseLeave}
@click=${() => this.handleOptionClick(item.value)}
@focus=${this.handleOptionFocus}
@blur=${this.handleOptionBlur}
>
${innerContent}
</button>
${hasCustomItems ? html `` : labelBelow}
</div>
`;
        })}
</div>
`;
    }
    renderViewMode(items, hasCustomItems) {
        const label = this.renderLabel();
        if (this.value === null) {
            return html `
<div class="text-slate-900 dark:text-slate-100">
${label}
<div class="text-slate-400 dark:text-slate-500">—</div>
${this.name ? html `<input type="hidden" name=${this.name} value="">` : html ``}
</div>
`;
        }
        return html `
<div class="text-slate-900 dark:text-slate-100">
${label}
${this.renderRatingOptions(items, hasCustomItems)}
${this.name ? html `<input type="hidden" name=${this.name} value=${String(this.value)}>` : html ``}
</div>
`;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const items = this.getItems();
        const hasCustomItems = this.getSlots('Item').length > 0;
        if (!this.isEditing) {
            return this.renderViewMode(items, hasCustomItems);
        }
        const invalidRequired = this.required && this.value === null;
        const hasError = Boolean(this.error) || invalidRequired;
        const labelId = this.hasSlot('Label') ? `label-${this.uid}` : undefined;
        const errorId = this.error ? `error-${this.uid}` : undefined;
        return html `
<div class="text-slate-900 dark:text-slate-100">
${this.renderLabel()}
<div
class=${this.getGroupClasses(hasError)}
role="radiogroup"
aria-disabled=${this.disabled}
aria-readonly=${this.readonly}
aria-required=${this.required}
aria-invalid=${hasError}
aria-labelledby=${labelId || ''}
aria-describedby=${errorId || ''}
@keydown=${this.handleKeyDown}
>
${this.renderRatingOptions(items, hasCustomItems)}
</div>
${this.renderHelperOrError(hasError)}
${this.name ? html `<input type="hidden" name=${this.name} value=${this.value === null ? '' : String(this.value)}>` : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], MlRatingSliderMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRatingSliderMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlRatingSliderMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlRatingSliderMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlRatingSliderMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlRatingSliderMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlRatingSliderMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRatingSliderMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRatingSliderMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlRatingSliderMolecule.prototype, "required", void 0);
__decorate([
    state()
], MlRatingSliderMolecule.prototype, "hoverValue", void 0);
MlRatingSliderMolecule = __decorate([
    customElement('grouprateitem--ml-rating-slider')
], MlRatingSliderMolecule);
export { MlRatingSliderMolecule };
