var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouprateitem/ml-emoji-mood-scale.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// EMOJI MOOD SCALE MOLECULE
// =============================================================================
// Skill Group: groupRateItem
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    empty: '—',
    required: 'Required',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let moodScaleId = 0;
let EmojiMoodScaleMolecule = class EmojiMoodScaleMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-emoji-mood-scale .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
grouprateitem--ml-emoji-mood-scale .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-emoji-mood-scale .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-emoji-mood-scale .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-emoji-mood-scale .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-emoji-mood-scale .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
grouprateitem--ml-emoji-mood-scale .ml-surface {
  background: var(--ml-surface, #ffffff);
}
grouprateitem--ml-emoji-mood-scale .ml-surface-dim {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouprateitem--ml-emoji-mood-scale .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
grouprateitem--ml-emoji-mood-scale .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
grouprateitem--ml-emoji-mood-scale .ml-focus-within:focus-within {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
grouprateitem--ml-emoji-mood-scale .ml-focus-ring:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
grouprateitem--ml-emoji-mood-scale .ml-mood-option:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouprateitem--ml-emoji-mood-scale .ml-mood-option-selected {
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-primary, #3b82f6);
}
`);
        this.msg = messages.en;
        this.uid = `mood-scale-${moodScaleId++}`;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = 0;
        this.max = 5;
        this.step = 1;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.hoverValue = null;
        this.focusedIndex = -1;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleOptionClick(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.value = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleOptionFocus(index) {
        if (!this.isEditing)
            return;
        this.focusedIndex = index;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleOptionBlur() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleMouseEnter(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = value;
    }
    handleMouseLeave() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = null;
    }
    handleKeydown(e, items) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        if (items.length === 0)
            return;
        const currentIndex = this.focusedIndex >= 0 ? this.focusedIndex : this.getSelectedIndex(items);
        if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
            e.preventDefault();
            const nextIndex = (currentIndex + 1) % items.length;
            this.focusItem(nextIndex);
            return;
        }
        if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
            e.preventDefault();
            const prevIndex = (currentIndex - 1 + items.length) % items.length;
            this.focusItem(prevIndex);
            return;
        }
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            const index = currentIndex >= 0 ? currentIndex : 0;
            const item = items[index];
            if (item)
                this.handleOptionClick(item.value);
        }
    }
    focusItem(index) {
        const el = this.querySelector(`[data-index="${index}"]`);
        if (el) {
            this.focusedIndex = index;
            el.focus();
        }
    }
    // ==========================================================================
    // DATA HELPERS
    // ==========================================================================
    getSelectedIndex(items) {
        if (this.value === null)
            return 0;
        const idx = items.findIndex((i) => i.value === this.value);
        return idx >= 0 ? idx : 0;
    }
    getItems() {
        if (this.hasSlot('Item')) {
            return this.getSlots('Item').map((el) => ({
                value: Number(el.getAttribute('value')),
                label: el.innerHTML,
            }));
        }
        const items = [];
        for (let v = this.min; v <= this.max; v += this.step) {
            items.push({ value: v, label: String(v) });
        }
        return items;
    }
    getActiveValue() {
        return this.hoverValue !== null ? this.hoverValue : this.value;
    }
    getHasError() {
        return Boolean(this.getErrorMessage());
    }
    getErrorMessage() {
        if (this.error && this.error.trim() !== '')
            return this.error;
        if (this.required && this.value === null)
            return this.msg.required;
        return '';
    }
    // ==========================================================================
    // RENDER HELPERS
    // ==========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div id="${this.uid}-label" class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}"
      ${unsafeHTML(this.getSlotContent('Label'))}
    </div>`;
    }
    renderHelperOrError() {
        const errorMessage = this.getErrorMessage();
        if (errorMessage) {
            return html `<div id="${this.uid}-error" class="mt-2 text-xs ml-error-text"
        ${unsafeHTML(errorMessage)}
      </div>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<div id="${this.uid}-helper" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}"
        ${unsafeHTML(this.getSlotContent('Helper'))}
      </div>`;
        }
        return html ``;
    }
    getContainerClasses() {
        return [
            'w-full rounded-lg border p-3 transition',
            'ml-surface',
            this.getHasError() ? 'ml-border-error' : 'ml-border',
            this.disabled ? 'ml-disabled' : '',
            !this.disabled && !this.readonly ? 'ml-focus-within' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getOptionClasses(isActive, isSelected) {
        return [
            'flex items-center justify-center rounded-md border px-3 py-2 text-xl transition',
            'ml-surface-dim ml-text',
            isActive || isSelected
                ? 'ml-mood-option-selected'
                : 'ml-border',
            !this.disabled && !this.readonly ? 'ml-mood-option cursor-pointer' : 'cursor-default',
            !this.disabled && !this.readonly ? 'ml-focus-ring' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderOption(item, index, activeValue) {
        const isSelected = this.value === item.value;
        const isActive = activeValue === item.value;
        const ariaChecked = isSelected ? 'true' : 'false';
        const label = `Rating ${item.value}`;
        const tabIndex = !this.disabled && !this.readonly && (isSelected || (this.value === null && index === 0)) ? 0 : -1;
        return html `
      <div
        class="${this.getOptionClasses(isActive, isSelected)}"
        role="radio"
        aria-checked="${ariaChecked}"
        aria-label="${label}"
        tabindex="${tabIndex}"
        data-index="${index}"
        @focus="${() => this.handleOptionFocus(index)}"
        @blur="${this.handleOptionBlur}"
        @mouseenter="${() => this.handleMouseEnter(item.value)}"
        @mouseleave="${this.handleMouseLeave}"
        @click="${() => this.handleOptionClick(item.value)}"
      >
        ${unsafeHTML(item.label)}
      </div>
    `;
    }
    renderViewMode(items) {
        const selected = items.find((i) => i.value === this.value);
        return html `
      <div class="flex items-center gap-3">
        ${selected
            ? html `<div class="rounded-md border ml-border ml-surface-dim px-3 py-2 text-xl">
              ${unsafeHTML(selected.label)}
            </div>`
            : html `<div class="ml-text-muted">${this.msg.empty}</div>`}
      </div>
    `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const items = this.getItems();
        if (!this.isEditing) {
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel()}
          ${this.renderViewMode(items)}
        </div>
      `;
        }
        const activeValue = this.getActiveValue();
        const hasError = this.getHasError();
        const describedBy = hasError ? `${this.uid}-error` : this.hasSlot('Helper') ? `${this.uid}-helper` : '';
        return html `
      <div
        class="${cn(this.getContainerClasses(), this.cssClass)}"
        role="radiogroup"
        aria-labelledby="${this.hasSlot('Label') ? `${this.uid}-label` : ''}"
        aria-describedby="${describedBy}"
        aria-invalid="${hasError ? 'true' : 'false'}"
        aria-required="${this.required ? 'true' : 'false'}"
        @keydown="${(e) => this.handleKeydown(e, items)}"
        @mouseleave="${this.handleMouseLeave}"
      >
        ${this.renderLabel()}
        <div class="flex items-center gap-2">
          ${items.map((item, index) => this.renderOption(item, index, activeValue))}
        </div>
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], EmojiMoodScaleMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EmojiMoodScaleMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EmojiMoodScaleMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EmojiMoodScaleMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EmojiMoodScaleMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EmojiMoodScaleMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EmojiMoodScaleMolecule.prototype, "required", void 0);
__decorate([
    state()
], EmojiMoodScaleMolecule.prototype, "hoverValue", void 0);
__decorate([
    state()
], EmojiMoodScaleMolecule.prototype, "focusedIndex", void 0);
EmojiMoodScaleMolecule = __decorate([
    customElement('grouprateitem--ml-emoji-mood-scale')
], EmojiMoodScaleMolecule);
export { EmojiMoodScaleMolecule };
