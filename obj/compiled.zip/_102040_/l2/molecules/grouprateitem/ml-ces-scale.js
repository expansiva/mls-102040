var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouprateitem/ml-ces-scale.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CES SCALE MOLECULE
// =============================================================================
// Skill Group: groupRateItem
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    required: 'This field is required',
    emptyValue: '—',
};
const messages = {
    en: message_en,
};
let CesScaleMolecule = class CesScaleMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouprateitem--ml-ces-scale .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-ces-scale .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-ces-scale .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-ces-scale .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
grouprateitem--ml-ces-scale .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-ces-scale .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-ces-scale .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouprateitem--ml-ces-scale .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
grouprateitem--ml-ces-scale .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouprateitem--ml-ces-scale .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
grouprateitem--ml-ces-scale .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
grouprateitem--ml-ces-scale .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
grouprateitem--ml-ces-scale .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
grouprateitem--ml-ces-scale .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
grouprateitem--ml-ces-scale .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
grouprateitem--ml-ces-scale .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouprateitem--ml-ces-scale .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
grouprateitem--ml-ces-scale .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
grouprateitem--ml-ces-scale .ml-gradient-1-bg {
  background: var(--ml-gradient-1, #10b981);
}
grouprateitem--ml-ces-scale .ml-gradient-1-text {
  color: var(--ml-on-gradient-1, #ffffff);
}
grouprateitem--ml-ces-scale .ml-gradient-2-bg {
  background: var(--ml-gradient-2, #84cc16);
}
grouprateitem--ml-ces-scale .ml-gradient-3-bg {
  background: var(--ml-gradient-3, #eab308);
}
grouprateitem--ml-ces-scale .ml-gradient-4-bg {
  background: var(--ml-gradient-4, #f59e0b);
}
grouprateitem--ml-ces-scale .ml-gradient-5-bg {
  background: var(--ml-gradient-5, #f97316);
}
grouprateitem--ml-ces-scale .ml-gradient-5-text {
  color: var(--ml-on-gradient-5, #ffffff);
}
grouprateitem--ml-ces-scale .ml-gradient-6-bg {
  background: var(--ml-gradient-6, #ef4444);
}
grouprateitem--ml-ces-scale .ml-gradient-6-text {
  color: var(--ml-on-gradient-6, #ffffff);
}
grouprateitem--ml-ces-scale .ml-gradient-7-bg {
  background: var(--ml-gradient-7, #e11d48);
}
grouprateitem--ml-ces-scale .ml-gradient-7-text {
  color: var(--ml-on-gradient-7, #ffffff);
}
`);
        this.msg = messages.en;
        this.baseId = `ces-scale-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Item'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.min = 0;
        this.max = 5;
        this.step = 1;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.hoverValue = null;
        this.isFocused = false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleItemClick(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.value = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleItemMouseEnter(value) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = value;
    }
    handleMouseLeave() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.hoverValue = null;
    }
    handleKeyDown(e, index, items) {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        const key = e.key;
        if (key === 'ArrowRight' || key === 'ArrowLeft' || key === 'Home' || key === 'End') {
            e.preventDefault();
            let nextIndex = index;
            if (key === 'ArrowRight')
                nextIndex = Math.min(items.length - 1, index + 1);
            if (key === 'ArrowLeft')
                nextIndex = Math.max(0, index - 1);
            if (key === 'Home')
                nextIndex = 0;
            if (key === 'End')
                nextIndex = items.length - 1;
            this.value = items[nextIndex].value;
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value }
            }));
            this.focusRateItem(nextIndex);
        }
        if (key === 'Enter' || key === '') {
            e.preventDefault();
            this.handleItemClick(items[index].value);
        }
    }
    focusRateItem(index) {
        requestAnimationFrame(() => {
            const buttons = this.querySelectorAll('button[data-rate-item]');
            const target = buttons[index];
            if (target)
                target.focus();
        });
    }
    handleFocusIn() {
        if (this.isFocused)
            return;
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleFocusOut(e) {
        const related = e.relatedTarget;
        if (related && this.contains(related))
            return;
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // HELPERS
    // ==========================================================================
    getItems() {
        const slotItems = this.getSlots('Item');
        if (slotItems.length > 0) {
            return slotItems.map(el => ({
                value: Number(el.getAttribute('value')),
                label: el.innerHTML,
            })).filter(item => !Number.isNaN(item.value));
        }
        const items = [];
        for (let v = 1; v <= 7; v += 1) {
            items.push({ value: v, label: '' });
        }
        return items;
    }
    getCompact() {
        return !this.hasSlot('Label') && !this.hasSlot('Helper');
    }
    getGradientClasses(index, count) {
        const palette = [
            { bg: 'ml-gradient-1-bg', text: 'ml-gradient-1-text' },
            { bg: 'ml-gradient-2-bg', text: 'ml-text' },
            { bg: 'ml-gradient-3-bg', text: 'ml-text' },
            { bg: 'ml-gradient-4-bg', text: 'ml-text' },
            { bg: 'ml-gradient-5-bg', text: 'ml-gradient-5-text' },
            { bg: 'ml-gradient-6-bg', text: 'ml-gradient-6-text' },
            { bg: 'ml-gradient-7-bg', text: 'ml-gradient-7-text' },
        ];
        const ratio = count > 1 ? index / (count - 1) : 0;
        const paletteIndex = Math.round(ratio * (palette.length - 1));
        return palette[Math.min(palette.length - 1, Math.max(0, paletteIndex))];
    }
    getItemClasses(isActive, hasError, compact, gradient) {
        return [
            'flex items-center justify-center rounded-md border transition',
            compact ? 'px-2 py-1 text-xs min-w-8' : 'px-3 py-2 text-sm min-w-10',
            gradient.bg,
            gradient.text,
            hasError ? 'ml-border-error' : 'ml-border',
            isActive ? 'ml-focus-ring scale-[1.02]' : 'ring-transparent',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div id=${labelId} class="${cn('mb-2 text-sm font-medium ml-text', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderHelper(hasError, errorId, errorMessage) {
        if (!this.isEditing)
            return html ``;
        if (hasError) {
            return html `<p id=${errorId} class="mt-2 text-xs ml-error-text">${unsafeHTML(errorMessage)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="${cn('mt-2 text-xs ml-text-muted', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderItems(items, hasError, compact) {
        const activeValue = this.hoverValue !== null && this.isEditing && !this.disabled && !this.readonly
            ? this.hoverValue
            : this.value;
        return html `
<div class="flex items-center ${compact ? 'gap-1' : 'gap-2'}" @mouseleave=${this.handleMouseLeave}>
${items.map((item, index) => {
            const isActive = activeValue !== null && item.value === activeValue;
            const gradient = this.getGradientClasses(index, items.length);
            const autoLabel = item.label ? unsafeHTML(item.label) : html `${item.value}`;
            const labelClasses = [
                item.label ? '' : 'font-semibold',
                item.label ? '' : (index === 0 || index === items.length - 1 ? 'opacity-95' : 'opacity-85'),
            ].filter(Boolean).join(' ');
            return html `
<button
class=${this.getItemClasses(isActive, hasError, compact, gradient)}
role="radio"
aria-checked=${isActive}
aria-label=${String(item.value)}
?disabled=${this.disabled}
?data-rate-item=${true}
@mouseenter=${() => this.handleItemMouseEnter(item.value)}
@click=${() => this.handleItemClick(item.value)}
@keydown=${(e) => this.handleKeyDown(e, index, items)}
.tabIndex=${this.disabled ? -1 : 0}
>
<span class=${labelClasses}>${autoLabel}</span>
</button>
`;
        })}
</div>
`;
    }
    renderView(items, compact) {
        if (this.value === null) {
            return html `<div class="text-sm ml-text-muted">${this.msg.emptyValue}</div>`;
        }
        return this.renderItems(items, false, compact);
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const items = this.getItems();
        const compact = this.getCompact();
        const labelId = `${this.baseId}-label`;
        const errorId = `${this.baseId}-error`;
        const requiredError = this.required && this.value === null ? this.msg.required : '';
        const errorMessage = this.isEditing ? (this.error || requiredError) : '';
        const hasError = this.isEditing && !!errorMessage;
        const ariaLabelledBy = this.hasSlot('Label') ? labelId : undefined;
        const ariaDescribedBy = hasError ? errorId : undefined;
        return html `
<div class="${cn('w-full', this.cssClass)}" @focusin=${this.handleFocusIn} @focusout=${this.handleFocusOut}>
${this.renderLabel(labelId)}
<div
role="radiogroup"
aria-labelledby=${ariaLabelledBy || ''}
aria-describedby=${ariaDescribedBy || ''}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
class=${[
            'flex flex-col rounded-lg border p-3 transition',
            compact ? 'gap-2' : 'gap-3',
            'ml-surface-bg',
            hasError ? 'ml-border-error' : 'ml-border',
            this.disabled ? 'opacity-50' : '',
        ].filter(Boolean).join(' ')}
>
${this.isEditing
            ? this.renderItems(items, hasError, compact)
            : this.renderView(items, compact)}
</div>
${this.renderHelper(hasError, errorId, errorMessage)}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], CesScaleMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], CesScaleMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], CesScaleMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Number })
], CesScaleMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], CesScaleMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Number })
], CesScaleMolecule.prototype, "step", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], CesScaleMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CesScaleMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CesScaleMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CesScaleMolecule.prototype, "required", void 0);
__decorate([
    state()
], CesScaleMolecule.prototype, "hoverValue", void 0);
__decorate([
    state()
], CesScaleMolecule.prototype, "isFocused", void 0);
CesScaleMolecule = __decorate([
    customElement('grouprateitem--ml-ces-scale')
], CesScaleMolecule);
export { CesScaleMolecule };
