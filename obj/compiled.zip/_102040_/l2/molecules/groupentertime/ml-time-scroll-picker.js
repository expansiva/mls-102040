var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertime/ml-time-scroll-picker.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// TIME SCROLL PICKER MOLECULE
// =============================================================================
// Skill Group: enter + time
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select time',
    confirm: 'Confirm',
    clear: 'Clear',
    loading: 'Loading...',
    viewEmpty: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione o horário',
        confirm: 'Confirmar',
        clear: 'Limpar',
        loading: 'Carregando...',
        viewEmpty: '—',
    },
};
/// **collab_i18n_end**
let MlTimeScrollPickerMolecule = class MlTimeScrollPickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertime--ml-time-scroll-picker .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertime--ml-time-scroll-picker .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertime--ml-time-scroll-picker .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertime--ml-time-scroll-picker .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-time-scroll-picker .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentertime--ml-time-scroll-picker .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertime--ml-time-scroll-picker .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-time-scroll-picker .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-time-scroll-picker .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-time-scroll-picker .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-time-scroll-picker .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertime--ml-time-scroll-picker .ml-time-column {
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
}
groupentertime--ml-time-scroll-picker .ml-time-option {
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) transparent;
  border-radius: var(--ml-radius-sm, 6px);
  transition: background-color var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-time-scroll-picker .ml-time-option:hover:not(:disabled) {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupentertime--ml-time-scroll-picker .ml-time-option-selected {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: var(--ml-primary, #3b82f6);
}
groupentertime--ml-time-scroll-picker .ml-time-option-selected:hover:not(:disabled) {
  background: var(--ml-primary, #3b82f6);
}
groupentertime--ml-time-scroll-picker .ml-scroll-panel {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupentertime--ml-time-scroll-picker .ml-scroll-action {
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface-muted, #49454f);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  transition: background-color var(--ml-transition, 200ms ease);
}
groupentertime--ml-time-scroll-picker .ml-scroll-action:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupentertime--ml-time-scroll-picker .ml-scroll-confirm {
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-primary, #3b82f6);
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  transition: opacity var(--ml-transition, 200ms ease);
}
groupentertime--ml-time-scroll-picker .ml-scroll-confirm:hover {
  opacity: 0.9;
}
groupentertime--ml-time-scroll-picker .ml-clock-icon {
  color: var(--ml-on-surface-muted, #49454f);
  transition: color var(--ml-transition, 200ms ease);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.selectedHour = 0;
        this.selectedMinute = 0;
        this.selectedSecond = 0;
        this.selectedPeriod = 'AM';
        this.componentId = `tsp-${Math.random().toString(36).slice(2)}`;
        this.handleOutsideClick = (e) => {
            const path = e.composedPath();
            if (!path.includes(this)) {
                this.isOpen = false;
                window.removeEventListener('click', this.handleOutsideClick);
            }
        };
        this.handleKeyDown = (e) => {
            if (e.key === 'Escape' && this.isOpen) {
                this.isOpen = false;
                window.removeEventListener('click', this.handleOutsideClick);
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.syncFromValue();
        this.addEventListener('keydown', this.handleKeyDown);
    }
    disconnectedCallback() {
        this.removeEventListener('keydown', this.handleKeyDown);
        window.removeEventListener('click', this.handleOutsideClick);
        super.disconnectedCallback();
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key) {
        const valueAttr = this.getAttribute('value');
        const hour12Attr = this.getAttribute('hour12');
        const showSecondsAttr = this.getAttribute('show-seconds');
        if (valueAttr === `{{${key}}}` ||
            hour12Attr === `{{${key}}}` ||
            showSecondsAttr === `{{${key}}}`) {
            this.syncFromValue();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggleOpen() {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            window.addEventListener('click', this.handleOutsideClick);
        }
        else {
            window.removeEventListener('click', this.handleOutsideClick);
        }
    }
    handleFocus() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleConfirm() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (!this.isSelectedTimeValid())
            return;
        this.value = this.formatValueFromSelection();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.isOpen = false;
        window.removeEventListener('click', this.handleOutsideClick);
    }
    handleClear() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.value = null;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.isOpen = false;
        window.removeEventListener('click', this.handleOutsideClick);
    }
    handleHourSelect(hour) {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (this.hour12) {
            this.selectedHour = this.to24Hour(hour, this.selectedPeriod);
        }
        else {
            this.selectedHour = hour;
        }
    }
    handleMinuteSelect(minute) {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.selectedMinute = minute;
    }
    handleSecondSelect(second) {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.selectedSecond = second;
    }
    handlePeriodSelect(period) {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.selectedPeriod = period;
        if (this.hour12) {
            const displayHour = this.to12Hour(this.selectedHour);
            this.selectedHour = this.to24Hour(displayHour, period);
        }
    }
    // ===========================================================================
    // DATA HELPERS
    // ===========================================================================
    syncFromValue() {
        const parsed = this.parseTimeValue(this.value);
        if (parsed) {
            this.selectedHour = parsed.hour;
            this.selectedMinute = parsed.minute;
            this.selectedSecond = this.showSeconds ? parsed.second : 0;
        }
        else {
            this.selectedHour = 0;
            this.selectedMinute = 0;
            this.selectedSecond = 0;
        }
        this.selectedPeriod = this.selectedHour >= 12 ? 'PM' : 'AM';
    }
    parseTimeValue(value) {
        if (!value)
            return null;
        const parts = value.split(':').map((v) => parseInt(v, 10));
        if (parts.length < 2)
            return null;
        const hour = parts[0] ?? 0;
        const minute = parts[1] ?? 0;
        const second = parts[2] ?? 0;
        return { hour, minute, second };
    }
    formatValueFromSelection() {
        const hh = String(this.selectedHour).padStart(2, '0');
        const mm = String(this.selectedMinute).padStart(2, '0');
        if (this.showSeconds) {
            const ss = String(this.selectedSecond).padStart(2, '0');
            return `${hh}:${mm}:${ss}`;
        }
        return `${hh}:${mm}`;
    }
    formatDisplay(value) {
        if (!value)
            return this.msg.viewEmpty;
        const parsed = this.parseTimeValue(value);
        if (!parsed)
            return this.msg.viewEmpty;
        const date = new Date(1970, 0, 1, parsed.hour, parsed.minute, parsed.second || 0);
        const opts = {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
        };
        const formatter = new Intl.DateTimeFormat(this.locale || undefined, opts);
        return formatter.format(date);
    }
    to12Hour(hour24) {
        const h = hour24 % 12;
        return h === 0 ? 12 : h;
    }
    to24Hour(hour12, period) {
        const base = hour12 % 12;
        return period === 'PM' ? base + 12 : base;
    }
    getMinSeconds() {
        if (!this.minTime)
            return null;
        const parsed = this.parseTimeValue(this.minTime);
        if (!parsed)
            return null;
        return parsed.hour * 3600 + parsed.minute * 60 + (parsed.second || 0);
    }
    getMaxSeconds() {
        if (!this.maxTime)
            return null;
        const parsed = this.parseTimeValue(this.maxTime);
        if (!parsed)
            return null;
        const base = parsed.hour * 3600 + parsed.minute * 60 + (parsed.second || 0);
        return this.showSeconds ? base : base + 59;
    }
    isTimeAllowed(hour, minute, second) {
        const min = this.getMinSeconds();
        const max = this.getMaxSeconds();
        const total = hour * 3600 + minute * 60 + second;
        if (min !== null && total < min)
            return false;
        if (max !== null && total > max)
            return false;
        return true;
    }
    isSelectedTimeValid() {
        const sec = this.showSeconds ? this.selectedSecond : 0;
        return this.isTimeAllowed(this.selectedHour, this.selectedMinute, sec);
    }
    getMinutesList() {
        const step = Math.max(1, this.minuteStep || 1);
        const list = [];
        for (let i = 0; i < 60; i += step)
            list.push(i);
        return list;
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelId = `${this.componentId}-label`;
        return html `
<label id="${labelId}" class="${cn('mb-1 block text-sm ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
${this.required ? html `<span class="ml-error-text">*</span>` : ''}
</label>
`;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${this.componentId}-error" class="${cn('mt-1 text-xs ml-error-text', this.getSlotClass('Helper'))}">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.componentId}-helper" class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderViewMode() {
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div class="text-sm ml-text">${this.formatDisplay(this.value)}</div>
</div>
`;
    }
    renderInput() {
        const labelId = this.hasSlot('Label') ? `${this.componentId}-label` : '';
        const describedBy = this.error
            ? `${this.componentId}-error`
            : this.hasSlot('Helper')
                ? `${this.componentId}-helper`
                : '';
        const placeholder = this.placeholder || this.msg.placeholder;
        const displayValue = this.value ? this.formatDisplay(this.value) : '';
        const inputClasses = this.getInputClasses();
        return html `
<div class="relative">
<input
id="${this.componentId}-input"
name="${this.name}"
class="${inputClasses}"
type="text"
.placeholder="${placeholder}"
.value="${displayValue}"
?disabled=${this.disabled}
?readonly=${true}
aria-labelledby="${labelId}"
aria-describedby="${describedBy}"
aria-invalid="${this.error ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
@focus=${this.handleFocus}
@blur=${this.handleBlur}
@click=${this.handleToggleOpen}

@input="${(e) => e.stopPropagation()}"

@change="${(e) => e.stopPropagation()}"
/>
<button
class="${this.getIconButtonClasses()}"
@click=${this.handleToggleOpen}
?disabled=${this.disabled || this.readonly || this.loading}
aria-label="${this.formatDisplay(this.value)}"
>
${this.renderClockIcon()}
</button>
</div>
`;
    }
    renderClockIcon() {
        return html `
<svg viewBox="0 0 24 24" class="h-4 w-4 ml-clock-icon">
${svg `<circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" stroke-width="2"></circle>`}
${svg `<path d="M12 7v5l3 3" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>`}
</svg>
`;
    }
    renderPicker() {
        if (!this.isOpen || this.loading)
            return html ``;
        return html `
<div
class="${cn('mt-2 grid gap-2 p-3 ml-scroll-panel', `grid-cols-${this.hour12 ? (this.showSeconds ? '4' : '3') : this.showSeconds ? '3' : '2'}`)}"
role="dialog"
aria-modal="true"
>
${this.renderHourColumn()}
${this.renderMinuteColumn()}
${this.showSeconds ? this.renderSecondColumn() : html ``}
${this.hour12 ? this.renderPeriodColumn() : html ``}
<div class="col-span-full mt-2 flex items-center justify-end gap-2">
<button class="px-3 py-1.5 text-sm ml-scroll-action" @click=${this.handleClear} ?disabled=${this.disabled || this.readonly || this.loading}>${this.msg.clear}</button>
<button class="px-3 py-1.5 text-sm ml-scroll-confirm" @click=${this.handleConfirm} ?disabled=${!this.isSelectedTimeValid() || this.disabled || this.readonly || this.loading}>${this.msg.confirm}</button>
</div>
</div>
`;
    }
    renderHourColumn() {
        const hours = this.hour12 ? Array.from({ length: 12 }, (_, i) => i + 1) : Array.from({ length: 24 }, (_, i) => i);
        return html `
<div class="flex flex-col">
<span class="mb-1 text-xs ml-text-muted">H</span>
<div class="max-h-48 overflow-y-auto p-1 ml-time-column">
${hours.map((h) => {
            const hour24 = this.hour12 ? this.to24Hour(h, this.selectedPeriod) : h;
            const isSelected = this.selectedHour === hour24;
            const disabled = !this.isTimeAllowed(hour24, this.selectedMinute, this.showSeconds ? this.selectedSecond : 0);
            return html `
<button
class="${this.getItemClasses(isSelected, disabled)}"
@click=${() => this.handleHourSelect(h)}
?disabled=${disabled}
>
${String(h).padStart(2, '0')}
</button>
`;
        })}
</div>
</div>
`;
    }
    renderMinuteColumn() {
        const minutes = this.getMinutesList();
        return html `
<div class="flex flex-col">
<span class="mb-1 text-xs ml-text-muted">M</span>
<div class="max-h-48 overflow-y-auto p-1 ml-time-column">
${minutes.map((m) => {
            const isSelected = this.selectedMinute === m;
            const disabled = !this.isTimeAllowed(this.selectedHour, m, this.showSeconds ? this.selectedSecond : 0);
            return html `
<button
class="${this.getItemClasses(isSelected, disabled)}"
@click=${() => this.handleMinuteSelect(m)}
?disabled=${disabled}
>
${String(m).padStart(2, '0')}
</button>
`;
        })}
</div>
</div>
`;
    }
    renderSecondColumn() {
        const seconds = Array.from({ length: 60 }, (_, i) => i);
        return html `
<div class="flex flex-col">
<span class="mb-1 text-xs ml-text-muted">S</span>
<div class="max-h-48 overflow-y-auto p-1 ml-time-column">
${seconds.map((s) => {
            const isSelected = this.selectedSecond === s;
            const disabled = !this.isTimeAllowed(this.selectedHour, this.selectedMinute, s);
            return html `
<button
class="${this.getItemClasses(isSelected, disabled)}"
@click=${() => this.handleSecondSelect(s)}
?disabled=${disabled}
>
${String(s).padStart(2, '0')}
</button>
`;
        })}
</div>
</div>
`;
    }
    renderPeriodColumn() {
        const periods = ['AM', 'PM'];
        return html `
<div class="flex flex-col">
<span class="mb-1 text-xs ml-text-muted">P</span>
<div class="max-h-48 overflow-y-auto p-1 ml-time-column">
${periods.map((p) => {
            const isSelected = this.selectedPeriod === p;
            const disabled = !this.isPeriodAllowed(p);
            return html `
<button
class="${this.getItemClasses(isSelected, disabled)}"
@click=${() => this.handlePeriodSelect(p)}
?disabled=${disabled}
>
${p}
</button>
`;
        })}
</div>
</div>
`;
    }
    isPeriodAllowed(period) {
        const minutes = this.selectedMinute;
        const seconds = this.showSeconds ? this.selectedSecond : 0;
        const hours = period === 'AM' ? Array.from({ length: 12 }, (_, i) => i) : Array.from({ length: 12 }, (_, i) => i + 12);
        return hours.some((h) => this.isTimeAllowed(h, minutes, seconds));
    }
    // ===========================================================================
    // CLASSES
    // ===========================================================================
    getInputClasses() {
        return cn('w-full px-3 py-2 pr-10 text-sm ml-input ml-input-container', this.error ? 'ml-input-container-error' : '', this.disabled ? 'ml-disabled' : 'cursor-text');
    }
    getIconButtonClasses() {
        return cn('absolute right-2 top-1/2 -translate-y-1/2 p-1 ml-clock-icon', this.disabled || this.readonly || this.loading ? 'ml-disabled' : '');
    }
    getItemClasses(isSelected, disabled) {
        return cn('w-full px-2 py-1 text-sm text-left ml-time-option', isSelected ? 'ml-time-option-selected' : '', disabled ? 'ml-disabled' : 'cursor-pointer');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
${this.renderInput()}
${this.loading ? html `<div class="mt-2 text-xs ml-text-muted">${this.msg.loading}</div>` : ''}
${this.renderPicker()}
${this.renderHelperOrError()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTimeScrollPickerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeScrollPickerMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeScrollPickerMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeScrollPickerMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour12' })
], MlTimeScrollPickerMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], MlTimeScrollPickerMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], MlTimeScrollPickerMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], MlTimeScrollPickerMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], MlTimeScrollPickerMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeScrollPickerMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlTimeScrollPickerMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeScrollPickerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeScrollPickerMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeScrollPickerMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeScrollPickerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTimeScrollPickerMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlTimeScrollPickerMolecule.prototype, "selectedHour", void 0);
__decorate([
    state()
], MlTimeScrollPickerMolecule.prototype, "selectedMinute", void 0);
__decorate([
    state()
], MlTimeScrollPickerMolecule.prototype, "selectedSecond", void 0);
__decorate([
    state()
], MlTimeScrollPickerMolecule.prototype, "selectedPeriod", void 0);
MlTimeScrollPickerMolecule = __decorate([
    customElement('groupentertime--ml-time-scroll-picker')
], MlTimeScrollPickerMolecule);
export { MlTimeScrollPickerMolecule };
