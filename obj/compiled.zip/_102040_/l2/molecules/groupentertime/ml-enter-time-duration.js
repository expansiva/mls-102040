var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertime/ml-enter-time-duration.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ENTER TIME DURATION MOLECULE
// =============================================================================
// Skill Group: groupEnterTime
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'HH:mm',
    emptyView: '—',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let EnterTimeDurationMolecule = class EnterTimeDurationMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertime--ml-enter-time-duration .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertime--ml-enter-time-duration .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertime--ml-enter-time-duration .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertime--ml-enter-time-duration .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-enter-time-duration .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentertime--ml-enter-time-duration .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertime--ml-enter-time-duration .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-enter-time-duration .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-enter-time-duration .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-enter-time-duration .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertime--ml-enter-time-duration .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertime--ml-enter-time-duration .ml-duration-segment {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
`);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.isOpen = false;
        this.rawValue = '';
    }
    // ==========================================================================
    // STATE CHANGE HANDLER
    // ==========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const showSecondsAttr = this.getAttribute('show-seconds');
        if (valueAttr === `{{${key}}}` || showSecondsAttr === `{{${key}}}`) {
            this.rawValue = this.formatStoredValue(value, this.showSeconds);
        }
        this.requestUpdate();
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    firstUpdated() {
        this.rawValue = this.formatStoredValue(this.value, this.showSeconds);
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleFocus() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleBlur() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.commitValue(this.rawValue);
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleInput(e) {
        e.stopPropagation();
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        const input = e.target;
        this.rawValue = input.value;
    }
    handleKeyDown(e) {
        if (e.key === 'Enter') {
            this.commitValue(this.rawValue);
        }
    }
    commitValue(raw) {
        if (raw.trim() === '') {
            this.value = null;
            this.rawValue = '';
            this.dispatchChange();
            return;
        }
        const parsed = this.parseTime(raw, this.showSeconds);
        if (!parsed) {
            this.rawValue = this.formatStoredValue(this.value, this.showSeconds);
            return;
        }
        const normalized = this.normalizeTime(parsed, this.minuteStep);
        if (!normalized) {
            this.rawValue = this.formatStoredValue(this.value, this.showSeconds);
            return;
        }
        if (!this.isWithinRange(normalized)) {
            this.rawValue = this.formatStoredValue(this.value, this.showSeconds);
            return;
        }
        const nextValue = this.formatTime(normalized, this.showSeconds);
        this.value = nextValue;
        this.rawValue = nextValue;
        this.dispatchChange();
    }
    dispatchChange() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    formatStoredValue(value, showSeconds) {
        if (!value)
            return '';
        if (!showSeconds && value.length === 8) {
            return value.slice(0, 5);
        }
        return value;
    }
    parseTime(raw, showSeconds) {
        const cleaned = raw.trim();
        const parts = cleaned.split(':');
        if (!showSeconds && parts.length !== 2)
            return null;
        if (showSeconds && parts.length !== 3)
            return null;
        const h = Number(parts[0]);
        const m = Number(parts[1]);
        const s = showSeconds ? Number(parts[2]) : 0;
        if ([h, m, s].some((n) => Number.isNaN(n)))
            return null;
        if (h < 0 || h > 23)
            return null;
        if (m < 0 || m > 59)
            return null;
        if (showSeconds && (s < 0 || s > 59))
            return null;
        return { h, m, s };
    }
    normalizeTime(time, step) {
        const safeStep = step > 0 ? step : 1;
        const normalizedMinutes = Math.floor(time.m / safeStep) * safeStep;
        if (normalizedMinutes < 0 || normalizedMinutes > 59)
            return null;
        return { h: time.h, m: normalizedMinutes, s: time.s };
    }
    formatTime(time, showSeconds) {
        const pad = (n) => String(n).padStart(2, '0');
        if (showSeconds) {
            return `${pad(time.h)}:${pad(time.m)}:${pad(time.s)}`;
        }
        return `${pad(time.h)}:${pad(time.m)}`;
    }
    timeToSeconds(time) {
        return time.h * 3600 + time.m * 60 + time.s;
    }
    isWithinRange(time) {
        if (!this.minTime && !this.maxTime)
            return true;
        const minParsed = this.minTime ? this.parseTime(this.minTime, false) : null;
        const maxParsed = this.maxTime ? this.parseTime(this.maxTime, false) : null;
        const current = this.timeToSeconds(time);
        if (minParsed) {
            const minSeconds = this.timeToSeconds({ h: minParsed.h, m: minParsed.m, s: 0 });
            if (current < minSeconds)
                return false;
        }
        if (maxParsed) {
            const maxSeconds = this.timeToSeconds({ h: maxParsed.h, m: maxParsed.m, s: 59 });
            if (current > maxSeconds)
                return false;
        }
        return true;
    }
    getDisplayValue() {
        if (!this.value)
            return this.msg.emptyView;
        const parsed = this.parseTime(this.value, this.value.length === 8);
        if (!parsed)
            return this.msg.emptyView;
        const baseDate = new Date(1970, 0, 1, parsed.h, parsed.m, parsed.s);
        const locale = this.locale || undefined;
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
        };
        return new Intl.DateTimeFormat(locale, options).format(baseDate);
    }
    getInputClasses() {
        return cn('w-full px-3 py-2 text-sm ml-input ml-input-container', this.error ? 'ml-input-container-error' : '', this.disabled ? 'ml-disabled' : '', this.readonly ? 'ml-disabled' : '');
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${labelId} class="${cn('mb-1 block text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderFeedback(helperId) {
        if (this.error) {
            return html `<p id=${helperId} class="${cn('mt-1 text-xs ml-error-text', this.getSlotClass('Helper'))}">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${helperId} class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const inputPlaceholder = this.placeholder || (this.showSeconds ? 'HH:mm:ss' : this.msg.placeholder);
        const labelId = `${this.id || 'time'}-label`;
        const helperId = `${this.id || 'time'}-helper`;
        if (!this.isEditing) {
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel(labelId)}
          <div class="text-sm ml-text">${this.getDisplayValue()}</div>
        </div>
      `;
        }
        if (this.loading) {
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel(labelId)}
          <div class="text-sm ml-text-muted">${this.msg.loading}</div>
        </div>
      `;
        }
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel(labelId)}
        <input
          class=${this.getInputClasses()}
          type="text"
          name=${this.name}
          .value=${this.rawValue}
          placeholder=${inputPlaceholder}
          ?disabled=${this.disabled}
          ?readonly=${this.readonly}
          aria-labelledby=${labelId}
          aria-describedby=${this.error || this.hasSlot('Helper') ? helperId : ''}
          aria-invalid=${this.error ? 'true' : 'false'}
          aria-required=${this.required ? 'true' : 'false'}
          @input=${this.handleInput}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
          @keydown=${this.handleKeyDown}
        
        @change=${(e) => e.stopPropagation()}
/>
        ${this.renderFeedback(helperId)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], EnterTimeDurationMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeDurationMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeDurationMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeDurationMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour12' })
], EnterTimeDurationMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], EnterTimeDurationMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], EnterTimeDurationMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], EnterTimeDurationMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], EnterTimeDurationMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeDurationMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EnterTimeDurationMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeDurationMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeDurationMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeDurationMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeDurationMolecule.prototype, "loading", void 0);
__decorate([
    state()
], EnterTimeDurationMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], EnterTimeDurationMolecule.prototype, "rawValue", void 0);
EnterTimeDurationMolecule = __decorate([
    customElement('groupentertime--ml-enter-time-duration')
], EnterTimeDurationMolecule);
export { EnterTimeDurationMolecule };
