var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertime/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupentertime/ml-clock-time-picker';
import '/_102040_/l2/molecules/groupentertime/ml-time-scroll-picker';
import '/_102040_/l2/molecules/groupentertime/ml-enter-time-duration';
import { molecules, scenarios } from '/_102040_/l2/molecules/groupentertime/index.defs.js';
import { renderCatalogReferenceTable } from '/_102020_/l2/aura/molecules/shared/indexReferenceTable.js';
let GroupEnterTimeIndex = class GroupEnterTimeIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        // ── Showcase card states ─────────────────────────────────────
        this.card1 = '08:30';
        this.card2 = '18:15';
        this.card3 = '01:45:00';
    }
    // ===========================================================================
    // HERO
    renderHero() {
        return html `
      <header class="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-8 py-20 text-center">
        <span class="inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-600 dark:text-sky-300 rounded-full text-xs font-semibold uppercase tracking-widest mb-6">
          groupEnterTime
        </span>
        <h1 class="text-5xl font-bold text-slate-900 dark:text-slate-50 mb-5 tracking-tight">
          Enter Time
        </h1>
        <p class="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Allows the user to input a time only (no date). Ideal for business hours, recurring daily schedules, alarm times, opening and closing times, and shift configurations. Implementations include time picker with scrollable columns, masked time input, time spinner, and clock face.
        </p>
      </header>
    `;
    }
    // ===========================================================================
    // SHOWCASE CARDS
    renderShowcaseCards() {
        return html `
      <section class="bg-slate-50 dark:bg-slate-950 px-8 py-12 border-b border-slate-200 dark:border-slate-700">
        <div class="max-w-2xl mx-auto flex flex-col gap-5">
          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-violet-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Clock face picker</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupentertime--ml-clock-time-picker</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Best for visual selection when users prefer analog-style time entry.</p>
              <groupentertime--ml-clock-time-picker
                name="card-1"
                value="${this.card1}"
                locale="en-US"
                placeholder="Select a time"
                .hour12=${true}
                .minuteStep=${5}
                .isEditing=${true}
                @change=${(e) => {
            this.card1 = e.detail.value ?? '';
        }}
              >
                <Label>Opening time</Label>
                <Helper>Tap the clock to choose a start time.</Helper>
              </groupentertime--ml-clock-time-picker>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-emerald-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Scrollable columns</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupentertime--ml-time-scroll-picker</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Great for kiosk-style interfaces and fast incremental changes.</p>
              <groupentertime--ml-time-scroll-picker
                name="card-2"
                value="${this.card2}"
                locale="en-GB"
                minTime="06:00"
                maxTime="22:00"
                placeholder="Pick a time"
                .minuteStep=${15}
                .isEditing=${true}
                @change=${(e) => {
            this.card2 = e.detail.value ?? '';
        }}
              >
                <Label>Closing time</Label>
                <Helper>Available in 15-minute increments.</Helper>
              </groupentertime--ml-time-scroll-picker>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-amber-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Time duration entry</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupentertime--ml-enter-time-duration</code>
              </div>
              <p class="text-xs text-slate-400 mb-5">Use when capturing elapsed time or shift length with seconds.</p>
              <groupentertime--ml-enter-time-duration
                name="card-3"
                value="${this.card3}"
                placeholder="HH:mm:ss"
                .showSeconds=${true}
                .isEditing=${true}
                @change=${(e) => {
            this.card3 = e.detail.value ?? '';
        }}
              >
                <Label>Shift duration</Label>
                <Helper>Include seconds for precise time tracking.</Helper>
              </groupentertime--ml-enter-time-duration>
            </div>
          </div>
        </div>
      </section>
    `;
    }
    // ===========================================================================
    // REFERENCE TABLE
    renderReferenceTable() {
        return renderCatalogReferenceTable(molecules, scenarios);
    }
    // ===========================================================================
    // RENDER
    render() {
        return html `
      <div class="font-sans min-h-screen">
        ${this.renderHero()}
        ${this.renderShowcaseCards()}
        ${this.renderReferenceTable()}
      </div>
    `;
    }
};
__decorate([
    state()
], GroupEnterTimeIndex.prototype, "card1", void 0);
__decorate([
    state()
], GroupEnterTimeIndex.prototype, "card2", void 0);
__decorate([
    state()
], GroupEnterTimeIndex.prototype, "card3", void 0);
GroupEnterTimeIndex = __decorate([
    customElement('molecules--groupentertime--index-102040')
], GroupEnterTimeIndex);
export { GroupEnterTimeIndex };
