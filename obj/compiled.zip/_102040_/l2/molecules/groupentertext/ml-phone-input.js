/// <mls fileReference="_102040_/l2/molecules/groupentertext/ml-phone-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// PHONE INPUT MOLECULE
// =============================================================================
// Skill Group: groupEnterText
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: '(00) 00000-0000',
    emptyValue: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: '(00) 00000-0000',
        emptyValue: '—',
    },
};
/// **collab_i18n_end**
let PhoneInputMolecule = class PhoneInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-phone-input .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-phone-input .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-phone-input .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-phone-input .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-phone-input .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-phone-input .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-phone-input .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertext--ml-phone-input .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-phone-input .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertext--ml-phone-input .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-phone-input .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentertext--ml-phone-input .ml-spinner {
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-phone-input .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        // Data
        this.value = '';
        this.error = '';
        this.name = '';
        // Configuration
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.autocomplete = '';
        // States
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isFocused = false;
        this.rawDisplay = '';
        this.labelId = `phone-label-${Math.random().toString(36).substr(2, 9)}`;
        this.errorId = `phone-error-${Math.random().toString(36).substr(2, 9)}`;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.rawDisplay = this.formatPhoneNumber(this.value);
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.rawDisplay = this.formatPhoneNumber(value || '');
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // FORMATTING HELPERS
    // ===========================================================================
    extractDigits(input) {
        return input.replace(/\D/g, '');
    }
    formatPhoneNumber(digits) {
        const cleaned = this.extractDigits(digits);
        if (cleaned.length === 0)
            return '';
        if (cleaned.length <= 2)
            return `(${cleaned}`;
        if (cleaned.length <= 7)
            return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2)}`;
        if (cleaned.length <= 11) {
            return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7)}`;
        }
        return `(${cleaned.slice(0, 2)}) ${cleaned.slice(2, 7)}-${cleaned.slice(7, 11)}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        const cursorPosition = input.selectionStart || 0;
        const previousLength = this.rawDisplay.length;
        let digits = this.extractDigits(input.value);
        // Apply maxLength constraint on digits
        const effectiveMaxLength = this.maxLength ?? 11;
        if (digits.length > effectiveMaxLength) {
            digits = digits.slice(0, effectiveMaxLength);
        }
        this.value = digits;
        this.rawDisplay = this.formatPhoneNumber(digits);
        // Restore cursor position after formatting
        requestAnimationFrame(() => {
            const newLength = this.rawDisplay.length;
            const diff = newLength - previousLength;
            let newPosition = cursorPosition + diff;
            // Ensure cursor doesn't go beyond input length
            newPosition = Math.max(0, Math.min(newPosition, newLength));
            input.setSelectionRange(newPosition, newPosition);
        });
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleFocus() {
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getContainerClasses() {
        return [
            'flex flex-col gap-1 w-full',
        ].join(' ');
    }
    getInputWrapperClasses() {
        const hasError = this.error && this.error.length > 0;
        return [
            'flex items-center gap-2 w-full px-3 py-2 ml-input-container',
            hasError ? 'ml-input-container-error' : '',
            this.disabled || this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses() {
        return [
            'flex-1 bg-transparent border-none outline-none text-sm ml-input',
            this.disabled || this.loading ? 'cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id="${this.labelId}" class="${cn('text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="ml-error-text ml-0.5">*</span>` : html ``}
      </label>
    `;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `
      <span class="${cn('flex items-center ml-text-muted', this.getSlotClass('Prefix'))}">
        ${unsafeHTML(this.getSlotContent('Prefix'))}
      </span>
    `;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `
      <span class="${cn('flex items-center ml-text-muted', this.getSlotClass('Suffix'))}">
        ${unsafeHTML(this.getSlotContent('Suffix'))}
      </span>
    `;
    }
    renderLoadingIndicator() {
        return html `
      <span class="h-4 w-4 animate-spin rounded-full ml-spinner"></span>
    `;
    }
    renderFeedback() {
        if (!this.isEditing)
            return html ``;
        const hasError = this.error && this.error.length > 0;
        if (hasError) {
            return html `
        <p id="${this.errorId}" class="text-xs ml-error-text" role="alert">
          ${unsafeHTML(this.error)}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="${cn('text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderViewMode() {
        const displayValue = this.value
            ? this.formatPhoneNumber(this.value)
            : this.msg.emptyValue;
        return html `
      <div class="${cn(this.getContainerClasses(), this.cssClass)}">
        ${this.renderLabel()}
        <div class="flex items-center gap-2">
          ${this.renderPrefix()}
          <span class="text-sm ml-text">${displayValue}</span>
          ${this.renderSuffix()}
        </div>
      </div>
    `;
    }
    renderEditMode() {
        const hasError = this.error && this.error.length > 0;
        const placeholderText = this.placeholder || this.msg.placeholder;
        return html `
      <div class="${cn(this.getContainerClasses(), this.cssClass)}">
        ${this.renderLabel()}
        <div class="${this.getInputWrapperClasses()}">
          ${this.renderPrefix()}
          <input
            type="tel"
            class="${this.getInputClasses()}"
            .value="${this.rawDisplay}"
            placeholder="${placeholderText}"
            ?disabled="${this.disabled || this.loading}"
            ?readonly="${this.readonly}"
            ?required="${this.required}"
            autocomplete="${this.autocomplete || 'tel'}"
            name="${this.name}"
            aria-labelledby="${this.hasSlot('Label') ? this.labelId : ''}"
            aria-describedby="${hasError ? this.errorId : ''}"
            aria-invalid="${hasError ? 'true' : 'false'}"
            aria-required="${this.required ? 'true' : 'false'}"
            @input="${this.handleInput}"
            @change="${this.handleChange}"
            @focus="${this.handleFocus}"
            @blur="${this.handleBlur}"
          />
          ${this.loading ? this.renderLoadingIndicator() : html ``}
          ${this.renderSuffix()}
        </div>
        ${this.renderFeedback()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
};
__decorate([
    propertyDataSource({ type: String })
], PhoneInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], PhoneInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], PhoneInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], PhoneInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], PhoneInputMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], PhoneInputMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: String })
], PhoneInputMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], PhoneInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PhoneInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PhoneInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PhoneInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], PhoneInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], PhoneInputMolecule.prototype, "isFocused", void 0);
__decorate([
    state()
], PhoneInputMolecule.prototype, "rawDisplay", void 0);
PhoneInputMolecule = __decorate([
    customElement('groupentertext--ml-phone-input')
], PhoneInputMolecule);
export { PhoneInputMolecule };
