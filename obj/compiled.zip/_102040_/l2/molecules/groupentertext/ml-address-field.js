/// <mls fileReference="_102040_/l2/molecules/groupentertext/ml-address-field.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ADDRESS FIELD MOLECULE
// =============================================================================
// Skill Group: groupEnterText
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    postalCodeLabel: 'Postal Code',
    streetLabel: 'Street',
    numberLabel: 'Number',
    complementLabel: 'Complement',
    neighborhoodLabel: 'Neighborhood',
    cityLabel: 'City',
    stateLabel: 'State',
    loading: 'Loading...',
    searching: 'Searching address...',
    emptyValue: '—',
    secureValue: '••••••••',
};
const messages = {
    en: message_en,
    pt: {
        postalCodeLabel: 'CEP',
        streetLabel: 'Rua',
        numberLabel: 'Número',
        complementLabel: 'Complemento',
        neighborhoodLabel: 'Bairro',
        cityLabel: 'Cidade',
        stateLabel: 'Estado',
        loading: 'Carregando...',
        searching: 'Buscando endereço...',
        emptyValue: '—',
        secureValue: '••••••••',
    },
};
let MlAddressFieldMolecule = class MlAddressFieldMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-address-field .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertext--ml-address-field .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-address-field .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertext--ml-address-field .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-address-field .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentertext--ml-address-field .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-address-field .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-address-field .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-address-field .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-address-field .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-address-field .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-address-field .ml-spinner {
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-address-field .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-address-field .ml-loading-overlay {
  background: color-mix(in srgb, var(--ml-surface, #ffffff) 50%, transparent);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        // Address values
        this.postalCode = '';
        this.street = '';
        this.number = '';
        this.complement = '';
        this.neighborhood = '';
        this.city = '';
        this.stateCode = '';
        // Error messages for each field
        this.postalCodeError = '';
        this.streetError = '';
        this.numberError = '';
        this.complementError = '';
        this.neighborhoodError = '';
        this.cityError = '';
        this.stateError = '';
        // Configuration
        this.name = '';
        this.postalCodeMask = '#####-###';
        this.postalCodeLength = 8;
        this.streetMaxLength = null;
        this.numberMaxLength = null;
        this.complementMaxLength = null;
        this.neighborhoodMaxLength = null;
        this.cityMaxLength = null;
        this.complementRows = 1;
        // States
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.loading = false;
        this.postalCodeRequired = false;
        this.streetRequired = false;
        this.numberRequired = false;
        this.neighborhoodRequired = false;
        this.cityRequired = false;
        this.stateRequired = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.postalCodeDisplay = '';
        this.isSearching = false;
        this.focusedField = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.postalCodeDisplay = this.applyMask(this.postalCode, this.postalCodeMask);
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const postalCodeAttr = this.getAttribute('postal-code');
        if (postalCodeAttr === `{{${key}}}`) {
            this.postalCodeDisplay = this.applyMask(value || '', this.postalCodeMask);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // MASK HELPERS
    // ===========================================================================
    applyMask(raw, mask) {
        if (!mask || !raw)
            return raw;
        let result = '';
        let rawIndex = 0;
        for (let i = 0; i < mask.length && rawIndex < raw.length; i++) {
            const maskChar = mask[i];
            const rawChar = raw[rawIndex];
            if (maskChar === '#') {
                if (/\d/.test(rawChar)) {
                    result += rawChar;
                    rawIndex++;
                }
                else {
                    rawIndex++;
                    i--;
                }
            }
            else if (maskChar === 'A') {
                if (/[a-zA-Z]/.test(rawChar)) {
                    result += rawChar;
                    rawIndex++;
                }
                else {
                    rawIndex++;
                    i--;
                }
            }
            else if (maskChar === '*') {
                result += rawChar;
                rawIndex++;
            }
            else {
                result += maskChar;
            }
        }
        return result;
    }
    extractRaw(masked, mask) {
        if (!mask)
            return masked;
        let raw = '';
        let maskIndex = 0;
        for (let i = 0; i < masked.length && maskIndex < mask.length; i++) {
            const maskChar = mask[maskIndex];
            const inputChar = masked[i];
            if (maskChar === '#' || maskChar === 'A' || maskChar === '*') {
                raw += inputChar;
                maskIndex++;
            }
            else if (inputChar === maskChar) {
                maskIndex++;
            }
        }
        return raw;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handlePostalCodeInput(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        const rawValue = input.value.replace(/\D/g, '');
        if (this.postalCodeLength && rawValue.length > this.postalCodeLength) {
            return;
        }
        this.postalCode = rawValue;
        this.postalCodeDisplay = this.applyMask(rawValue, this.postalCodeMask);
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { field: 'postalCode', value: rawValue }
        }));
        if (rawValue.length === this.postalCodeLength) {
            this.triggerAddressLookup(rawValue);
        }
    }
    handleFieldInput(field, maxLength, e) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        let value = input.value;
        if (maxLength !== null && value.length > maxLength) {
            value = value.substring(0, maxLength);
            input.value = value;
        }
        this[field] = value;
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { field, value }
        }));
    }
    handleFieldBlur(field) {
        this.focusedField = null;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: { field, value: this[field] }
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { field, value: this[field] }
        }));
    }
    handleFieldFocus(field) {
        this.focusedField = field;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: { field }
        }));
    }
    triggerAddressLookup(postalCode) {
        this.isSearching = true;
        this.dispatchEvent(new CustomEvent('address-lookup', {
            bubbles: true,
            composed: true,
            detail: { postalCode }
        }));
    }
    confirmAddress() {
        const address = {
            postalCode: this.postalCode,
            street: this.street,
            number: this.number,
            complement: this.complement,
            neighborhood: this.neighborhood,
            city: this.city,
            state: this.stateCode,
        };
        this.dispatchEvent(new CustomEvent('address-confirmed', {
            bubbles: true,
            composed: true,
            detail: { address }
        }));
    }
    // ===========================================================================
    // CSS HELPERS
    // ===========================================================================
    getInputClasses(hasError, isFocused) {
        return [
            'w-full rounded-lg px-3 py-2 text-sm transition ml-input ml-input-container',
            hasError ? 'ml-input-container-error' : '',
            this.disabled ? 'ml-disabled' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getLabelClasses() {
        return 'block text-sm font-medium mb-1 ml-label';
    }
    getErrorClasses() {
        return 'mt-1 text-xs ml-error-text';
    }
    getHelperClasses() {
        return 'mt-1 text-xs ml-helper';
    }
    getViewValueClasses() {
        return 'text-sm ml-text';
    }
    getCounterClasses() {
        return 'mt-1 text-xs ml-text-muted text-right';
    }
    getContainerClasses() {
        return [
            'relative',
            this.loading ? 'opacity-70 pointer-events-none' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel(text, required) {
        return html `
      <label class="${this.getLabelClasses()}">
        ${text}
        ${required ? html `<span class="ml-error-text">*</span>` : html ``}
      </label>
    `;
    }
    renderViewValue(value) {
        const displayValue = value || this.msg.emptyValue;
        return html `<span class="${this.getViewValueClasses()}">${displayValue}</span>`;
    }
    renderError(error) {
        if (!error)
            return html ``;
        return html `<p class="${this.getErrorClasses()}">${unsafeHTML(error)}</p>`;
    }
    renderCounter(value, maxLength) {
        if (maxLength === null)
            return html ``;
        return html `
      <p class="${this.getCounterClasses()}" aria-live="polite">
        ${String(value ?? '').length} / ${maxLength}
      </p>
    `;
    }
    renderInput(field, value, label, required, error, maxLength, placeholder = '') {
        const isFocused = this.focusedField === field;
        const hasError = !!error;
        const inputId = `${this.name}-${field}`;
        const errorId = `${inputId}-error`;
        if (!this.isEditing) {
            return html `
        <div class="mb-4">
          ${this.renderLabel(label, required)}
          ${this.renderViewValue(value)}
        </div>
      `;
        }
        return html `
      <div class="mb-4">
        ${this.renderLabel(label, required)}
        <input
          type="text"
          id="${inputId}"
          class="${this.getInputClasses(hasError, isFocused)}"
          .value="${value}"
          placeholder="${placeholder}"
          ?disabled="${this.disabled}"
          ?readonly="${this.readonly}"
          aria-required="${required}"
          aria-invalid="${hasError}"
          aria-describedby="${hasError ? errorId : ''}"
          maxlength="${maxLength !== null ? maxLength : ''}"
          @input="${(e) => { e.stopPropagation(); this.handleFieldInput(field, maxLength, e); }}"
          @blur="${() => this.handleFieldBlur(field)}"
          @focus="${() => this.handleFieldFocus(field)}"
        
        @change="${(e) => e.stopPropagation()}"
/>
        ${this.renderError(error)}
      </div>
    `;
    }
    renderTextarea(field, value, label, required, error, maxLength, rows, placeholder = '') {
        const isFocused = this.focusedField === field;
        const hasError = !!error;
        const inputId = `${this.name}-${field}`;
        const errorId = `${inputId}-error`;
        const counterId = `${inputId}-counter`;
        if (!this.isEditing) {
            return html `
        <div class="mb-4">
          ${this.renderLabel(label, required)}
          ${this.renderViewValue(value)}
        </div>
      `;
        }
        return html `
      <div class="mb-4">
        ${this.renderLabel(label, required)}
        <textarea
          id="${inputId}"
          class="${this.getInputClasses(hasError, isFocused)} resize-none"
          .value="${value}"
          placeholder="${placeholder}"
          rows="${rows}"
          ?disabled="${this.disabled}"
          ?readonly="${this.readonly}"
          aria-required="${required}"
          aria-invalid="${hasError}"
          aria-describedby="${hasError ? errorId : counterId}"
          maxlength="${maxLength !== null ? maxLength : ''}"
          @input="${(e) => { e.stopPropagation(); this.handleFieldInput(field, maxLength, e); }}"
          @blur="${() => this.handleFieldBlur(field)}"
          @focus="${() => this.handleFieldFocus(field)}"
        
          @change="${(e) => e.stopPropagation()}"
></textarea>
        ${this.renderCounter(value, maxLength)}
        ${this.renderError(error)}
      </div>
    `;
    }
    renderPostalCodeField() {
        const isFocused = this.focusedField === 'postalCode';
        const hasError = !!this.postalCodeError;
        const inputId = `${this.name}-postalCode`;
        const errorId = `${inputId}-error`;
        if (!this.isEditing) {
            return html `
        <div class="mb-4">
          ${this.renderLabel(this.msg.postalCodeLabel, this.postalCodeRequired)}
          ${this.renderViewValue(this.postalCodeDisplay || this.postalCode)}
        </div>
      `;
        }
        return html `
      <div class="mb-4">
        ${this.renderLabel(this.msg.postalCodeLabel, this.postalCodeRequired)}
        <div class="relative">
          <input
            type="text"
            id="${inputId}"
            class="${this.getInputClasses(hasError, isFocused)}"
            .value="${this.postalCodeDisplay}"
            ?disabled="${this.disabled}"
            ?readonly="${this.readonly}"
            aria-required="${this.postalCodeRequired}"
            aria-invalid="${hasError}"
            aria-describedby="${hasError ? errorId : ''}"
            @input="${this.handlePostalCodeInput}"
            @blur="${() => this.handleFieldBlur('postalCode')}"
            @focus="${() => this.handleFieldFocus('postalCode')}"
          
          @change="${(e) => e.stopPropagation()}"
/>
          ${this.isSearching ? html `
            <div class="absolute right-3 top-1/2 -translate-y-1/2">
              <svg class="animate-spin h-4 w-4 ml-spinner" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
            </div>
          ` : html ``}
        </div>
        ${this.renderError(this.postalCodeError)}
      </div>
    `;
    }
    renderLoadingOverlay() {
        if (!this.loading)
            return html ``;
        return html `
      <div class="absolute inset-0 flex items-center justify-center rounded-lg z-10 ml-loading-overlay">
        <div class="flex items-center gap-2 ml-text-muted">
          <svg class="animate-spin h-5 w-5 ml-spinner" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <span class="text-sm">${this.msg.loading}</span>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <div class="${cn(this.getContainerClasses(), this.cssClass)}">
        ${this.renderLoadingOverlay()}

        <div class="space-y-4">
          <!-- Postal Code -->
          ${this.renderPostalCodeField()}
          
          <!-- Street -->
          ${this.renderInput('street', this.street, this.msg.streetLabel, this.streetRequired, this.streetError, this.streetMaxLength)}
          
          <!-- Number and Complement Row -->
          <div class="grid grid-cols-2 gap-4">
            <div>
              ${this.renderInput('number', this.number, this.msg.numberLabel, this.numberRequired, this.numberError, this.numberMaxLength)}
            </div>
            <div>
              ${this.complementRows > 1
            ? this.renderTextarea('complement', this.complement, this.msg.complementLabel, false, this.complementError, this.complementMaxLength, this.complementRows)
            : this.renderInput('complement', this.complement, this.msg.complementLabel, false, this.complementError, this.complementMaxLength)}
            </div>
          </div>
          
          <!-- Neighborhood -->
          ${this.renderInput('neighborhood', this.neighborhood, this.msg.neighborhoodLabel, this.neighborhoodRequired, this.neighborhoodError, this.neighborhoodMaxLength)}
          
          <!-- City and State Row -->
          <div class="grid grid-cols-3 gap-4">
            <div class="col-span-2">
              ${this.renderInput('city', this.city, this.msg.cityLabel, this.cityRequired, this.cityError, this.cityMaxLength)}
            </div>
            <div>
              ${this.renderInput('stateCode', this.stateCode, this.msg.stateLabel, this.stateRequired, this.stateError, 2)}
            </div>
          </div>
        </div>
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'postal-code' })
], MlAddressFieldMolecule.prototype, "postalCode", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAddressFieldMolecule.prototype, "street", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAddressFieldMolecule.prototype, "number", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAddressFieldMolecule.prototype, "complement", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAddressFieldMolecule.prototype, "neighborhood", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAddressFieldMolecule.prototype, "city", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'state-code' })
], MlAddressFieldMolecule.prototype, "stateCode", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'postal-code-error' })
], MlAddressFieldMolecule.prototype, "postalCodeError", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'street-error' })
], MlAddressFieldMolecule.prototype, "streetError", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'number-error' })
], MlAddressFieldMolecule.prototype, "numberError", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'complement-error' })
], MlAddressFieldMolecule.prototype, "complementError", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'neighborhood-error' })
], MlAddressFieldMolecule.prototype, "neighborhoodError", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'city-error' })
], MlAddressFieldMolecule.prototype, "cityError", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'state-error' })
], MlAddressFieldMolecule.prototype, "stateError", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlAddressFieldMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'postal-code-mask' })
], MlAddressFieldMolecule.prototype, "postalCodeMask", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'postal-code-length' })
], MlAddressFieldMolecule.prototype, "postalCodeLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'street-max-length' })
], MlAddressFieldMolecule.prototype, "streetMaxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'number-max-length' })
], MlAddressFieldMolecule.prototype, "numberMaxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'complement-max-length' })
], MlAddressFieldMolecule.prototype, "complementMaxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'neighborhood-max-length' })
], MlAddressFieldMolecule.prototype, "neighborhoodMaxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'city-max-length' })
], MlAddressFieldMolecule.prototype, "cityMaxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'complement-rows' })
], MlAddressFieldMolecule.prototype, "complementRows", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlAddressFieldMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAddressFieldMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAddressFieldMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlAddressFieldMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'postal-code-required' })
], MlAddressFieldMolecule.prototype, "postalCodeRequired", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'street-required' })
], MlAddressFieldMolecule.prototype, "streetRequired", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'number-required' })
], MlAddressFieldMolecule.prototype, "numberRequired", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'neighborhood-required' })
], MlAddressFieldMolecule.prototype, "neighborhoodRequired", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'city-required' })
], MlAddressFieldMolecule.prototype, "cityRequired", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'state-required' })
], MlAddressFieldMolecule.prototype, "stateRequired", void 0);
__decorate([
    state()
], MlAddressFieldMolecule.prototype, "postalCodeDisplay", void 0);
__decorate([
    state()
], MlAddressFieldMolecule.prototype, "isSearching", void 0);
__decorate([
    state()
], MlAddressFieldMolecule.prototype, "focusedField", void 0);
MlAddressFieldMolecule = __decorate([
    customElement('groupentertext--ml-address-field')
], MlAddressFieldMolecule);
export { MlAddressFieldMolecule };
