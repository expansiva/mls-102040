/// <mls fileReference="_102040_/l2/molecules/groupentertext/ml-tag-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TAG INPUT MOLECULE
// =============================================================================
// Skill Group: groupEnterText
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Type and press Enter to add tags',
    noValue: '—',
    removeTag: 'Remove tag',
    charactersRemaining: 'characters remaining',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Digite e pressione Enter para adicionar tags',
        noValue: '—',
        removeTag: 'Remover tag',
        charactersRemaining: 'caracteres restantes',
    },
};
/// **collab_i18n_end**
let MlTagInputMolecule = class MlTagInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-tag-input .ml-input-container {
  background: var(--surface-bg, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-small, 6px);
  transition: border-color var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
}
groupentertext--ml-tag-input .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-tag-input .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertext--ml-tag-input .ml-input {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-tag-input .ml-input::placeholder {
  color: var(--text-muted-disabled, #79747e);
}
groupentertext--ml-tag-input .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupentertext--ml-tag-input .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-tag-input .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-tag-input .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-tag-input .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-tag-input .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-tag-input .ml-spinner {
  border-color: var(--border-default, #e2e8f0);
  border-top-color: var(--text-strong, #1c1b1f);
}
groupentertext--ml-tag-input .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertext--ml-tag-input .ml-loading-overlay {
  background: color-mix(in srgb, var(--surface-bg, #ffffff) 50%, transparent);
}
groupentertext--ml-tag-input .ml-tag {
  background: var(--ml-surface-dim, #f1f5f9);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-small, 6px);
  color: var(--text-strong, #1c1b1f);
}
groupentertext--ml-tag-input .ml-tag-remove {
  color: var(--text-muted, #49454f);
}
groupentertext--ml-tag-input .ml-tag-remove:hover {
  color: var(--status-error-text, #ef4444);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        // Data
        this.value = '';
        this.error = '';
        this.name = '';
        // Configuration
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        // States
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.currentInput = '';
        this.isFocused = false;
    }
    // ===========================================================================
    // COMPUTED PROPERTIES
    // ===========================================================================
    get tags() {
        if (!this.value || this.value.trim() === '')
            return [];
        return this.value
            .split(',')
            .map(tag => tag.trim())
            .filter(tag => tag.length > 0);
    }
    get isInteractive() {
        return !this.disabled && !this.loading && !this.readonly;
    }
    get isMultiLine() {
        return this.rows > 1;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            // Value changed externally, reset current input
            this.currentInput = '';
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        e.stopPropagation();
        const target = e.target;
        if (this.isMultiLine) {
            // Multi-line mode: standard text behavior
            if (this.maxLength !== null && target.value.length > this.maxLength) {
                target.value = target.value.slice(0, this.maxLength);
            }
            this.value = target.value;
            this.dispatchEvent(new CustomEvent('input', {
                bubbles: true,
                composed: true,
                detail: { value: this.value }
            }));
        }
        else {
            // Single-line tag mode
            let inputValue = target.value;
            // Block input beyond max length for current token
            if (this.maxLength !== null && inputValue.length > this.maxLength) {
                inputValue = inputValue.slice(0, this.maxLength);
                target.value = inputValue;
            }
            // Check for comma delimiter
            if (inputValue.includes(',')) {
                const parts = inputValue.split(',');
                for (let i = 0; i < parts.length - 1; i++) {
                    this.addTag(parts[i].trim());
                }
                this.currentInput = parts[parts.length - 1];
                target.value = this.currentInput;
            }
            else {
                this.currentInput = inputValue;
            }
        }
    }
    handleKeyDown(e) {
        if (!this.isInteractive || this.isMultiLine)
            return;
        if (e.key === 'Enter') {
            e.preventDefault();
            this.addTag(this.currentInput.trim());
        }
        else if (e.key === 'Backspace' && this.currentInput === '' && this.tags.length > 0) {
            // Remove last tag when backspace on empty input
            this.removeTagByIndex(this.tags.length - 1);
        }
    }
    addTag(tag) {
        if (!tag || tag.length === 0)
            return;
        // Check min length
        if (this.minLength !== null && tag.length < this.minLength)
            return;
        // Check max length
        if (this.maxLength !== null && tag.length > this.maxLength)
            return;
        // Check for duplicates (case-insensitive)
        const lowerTag = tag.toLowerCase();
        const isDuplicate = this.tags.some(t => t.toLowerCase() === lowerTag);
        if (isDuplicate)
            return;
        // Add tag
        const newTags = [...this.tags, tag];
        this.value = newTags.join(', ');
        this.currentInput = '';
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    removeTagByIndex(index) {
        if (!this.isInteractive)
            return;
        const newTags = this.tags.filter((_, i) => i !== index);
        this.value = newTags.join(', ');
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleFocus() {
        if (!this.isInteractive)
            return;
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        if (!this.isInteractive)
            return;
        this.isFocused = false;
        // Commit any pending input as tag on blur (single-line mode)
        if (!this.isMultiLine && this.currentInput.trim()) {
            this.addTag(this.currentInput.trim());
        }
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleContainerClick(e) {
        if (!this.isInteractive || !this.isEditing)
            return;
        // Focus the input when clicking on the container
        const input = this.querySelector('input, textarea');
        if (input) {
            input.focus();
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getContainerClasses() {
        const hasError = this.error && this.error.length > 0;
        return [
            'w-full rounded-lg transition-all ml-input-container',
            hasError ? 'ml-input-container-error' : '',
            this.disabled || this.loading
                ? 'ml-disabled'
                : this.readonly
                    ? 'cursor-default'
                    : 'cursor-text',
        ].filter(Boolean).join(' ');
    }
    getInputClasses() {
        return [
            'flex-1 min-w-[120px] bg-transparent border-none outline-none text-sm ml-input',
            this.disabled || this.loading ? 'cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getTagClasses() {
        return [
            'inline-flex items-center gap-1 px-2 py-1 rounded-md text-sm ml-tag',
        ].join(' ');
    }
    getRemoveButtonClasses() {
        return [
            'inline-flex items-center justify-center w-4 h-4 rounded-full',
            'ml-tag-remove',
            'focus:outline-none',
            'transition-colors',
            !this.isInteractive ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        return html `
      <label class="${cn('block text-sm font-medium mb-1 ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(labelContent)}
        ${this.required ? html `<span class="ml-error-text ml-0.5">*</span>` : ''}
      </label>
    `;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        const prefixContent = this.getSlotContent('Prefix');
        return html `
      <span class="${cn('flex-shrink-0 ml-text-faint', this.getSlotClass('Prefix'))}">
        ${unsafeHTML(prefixContent)}
      </span>
    `;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        const suffixContent = this.getSlotContent('Suffix');
        return html `
      <span class="${cn('flex-shrink-0 ml-text-faint', this.getSlotClass('Suffix'))}">
        ${unsafeHTML(suffixContent)}
      </span>
    `;
    }
    renderTag(tag, index) {
        return html `
      <span class="${this.getTagClasses()}">
        <span class="max-w-[150px] truncate">${tag}</span>
        ${this.isInteractive ? html `
          <button
            type="button"
            class="${this.getRemoveButtonClasses()}"
            @click=${(e) => {
            e.stopPropagation();
            this.removeTagByIndex(index);
        }}
            aria-label="${this.msg.removeTag}: ${tag}"
            ?disabled=${!this.isInteractive}
          >
            <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        ` : ''}
      </span>
    `;
    }
    renderTags() {
        if (this.tags.length === 0)
            return html ``;
        return html `
      ${this.tags.map((tag, index) => this.renderTag(tag, index))}
    `;
    }
    renderInput() {
        const placeholderText = this.placeholder || this.msg.placeholder;
        return html `
      <input
        type="${this.inputType}"
        class="${this.getInputClasses()}"
        .value=${this.currentInput}
        placeholder=${this.tags.length === 0 ? placeholderText : ''}
        ?disabled=${this.disabled || this.loading}
        ?readonly=${this.readonly}
        autocomplete=${this.autocomplete || 'off'}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        @input=${this.handleInput}
        @keydown=${this.handleKeyDown}
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
      
      @change="${(e) => e.stopPropagation()}"
/>
    `;
    }
    renderTextarea() {
        const placeholderText = this.placeholder || this.msg.placeholder;
        const currentLength = this.value?.length || 0;
        return html `
      <textarea
        class="${this.getInputClasses()} w-full resize-none py-2"
        .value=${this.value || ''}
        placeholder=${placeholderText}
        rows=${this.rows}
        ?disabled=${this.disabled || this.loading}
        ?readonly=${this.readonly}
        autocomplete=${this.autocomplete || 'off'}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
        @input=${this.handleInput}
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
      
        @change="${(e) => e.stopPropagation()}"
></textarea>
      ${this.maxLength !== null ? html `
        <div class="text-xs ml-text-muted text-right mt-1" aria-live="polite">
          ${currentLength} / ${this.maxLength}
        </div>
      ` : ''}
    `;
    }
    renderEditMode() {
        if (this.isMultiLine) {
            return html `
        <div class="${this.getContainerClasses()} p-2">
          ${this.renderPrefix()}
          ${this.renderTextarea()}
          ${this.renderSuffix()}
        </div>
      `;
        }
        return html `
      <div 
        class="${this.getContainerClasses()} p-2 min-h-[42px]"
        @click=${this.handleContainerClick}
      >
        <div class="flex flex-wrap items-center gap-2">
          ${this.renderPrefix()}
          ${this.renderTags()}
          ${this.renderInput()}
          ${this.renderSuffix()}
        </div>
      </div>
    `;
    }
    renderViewMode() {
        const displayValue = this.value && this.value.trim() !== ''
            ? this.value
            : this.msg.noValue;
        return html `
      <div class="flex items-center gap-2 py-2 text-sm ml-text">
        ${this.renderPrefix()}
        <span>${displayValue}</span>
        ${this.renderSuffix()}
      </div>
    `;
    }
    renderHelper() {
        if (!this.isEditing)
            return html ``;
        if (this.error && this.error.length > 0) {
            return html `
        <p class="mt-1 text-xs ml-error-text" role="alert">
          ${unsafeHTML(this.error)}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <div class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </div>
      `;
        }
        return html ``;
    }
    renderLoadingIndicator() {
        if (!this.loading)
            return html ``;
        return html `
      <div class="absolute inset-0 flex items-center justify-center rounded-lg ml-loading-overlay">
        <svg class="animate-spin h-5 w-5 ml-spinner" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        <div class="relative">
          ${this.isEditing ? this.renderEditMode() : this.renderViewMode()}
          ${this.renderLoadingIndicator()}
        </div>
        ${this.renderHelper()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTagInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTagInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTagInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTagInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], MlTagInputMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], MlTagInputMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlTagInputMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTagInputMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], MlTagInputMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlTagInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTagInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTagInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTagInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTagInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTagInputMolecule.prototype, "currentInput", void 0);
__decorate([
    state()
], MlTagInputMolecule.prototype, "isFocused", void 0);
MlTagInputMolecule = __decorate([
    customElement('groupentertext--ml-tag-input')
], MlTagInputMolecule);
export { MlTagInputMolecule };
