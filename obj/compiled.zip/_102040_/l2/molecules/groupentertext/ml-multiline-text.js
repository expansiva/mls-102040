var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertext/ml-multiline-text.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTILINE TEXT MOLECULE
// =============================================================================
// Skill Group: groupEnterText (enter + text)
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
let MultilineTextMolecule = class MultilineTextMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-multiline-text .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-multiline-text .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-multiline-text .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-multiline-text .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-multiline-text .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-multiline-text .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-multiline-text .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertext--ml-multiline-text .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-multiline-text .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertext--ml-multiline-text .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-multiline-text .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentertext--ml-multiline-text .ml-spinner {
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-multiline-text .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        this.mask = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.rawDisplay = '';
        this.labelId = `mlt-label-${Math.random().toString(36).slice(2)}`;
        this.inputId = `mlt-input-${Math.random().toString(36).slice(2)}`;
        this.helperId = `mlt-helper-${Math.random().toString(36).slice(2)}`;
        this.errorId = `mlt-error-${Math.random().toString(36).slice(2)}`;
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    firstUpdated() {
        this.syncRawDisplay();
    }
    // ==========================================================================
    // STATE CHANGE HANDLER
    // ==========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const maskAttr = this.getAttribute('mask');
        const rowsAttr = this.getAttribute('rows');
        const inputTypeAttr = this.getAttribute('input-type');
        if (valueAttr === `{{${key}}}` ||
            maskAttr === `{{${key}}}` ||
            rowsAttr === `{{${key}}}` ||
            inputTypeAttr === `{{${key}}}`) {
            this.syncRawDisplay();
        }
        this.requestUpdate();
    }
    // ==========================================================================
    // HELPERS
    // ==========================================================================
    isMaskActive() {
        return Boolean(this.mask && this.mask.length > 0 && this.rows === 1);
    }
    shouldRenderTextarea() {
        return this.rows > 1;
    }
    normalizeValue(value) {
        return value ?? '';
    }
    syncRawDisplay() {
        const currentValue = this.normalizeValue(this.value);
        if (this.inputType === 'password') {
            this.rawDisplay = '';
            return;
        }
        if (this.isMaskActive()) {
            this.rawDisplay = this.applyMaskToRaw(currentValue, this.mask);
        }
        else {
            this.rawDisplay = currentValue;
        }
    }
    applyMaxLength(raw) {
        if (this.maxLength === null || this.maxLength === undefined)
            return raw;
        return raw.slice(0, this.maxLength);
    }
    getRawFromInput(input, mask) {
        const tokens = mask.split('').filter((ch) => ch === '#' || ch === 'A' || ch === '*');
        let raw = '';
        let tokenIndex = 0;
        for (let i = 0; i < input.length; i += 1) {
            if (tokenIndex >= tokens.length)
                break;
            const token = tokens[tokenIndex];
            const char = input[i];
            if (this.matchToken(token, char)) {
                raw += char;
                tokenIndex += 1;
            }
        }
        return raw;
    }
    matchToken(token, char) {
        if (token === '#')
            return /[0-9]/.test(char);
        if (token === 'A')
            return /[A-Za-z]/.test(char);
        return char.length > 0;
    }
    applyMaskToRaw(raw, mask) {
        let result = '';
        let rawIndex = 0;
        for (let i = 0; i < mask.length; i += 1) {
            const m = mask[i];
            const isToken = m === '#' || m === 'A' || m === '*';
            if (isToken) {
                if (rawIndex >= raw.length)
                    break;
                result += raw[rawIndex];
                rawIndex += 1;
            }
            else if (rawIndex > 0) {
                result += m;
            }
        }
        return result;
    }
    getDisplayValue() {
        if (!this.isEditing) {
            if (this.inputType === 'password')
                return '••••••••';
            const value = this.normalizeValue(this.value);
            return value === '' ? '—' : value;
        }
        if (this.inputType === 'password')
            return this.normalizeValue(this.value);
        if (this.isMaskActive())
            return this.rawDisplay;
        return this.normalizeValue(this.value);
    }
    getWrapperClasses(hasError) {
        return [
            'flex items-stretch gap-2 w-full px-3 py-2 ml-input-container',
            hasError ? 'ml-input-container-error' : '',
            this.disabled || this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses() {
        return [
            'flex-1 bg-transparent outline-none text-sm ml-input',
            this.disabled || this.loading ? 'cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<label id=${this.labelId} class="${cn('mb-1 block text-sm ml-label', this.getSlotClass('Label'))}" for=${this.inputId}>
${unsafeHTML(this.getSlotContent('Label'))}
</label>`;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<div class="${cn('flex items-center ml-text-muted', this.getSlotClass('Prefix'))}">
${unsafeHTML(this.getSlotContent('Prefix'))}
</div>`;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix'))
            return html ``;
        return html `<div class="${cn('flex items-center ml-text-muted', this.getSlotClass('Suffix'))}">
${unsafeHTML(this.getSlotContent('Suffix'))}
</div>`;
    }
    renderLoading() {
        if (!this.loading)
            return html ``;
        return html `<div class="ml-2 flex items-center">
<span class="h-4 w-4 animate-spin rounded-full ml-spinner"></span>
</div>`;
    }
    renderHelperOrError() {
        if (this.error) {
            return html `<p id=${this.errorId} class="mt-1 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${this.helperId} class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderCounter() {
        const isMultiline = this.shouldRenderTextarea();
        const hasMax = this.maxLength !== null && this.maxLength !== undefined;
        if (!isMultiline || !hasMax)
            return html ``;
        const count = this.normalizeValue(this.value).length;
        return html `<p class="mt-1 text-xs ml-text-muted" aria-live="polite">
${count} / ${this.maxLength}
</p>`;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleInput(e) {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const target = e.target;
        const inputValue = target.value || '';
        if (this.shouldRenderTextarea()) {
            let next = inputValue;
            if (this.maxLength !== null && this.maxLength !== undefined) {
                next = next.slice(0, this.maxLength);
                if (next !== inputValue)
                    target.value = next;
            }
            this.value = next;
            this.dispatchEvent(new CustomEvent('input', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            return;
        }
        if (this.isMaskActive()) {
            const raw = this.getRawFromInput(inputValue, this.mask);
            const limitedRaw = this.applyMaxLength(raw);
            const masked = this.applyMaskToRaw(limitedRaw, this.mask);
            this.rawDisplay = masked;
            this.value = limitedRaw;
            if (target.value !== masked)
                target.value = masked;
        }
        else {
            let next = inputValue;
            if (this.maxLength !== null && this.maxLength !== undefined) {
                next = next.slice(0, this.maxLength);
                if (next !== inputValue)
                    target.value = next;
            }
            this.value = next;
        }
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    handleFocus() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        return this.isEditing ? this.renderEditMode() : this.renderViewMode();
    }
    renderViewMode() {
        const displayValue = this.getDisplayValue();
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div class="flex items-center gap-2">
${this.renderPrefix()}
<div class="text-sm ml-text">${displayValue}</div>
${this.renderSuffix()}
</div>
</div>
`;
    }
    renderEditMode() {
        const hasError = Boolean(this.error);
        const isMultiline = this.shouldRenderTextarea();
        const describedBy = hasError
            ? this.errorId
            : this.hasSlot('Helper')
                ? this.helperId
                : undefined;
        const maxLengthAttr = this.maxLength !== null && this.maxLength !== undefined && !this.isMaskActive()
            ? this.maxLength
            : undefined;
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div class=${this.getWrapperClasses(hasError)}>
${this.renderPrefix()}
${isMultiline
            ? html `<textarea
id=${this.inputId}
class=${this.getInputClasses()}
rows=${this.rows}
.name=${this.name}
.placeholder=${this.placeholder}
.value=${this.getDisplayValue()}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
?required=${this.required}
maxlength=${ifDefined(maxLengthAttr)}
aria-labelledby=${ifDefined(this.hasSlot('Label') ? this.labelId : undefined)}
aria-describedby=${ifDefined(describedBy)}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@input=${this.handleInput}
@blur=${this.handleBlur}
@focus=${this.handleFocus}
></textarea>`
            : html `<input
id=${this.inputId}
class=${this.getInputClasses()}
type=${this.inputType}
.name=${this.name}
.placeholder=${this.placeholder}
.value=${this.getDisplayValue()}
autocomplete=${this.autocomplete}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
?required=${this.required}
maxlength=${ifDefined(maxLengthAttr)}
aria-labelledby=${ifDefined(this.hasSlot('Label') ? this.labelId : undefined)}
aria-describedby=${ifDefined(describedBy)}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@input=${this.handleInput}
@blur=${this.handleBlur}
@focus=${this.handleFocus}
/>`}
${this.renderSuffix()}
${this.renderLoading()}
</div>
${this.renderCounter()}
${this.renderHelperOrError()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MultilineTextMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultilineTextMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultilineTextMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultilineTextMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], MultilineTextMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], MultilineTextMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MultilineTextMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultilineTextMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], MultilineTextMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultilineTextMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MultilineTextMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultilineTextMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultilineTextMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultilineTextMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultilineTextMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MultilineTextMolecule.prototype, "rawDisplay", void 0);
MultilineTextMolecule = __decorate([
    customElement('groupentertext--ml-multiline-text')
], MultilineTextMolecule);
export { MultilineTextMolecule };
