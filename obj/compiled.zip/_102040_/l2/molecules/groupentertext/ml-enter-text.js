/// <mls fileReference="_102040_/l2/molecules/groupentertext/ml-enter-text.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// GROUP ENTER TEXT – ML ENTER TEXT MOLECULE
// =============================================================================
// Skill Group: groupEnterText (Data Entry)
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select an option',
    noResults: 'No results found',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    // other locales could be added here
};
/// **collab_i18n_end**
let MlEnterTextMolecule = class MlEnterTextMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-enter-text .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertext--ml-enter-text .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-enter-text .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertext--ml-enter-text .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentertext--ml-enter-text .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-enter-text .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-enter-text .ml-spinner {
  border-color: var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-on-surface, #1c1b1f);
}
groupentertext--ml-enter-text .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES – From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        this.mask = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.rawDisplay = '';
        this.isFocused = false;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER – derived state from value
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.updateRawDisplay(value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // Lit updated hook – also keep derived state in sync for direct bindings
    // ===========================================================================
    updated(changedProps) {
        if (changedProps.has('value')) {
            this.updateRawDisplay(this.value);
        }
    }
    // ===========================================================================
    // HELPERS – mask handling & CSS classes
    // ===========================================================================
    updateRawDisplay(raw) {
        // Bound props ({{...}}) resolve to undefined before the state is seeded.
        raw = String(raw ?? '');
        if (this.mask) {
            this.rawDisplay = this.applyMask(raw);
        }
        else {
            this.rawDisplay = raw;
        }
    }
    stripMask(display) {
        // Remove all characters that are not alphanumeric – simple approach
        return display.replace(/[^a-zA-Z0-9]/g, '');
    }
    applyMask(raw) {
        if (!this.mask)
            return raw;
        let result = '';
        let rawIdx = 0;
        for (const ch of this.mask) {
            if (rawIdx >= raw.length)
                break;
            if (ch === '#') {
                // digit only – if not a digit, skip
                const digit = raw[rawIdx].match(/\d/);
                if (digit) {
                    result += digit[0];
                    rawIdx++;
                }
                else {
                    // skip non‑digit in raw
                    rawIdx++;
                    continue;
                }
            }
            else if (ch === 'A') {
                const letter = raw[rawIdx].match(/[a-zA-Z]/);
                if (letter) {
                    result += letter[0];
                    rawIdx++;
                }
                else {
                    rawIdx++;
                    continue;
                }
            }
            else if (ch === '*') {
                result += raw[rawIdx];
                rawIdx++;
            }
            else {
                // literal character from mask
                result += ch;
            }
        }
        return result;
    }
    getInputClasses() {
        const base = [
            'w-full rounded-md px-3 py-2 text-sm transition ml-input ml-input-container',
            this.error ? 'ml-input-container-error' : '',
            this.disabled || this.loading ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
        return base;
    }
    getTextareaClasses() {
        return this.getInputClasses();
    }
    getLabelId() {
        return `${this.id}-label`;
    }
    getHelperId() {
        return `${this.id}-helper`;
    }
    getErrorId() {
        return `${this.id}-error`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        e.stopPropagation();
        const target = e.target;
        let displayValue = target.value;
        // Apply mask if needed
        if (this.mask) {
            const raw = this.stripMask(displayValue);
            // Enforce maxLength on raw value
            const limitedRaw = this.maxLength !== null ? raw.slice(0, this.maxLength) : raw;
            this.value = limitedRaw;
            this.rawDisplay = this.applyMask(limitedRaw);
            // Reflect masked value back to the element (avoid cursor jump for simplicity)
            target.value = this.rawDisplay;
        }
        else {
            // Enforce maxLength directly
            if (this.maxLength !== null && displayValue.length > this.maxLength) {
                displayValue = displayValue.slice(0, this.maxLength);
                target.value = displayValue;
            }
            this.value = displayValue;
            this.rawDisplay = displayValue;
        }
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleBlur() {
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleFocus() {
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (this.hasSlot('Label')) {
            const content = this.getSlotContent('Label');
            return html `<label id="${this.getLabelId()}" class="${cn('block mb-1 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(content)}
      </label>`;
        }
        return nothing;
    }
    renderHelperOrError() {
        if (this.error && this.isEditing) {
            return html `<p id="${this.getErrorId()}" class="mt-1 text-xs ml-error-text" role="alert">
        ${unsafeHTML(this.error)}
      </p>`;
        }
        if (this.hasSlot('Helper') && this.isEditing) {
            const content = this.getSlotContent('Helper');
            return html `<p id="${this.getHelperId()}" class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">
        ${unsafeHTML(content)}
      </p>`;
        }
        return nothing;
    }
    renderPrefix() {
        if (this.hasSlot('Prefix')) {
            return html `<span class="${cn('inline-flex items-center mr-2', this.getSlotClass('Prefix'))}">
        ${unsafeHTML(this.getSlotContent('Prefix'))}
      </span>`;
        }
        return nothing;
    }
    renderSuffix() {
        if (this.hasSlot('Suffix')) {
            return html `<span class="${cn('inline-flex items-center ml-2', this.getSlotClass('Suffix'))}">
        ${unsafeHTML(this.getSlotContent('Suffix'))}
      </span>`;
        }
        return nothing;
    }
    renderCounter() {
        if (this.rows > 1 && this.maxLength !== null) {
            return html `<div class="mt-1 text-xs ml-text-muted" aria-live="polite">
        ${String(this.value ?? '').length} / ${this.maxLength}
      </div>`;
        }
        return nothing;
    }
    renderInput() {
        const commonAttrs = {
            name: this.name,
            placeholder: this.placeholder || undefined,
            autocomplete: this.autocomplete || undefined,
            disabled: this.disabled || this.loading,
            readonly: this.readonly,
            required: this.required,
            'aria-labelledby': this.hasSlot('Label') ? this.getLabelId() : undefined,
            'aria-describedby': this.error && this.isEditing ? this.getErrorId() : (this.hasSlot('Helper') ? this.getHelperId() : undefined),
            'aria-invalid': this.error && this.isEditing ? 'true' : undefined,
            'aria-required': this.required ? 'true' : undefined,
        };
        if (this.rows === 1) {
            return html `
        <div class="flex items-center">
          ${this.renderPrefix()}
          <input
            type="${this.inputType}"
            class="${this.getInputClasses()}"
            .value="${this.rawDisplay}"
            @input="${this.handleInput}"
            @blur="${this.handleBlur}"
            @focus="${this.handleFocus}"
            ...=${commonAttrs}
          
          @change="${(e) => e.stopPropagation()}"
/>
          ${this.renderSuffix()}
        </div>`;
        }
        // Textarea (rows > 1) – mask not applied
        return html `
      <div class="flex flex-col">
        ${this.renderPrefix()}
        <textarea
          class="${this.getTextareaClasses()}"
          rows="${this.rows}"
          .value="${this.value}"
          @input="${this.handleInput}"
          @blur="${this.handleBlur}"
          @focus="${this.handleFocus}"
          ...=${commonAttrs}
        
          @change="${(e) => e.stopPropagation()}"
></textarea>
        ${this.renderSuffix()}
        ${this.renderCounter()}
      </div>`;
    }
    renderViewMode() {
        const displayText = (() => {
            if (!this.value)
                return '—';
            if (this.inputType === 'password')
                return '••••••••';
            return this.mask ? this.applyMask(this.value) : this.value;
        })();
        return html `
      <div class="flex items-center">
        ${this.renderPrefix()}
        <span class="${this.getInputClasses()}" aria-labelledby="${this.hasSlot('Label') ? this.getLabelId() : ''}">
          ${unsafeHTML(displayText)}
        </span>
        ${this.renderSuffix()}
      </div>`;
    }
    // ===========================================================================
    // MAIN RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `<div class="text-sm ml-text-muted">${this.msg.loading}</div>`;
        }
        return html `
      <div class="${cn('groupentertext--ml-enter-text', this.cssClass)}">
        ${this.renderLabel()}
        ${this.isEditing ? this.renderInput() : this.renderViewMode()}
        ${this.renderHelperOrError()}
      </div>`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], MlEnterTextMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], MlEnterTextMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlEnterTextMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlEnterTextMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlEnterTextMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'disabled' })
], MlEnterTextMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'readonly' })
], MlEnterTextMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'required' })
], MlEnterTextMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'loading' })
], MlEnterTextMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlEnterTextMolecule.prototype, "rawDisplay", void 0);
__decorate([
    state()
], MlEnterTextMolecule.prototype, "isFocused", void 0);
MlEnterTextMolecule = __decorate([
    customElement('groupentertext--ml-enter-text')
], MlEnterTextMolecule);
export { MlEnterTextMolecule };
