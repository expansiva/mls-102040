var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertext/ml-floating-text-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML FLOATING TEXT INPUT MOLECULE
// =============================================================================
// Skill Group: groupEnterText
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
let MlFloatingTextInputMolecule = class MlFloatingTextInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertext--ml-floating-text-input .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-floating-text-input .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-floating-text-input .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-floating-text-input .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupentertext--ml-floating-text-input .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-floating-text-input .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-floating-text-input .ml-input-container {
  background: var(--surface-bg, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-small, 6px);
  transition: border-color var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
}
groupentertext--ml-floating-text-input .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupentertext--ml-floating-text-input .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertext--ml-floating-text-input .ml-input {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertext--ml-floating-text-input .ml-input::placeholder {
  color: var(--text-muted-disabled, #79747e);
}
groupentertext--ml-floating-text-input .ml-spinner {
  border-color: var(--border-default, #e2e8f0);
  border-top-color: var(--text-strong, #1c1b1f);
}
groupentertext--ml-floating-text-input .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Prefix', 'Suffix'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.maxLength = null;
        this.minLength = null;
        this.rows = 1;
        this.autocomplete = '';
        this.inputType = 'text';
        this.mask = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.rawDisplay = '';
        this.isFocused = false;
        this.uid = `ml-floating-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER (derived values)
    // ==========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const maskAttr = this.getAttribute('mask');
        const inputTypeAttr = this.getAttribute('input-type');
        if (valueAttr === `{{${key}}}` || maskAttr === `{{${key}}}` || inputTypeAttr === `{{${key}}}`) {
            this.rawDisplay = this.getMaskedDisplayValue(this.value, this.mask, this.inputType);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================
    updated(changedProps) {
        if (changedProps.has('value') || changedProps.has('mask') || changedProps.has('inputType')) {
            this.rawDisplay = this.getMaskedDisplayValue(this.value, this.mask, this.inputType);
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleInput(e) {
        e.stopPropagation(); // native input must not leak past the molecule tag; the custom 'input' below is the contract
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const input = e.target;
        const incomingValue = input.value ?? '';
        let nextRaw = incomingValue;
        let nextDisplay = incomingValue;
        if (this.shouldUseMask()) {
            nextRaw = this.extractRawFromInput(incomingValue, this.mask);
            if (this.maxLength !== null) {
                nextRaw = nextRaw.slice(0, this.maxLength);
            }
            nextDisplay = this.applyMaskToRaw(nextRaw, this.mask);
            input.value = nextDisplay;
            this.rawDisplay = nextDisplay;
        }
        else {
            if (this.maxLength !== null && incomingValue.length > this.maxLength) {
                nextRaw = incomingValue.slice(0, this.maxLength);
                input.value = nextRaw;
            }
        }
        this.value = nextRaw;
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    handleFocus() {
        if (!this.isEditing)
            return;
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // MASK HELPERS
    // ==========================================================================
    shouldUseMask() {
        return Boolean(this.mask) && this.inputType !== 'password';
    }
    getMaskedDisplayValue(value, mask, inputType) {
        if (!mask || inputType === 'password')
            return value ?? '';
        return this.applyMaskToRaw(value ?? '', mask);
    }
    applyMaskToRaw(raw, mask) {
        if (!mask)
            return raw;
        let result = '';
        let rawIndex = 0;
        for (let i = 0; i < mask.length; i += 1) {
            const maskChar = mask[i];
            if (this.isMaskToken(maskChar)) {
                if (rawIndex >= raw.length)
                    break;
                result += raw[rawIndex];
                rawIndex += 1;
            }
            else {
                if (rawIndex > 0 && rawIndex <= raw.length) {
                    result += maskChar;
                }
            }
        }
        return result;
    }
    extractRawFromInput(input, mask) {
        if (!mask)
            return input;
        const tokens = mask.split('').filter((ch) => this.isMaskToken(ch));
        let raw = '';
        let tokenIndex = 0;
        for (let i = 0; i < input.length; i += 1) {
            if (tokenIndex >= tokens.length)
                break;
            const token = tokens[tokenIndex];
            const ch = input[i];
            if (this.isCharValidForToken(ch, token)) {
                raw += ch;
                tokenIndex += 1;
            }
        }
        return raw;
    }
    isMaskToken(ch) {
        return ch === '#' || ch === 'A' || ch === '*';
    }
    isCharValidForToken(ch, token) {
        if (token === '#')
            return /\d/.test(ch);
        if (token === 'A')
            return /[a-zA-Z]/.test(ch);
        return true;
    }
    // ===========================================================================
    // RENDER HELPERS
    // ==========================================================================
    getLabelText() {
        if (this.hasSlot('Label')) {
            return this.getSlotContent('Label');
        }
        return this.placeholder || '';
    }
    getInputPlaceholder(labelText) {
        return labelText ? '' : this.placeholder;
    }
    getViewValue() {
        if (this.inputType === 'password')
            return '••••••••';
        if (!this.value)
            return '—';
        if (this.shouldUseMask())
            return this.getMaskedDisplayValue(this.value, this.mask, this.inputType);
        return this.value;
    }
    renderPrefix() {
        if (!this.hasSlot('Prefix'))
            return html ``;
        return html `<div class="${cn('ml-text-muted', this.getSlotClass('Prefix'))}">${unsafeHTML(this.getSlotContent('Prefix'))}</div>`;
    }
    renderSuffix() {
        if (!this.hasSlot('Suffix') && !this.loading)
            return html ``;
        return html `
<div class="${cn('flex items-center gap-2 ml-text-muted', this.getSlotClass('Suffix'))}">
${this.hasSlot('Suffix') ? unsafeHTML(this.getSlotContent('Suffix')) : html ``}
${this.loading ? html `<span class="inline-block h-4 w-4 animate-spin rounded-full ml-spinner"></span>` : html ``}
</div>
`;
    }
    renderFeedback(labelId) {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${labelId}-error" class="mt-1 text-xs ml-error-text">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${labelId}-helper" class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderInlineLabel(labelText, labelId) {
        if (!labelText)
            return html ``;
        const labelClasses = [
            // When prefix exists, shift the inline label to avoid overlapping the prefix content.
            this.hasSlot('Prefix') ? 'left-10' : 'left-3',
            'absolute transition-all pointer-events-none top-1/2 -translate-y-1/2 text-sm ml-text-faint',
            this.getSlotClass('Label'),
        ].filter(Boolean).join(' ');
        return html `<label id="${labelId}" class="${labelClasses}">${unsafeHTML(labelText)}</label>`;
    }
    renderFloatingLabel(labelText, labelId) {
        if (!labelText)
            return html ``;
        // Show label above the input when focused or filled to keep field context visible.
        return html `<label id="${labelId}" class="${cn('mb-1 block text-xs ml-text-muted', this.getSlotClass('Label'))}">${unsafeHTML(labelText)}</label>`;
    }
    getContainerClasses(hasInlineLabel) {
        return [
            'relative flex w-full items-center gap-2 ml-input-container',
            hasInlineLabel ? 'pt-4 pb-1 px-3' : 'py-2 px-3',
            this.error ? 'ml-input-container-error' : '',
            this.disabled || this.loading ? 'ml-disabled' : 'cursor-text',
        ].filter(Boolean).join(' ');
    }
    getInputClasses() {
        return [
            'flex-1 bg-transparent outline-none text-sm ml-input',
            this.disabled || this.loading ? 'cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const labelText = this.getLabelText();
        const labelId = `${this.uid}-label`;
        if (!this.isEditing) {
            return html `
<div class="${cn('w-full', this.cssClass)}">
${labelText ? html `<div class="mb-1 text-sm ml-text-muted">${unsafeHTML(labelText)}</div>` : html ``}
<div class="flex items-center gap-2 text-sm ml-text">
${this.renderPrefix()}
<span>${this.getViewValue()}</span>
${this.renderSuffix()}
</div>
</div>
`;
        }
        const floating = this.isFocused || Boolean(this.value);
        const showFloatingLabel = Boolean(labelText) && floating;
        const showInlineLabel = Boolean(labelText) && !floating;
        const inputValue = this.shouldUseMask() ? this.rawDisplay : this.value;
        const inputPlaceholder = this.getInputPlaceholder(labelText);
        const inputDisabled = this.disabled || this.loading;
        const describedBy = this.error
            ? `${labelId}-error`
            : this.hasSlot('Helper') ? `${labelId}-helper` : undefined;
        return html `
<div class="${cn('w-full', this.cssClass)}">
<div class="min-h-[1rem]">
<!-- Reserve vertical space for the floating label to avoid layout shift -->
${showFloatingLabel ? this.renderFloatingLabel(labelText, labelId) : html ``}
</div>
<div class="${this.getContainerClasses(showInlineLabel)}">
${showInlineLabel ? this.renderInlineLabel(labelText, labelId) : html ``}
${this.renderPrefix()}
<input
class="${this.getInputClasses()}"
type="${this.inputType}"
.value="${inputValue}"
placeholder="${inputPlaceholder}"
maxlength=${ifDefined(this.maxLength ?? undefined)}
minlength=${ifDefined(this.minLength ?? undefined)}
name="${this.name}"
autocomplete="${this.autocomplete}"
?disabled=${inputDisabled}
?readonly=${this.readonly}
?required=${this.required}
aria-labelledby=${ifDefined(labelText ? labelId : undefined)}
aria-describedby=${ifDefined(describedBy)}
aria-invalid=${this.error ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@input=${this.handleInput}
@change=${(e) => e.stopPropagation()}
@blur=${this.handleBlur}
@focus=${this.handleFocus}
/>
${this.renderSuffix()}
</div>
${this.renderFeedback(labelId)}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-length' })
], MlFloatingTextInputMolecule.prototype, "maxLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-length' })
], MlFloatingTextInputMolecule.prototype, "minLength", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'rows' })
], MlFloatingTextInputMolecule.prototype, "rows", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "autocomplete", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'input-type' })
], MlFloatingTextInputMolecule.prototype, "inputType", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFloatingTextInputMolecule.prototype, "mask", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlFloatingTextInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFloatingTextInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlFloatingTextInputMolecule.prototype, "rawDisplay", void 0);
__decorate([
    state()
], MlFloatingTextInputMolecule.prototype, "isFocused", void 0);
__decorate([
    state()
], MlFloatingTextInputMolecule.prototype, "uid", void 0);
MlFloatingTextInputMolecule = __decorate([
    customElement('groupentertext--ml-floating-text-input')
], MlFloatingTextInputMolecule);
export { MlFloatingTextInputMolecule };
