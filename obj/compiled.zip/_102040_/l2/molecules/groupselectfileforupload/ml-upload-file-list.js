var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectfileforupload/ml-upload-file-list.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML UPLOAD FILE LIST MOLECULE
// =============================================================================
// Skill Group: groupSelectFileForUpload
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, query, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    addFiles: 'Add files',
    dropHere: 'Drop files here or click to browse',
    noFiles: 'No files selected',
    uploading: 'Uploading...',
    uploaded: 'Ready',
    remove: 'Remove',
    size: 'Size',
    type: 'Type',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let UploadFileListMolecule = class UploadFileListMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectfileforupload--ml-upload-file-list .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectfileforupload--ml-upload-file-list .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-upload-file-list .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-upload-file-list .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-upload-file-list .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-upload-file-list .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectfileforupload--ml-upload-file-list .ml-dropzone {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-upload-file-list .ml-dropzone-active {
  border-color: var(--ml-primary, #3b82f6);
  background: var(--ml-primary-container, rgba(59, 130, 246, 0.1));
}
groupselectfileforupload--ml-upload-file-list .ml-dropzone-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupselectfileforupload--ml-upload-file-list .ml-file-item {
  border-color: var(--ml-outline-variant, #e2e8f0);
  background: var(--ml-surface, #ffffff);
}
groupselectfileforupload--ml-upload-file-list .ml-file-item-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupselectfileforupload--ml-upload-file-list .ml-file-remove {
  color: var(--ml-error, #ef4444);
}
groupselectfileforupload--ml-upload-file-list .ml-file-remove:hover {
  text-decoration: underline;
}
groupselectfileforupload--ml-upload-file-list .ml-file-type-badge {
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectfileforupload--ml-upload-file-list .ml-file-progress-track {
  background: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-upload-file-list .ml-file-progress-active {
  background: var(--ml-primary, #3b82f6);
}
groupselectfileforupload--ml-upload-file-list .ml-file-progress-done {
  background: #22c55e;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = [];
        this.error = '';
        this.multiple = false;
        this.accept = '';
        this.maxSizeKb = 0;
        this.maxFiles = 0;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isDragging = false;
        this.uid = `ufl-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        if (this.disabled || this.loading)
            return;
        this.fileInput?.click();
    }
    handleTriggerKeydown(event) {
        if (this.disabled || this.loading)
            return;
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.fileInput?.click();
        }
    }
    handleInputChange(event) {
        if (this.disabled || this.loading)
            return;
        const input = event.target;
        const files = input.files ? Array.from(input.files) : [];
        this.validateAndMergeFiles(files);
        input.value = '';
    }
    handleDragOver(event) {
        event.preventDefault();
        if (this.disabled || this.loading)
            return;
        this.isDragging = true;
    }
    handleDragLeave() {
        if (this.disabled || this.loading)
            return;
        this.isDragging = false;
    }
    handleDrop(event) {
        event.preventDefault();
        if (this.disabled || this.loading)
            return;
        this.isDragging = false;
        const files = event.dataTransfer?.files ? Array.from(event.dataTransfer.files) : [];
        this.validateAndMergeFiles(files);
    }
    handleRemoveFile(index) {
        if (this.disabled || this.loading)
            return;
        const list = Array.isArray(this.value) ? [...this.value] : [];
        list.splice(index, 1);
        this.value = list;
    }
    // ===========================================================================
    // VALIDATION
    // ===========================================================================
    validateAndMergeFiles(files) {
        if (!files.length)
            return;
        const rejectedType = [];
        const rejectedSize = [];
        const rejectedCount = [];
        const valid = [];
        for (const file of files) {
            if (!this.matchesAccept(file)) {
                rejectedType.push(file);
                continue;
            }
            if (this.maxSizeKb > 0 && file.size / 1024 > this.maxSizeKb) {
                rejectedSize.push(file);
                continue;
            }
            valid.push(file);
        }
        if (!this.multiple) {
            if (valid.length > 0) {
                this.value = [valid[0]];
            }
            this.dispatchRejectEvents(rejectedType, rejectedSize, []);
            return;
        }
        const current = Array.isArray(this.value) ? [...this.value] : [];
        if (this.maxFiles > 0) {
            for (const file of valid) {
                if (current.length < this.maxFiles) {
                    current.push(file);
                }
                else {
                    rejectedCount.push(file);
                }
            }
        }
        else {
            current.push(...valid);
        }
        if (valid.length > 0) {
            this.value = current;
        }
        this.dispatchRejectEvents(rejectedType, rejectedSize, rejectedCount);
    }
    dispatchRejectEvents(typeFiles, sizeFiles, countFiles) {
        if (typeFiles.length) {
            this.dispatchEvent(new CustomEvent('reject', {
                bubbles: true,
                composed: true,
                detail: { files: typeFiles, reason: 'type' },
            }));
        }
        if (sizeFiles.length) {
            this.dispatchEvent(new CustomEvent('reject', {
                bubbles: true,
                composed: true,
                detail: { files: sizeFiles, reason: 'size' },
            }));
        }
        if (countFiles.length) {
            this.dispatchEvent(new CustomEvent('reject', {
                bubbles: true,
                composed: true,
                detail: { files: countFiles, reason: 'count' },
            }));
        }
    }
    matchesAccept(file) {
        if (!this.accept)
            return true;
        const acceptItems = this.accept.split(',').map((item) => item.trim()).filter(Boolean);
        if (!acceptItems.length)
            return true;
        const fileType = (file.type || '').toLowerCase();
        const fileName = file.name.toLowerCase();
        return acceptItems.some((accept) => {
            const rule = accept.toLowerCase();
            if (rule.startsWith('.')) {
                return fileName.endsWith(rule);
            }
            if (rule.endsWith('/*')) {
                const prefix = rule.replace('/*', '');
                return fileType.startsWith(prefix);
            }
            return fileType === rule;
        });
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    formatSize(bytes) {
        if (bytes === 0)
            return '0 B';
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        const index = Math.floor(Math.log(bytes) / Math.log(1024));
        const size = bytes / Math.pow(1024, index);
        return `${size.toFixed(size >= 10 || index === 0 ? 0 : 1)} ${units[index]}`;
    }
    getFileExtension(file) {
        const name = file.name || '';
        const parts = name.split('.');
        if (parts.length < 2)
            return 'FILE';
        return parts[parts.length - 1].toUpperCase();
    }
    getDropZoneClasses(hasError) {
        return [
            'w-full rounded-lg border border-dashed p-4 transition text-sm flex flex-col gap-2 items-center justify-center text-center ml-dropzone',
            hasError ? 'ml-dropzone-error' : '',
            this.isDragging ? 'ml-dropzone-active' : '',
            this.disabled || this.loading ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getFileRowClasses() {
        return [
            'w-full rounded-md border p-3 flex flex-col gap-2 ml-file-item',
        ].join(' ');
    }
    getTypeBadgeClasses() {
        return [
            'inline-flex items-center justify-center rounded-full px-2 py-1 text-xs font-semibold ml-file-type-badge',
        ].join(' ');
    }
    getRemoveButtonClasses() {
        return [
            'text-xs font-medium transition ml-file-remove',
            this.disabled || this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div id=${labelId} class="${cn('text-sm font-medium ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderHelperOrError(helperId, hasError) {
        if (hasError) {
            return html `
        <p id=${helperId} class="text-xs ml-error-text">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p id=${helperId} class="${cn('text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderTriggerContent() {
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        return html `
      <div class="text-sm font-medium ml-label">${this.msg.addFiles}</div>
      <div class="text-xs ml-text-muted">${this.msg.dropHere}</div>
    `;
    }
    renderFileList(hasFiles) {
        if (!hasFiles) {
            return html `
        <div class="text-sm ml-text-muted">${this.msg.noFiles}</div>
      `;
        }
        return html `
      <div class="flex flex-col gap-3">
        ${this.value.map((file, index) => html `
          <div class=${this.getFileRowClasses()}>
            <div class="flex items-center justify-between gap-3">
              <div class="flex items-center gap-3">
                <span class=${this.getTypeBadgeClasses()}>${this.getFileExtension(file)}</span>
                <div class="flex flex-col">
                  <span class="text-sm font-medium ml-text">${file.name}</span>
                  <span class="text-xs ml-text-muted">${this.msg.size}: ${this.formatSize(file.size)}</span>
                </div>
              </div>
              <button
                type="button"
                class=${this.getRemoveButtonClasses()}
                @click=${() => this.handleRemoveFile(index)}
                aria-label=${this.msg.remove}
                ?disabled=${this.disabled || this.loading}
              >
                ${this.msg.remove}
              </button>
            </div>
            <div class="flex flex-col gap-1">
              <div class="text-xs ml-text-muted">
                ${this.loading ? this.msg.uploading : this.msg.uploaded}
              </div>
              <div class="h-1 w-full rounded overflow-hidden ml-file-progress-track">
                <div class=${[
            'h-full w-full',
            this.loading
                ? 'ml-file-progress-active animate-pulse'
                : 'ml-file-progress-done',
        ].join(' ')}></div>
              </div>
            </div>
          </div>
        `)}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasError = Boolean(this.error);
        const labelId = `${this.uid}-label`;
        const helperId = `${this.uid}-helper`;
        const describedBy = hasError || this.hasSlot('Helper') ? helperId : undefined;
        const hasFiles = Array.isArray(this.value) && this.value.length > 0;
        return html `
      <div class="${cn('flex flex-col gap-3', this.cssClass)}">
        ${this.renderLabel(labelId)}

        <div
          class=${this.getDropZoneClasses(hasError)}
          role="button"
          tabindex=${this.disabled || this.loading ? -1 : 0}
          aria-labelledby=${this.hasSlot('Label') ? labelId : undefined}
          aria-describedby=${describedBy}
          aria-invalid=${hasError ? 'true' : 'false'}
          @click=${this.handleTriggerClick}
          @keydown=${this.handleTriggerKeydown}
          @dragover=${this.handleDragOver}
          @dragleave=${this.handleDragLeave}
          @drop=${this.handleDrop}
        >
          ${this.renderTriggerContent()}
          <input
            class="sr-only"
            type="file"
            ?multiple=${this.multiple}
            ?disabled=${this.disabled || this.loading}
            accept=${this.accept}
            @change=${this.handleInputChange}
          />
        </div>

        ${this.renderHelperOrError(helperId, hasError)}

        ${this.renderFileList(hasFiles)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Array })
], UploadFileListMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], UploadFileListMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], UploadFileListMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: String })
], UploadFileListMolecule.prototype, "accept", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-size-kb' })
], UploadFileListMolecule.prototype, "maxSizeKb", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-files' })
], UploadFileListMolecule.prototype, "maxFiles", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], UploadFileListMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], UploadFileListMolecule.prototype, "loading", void 0);
__decorate([
    state()
], UploadFileListMolecule.prototype, "isDragging", void 0);
__decorate([
    query('input[type="file"]')
], UploadFileListMolecule.prototype, "fileInput", void 0);
UploadFileListMolecule = __decorate([
    customElement('groupselectfileforupload--ml-upload-file-list')
], UploadFileListMolecule);
export { UploadFileListMolecule };
