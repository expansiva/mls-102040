/// <mls fileReference="_102040_/l2/molecules/groupselectfileforupload/ml-file-metadata-uploader.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// FILE METADATA UPLOADER MOLECULE
// =============================================================================
// Skill Group: groupSelectFileForUpload
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    dropFilesHere: 'Drop files here or click to select',
    dropFilesHereSingle: 'Drop file here or click to select',
    dragActive: 'Drop files here',
    loading: 'Loading...',
    selectedFiles: 'Selected files',
    removeFile: 'Remove file',
    browse: 'Browse',
};
const messages = {
    en: message_en,
    pt: {
        dropFilesHere: 'Solte arquivos aqui ou clique para selecionar',
        dropFilesHereSingle: 'Solte arquivo aqui ou clique para selecionar',
        dragActive: 'Solte os arquivos aqui',
        loading: 'Carregando...',
        selectedFiles: 'Arquivos selecionados',
        removeFile: 'Remover arquivo',
        browse: 'Procurar',
    },
};
/// **collab_i18n_end**
let MlFileMetadataUploaderMolecule = class MlFileMetadataUploaderMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        // Data
        this.value = [];
        this.error = '';
        // Configuration
        this.multiple = false;
        this.accept = '';
        this.maxSizeKb = 0;
        this.maxFiles = 0;
        // States
        this.disabled = false;
        this.loading = false;
        this.name = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isDragging = false;
        this.inputId = `file-input-${Math.random().toString(36).substring(2, 9)}`;
        this.labelId = `file-label-${Math.random().toString(36).substring(2, 9)}`;
        this.errorId = `file-error-${Math.random().toString(36).substring(2, 9)}`;
    }
    // ===========================================================================
    // FILE VALIDATION
    // ===========================================================================
    validateFiles(files) {
        const valid = [];
        const rejectedByType = [];
        const rejectedBySize = [];
        for (const file of files) {
            // Type validation
            if (this.accept && !this.isFileTypeAccepted(file)) {
                rejectedByType.push(file);
                continue;
            }
            // Size validation
            if (this.maxSizeKb > 0 && file.size > this.maxSizeKb * 1024) {
                rejectedBySize.push(file);
                continue;
            }
            valid.push(file);
        }
        const rejected = [];
        if (rejectedByType.length > 0) {
            rejected.push({ files: rejectedByType, reason: 'type' });
        }
        if (rejectedBySize.length > 0) {
            rejected.push({ files: rejectedBySize, reason: 'size' });
        }
        // Count validation
        if (this.maxFiles > 0) {
            const currentCount = this.value?.length || 0;
            const availableSlots = this.maxFiles - currentCount;
            if (valid.length > availableSlots) {
                const rejectedByCount = valid.splice(availableSlots);
                rejected.push({ files: rejectedByCount, reason: 'count' });
            }
        }
        return { valid, rejected };
    }
    isFileTypeAccepted(file) {
        if (!this.accept)
            return true;
        const acceptedTypes = this.accept.split(',').map(t => t.trim().toLowerCase());
        const fileType = file.type.toLowerCase();
        const fileExtension = '.' + file.name.split('.').pop()?.toLowerCase();
        for (const accepted of acceptedTypes) {
            // Wildcard match (e.g., image/*)
            if (accepted.endsWith('/*')) {
                const category = accepted.slice(0, -2);
                if (fileType.startsWith(category + '/')) {
                    return true;
                }
            }
            // Extension match (e.g., .pdf)
            else if (accepted.startsWith('.')) {
                if (fileExtension === accepted) {
                    return true;
                }
            }
            // MIME type match
            else if (fileType === accepted) {
                return true;
            }
        }
        return false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleDragOver(e) {
        e.preventDefault();
        if (this.disabled || this.loading)
            return;
        this.isDragging = true;
    }
    handleDragLeave(e) {
        e.preventDefault();
        this.isDragging = false;
    }
    handleDrop(e) {
        e.preventDefault();
        this.isDragging = false;
        if (this.disabled || this.loading)
            return;
        const files = Array.from(e.dataTransfer?.files || []);
        this.processFiles(files);
    }
    handleFileInputChange(e) {
        if (this.disabled || this.loading)
            return;
        const input = e.target;
        const files = Array.from(input.files || []);
        this.processFiles(files);
        // Reset input to allow selecting the same file again
        input.value = '';
    }
    processFiles(files) {
        if (files.length === 0)
            return;
        const { valid, rejected } = this.validateFiles(files);
        // Emit reject events for invalid files
        for (const rejection of rejected) {
            this.dispatchEvent(new CustomEvent('reject', {
                bubbles: true,
                composed: true,
                detail: { files: rejection.files, reason: rejection.reason }
            }));
        }
        // Update value with valid files
        if (valid.length > 0) {
            if (this.multiple) {
                this.value = [...(this.value || []), ...valid];
            }
            else {
                this.value = [valid[0]];
            }
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value }
            }));
        }
    }
    handleRemoveFile(index) {
        if (this.disabled || this.loading)
            return;
        const newValue = [...(this.value || [])];
        newValue.splice(index, 1);
        this.value = newValue;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleDropZoneClick() {
        if (this.disabled || this.loading)
            return;
        const input = this.querySelector(`#${this.inputId}`);
        input?.click();
    }
    handleDropZoneKeyDown(e) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleDropZoneClick();
        }
    }
    // ===========================================================================
    // HELPER METHODS
    // ===========================================================================
    formatFileSize(bytes) {
        if (bytes < 1024)
            return `${bytes} B`;
        if (bytes < 1024 * 1024)
            return `${(bytes / 1024).toFixed(1)} KB`;
        return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
    }
    getDropZoneClasses() {
        const hasError = !!this.error;
        return [
            // Base
            'relative flex flex-col items-center justify-center w-full min-h-32 p-6',
            'border-2 border-dashed rounded-lg transition-all duration-200',
            'cursor-pointer',
            // Background
            'bg-slate-50 dark:bg-slate-900',
            // Border states
            this.isDragging && !this.disabled && !this.loading
                ? 'border-sky-500 dark:border-sky-400 bg-sky-50 dark:bg-sky-900/20'
                : hasError
                    ? 'border-red-500 dark:border-red-400'
                    : 'border-slate-300 dark:border-slate-600',
            // Hover (only when not disabled/loading/dragging)
            !this.disabled && !this.loading && !this.isDragging
                ? 'hover:border-sky-400 dark:hover:border-sky-500 hover:bg-slate-100 dark:hover:bg-slate-800'
                : '',
            // Disabled/Loading state
            this.disabled || this.loading
                ? 'opacity-50 cursor-not-allowed'
                : '',
            // Focus
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400 focus:ring-offset-2 dark:focus:ring-offset-slate-900',
        ].filter(Boolean).join(' ');
    }
    getFileItemClasses() {
        return [
            'flex items-center justify-between gap-3 p-3 rounded-lg',
            'bg-white dark:bg-slate-800',
            'border border-slate-200 dark:border-slate-700',
            'text-sm text-slate-900 dark:text-slate-100',
        ].join(' ');
    }
    getRemoveButtonClasses() {
        return [
            'flex items-center justify-center w-6 h-6 rounded-full',
            'text-slate-400 dark:text-slate-500',
            'hover:text-red-500 dark:hover:text-red-400',
            'hover:bg-red-50 dark:hover:bg-red-900/20',
            'transition-colors duration-150',
            'focus:outline-none focus:ring-2 focus:ring-red-500 dark:focus:ring-red-400',
            this.disabled || this.loading ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER METHODS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label
        id="${this.labelId}"
        class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-2"
      >
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderDropZone() {
        const hasTrigger = this.hasSlot('Trigger');
        const dropText = this.multiple ? this.msg.dropFilesHere : this.msg.dropFilesHereSingle;
        return html `
      <div
        class="${this.getDropZoneClasses()}"
        role="button"
        tabindex="${this.disabled || this.loading ? -1 : 0}"
        aria-labelledby="${this.hasSlot('Label') ? this.labelId : ''}"
        aria-describedby="${this.error ? this.errorId : ''}"
        aria-invalid="${this.error ? 'true' : 'false'}"
        aria-disabled="${this.disabled || this.loading}"
        @click="${this.handleDropZoneClick}"
        @keydown="${this.handleDropZoneKeyDown}"
        @dragover="${this.handleDragOver}"
        @dragleave="${this.handleDragLeave}"
        @drop="${this.handleDrop}"
      >
        ${this.loading
            ? this.renderLoadingState()
            : this.isDragging
                ? this.renderDragActiveState()
                : hasTrigger
                    ? html `${unsafeHTML(this.getSlotContent('Trigger'))}`
                    : this.renderDefaultTrigger(dropText)}
      </div>

      <input
        type="file"
        id="${this.inputId}"
        name="${this.name}"
        class="sr-only"
        ?multiple="${this.multiple}"
        accept="${this.accept}"
        ?disabled="${this.disabled || this.loading}"
        @change="${this.handleFileInputChange}"
        aria-hidden="true"
        tabindex="-1"
      />
    `;
    }
    renderDefaultTrigger(dropText) {
        return html `
      <div class="flex flex-col items-center gap-2 text-center">
        <svg
          class="w-10 h-10 text-slate-400 dark:text-slate-500"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="1.5"
            d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
          />
        </svg>
        <p class="text-sm text-slate-600 dark:text-slate-400">
          ${dropText}
        </p>
        <span class="inline-flex items-center px-3 py-1.5 text-sm font-medium text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-900/30 rounded-md">
          ${this.msg.browse}
        </span>
      </div>
    `;
    }
    renderDragActiveState() {
        return html `
      <div class="flex flex-col items-center gap-2 text-center">
        <svg
          class="w-10 h-10 text-sky-500 dark:text-sky-400 animate-bounce"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            stroke-linecap="round"
            stroke-linejoin="round"
            stroke-width="1.5"
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
        <p class="text-sm font-medium text-sky-600 dark:text-sky-400">
          ${this.msg.dragActive}
        </p>
      </div>
    `;
    }
    renderLoadingState() {
        return html `
      <div class="flex flex-col items-center gap-2 text-center">
        <svg
          class="w-8 h-8 text-sky-500 dark:text-sky-400 animate-spin"
          fill="none"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <circle
            class="opacity-25"
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            stroke-width="4"
          />
          <path
            class="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          />
        </svg>
        <p class="text-sm text-slate-600 dark:text-slate-400">
          ${this.msg.loading}
        </p>
      </div>
    `;
    }
    renderSelectedFiles() {
        if (!this.value || this.value.length === 0)
            return html ``;
        return html `
      <div class="mt-4 space-y-2">
        <p class="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide">
          ${this.msg.selectedFiles} (${this.value.length})
        </p>
        <ul class="space-y-2">
          ${this.value.map((file, index) => this.renderFileItem(file, index))}
        </ul>
      </div>
    `;
    }
    renderFileItem(file, index) {
        return html `
      <li class="${this.getFileItemClasses()}">
        <div class="flex items-center gap-3 min-w-0 flex-1">
          <svg
            class="w-5 h-5 flex-shrink-0 text-slate-400 dark:text-slate-500"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="1.5"
              d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
            />
          </svg>
          <div class="min-w-0 flex-1">
            <p class="text-sm font-medium text-slate-900 dark:text-slate-100 truncate">
              ${file.name}
            </p>
            <p class="text-xs text-slate-500 dark:text-slate-400">
              ${this.formatFileSize(file.size)}
            </p>
          </div>
        </div>
        <button
          type="button"
          class="${this.getRemoveButtonClasses()}"
          aria-label="${this.msg.removeFile}: ${file.name}"
          ?disabled="${this.disabled || this.loading}"
          @click="${(e) => { e.stopPropagation(); this.handleRemoveFile(index); }}"
        >
          <svg
            class="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
            aria-hidden="true"
          >
            <path
              stroke-linecap="round"
              stroke-linejoin="round"
              stroke-width="2"
              d="M6 18L18 6M6 6l12 12"
            />
          </svg>
        </button>
      </li>
    `;
    }
    renderMetadataSlot() {
        return html `
      <div class="mt-4">
        <slot></slot>
      </div>
    `;
    }
    renderFeedback() {
        if (this.error) {
            return html `
        <p
          id="${this.errorId}"
          class="mt-2 text-xs text-red-600 dark:text-red-400"
          role="alert"
        >
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="mt-2 text-xs text-slate-500 dark:text-slate-400">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <div class="w-full">
        ${this.renderLabel()}
        ${this.renderDropZone()}
        ${this.renderSelectedFiles()}
        ${this.renderMetadataSlot()}
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Array })
], MlFileMetadataUploaderMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFileMetadataUploaderMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileMetadataUploaderMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFileMetadataUploaderMolecule.prototype, "accept", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-size-kb' })
], MlFileMetadataUploaderMolecule.prototype, "maxSizeKb", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-files' })
], MlFileMetadataUploaderMolecule.prototype, "maxFiles", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileMetadataUploaderMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileMetadataUploaderMolecule.prototype, "loading", void 0);
__decorate([
    property({ type: String })
], MlFileMetadataUploaderMolecule.prototype, "name", void 0);
__decorate([
    state()
], MlFileMetadataUploaderMolecule.prototype, "isDragging", void 0);
MlFileMetadataUploaderMolecule = __decorate([
    customElement('groupselectfileforupload--ml-file-metadata-uploader')
], MlFileMetadataUploaderMolecule);
export { MlFileMetadataUploaderMolecule };
