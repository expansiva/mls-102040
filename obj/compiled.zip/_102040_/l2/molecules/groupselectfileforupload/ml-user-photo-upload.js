var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectfileforupload/ml-user-photo-upload.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML USER PHOTO UPLOAD MOLECULE
// =============================================================================
// Skill Group: groupSelectFileForUpload
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    selectPhoto: 'Select a photo',
    dropHere: 'or drag and drop',
    loading: 'Loading...',
    remove: 'Remove',
    fileCount: 'Selected files',
};
const messages = {
    en: message_en,
    pt: {
        selectPhoto: 'Selecione uma foto',
        dropHere: 'ou arraste e solte',
        loading: 'Carregando...',
        remove: 'Remover',
        fileCount: 'Arquivos selecionados',
    },
};
/// **collab_i18n_end**
let MlUserPhotoUploadMolecule = class MlUserPhotoUploadMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectfileforupload--ml-user-photo-upload .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectfileforupload--ml-user-photo-upload .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-user-photo-upload .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-user-photo-upload .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-user-photo-upload .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-user-photo-upload .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectfileforupload--ml-user-photo-upload .ml-photo-container {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface-muted, #49454f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-user-photo-upload .ml-photo-container:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectfileforupload--ml-user-photo-upload .ml-dropzone-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupselectfileforupload--ml-user-photo-upload .ml-dropzone-active {
  background: var(--ml-primary-container, rgba(59, 130, 246, 0.1));
  border-color: var(--ml-primary, #3b82f6);
}
groupselectfileforupload--ml-user-photo-upload .ml-preview-card {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-user-photo-upload .ml-preview-remove {
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectfileforupload--ml-user-photo-upload .ml-preview-remove:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = [];
        this.error = '';
        this.multiple = false;
        this.accept = '';
        this.maxSizeKb = 0;
        this.maxFiles = 0;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isDragging = false;
        this.previewUrl = null;
        this.previewFile = null;
        this.uid = `ml-user-photo-${Math.random().toString(36).slice(2)}`;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            const files = Array.isArray(value) ? value : [];
            this.updatePreview(files);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        this.revokePreview();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        if (this.isBusy())
            return;
        this.openFilePicker();
    }
    handleTriggerKeyDown(event) {
        if (this.isBusy())
            return;
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.openFilePicker();
        }
    }
    handleInputChange(event) {
        event.stopPropagation();
        if (this.isBusy())
            return;
        const input = event.target;
        this.processFiles(input.files);
        input.value = '';
    }
    handleDragOver(event) {
        if (this.isBusy())
            return;
        event.preventDefault();
        this.isDragging = true;
    }
    handleDragLeave() {
        this.isDragging = false;
    }
    handleDrop(event) {
        if (this.isBusy())
            return;
        event.preventDefault();
        this.isDragging = false;
        this.processFiles(event.dataTransfer?.files || null);
    }
    handleRemove(index) {
        if (this.isBusy())
            return;
        const files = this.value ? [...this.value] : [];
        files.splice(index, 1);
        this.value = files;
        this.updatePreview(files);
    }
    // ===========================================================================
    // FILE PROCESSING
    // ===========================================================================
    processFiles(fileList) {
        if (!fileList || fileList.length === 0)
            return;
        const incoming = Array.from(fileList);
        const baseValue = this.multiple ? (this.value ? [...this.value] : []) : [];
        const maxAllowed = this.multiple ? (this.maxFiles > 0 ? this.maxFiles : Number.POSITIVE_INFINITY) : 1;
        const accepted = [];
        const rejectedType = [];
        const rejectedSize = [];
        const rejectedCount = [];
        let currentCount = baseValue.length;
        incoming.forEach((file) => {
            if (!this.isImageFile(file) || !this.isAcceptedType(file)) {
                rejectedType.push(file);
                return;
            }
            if (this.maxSizeKb > 0 && file.size / 1024 > this.maxSizeKb) {
                rejectedSize.push(file);
                return;
            }
            if (currentCount + accepted.length >= maxAllowed) {
                rejectedCount.push(file);
                return;
            }
            accepted.push(file);
        });
        const newValue = baseValue.concat(accepted);
        if (!this.multiple && accepted.length > 0) {
            this.value = [accepted[0]];
        }
        else if (accepted.length > 0 || baseValue.length !== newValue.length) {
            this.value = newValue;
        }
        this.updatePreview(this.value || []);
        this.dispatchRejects(rejectedType, rejectedSize, rejectedCount);
    }
    dispatchRejects(typeFiles, sizeFiles, countFiles) {
        if (typeFiles.length > 0) {
            this.dispatchEvent(new CustomEvent('reject', {
                bubbles: true,
                composed: true,
                detail: { files: typeFiles, reason: 'type' }
            }));
        }
        if (sizeFiles.length > 0) {
            this.dispatchEvent(new CustomEvent('reject', {
                bubbles: true,
                composed: true,
                detail: { files: sizeFiles, reason: 'size' }
            }));
        }
        if (countFiles.length > 0) {
            this.dispatchEvent(new CustomEvent('reject', {
                bubbles: true,
                composed: true,
                detail: { files: countFiles, reason: 'count' }
            }));
        }
    }
    isImageFile(file) {
        if (file.type && file.type.startsWith('image/'))
            return true;
        const ext = file.name.split('.').pop()?.toLowerCase() || '';
        return ['png', 'jpg', 'jpeg', 'gif', 'webp', 'bmp', 'svg'].includes(ext);
    }
    isAcceptedType(file) {
        if (!this.accept)
            return true;
        const acceptList = this.accept.split(',').map((item) => item.trim()).filter(Boolean);
        if (acceptList.length === 0)
            return true;
        const fileName = file.name.toLowerCase();
        const fileType = (file.type || '').toLowerCase();
        return acceptList.some((rule) => {
            const r = rule.toLowerCase();
            if (r.endsWith('/*')) {
                const prefix = r.replace('/*', '/');
                return fileType.startsWith(prefix);
            }
            if (r.startsWith('.')) {
                return fileName.endsWith(r);
            }
            return fileType === r;
        });
    }
    updatePreview(files) {
        const file = files && files.length > 0 ? files[0] : null;
        if (file && this.previewFile === file)
            return;
        this.revokePreview();
        if (file) {
            this.previewUrl = URL.createObjectURL(file);
            this.previewFile = file;
        }
        else {
            this.previewUrl = null;
            this.previewFile = null;
        }
    }
    revokePreview() {
        if (this.previewUrl) {
            URL.revokeObjectURL(this.previewUrl);
        }
    }
    // ===========================================================================
    // UTILITIES
    // ===========================================================================
    isBusy() {
        return this.disabled || this.loading;
    }
    openFilePicker() {
        const input = this.querySelector('input[type="file"]');
        input?.click();
    }
    formatSize(size) {
        const kb = size / 1024;
        if (kb < 1024)
            return `${kb.toFixed(1)} KB`;
        return `${(kb / 1024).toFixed(1)} MB`;
    }
    getTriggerClasses(hasError, isBusy) {
        return [
            'w-full rounded-lg border-2 border-dashed p-4 text-center transition ml-photo-container',
            hasError ? 'ml-dropzone-error' : '',
            this.isDragging ? 'ml-dropzone-active' : '',
            !isBusy ? 'cursor-pointer' : 'ml-disabled',
        ].filter(Boolean).join(' ');
    }
    getRemoveButtonClasses() {
        return [
            'inline-flex items-center rounded-md px-2 py-1 text-xs font-medium border transition ml-preview-remove',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasError = Boolean(this.error);
        const hasHelper = this.hasSlot('Helper');
        const isBusy = this.isBusy();
        const labelId = `${this.uid}-label`;
        const helperId = `${this.uid}-helper`;
        const errorId = `${this.uid}-error`;
        const describedBy = hasError ? errorId : (hasHelper ? helperId : undefined);
        const files = this.value || [];
        const acceptAttr = this.accept || 'image/*';
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel(labelId)}
<div
class="${this.getTriggerClasses(hasError, isBusy)}"
role="button"
tabindex="${isBusy ? '-1' : '0'}"
aria-label="${this.msg.selectPhoto}"
aria-labelledby="${this.hasSlot('Label') ? labelId : ''}"
aria-describedby="${describedBy || ''}"
aria-invalid="${hasError ? 'true' : 'false'}"
aria-busy="${this.loading ? 'true' : 'false'}"
@keydown=${this.handleTriggerKeyDown}
@click=${this.handleTriggerClick}
@dragover=${this.handleDragOver}
@dragleave=${this.handleDragLeave}
@drop=${this.handleDrop}
>
${this.renderTriggerContent()}
</div>
<input
class="hidden"
type="file"
?multiple=${this.multiple}
accept="${acceptAttr}"
?disabled=${isBusy}
@change=${this.handleInputChange}
aria-hidden="true"

@input="${(e) => e.stopPropagation()}"
/>
${this.renderPreview(files)}
${this.renderFileList(files)}
${this.renderFeedback(hasError, hasHelper, errorId, helperId)}
</div>
`;
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label id="${labelId}" class="${cn('mb-2 block text-sm font-medium ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderTriggerContent() {
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        return html `
<div class="flex flex-col items-center gap-1 ml-photo-placeholder">
<span class="text-sm font-medium ml-text">${this.msg.selectPhoto}</span>
<span class="text-xs ml-text-muted">${this.msg.dropHere}</span>
${this.loading ? html `<span class="text-xs ml-text-muted">${this.msg.loading}</span>` : html ``}
</div>
`;
    }
    renderPreview(files) {
        if (!files || files.length === 0 || !this.previewUrl)
            return html ``;
        const file = files[0];
        return html `
<div class="mt-4 flex items-center gap-4 ml-photo-overlay">
<img
src="${this.previewUrl}"
alt="${file.name}"
class="h-20 w-20 rounded-lg border object-cover ml-preview-card"
/>
<div class="flex-1">
<p class="text-sm font-medium ml-text">${file.name}</p>
<p class="text-xs ml-text-muted">${this.formatSize(file.size)}</p>
</div>
<button
type="button"
class="${this.getRemoveButtonClasses()}"
?disabled=${this.isBusy()}
@click=${() => this.handleRemove(0)}
>
${this.msg.remove}
</button>
</div>
`;
    }
    renderFileList(files) {
        if (!this.multiple || files.length <= 1)
            return html ``;
        return html `
<div class="mt-3">
<p class="text-xs ml-text-muted">${this.msg.fileCount}: ${files.length}</p>
<ul class="mt-2 space-y-2">
${files.map((file, index) => html `
<li class="flex items-center justify-between rounded-md border px-3 py-2 ml-preview-card">
<div>
<p class="text-sm ml-text">${file.name}</p>
<p class="text-xs ml-text-muted">${this.formatSize(file.size)}</p>
</div>
<button
type="button"
class="${this.getRemoveButtonClasses()}"
?disabled=${this.isBusy()}
@click=${() => this.handleRemove(index)}
>
${this.msg.remove}
</button>
</li>
`)}
</ul>
</div>
`;
    }
    renderFeedback(hasError, hasHelper, errorId, helperId) {
        if (hasError) {
            return html `<p id="${errorId}" class="mt-2 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (hasHelper) {
            return html `<p id="${helperId}" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
};
__decorate([
    propertyDataSource({ type: Array })
], MlUserPhotoUploadMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlUserPhotoUploadMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlUserPhotoUploadMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlUserPhotoUploadMolecule.prototype, "accept", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-size-kb' })
], MlUserPhotoUploadMolecule.prototype, "maxSizeKb", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-files' })
], MlUserPhotoUploadMolecule.prototype, "maxFiles", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlUserPhotoUploadMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlUserPhotoUploadMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlUserPhotoUploadMolecule.prototype, "isDragging", void 0);
__decorate([
    state()
], MlUserPhotoUploadMolecule.prototype, "previewUrl", void 0);
__decorate([
    state()
], MlUserPhotoUploadMolecule.prototype, "previewFile", void 0);
MlUserPhotoUploadMolecule = __decorate([
    customElement('groupselectfileforupload--ml-user-photo-upload')
], MlUserPhotoUploadMolecule);
export { MlUserPhotoUploadMolecule };
