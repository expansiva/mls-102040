/// <mls fileReference="_102040_/l2/molecules/groupselectfileforupload/ml-file-upload-preview.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML FILE UPLOAD PREVIEW MOLECULE
// =============================================================================
// Skill Group: select + fileForUpload
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    labelDefault: 'Upload files',
    triggerTitle: 'Click to select files',
    triggerSubtitle: 'or drag and drop here',
    addMore: 'Add more files',
    replaceFile: 'Replace file',
    loading: 'Uploading...',
    remove: 'Remove',
    noPreview: 'No preview',
};
const messages = {
    en: message_en,
    pt: {
        labelDefault: 'Enviar arquivos',
        triggerTitle: 'Clique para selecionar arquivos',
        triggerSubtitle: 'ou arraste e solte aqui',
        addMore: 'Adicionar mais arquivos',
        replaceFile: 'Substituir arquivo',
        loading: 'Enviando...',
        remove: 'Remover',
        noPreview: 'Sem prévia',
    },
};
/// **collab_i18n_end**
let MlFileUploadPreviewMolecule = class MlFileUploadPreviewMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectfileforupload--ml-file-upload-preview .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectfileforupload--ml-file-upload-preview .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-file-upload-preview .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-file-upload-preview .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-file-upload-preview .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectfileforupload--ml-file-upload-preview .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectfileforupload--ml-file-upload-preview .ml-dropzone {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-file-upload-preview .ml-dropzone:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectfileforupload--ml-file-upload-preview .ml-dropzone:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupselectfileforupload--ml-file-upload-preview .ml-dropzone-active {
  border-color: var(--ml-primary, #3b82f6);
  background: var(--ml-primary-container, rgba(59, 130, 246, 0.1));
}
groupselectfileforupload--ml-file-upload-preview .ml-dropzone-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupselectfileforupload--ml-file-upload-preview .ml-dropzone-loading-overlay {
  background: rgba(255, 255, 255, 0.7);
}
groupselectfileforupload--ml-file-upload-preview .ml-dropzone-spinner {
  border: 2px solid var(--ml-outline-variant, #e2e8f0);
  border-top-color: var(--ml-on-surface-muted, #49454f);
}
groupselectfileforupload--ml-file-upload-preview .ml-preview-card {
  background: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-file-upload-preview .ml-preview-thumbnail {
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-file-upload-preview .ml-preview-remove {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface-muted, #49454f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectfileforupload--ml-file-upload-preview .ml-preview-remove:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
`);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger'];
        // O slot Trigger carrega CONTROLES do consumidor, não conteúdo
        // decorativo — precisa de nó vivo, com handler e componente preservados.
        // Os demais slots continuam vindo pelo caminho de snapshot: são conteúdo.
        this.usesLiveSlots = true;
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = [];
        this.error = '';
        this.multiple = false;
        this.accept = '';
        this.maxSizeKb = 0;
        this.maxFiles = 0;
        this.disabled = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.isDragging = false;
        this.previewUrls = new Map();
        this.uid = `ml-fup-${Math.random().toString(36).slice(2)}`;
    }
    // ==========================================================================
    // STATE CHANGE HANDLER (derived values)
    // ==========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.syncPreviewUrls(value);
        }
        this.requestUpdate();
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    disconnectedCallback() {
        this.revokeAllPreviews();
        super.disconnectedCallback();
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleTriggerClick() {
        if (this.disabled || this.loading)
            return;
        const input = this.getFileInput();
        if (input)
            input.click();
    }
    handleTriggerKeydown(e) {
        if (this.disabled || this.loading)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleTriggerClick();
        }
    }
    handleInputChange(e) {
        e.stopPropagation();
        const input = e.target;
        const files = input.files ? Array.from(input.files) : [];
        this.processFiles(files);
        input.value = '';
    }
    handleDragOver(e) {
        if (this.disabled || this.loading)
            return;
        e.preventDefault();
        this.isDragging = true;
    }
    handleDragLeave() {
        if (this.disabled || this.loading)
            return;
        this.isDragging = false;
    }
    handleDrop(e) {
        if (this.disabled || this.loading)
            return;
        e.preventDefault();
        this.isDragging = false;
        const files = e.dataTransfer?.files ? Array.from(e.dataTransfer.files) : [];
        this.processFiles(files);
    }
    handleRemoveFile(index) {
        if (this.disabled || this.loading)
            return;
        if (!Array.isArray(this.value))
            return;
        const next = this.value.filter((_, i) => i !== index);
        this.value = next;
        this.syncPreviewUrls(next);
    }
    // ==========================================================================
    // FILE PROCESSING
    // ==========================================================================
    processFiles(files) {
        if (!files.length)
            return;
        const existing = this.value || [];
        const allowCount = this.multiple ? (this.maxFiles > 0 ? this.maxFiles : Infinity) : 1;
        let remaining = allowCount - existing.length;
        const accepted = [];
        const rejectedByReason = {
            size: [],
            type: [],
            count: [],
        };
        files.forEach((file) => {
            if (remaining <= 0) {
                rejectedByReason.count.push(file);
                return;
            }
            if (!this.isAcceptedType(file)) {
                rejectedByReason.type.push(file);
                return;
            }
            if (this.maxSizeKb > 0 && file.size > this.maxSizeKb * 1024) {
                rejectedByReason.size.push(file);
                return;
            }
            accepted.push(file);
            remaining -= 1;
        });
        if (accepted.length > 0) {
            const next = this.multiple ? [...existing, ...accepted] : [accepted[0]];
            this.value = next;
            this.syncPreviewUrls(next);
        }
        Object.keys(rejectedByReason).forEach((reason) => {
            const rejected = rejectedByReason[reason];
            if (rejected.length > 0) {
                this.dispatchEvent(new CustomEvent('reject', {
                    bubbles: true,
                    composed: true,
                    detail: { files: rejected, reason },
                }));
            }
        });
    }
    isAcceptedType(file) {
        if (!this.accept)
            return true;
        const accepted = this.accept.split(',').map((v) => v.trim()).filter(Boolean);
        if (accepted.length === 0)
            return true;
        return accepted.some((rule) => {
            if (rule.startsWith('.')) {
                return file.name.toLowerCase().endsWith(rule.toLowerCase());
            }
            if (rule.endsWith('/*')) {
                const base = rule.replace('/*', '');
                return file.type.startsWith(`${base}/`);
            }
            return file.type === rule;
        });
    }
    // ==========================================================================
    // PREVIEW MANAGEMENT
    // ==========================================================================
    syncPreviewUrls(files = []) {
        const nextKeys = new Set(files.map((f) => this.getFileKey(f)));
        this.previewUrls.forEach((url, key) => {
            if (!nextKeys.has(key)) {
                URL.revokeObjectURL(url);
                this.previewUrls.delete(key);
            }
        });
        files.forEach((file) => {
            const key = this.getFileKey(file);
            if (!this.previewUrls.has(key) && file.type.startsWith('image/')) {
                this.previewUrls.set(key, URL.createObjectURL(file));
            }
        });
    }
    revokeAllPreviews() {
        this.previewUrls.forEach((url) => URL.revokeObjectURL(url));
        this.previewUrls.clear();
    }
    getFileKey(file) {
        return `${file.name}-${file.size}-${file.lastModified}`;
    }
    getPreviewUrl(file) {
        const key = this.getFileKey(file);
        return this.previewUrls.get(key) || null;
    }
    // ==========================================================================
    // RENDER HELPERS
    // ==========================================================================
    getContainerClasses() {
        return [
            'w-full',
            this.disabled || this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getDropZoneClasses(hasError) {
        return [
            'relative w-full rounded-lg border border-dashed p-4 transition ml-dropzone',
            hasError ? 'ml-dropzone-error' : '',
            this.isDragging ? 'ml-dropzone-active' : '',
            !this.disabled && !this.loading ? 'cursor-pointer' : 'cursor-not-allowed',
            'focus:outline-none',
        ].filter(Boolean).join(' ');
    }
    getFileItemClasses() {
        return [
            'flex items-center gap-3 rounded-md border p-2 ml-preview-card',
        ].join(' ');
    }
    getRemoveButtonClasses() {
        return [
            'ml-auto inline-flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium transition ml-preview-remove',
            !this.disabled && !this.loading ? '' : 'cursor-not-allowed',
        ].filter(Boolean).join(' ');
    }
    formatSize(size) {
        if (size < 1024)
            return `${size} B`;
        const kb = size / 1024;
        if (kb < 1024)
            return `${kb.toFixed(1)} KB`;
        const mb = kb / 1024;
        return `${mb.toFixed(1)} MB`;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div id="${this.uid}-label" class="${cn('mb-2 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderHelperOrError() {
        if (this.error) {
            return html `
        <p id="${this.uid}-error" class="mt-2 text-xs ml-error-text">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p id="${this.uid}-helper" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderTriggerContent() {
        if (this.hasSlot('Trigger') && (!this.value || this.value.length === 0)) {
            return html `${this.renderLiveSlot('Trigger')}`;
        }
        const title = (this.value?.length || 0) > 0
            ? (this.multiple ? this.msg.addMore : this.msg.replaceFile)
            : this.msg.triggerTitle;
        return html `
      <div class="flex flex-col items-center justify-center gap-1 text-center">
        <div class="text-sm font-medium ml-label">${title}</div>
        <div class="text-xs ml-text-muted">${this.msg.triggerSubtitle}</div>
      </div>
    `;
    }
    renderLoadingIndicator() {
        if (!this.loading)
            return html ``;
        return html `
      <div class="absolute inset-0 flex items-center justify-center rounded-lg ml-dropzone-loading-overlay">
        <div class="flex items-center gap-2 text-sm ml-text-muted">
          <span class="inline-block h-4 w-4 animate-spin rounded-full ml-dropzone-spinner"></span>
          ${this.msg.loading}
        </div>
      </div>
    `;
    }
    renderFileList() {
        if (!this.value || this.value.length === 0)
            return html ``;
        return html `
      <div class="mt-3 grid gap-2">
        ${this.value.map((file, index) => {
            const previewUrl = this.getPreviewUrl(file);
            return html `
            <div class="${this.getFileItemClasses()}">
              <div class="h-12 w-12 overflow-hidden rounded-md border flex items-center justify-center ml-preview-thumbnail">
                ${previewUrl
                ? html `<img src="${previewUrl}" alt="${file.name}" class="h-full w-full object-cover" />`
                : html `<span class="text-[10px] ml-text-muted">${this.msg.noPreview}</span>`}
              </div>
              <div class="flex flex-col">
                <span class="text-sm ml-text">${file.name}</span>
                <span class="text-xs ml-text-muted">${this.formatSize(file.size)}</span>
              </div>
              <button
                class="${this.getRemoveButtonClasses()}"
                type="button"
                @click=${() => this.handleRemoveFile(index)}
                ?disabled=${this.disabled || this.loading}
                aria-label="${this.msg.remove}"
              >
                ${svg `
                  <svg viewBox="0 0 24 24" class="h-4 w-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 6h18"></path>
                    <path d="M8 6v12"></path>
                    <path d="M16 6v12"></path>
                    <path d="M5 6l1-3h12l1 3"></path>
                  </svg>
                `}
                ${this.msg.remove}
              </button>
            </div>
          `;
        })}
      </div>
    `;
    }
    getFileInput() {
        return this.querySelector('input[type="file"]');
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasError = Boolean(this.error);
        const describedBy = hasError
            ? `${this.uid}-error`
            : this.hasSlot('Helper')
                ? `${this.uid}-helper`
                : nothing;
        const labelledBy = this.hasSlot('Label') ? `${this.uid}-label` : nothing;
        return html `
      <div class="${cn(this.getContainerClasses(), this.cssClass)}">
        ${this.renderLabel()}

        <div
          class="${this.getDropZoneClasses(hasError)}"
          role="button"
          tabindex="${this.disabled || this.loading ? -1 : 0}"
          aria-disabled="${this.disabled || this.loading}"
          aria-labelledby=${labelledBy ?? nothing}
          aria-describedby=${describedBy ?? nothing}
          aria-invalid="${hasError}"
          @click=${this.handleTriggerClick}
          @keydown=${this.handleTriggerKeydown}
          @dragover=${this.handleDragOver}
          @dragleave=${this.handleDragLeave}
          @drop=${this.handleDrop}
        >
          ${this.renderTriggerContent()}
          <input
            class="hidden"
            type="file"
            accept="${this.accept}"
            ?multiple=${this.multiple}
            ?disabled=${this.disabled || this.loading}
            aria-labelledby=${labelledBy ?? nothing}
            aria-describedby=${describedBy ?? nothing}
            aria-invalid="${hasError}"
            @change=${this.handleInputChange}
          
          @input="${(e) => e.stopPropagation()}"
/>
          ${this.renderLoadingIndicator()}
        </div>

        ${this.renderFileList()}
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Array })
], MlFileUploadPreviewMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFileUploadPreviewMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileUploadPreviewMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlFileUploadPreviewMolecule.prototype, "accept", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-size-kb' })
], MlFileUploadPreviewMolecule.prototype, "maxSizeKb", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-files' })
], MlFileUploadPreviewMolecule.prototype, "maxFiles", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileUploadPreviewMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlFileUploadPreviewMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlFileUploadPreviewMolecule.prototype, "isDragging", void 0);
MlFileUploadPreviewMolecule = __decorate([
    customElement('groupselectfileforupload--ml-file-upload-preview')
], MlFileUploadPreviewMolecule);
export { MlFileUploadPreviewMolecule };
