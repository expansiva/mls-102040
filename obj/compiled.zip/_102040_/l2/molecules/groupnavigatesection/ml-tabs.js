/// <mls fileReference="_102040_/l2/molecules/groupnavigatesection/ml-tabs.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// GROUP NAVIGATE SECTION — TABS MOLECULE
// =============================================================================
// Skill Group: groupNavigateSection
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No tabs available',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhuma aba disponível',
    },
};
let MlTabsMolecule = class MlTabsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-tabs .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupnavigatesection--ml-tabs .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-tabs .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-tabs .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesection--ml-tabs .ml-tab {
  color: var(--text-muted, #49454f);
  border-bottom: 2px var(--ml-border-style, solid) transparent;
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  transition: color var(--transition-fast, 200ms ease), border-color var(--transition-fast, 200ms ease);
}
groupnavigatesection--ml-tabs .ml-tab:hover {
  color: var(--text-strong, #1c1b1f);
}
groupnavigatesection--ml-tabs .ml-tab-active {
  color: var(--selected-text, #3b82f6);
  border-bottom-color: var(--selected-border, #3b82f6);
  font-weight: var(--font-weight-bold, 500);
}
groupnavigatesection--ml-tabs .ml-tab-list {
  border-bottom: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
}
groupnavigatesection--ml-tabs .ml-tab-panel {
  background-color: var(--surface-bg, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  color: var(--text-strong, #1c1b1f);
}
groupnavigatesection--ml-tabs .ml-tab-container {
  background-color: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Tab'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.uid = `tabs-${Math.random().toString(36).slice(2, 10)}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTabClick(tab, activeValue) {
        if (this.disabled || this.loading || tab.disabled)
            return;
        if (activeValue === tab.value)
            return;
        this.value = tab.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: tab.value, title: tab.title },
        }));
    }
    handleKeyDown(event) {
        if (this.disabled || this.loading)
            return;
        const tabs = this.parseTabs();
        if (tabs.length === 0)
            return;
        const activeValue = this.getActiveValue(tabs);
        const enabledTabs = tabs.filter(t => !t.disabled);
        if (enabledTabs.length === 0)
            return;
        const buttons = Array.from(this.querySelectorAll('[data-tab-button]'));
        const enabledButtons = buttons.filter(btn => btn.getAttribute('aria-disabled') !== 'true');
        const currentIndexByFocus = enabledButtons.indexOf(document.activeElement);
        const currentIndexByActive = enabledTabs.findIndex(t => t.value === activeValue);
        const currentIndex = currentIndexByFocus >= 0 ? currentIndexByFocus : currentIndexByActive;
        if (event.key === 'ArrowRight') {
            event.preventDefault();
            const nextIndex = (currentIndex + 1 + enabledButtons.length) % enabledButtons.length;
            enabledButtons[nextIndex]?.focus();
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            const prevIndex = (currentIndex - 1 + enabledButtons.length) % enabledButtons.length;
            enabledButtons[prevIndex]?.focus();
        }
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            const focused = document.activeElement;
            if (!focused)
                return;
            const tabValue = focused.getAttribute('data-value');
            const tab = tabs.find(t => t.value === tabValue);
            if (tab)
                this.handleTabClick(tab, activeValue);
        }
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    parseTabs() {
        return this.getSlots('Tab').map(el => ({
            value: el.getAttribute('value') || '',
            title: el.getAttribute('title') || '',
            icon: el.getAttribute('icon') || '',
            disabled: el.hasAttribute('disabled'),
            content: el.innerHTML,
        }));
    }
    getActiveValue(tabs) {
        if (tabs.length === 0)
            return null;
        const found = tabs.find(t => t.value === this.value);
        if (found && !found.disabled)
            return found.value;
        const firstEnabled = tabs.find(t => !t.disabled);
        return firstEnabled ? firstEnabled.value : null;
    }
    toSafeId(value) {
        return value.replace(/[^a-zA-Z0-9_-]/g, '-');
    }
    getTabClasses(isActive, isDisabled) {
        return [
            'inline-flex items-center gap-2 px-4 py-2 text-sm border-b-2 transition',
            'ml-tab',
            isActive ? 'ml-tab-active' : '',
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getTabListClasses() {
        return 'flex flex-wrap gap-2 border-b ml-tab-list';
    }
    getPanelClasses() {
        return 'mt-4 rounded-lg border p-4 ml-tab-panel';
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div id="${this.uid}-label" class="${cn('mb-2 text-sm font-semibold ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderLoading() {
        return html `
      <div class="rounded-lg border p-4 text-sm ml-tab-container ml-text-muted">
        ${this.msg.loading}
      </div>
    `;
    }
    renderError() {
        if (!this.error)
            return html ``;
        return html `
      <p class="mt-2 text-xs ml-error-text">
        ${unsafeHTML(String(this.error))}
      </p>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel()}
          ${this.renderLoading()}
        </div>
      `;
        }
        const tabs = this.parseTabs();
        if (tabs.length === 0) {
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel()}
          <div class="rounded-lg border p-4 text-sm ml-tab-container ml-text-muted">
            ${this.msg.empty}
          </div>
        </div>
      `;
        }
        const activeValue = this.getActiveValue(tabs);
        const activeTab = tabs.find(t => t.value === activeValue) || null;
        const labelId = this.hasSlot('Label') ? `${this.uid}-label` : undefined;
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        <div
          class="${this.getTabListClasses()}"
          role="tablist"
          aria-labelledby="${labelId || nothing}"
          @keydown="${this.handleKeyDown}"
        >
          ${tabs.map(tab => {
            const isActive = tab.value === activeValue;
            const isDisabled = this.disabled || this.loading || tab.disabled;
            const tabId = `${this.uid}-tab-${this.toSafeId(tab.value)}`;
            const panelId = `${this.uid}-panel-${this.toSafeId(tab.value)}`;
            return html `
              <button
                id="${tabId}"
                data-tab-button
                data-value="${tab.value}"
                class="${this.getTabClasses(isActive, isDisabled)}"
                role="tab"
                type="button"
                aria-selected="${isActive ? 'true' : 'false'}"
                aria-disabled="${isDisabled ? 'true' : 'false'}"
                aria-controls="${panelId}"
                tabindex="${isActive ? '0' : '-1'}"
                @click="${() => this.handleTabClick(tab, activeValue)}"
              >
                ${tab.icon ? html `<span class="text-base">${unsafeHTML(tab.icon)}</span>` : nothing}
                <span>${unsafeHTML(tab.title)}</span>
              </button>
            `;
        })}
        </div>

        ${activeTab
            ? html `
              <div
                id="${this.uid}-panel-${this.toSafeId(activeTab.value)}"
                class="${this.getPanelClasses()}"
                role="tabpanel"
                aria-labelledby="${this.uid}-tab-${this.toSafeId(activeTab.value)}"
              >
                ${unsafeHTML(activeTab.content)}
              </div>
            `
            : html ``}

        ${this.renderError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTabsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTabsMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTabsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTabsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTabsMolecule.prototype, "uid", void 0);
MlTabsMolecule = __decorate([
    customElement('groupnavigatesection--ml-tabs')
], MlTabsMolecule);
export { MlTabsMolecule };
