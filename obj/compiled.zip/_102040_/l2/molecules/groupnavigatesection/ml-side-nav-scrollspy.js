/// <mls fileReference="_102040_/l2/molecules/groupnavigatesection/ml-side-nav-scrollspy.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SIDE NAV SCROLLSPY MOLECULE
// =============================================================================
// Skill Group: groupNavigateSection
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    navigation: 'Navigation',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        navigation: 'Navegação',
    },
};
let MlSideNavScrollspyMolecule = class MlSideNavScrollspyMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-side-nav-scrollspy .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupnavigatesection--ml-side-nav-scrollspy .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-side-nav-scrollspy .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-side-nav-scrollspy .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-side-nav-scrollspy .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesection--ml-side-nav-scrollspy .ml-scrollspy-item {
  color: var(--text-muted, #49454f);
  border-left-color: transparent;
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-side-nav-scrollspy .ml-scrollspy-item-active {
  border-left-color: var(--selected-border, #3b82f6);
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 10%, transparent);
  color: var(--selected-text, #3b82f6);
}
groupnavigatesection--ml-side-nav-scrollspy .ml-scrollspy-dot {
  background-color: var(--button-primary-bg, #3b82f6);
}
groupnavigatesection--ml-side-nav-scrollspy .ml-skeleton {
  background-color: var(--surface-alt-bg, #f5f5f5);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Tab'];
        // Tab carries CONTENT and CONTROLS — usually whole sections with their own molecules. Re-emitting
        // it through innerHTML + unsafeHTML handed the panel a COPY: every binding the consumer set inside
        // (@click, @change, .value…) was lost, and the real molecules stayed inert in the hidden Tab.
        // With live slots the active Tab's children are MOVED into the panel; switching tabs parks the
        // previous ones (listeners intact) until they come back.
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        // Not @state: re-read from the live children on every render, and assigning it there must not
        // schedule another update.
        this.parsedTabs = [];
        this.activeValue = '';
        this.isScrolling = false;
        this.scrollTimeout = null;
        this.observer = null;
        this.sectionVisibility = new Map();
        // ===========================================================================
        // EVENT HANDLERS
        // ===========================================================================
        this.handleScroll = () => {
            if (this.scrollTimeout) {
                clearTimeout(this.scrollTimeout);
            }
            this.scrollTimeout = window.setTimeout(() => {
                this.isScrolling = false;
            }, 150);
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        window.addEventListener('scroll', this.handleScroll, { passive: true });
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        window.removeEventListener('scroll', this.handleScroll);
        this.cleanupObserver();
        if (this.scrollTimeout) {
            clearTimeout(this.scrollTimeout);
        }
    }
    firstUpdated() {
        this.parseTabs();
        this.initializeActiveValue();
        this.setupIntersectionObserver();
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            this.syncActiveValue();
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.syncActiveValue();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    // Read from the LIVE children, not the snapshot: a projected Tab is empty and a re-snapshot would
    // read it so. Direct children only — a nested navigation molecule inside a panel has Tabs of its own.
    parseTabs() {
        const tabElements = Array.from(this.children).filter(el => el.tagName === 'TAB');
        this.parsedTabs = tabElements.map(el => ({
            value: el.getAttribute('value') || '',
            title: el.getAttribute('title') || '',
            icon: el.getAttribute('icon') || '',
            disabled: el.hasAttribute('disabled'),
            element: el,
        }));
    }
    initializeActiveValue() {
        if (this.value !== null && this.value !== '') {
            const tab = this.parsedTabs.find(t => t.value === this.value && !t.disabled);
            if (tab) {
                this.activeValue = tab.value;
                return;
            }
        }
        const firstEnabled = this.parsedTabs.find(t => !t.disabled);
        if (firstEnabled) {
            this.activeValue = firstEnabled.value;
            this.value = firstEnabled.value;
        }
    }
    syncActiveValue() {
        if (this.value !== null && this.value !== '') {
            const tab = this.parsedTabs.find(t => t.value === this.value && !t.disabled);
            if (tab) {
                this.activeValue = tab.value;
            }
        }
    }
    // ===========================================================================
    // INTERSECTION OBSERVER
    // ===========================================================================
    setupIntersectionObserver() {
        this.cleanupObserver();
        this.observer = new IntersectionObserver((entries) => {
            if (this.isScrolling)
                return;
            entries.forEach(entry => {
                const sectionId = entry.target.getAttribute('id');
                if (sectionId) {
                    this.sectionVisibility.set(sectionId, entry.intersectionRatio);
                }
            });
            this.updateActiveFromVisibility();
        }, {
            threshold: [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1],
            rootMargin: '-10% 0px -10% 0px',
        });
        this.parsedTabs.forEach(tab => {
            const section = document.getElementById(tab.value);
            if (section) {
                this.observer?.observe(section);
            }
        });
    }
    cleanupObserver() {
        if (this.observer) {
            this.observer.disconnect();
            this.observer = null;
        }
        this.sectionVisibility.clear();
    }
    updateActiveFromVisibility() {
        if (this.disabled)
            return;
        let maxVisibility = 0;
        let mostVisibleSection = '';
        this.sectionVisibility.forEach((visibility, sectionId) => {
            const tab = this.parsedTabs.find(t => t.value === sectionId);
            if (tab && !tab.disabled && visibility > maxVisibility) {
                maxVisibility = visibility;
                mostVisibleSection = sectionId;
            }
        });
        if (mostVisibleSection && mostVisibleSection !== this.activeValue) {
            this.activeValue = mostVisibleSection;
            this.value = mostVisibleSection;
            this.emitChange(mostVisibleSection);
        }
    }
    handleTabClick(tab) {
        if (this.disabled || tab.disabled)
            return;
        this.isScrolling = true;
        this.activeValue = tab.value;
        this.value = tab.value;
        this.emitChange(tab.value);
        this.scrollToSection(tab.value);
    }
    handleKeyDown(e, tab, index) {
        if (this.disabled)
            return;
        const enabledTabs = this.parsedTabs.filter(t => !t.disabled);
        const currentIndex = enabledTabs.findIndex(t => t.value === tab.value);
        switch (e.key) {
            case 'ArrowDown':
            case 'ArrowRight':
                e.preventDefault();
                if (currentIndex < enabledTabs.length - 1) {
                    this.focusTab(enabledTabs[currentIndex + 1].value);
                }
                break;
            case 'ArrowUp':
            case 'ArrowLeft':
                e.preventDefault();
                if (currentIndex > 0) {
                    this.focusTab(enabledTabs[currentIndex - 1].value);
                }
                break;
            case 'Enter':
            case ' ':
                e.preventDefault();
                this.handleTabClick(tab);
                break;
            case 'Home':
                e.preventDefault();
                if (enabledTabs.length > 0) {
                    this.focusTab(enabledTabs[0].value);
                }
                break;
            case 'End':
                e.preventDefault();
                if (enabledTabs.length > 0) {
                    this.focusTab(enabledTabs[enabledTabs.length - 1].value);
                }
                break;
        }
    }
    focusTab(value) {
        const tabElement = this.querySelector(`[data-tab-value="${value}"]`);
        if (tabElement) {
            tabElement.focus();
        }
    }
    scrollToSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (section) {
            section.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }
    emitChange(value) {
        const tab = this.parsedTabs.find(t => t.value === value);
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value, title: tab?.title || '' },
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getNavClasses() {
        return [
            'flex flex-col gap-1 w-full',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getTabClasses(tab, isActive) {
        return [
            'flex items-center gap-2 px-3 py-2 text-sm rounded-md transition-all duration-200',
            'border-l-2 -ml-px',
            'ml-scrollspy-item',
            isActive ? 'ml-scrollspy-item-active font-medium' : '',
            tab.disabled || this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getContainerClasses() {
        return cn('flex gap-6 w-full', this.cssClass);
    }
    getSidebarClasses() {
        return [
            'flex-shrink-0 w-48 sticky top-4 self-start',
        ].join(' ');
    }
    getContentClasses() {
        return [
            'flex-1 min-w-0',
        ].join(' ');
    }
    getLabelClasses() {
        return [
            'text-xs font-semibold uppercase tracking-wider mb-3 px-3',
            'ml-label',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        this.parseTabs();
        const hasLabel = this.hasSlot('Label');
        // getLiveText: once projected, the Label source is empty and getSlotContent would read ''.
        const labelText = hasLabel ? this.getLiveText(this.getLiveSlot('Label')) : '';
        const activeTab = this.parsedTabs.find(t => t.value === this.activeValue);
        return html `
      <div class=${this.getContainerClasses()}>
        <aside class=${this.getSidebarClasses()}>
          <nav
            role="tablist"
            aria-label=${labelText || this.msg.navigation}
            aria-orientation="vertical"
            class=${this.getNavClasses()}
          >
            ${hasLabel ? html `
              <div class=${this.getLabelClasses()}>
                ${this.renderLiveSlot('Label')}
              </div>
            ` : html ``}
            ${this.parsedTabs.map((tab, index) => this.renderTab(tab, index))}
          </nav>
        </aside>
        <div
          class=${this.getContentClasses()}
          role="tabpanel"
          aria-labelledby=${activeTab ? `tab-${activeTab.value}` : ''}
        >
          ${activeTab ? this.renderLiveSlotFrom(activeTab.element) : html ``}
        </div>
      </div>
      ${this.error ? this.renderError() : html ``}
    `;
    }
    renderTab(tab, index) {
        const isActive = tab.value === this.activeValue;
        const isDisabled = tab.disabled || this.disabled;
        return html `
      <button
        id="tab-${tab.value}"
        data-tab-value=${tab.value}
        role="tab"
        aria-selected=${isActive ? 'true' : 'false'}
        aria-disabled=${isDisabled ? 'true' : 'false'}
        aria-controls="panel-${tab.value}"
        tabindex=${isActive && !isDisabled ? '0' : '-1'}
        class=${this.getTabClasses(tab, isActive)}
        @click=${() => this.handleTabClick(tab)}
        @keydown=${(e) => this.handleKeyDown(e, tab, index)}
        ?disabled=${isDisabled}
      >
        ${tab.icon ? html `<span class="flex-shrink-0">${tab.icon}</span>` : html ``}
        <span class="truncate">${tab.title}</span>
        ${isActive ? html `
          <span class="ml-auto w-1.5 h-1.5 rounded-full ml-scrollspy-dot flex-shrink-0"></span>
        ` : html ``}
      </button>
    `;
    }
    renderLoading() {
        return html `
      <div class=${this.getContainerClasses()}>
        <aside class=${this.getSidebarClasses()}>
          <nav class=${this.getNavClasses()}>
            <div class="animate-pulse space-y-2 px-3">
              <div class="h-3 w-16 ml-skeleton rounded"></div>
              <div class="h-8 w-full ml-skeleton rounded"></div>
              <div class="h-8 w-full ml-skeleton rounded"></div>
              <div class="h-8 w-full ml-skeleton rounded"></div>
              <div class="h-8 w-3/4 ml-skeleton rounded"></div>
            </div>
          </nav>
        </aside>
        <div class=${this.getContentClasses()}>
          <div class="animate-pulse space-y-4">
            <div class="h-6 w-1/3 ml-skeleton rounded"></div>
            <div class="h-4 w-full ml-skeleton rounded"></div>
            <div class="h-4 w-full ml-skeleton rounded"></div>
            <div class="h-4 w-2/3 ml-skeleton rounded"></div>
          </div>
        </div>
      </div>
    `;
    }
    renderError() {
        return html `
      <p class="mt-2 text-xs ml-error-text">
        ${unsafeHTML(this.error)}
      </p>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSideNavScrollspyMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSideNavScrollspyMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSideNavScrollspyMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSideNavScrollspyMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSideNavScrollspyMolecule.prototype, "activeValue", void 0);
__decorate([
    state()
], MlSideNavScrollspyMolecule.prototype, "isScrolling", void 0);
MlSideNavScrollspyMolecule = __decorate([
    customElement('groupnavigatesection--ml-side-nav-scrollspy')
], MlSideNavScrollspyMolecule);
export { MlSideNavScrollspyMolecule };
