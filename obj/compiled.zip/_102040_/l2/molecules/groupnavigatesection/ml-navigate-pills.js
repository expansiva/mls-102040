var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupnavigatesection/ml-navigate-pills.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NAVIGATE PILLS MOLECULE
// =============================================================================
// Skill Group: groupNavigateSection
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
let NavigatePillsMolecule = class NavigatePillsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-navigate-pills .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupnavigatesection--ml-navigate-pills .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-pills .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-pills .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-pills .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesection--ml-navigate-pills .ml-nav-pill {
  background-color: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-md, 8px);
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-pills .ml-nav-pill-active {
  border-color: var(--ml-primary, #3b82f6);
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupnavigatesection--ml-navigate-pills .ml-nav-pill-panel {
  background-color: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
}
`);
        this.msg = messages.en;
        this.instanceId = `nav-${Math.random().toString(36).slice(2, 8)}`;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================='
        this.slotTags = ['Label', 'Tab'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================='
        this.value = null;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.lastActiveIndex = -1;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTabClick(tab) {
        if (this.disabled || this.loading || tab.disabled)
            return;
        this.value = tab.value;
        this.dispatchChange(tab);
    }
    handleKeyDown(e, index, tabs) {
        if (this.disabled || this.loading)
            return;
        const key = e.key;
        if (key !== 'ArrowLeft' && key !== 'ArrowRight' && key !== 'Enter' && key !== ' ')
            return;
        const enabledIndices = tabs
            .map((t, i) => ({ t, i }))
            .filter(({ t }) => !t.disabled)
            .map(({ i }) => i);
        if (enabledIndices.length === 0)
            return;
        if (key === 'Enter' || key === ' ') {
            e.preventDefault();
            const tab = tabs[index];
            if (tab && !tab.disabled) {
                this.value = tab.value;
                this.dispatchChange(tab);
            }
            return;
        }
        e.preventDefault();
        const currentPos = enabledIndices.indexOf(index);
        if (currentPos === -1)
            return;
        let nextIndex = index;
        if (key === 'ArrowRight') {
            nextIndex = enabledIndices[(currentPos + 1) % enabledIndices.length];
        }
        else if (key === 'ArrowLeft') {
            nextIndex = enabledIndices[(currentPos - 1 + enabledIndices.length) % enabledIndices.length];
        }
        this.focusTabButton(nextIndex);
    }
    focusTabButton(index) {
        const button = this.querySelector(`[data-tab-index="${index}"]`);
        if (button)
            button.focus();
    }
    dispatchChange(tab) {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: tab.value, title: tab.title },
        }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getTabs() {
        return this.getSlots('Tab').map(el => ({
            value: el.getAttribute('value') || '',
            title: el.getAttribute('title') || '',
            icon: el.getAttribute('icon') || '',
            disabled: el.hasAttribute('disabled'),
            content: el.innerHTML || '',
        })).filter(tab => tab.value && tab.title);
    }
    getActiveIndex(tabs) {
        if (tabs.length === 0)
            return -1;
        const explicitIndex = this.value
            ? tabs.findIndex(t => t.value === this.value && !t.disabled)
            : -1;
        if (explicitIndex !== -1)
            return explicitIndex;
        const firstAvailable = tabs.findIndex(t => !t.disabled);
        return firstAvailable;
    }
    getTabClasses(isActive, isDisabled) {
        return [
            'flex items-center gap-2 rounded-full px-4 py-2 text-sm font-medium border transition whitespace-nowrap',
            'ml-nav-pill',
            isActive ? 'ml-nav-pill-active' : '',
            (isDisabled || this.disabled || this.loading) ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelContent = this.getSlotContent('Label');
        return html `<div class="mb-2 text-sm font-semibold ml-label">${unsafeHTML(labelContent)}</div>`;
    }
    renderLoading() {
        return html `
<div class="space-y-2">
${this.renderLabel()}
<div class="flex items-center gap-2 rounded-lg border px-4 py-3 text-sm ml-nav-pill ml-text-muted">
${this.msg.loading}
</div>
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        const tabs = this.getTabs();
        const activeIndex = this.getActiveIndex(tabs);
        this.lastActiveIndex = activeIndex;
        const activeTab = activeIndex >= 0 ? tabs[activeIndex] : null;
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div
class="flex gap-2 overflow-x-auto pb-1"
role="tablist"
aria-label="${this.hasSlot('Label') ? this.getSlotContent('Label') : 'Navigation'}"
>
${tabs.map((tab, index) => {
            const isActive = index === activeIndex;
            const isDisabled = tab.disabled;
            const tabId = `${this.instanceId}-tab-${index}`;
            const panelId = `${this.instanceId}-panel-${index}`;
            return html `
<button
class="${this.getTabClasses(isActive, isDisabled)}"
role="tab"
aria-selected="${isActive ? 'true' : 'false'}"
aria-disabled="${isDisabled || this.disabled || this.loading ? 'true' : 'false'}"
aria-controls="${panelId}"
id="${tabId}"
data-tab-index="${index}"
?disabled=${isDisabled || this.disabled || this.loading}
@click=${() => this.handleTabClick(tab)}
@keydown=${(e) => this.handleKeyDown(e, index, tabs)}
>
${tab.icon ? html `<span class="text-base">${unsafeHTML(tab.icon)}</span>` : html ``}
<span>${unsafeHTML(tab.title)}</span>
</button>
`;
        })}
</div>
${activeTab ? html `
<div
class="mt-4 rounded-lg border p-4 ml-nav-pill-panel ml-text"
role="tabpanel"
id="${this.instanceId}-panel-${activeIndex}"
aria-labelledby="${this.instanceId}-tab-${activeIndex}"
>
${unsafeHTML(activeTab.content)}
</div>
` : html ``}
${this.error ? html `<p class="mt-2 text-xs ml-error-text">${unsafeHTML(this.error)}</p>` : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], NavigatePillsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], NavigatePillsMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NavigatePillsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], NavigatePillsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], NavigatePillsMolecule.prototype, "lastActiveIndex", void 0);
NavigatePillsMolecule = __decorate([
    customElement('groupnavigatesection--ml-navigate-pills')
], NavigatePillsMolecule);
export { NavigatePillsMolecule };
