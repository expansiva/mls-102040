/// <mls fileReference="_102040_/l2/molecules/groupnavigatesection/ml-navigate-tabs.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// NAVIGATE TABS MOLECULE
// =============================================================================
// Skill Group: groupNavigateSection
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
    },
};
let MlNavigateTabsMolecule = class MlNavigateTabsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-navigate-tabs .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupnavigatesection--ml-navigate-tabs .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-tabs .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-tabs .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-tabs .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesection--ml-navigate-tabs .ml-tab-list {
  background-color: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
}
groupnavigatesection--ml-navigate-tabs .ml-tab {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-navigate-tabs .ml-tab-active {
  color: var(--selected-text, #3b82f6);
}
groupnavigatesection--ml-navigate-tabs .ml-tab-indicator {
  background-color: var(--ml-primary, #3b82f6);
}
groupnavigatesection--ml-navigate-tabs .ml-tab-panel {
  color: var(--text-strong, #1c1b1f);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Tab'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.parsedTabs = [];
        this.focusedIndex = 0;
        this.indicatorStyle = '';
        this.touchStartX = 0;
        this.touchEndX = 0;
        this.tabListRef = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseTabs();
        this.initializeActiveTab();
        requestAnimationFrame(() => this.updateIndicator());
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            requestAnimationFrame(() => this.updateIndicator());
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.value = value;
            requestAnimationFrame(() => this.updateIndicator());
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // TAB PARSING
    // ===========================================================================
    parseTabs() {
        const tabElements = this.getSlots('Tab');
        this.parsedTabs = tabElements.map((el, index) => ({
            value: el.getAttribute('value') || String(index),
            title: el.getAttribute('title') || '',
            icon: el.getAttribute('icon') || '',
            disabled: el.hasAttribute('disabled'),
            content: el.innerHTML,
            element: el,
        }));
    }
    initializeActiveTab() {
        if (this.value === null && this.parsedTabs.length > 0) {
            const firstEnabled = this.parsedTabs.find(tab => !tab.disabled);
            if (firstEnabled) {
                this.value = firstEnabled.value;
            }
        }
        this.updateFocusedIndex();
    }
    updateFocusedIndex() {
        const index = this.parsedTabs.findIndex(tab => tab.value === this.value);
        this.focusedIndex = index >= 0 ? index : 0;
    }
    getActiveTab() {
        return this.parsedTabs.find(tab => tab.value === this.value);
    }
    // ===========================================================================
    // INDICATOR
    // ===========================================================================
    updateIndicator() {
        const tabList = this.querySelector('[role="tablist"]');
        if (!tabList)
            return;
        const activeTabEl = tabList.querySelector('[aria-selected="true"]');
        if (!activeTabEl) {
            this.indicatorStyle = 'opacity: 0;';
            return;
        }
        const tabListRect = tabList.getBoundingClientRect();
        const activeRect = activeTabEl.getBoundingClientRect();
        const left = activeRect.left - tabListRect.left + tabList.scrollLeft;
        const width = activeRect.width;
        this.indicatorStyle = `left: ${left}px; width: ${width}px; opacity: 1;`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTabClick(tab) {
        if (this.disabled || this.loading || tab.disabled)
            return;
        this.selectTab(tab);
    }
    selectTab(tab) {
        if (tab.disabled)
            return;
        this.value = tab.value;
        this.updateFocusedIndex();
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: tab.value, title: tab.title },
        }));
    }
    handleKeyDown(e) {
        if (this.disabled || this.loading)
            return;
        const enabledTabs = this.parsedTabs.filter(tab => !tab.disabled);
        if (enabledTabs.length === 0)
            return;
        const currentEnabledIndex = enabledTabs.findIndex(tab => tab.value === this.parsedTabs[this.focusedIndex]?.value);
        switch (e.key) {
            case 'ArrowLeft':
                e.preventDefault();
                this.moveFocus(enabledTabs, currentEnabledIndex, -1);
                break;
            case 'ArrowRight':
                e.preventDefault();
                this.moveFocus(enabledTabs, currentEnabledIndex, 1);
                break;
            case 'Enter':
            case ' ':
                e.preventDefault();
                const focusedTab = this.parsedTabs[this.focusedIndex];
                if (focusedTab && !focusedTab.disabled) {
                    this.selectTab(focusedTab);
                }
                break;
            case 'Home':
                e.preventDefault();
                if (enabledTabs.length > 0) {
                    this.focusTab(enabledTabs[0]);
                }
                break;
            case 'End':
                e.preventDefault();
                if (enabledTabs.length > 0) {
                    this.focusTab(enabledTabs[enabledTabs.length - 1]);
                }
                break;
        }
    }
    moveFocus(enabledTabs, currentIndex, direction) {
        let newIndex = currentIndex + direction;
        if (newIndex < 0)
            newIndex = enabledTabs.length - 1;
        if (newIndex >= enabledTabs.length)
            newIndex = 0;
        this.focusTab(enabledTabs[newIndex]);
    }
    focusTab(tab) {
        const index = this.parsedTabs.findIndex(t => t.value === tab.value);
        if (index >= 0) {
            this.focusedIndex = index;
            const tabEl = this.querySelector(`[data-tab-value="${tab.value}"]`);
            tabEl?.focus();
        }
    }
    // ===========================================================================
    // TOUCH HANDLERS
    // ===========================================================================
    handleTouchStart(e) {
        if (this.disabled || this.loading)
            return;
        this.touchStartX = e.touches[0].clientX;
    }
    handleTouchMove(e) {
        if (this.disabled || this.loading)
            return;
        this.touchEndX = e.touches[0].clientX;
    }
    handleTouchEnd() {
        if (this.disabled || this.loading)
            return;
        const swipeThreshold = 50;
        const diff = this.touchStartX - this.touchEndX;
        if (Math.abs(diff) < swipeThreshold)
            return;
        const enabledTabs = this.parsedTabs.filter(tab => !tab.disabled);
        const currentIndex = enabledTabs.findIndex(tab => tab.value === this.value);
        if (diff > 0) {
            // Swipe left - next tab
            const nextIndex = currentIndex + 1;
            if (nextIndex < enabledTabs.length) {
                this.selectTab(enabledTabs[nextIndex]);
            }
        }
        else {
            // Swipe right - previous tab
            const prevIndex = currentIndex - 1;
            if (prevIndex >= 0) {
                this.selectTab(enabledTabs[prevIndex]);
            }
        }
        this.touchStartX = 0;
        this.touchEndX = 0;
    }
    // ===========================================================================
    // STYLES
    // ===========================================================================
    getContainerClasses() {
        return cn([
            'w-full',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' '), this.cssClass);
    }
    getTabListClasses() {
        return [
            'relative flex overflow-x-auto scrollbar-hide',
            'border-b ml-tab-list',
        ].join(' ');
    }
    getTabClasses(tab, isActive, isFocused) {
        return [
            'relative flex items-center gap-2 px-4 py-3 text-sm font-medium whitespace-nowrap',
            'transition-colors duration-200 outline-none',
            'ml-tab',
            isActive ? 'ml-tab-active' : '',
            tab.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getIndicatorClasses() {
        return [
            'absolute bottom-0 h-0.5 ml-tab-indicator',
            'transition-all duration-300 ease-out',
        ].join(' ');
    }
    getPanelClasses() {
        return [
            'w-full py-4',
            'ml-tab-panel ml-text',
        ].join(' ');
    }
    getLoadingClasses() {
        return [
            'flex items-center justify-center py-8',
            'ml-text-muted',
        ].join(' ');
    }
    getErrorClasses() {
        return [
            'mt-2 text-sm ml-error-text',
        ].join(' ');
    }
    getLabelClasses() {
        return [
            'block mb-2 text-sm font-medium',
            'ml-label',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        const labelContent = this.getSlotContent('Label');
        const activeTab = this.getActiveTab();
        return html `
      <div class=${this.getContainerClasses()}>
        ${labelContent ? this.renderLabel(labelContent) : html ``}
        ${this.renderTabList()}
        ${this.error ? this.renderError() : html ``}
        ${activeTab ? this.renderPanel(activeTab) : html ``}
      </div>
    `;
    }
    renderLoading() {
        return html `
      <div class=${this.getLoadingClasses()}>
        <span>${this.msg.loading}</span>
      </div>
    `;
    }
    renderLabel(content) {
        return html `
      <span class=${this.getLabelClasses()} id="tab-label">
        ${unsafeHTML(content)}
      </span>
    `;
    }
    renderTabList() {
        const labelContent = this.getSlotContent('Label');
        return html `
      <div
        role="tablist"
        class=${this.getTabListClasses()}
        aria-label=${labelContent || ''}
        @keydown=${this.handleKeyDown}
        @touchstart=${this.handleTouchStart}
        @touchmove=${this.handleTouchMove}
        @touchend=${this.handleTouchEnd}
      >
        ${this.parsedTabs.map((tab, index) => this.renderTab(tab, index))}
        <div
          class=${this.getIndicatorClasses()}
          style=${this.indicatorStyle}
          aria-hidden="true"
        ></div>
      </div>
    `;
    }
    renderTab(tab, index) {
        const isActive = tab.value === this.value;
        const isFocused = index === this.focusedIndex;
        const panelId = `panel-${tab.value}`;
        const tabId = `tab-${tab.value}`;
        return html `
      <button
        id=${tabId}
        role="tab"
        type="button"
        class=${this.getTabClasses(tab, isActive, isFocused)}
        data-tab-value=${tab.value}
        aria-selected=${isActive ? 'true' : 'false'}
        aria-disabled=${tab.disabled ? 'true' : 'false'}
        aria-controls=${panelId}
        tabindex=${isActive ? '0' : '-1'}
        @click=${() => this.handleTabClick(tab)}
      >
        ${tab.icon ? html `<span aria-hidden="true">${tab.icon}</span>` : html ``}
        <span>${tab.title}</span>
      </button>
    `;
    }
    renderPanel(tab) {
        const panelId = `panel-${tab.value}`;
        const tabId = `tab-${tab.value}`;
        return html `
      <div
        id=${panelId}
        role="tabpanel"
        class=${this.getPanelClasses()}
        aria-labelledby=${tabId}
        tabindex="0"
      >
        ${unsafeHTML(tab.content)}
      </div>
    `;
    }
    renderError() {
        return html `
      <p class=${this.getErrorClasses()}>
        ${unsafeHTML(this.error)}
      </p>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlNavigateTabsMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlNavigateTabsMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNavigateTabsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlNavigateTabsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlNavigateTabsMolecule.prototype, "parsedTabs", void 0);
__decorate([
    state()
], MlNavigateTabsMolecule.prototype, "focusedIndex", void 0);
__decorate([
    state()
], MlNavigateTabsMolecule.prototype, "indicatorStyle", void 0);
MlNavigateTabsMolecule = __decorate([
    customElement('groupnavigatesection--ml-navigate-tabs')
], MlNavigateTabsMolecule);
export { MlNavigateTabsMolecule };
