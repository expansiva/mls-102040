var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupnavigatesection/ml-breadcrumb-trail.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// BREADCRUMB TRAIL MOLECULE
// =============================================================================
// Skill Group: groupNavigateSection
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    overflow: 'More levels',
};
const messages = {
    en: message_en,
};
let BreadcrumbTrailMolecule = class BreadcrumbTrailMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupnavigatesection--ml-breadcrumb-trail .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupnavigatesection--ml-breadcrumb-trail .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-breadcrumb-trail .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-breadcrumb-trail .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-breadcrumb-trail .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupnavigatesection--ml-breadcrumb-trail .ml-breadcrumb {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupnavigatesection--ml-breadcrumb-trail .ml-breadcrumb-separator {
  color: var(--ml-on-surface-muted, #49454f);
}
groupnavigatesection--ml-breadcrumb-trail .ml-breadcrumb-current {
  color: var(--ml-on-surface, #1c1b1f);
}
groupnavigatesection--ml-breadcrumb-trail .ml-breadcrumb-dropdown {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Tab'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = null;
        this.error = '';
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.isOverflowOpen = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // =========================================================================
    firstUpdated() {
        this.addEventListener('keydown', this.handleKeyDown);
    }
    // ===========================================================================
    // HELPERS
    // =========================================================================
    getTabs() {
        const elements = this.getSlots('Tab');
        return elements.map((el, index) => ({
            value: el.getAttribute('value') || '',
            title: el.getAttribute('title') || '',
            icon: el.getAttribute('icon') || '',
            disabled: el.hasAttribute('disabled'),
            content: el.innerHTML || '',
            index,
            isLast: index === elements.length - 1,
        }));
    }
    getActiveValue(tabs) {
        if (this.value && tabs.find(tab => tab.value === this.value)) {
            return this.value;
        }
        const firstActive = tabs.find(tab => !tab.disabled);
        return firstActive ? firstActive.value : (tabs[0]?.value || null);
    }
    getTabClasses(isActive, disabled, interactive) {
        return [
            'inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-sm transition whitespace-nowrap',
            'ml-breadcrumb',
            interactive ? 'cursor-pointer' : 'cursor-default',
            isActive ? 'ml-breadcrumb-current font-medium' : '',
            disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getDelimiterClasses() {
        return [
            'mx-1 ml-breadcrumb-separator select-none',
        ].join(' ');
    }
    getOverflowButtonClasses() {
        return [
            'inline-flex items-center rounded-md px-1.5 py-0.5 text-sm transition whitespace-nowrap',
            'ml-breadcrumb',
            this.disabled || this.loading ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'pt-2 text-sm',
            'ml-text',
        ].join(' ');
    }
    getLabelClasses() {
        return [
            'block text-xs font-medium mb-1',
            'ml-label',
        ].join(' ');
    }
    getErrorClasses() {
        return [
            'pt-1 text-xs',
            'ml-error-text',
        ].join(' ');
    }
    renderTab(tab, activeValue) {
        const isActive = tab.value === activeValue;
        const interactive = !tab.isLast && !tab.disabled && !this.disabled && !this.loading;
        if (tab.isLast) {
            return html `
<span class="${this.getTabClasses(isActive, tab.disabled, false)}" role="tab" aria-selected="${isActive}" aria-disabled="true">
${tab.icon ? html `<span class="text-base">${tab.icon}</span>` : ''}
<span>${tab.title}</span>
</span>
`;
        }
        return html `
<button
class="${this.getTabClasses(isActive, tab.disabled || this.disabled || this.loading, interactive)}"
role="tab"
aria-selected="${isActive}"
aria-disabled="${tab.disabled || this.disabled || this.loading}"
?disabled=${tab.disabled || this.disabled || this.loading}
data-tab-button="true"
@ক্তclick=${() => this.handleTabClick(tab)}
>
${tab.icon ? html `<span class="text-base">${tab.icon}</span>` : ''}
<span>${tab.title}</span>
</button>
`;
    }
    renderOverflowMenu(hiddenTabs, activeValue) {
        if (!hiddenTabs.length)
            return html ``;
        return html `
<div class="relative inline-flex items-center">
<button
class="${this.getOverflowButtonClasses()}"
aria-label="${this.msg.overflow}"
?disabled=${this.disabled || this.loading}
@click=${this.handleOverflowToggle}
>
...
</button>
${this.isOverflowOpen ? html `
<div class="absolute left-0 top-full mt-1 w-48 rounded-md border ml-breadcrumb-dropdown shadow-md z-10">
<div class="p-1">
${hiddenTabs.map(tab => html `
<button
class="${this.getTabClasses(tab.value === activeValue, tab.disabled || this.disabled || this.loading, !tab.disabled)} w-full justify-start" 
role="tab"
aria-selected="${tab.value === activeValue}"
aria-disabled="${tab.disabled || this.disabled || this.loading}"
?disabled=${tab.disabled || this.disabled || this.loading}
data-tab-button="true"
@click=${() => this.handleTabClick(tab, true)}
>
${tab.icon ? html `<span class="text-base">${tab.icon}</span>` : ''}
<span>${tab.title}</span>
</button>
`)}
</div>
</div>
` : ''}
</div>
`;
    }
    renderTrail(tabs, activeValue) {
        if (!tabs.length)
            return html ``;
        const first = tabs[0];
        const last = tabs[tabs.length - 1];
        const middle = tabs.slice(1, tabs.length - 1);
        return html `
<div class="flex items-center whitespace-nowrap" role="tablist">
<div class="flex items-center sm:hidden">
${this.renderTab(first, activeValue)}
<span class="${this.getDelimiterClasses()}">/</span>
${this.renderOverflowMenu(middle, activeValue)}
<span class="${this.getDelimiterClasses()}">/</span>
${this.renderTab(last, activeValue)}
</div>
<div class="hidden sm:flex items-center">
${tabs.map((tab, index) => html `
${index > 0 ? html `<span class="${this.getDelimiterClasses()}">/</span>` : ''}
${this.renderTab(tab, activeValue)}
`)}
</div>
</div>
`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleTabClick(tab, closeOverflow = false) {
        if (this.loading || this.disabled)
            return;
        if (tab.disabled || tab.isLast)
            return;
        this.value = tab.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: tab.value, title: tab.title },
        }));
        if (closeOverflow) {
            this.isOverflowOpen = false;
        }
    }
    handleOverflowToggle() {
        if (this.loading || this.disabled)
            return;
        this.isOverflowOpen = !this.isOverflowOpen;
    }
    handleKeyDown(e) {
        if (this.loading || this.disabled)
            return;
        const keys = ['ArrowLeft', 'ArrowRight', 'Enter', ' '];
        if (!keys.includes(e.key))
            return;
        const buttons = Array.from(this.querySelectorAll('button[data-tab-button="true"]'))
            .filter(btn => !btn.disabled);
        if (!buttons.length)
            return;
        const current = document.activeElement;
        const currentIndex = buttons.findIndex(btn => btn === current);
        if (e.key === 'ArrowLeft' || e.key === 'ArrowRight') {
            e.preventDefault();
            const dir = e.key === 'ArrowRight' ? 1 : -1;
            const nextIndex = (currentIndex + dir + buttons.length) % buttons.length;
            buttons[nextIndex].focus();
        }
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            current?.click();
        }
    }
    // ===========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const tabs = this.getTabs();
        const activeValue = this.getActiveValue(tabs);
        const activeTab = tabs.find(tab => tab.value === activeValue) || tabs[0];
        const labelContent = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const activeContent = activeTab ? activeTab.content : '';
        return html `
<div class="${cn('w-full', this.cssClass)}">
${labelContent ? html `<span class="${this.getLabelClasses()}">${unsafeHTML(labelContent)}</span>` : ''}
<div class="relative">
${this.loading
            ? html `<div class="text-sm ml-text-muted">${this.msg.loading}</div>`
            : this.renderTrail(tabs, activeValue)}
</div>
<div class="${this.getPanelClasses()}" role="tabpanel">
${activeContent ? unsafeHTML(activeContent) : ''}
</div>
${this.error ? html `<div class="${this.getErrorClasses()}">${unsafeHTML(this.error)}</div>` : ''}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], BreadcrumbTrailMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], BreadcrumbTrailMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], BreadcrumbTrailMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], BreadcrumbTrailMolecule.prototype, "loading", void 0);
__decorate([
    state()
], BreadcrumbTrailMolecule.prototype, "isOverflowOpen", void 0);
BreadcrumbTrailMolecule = __decorate([
    customElement('groupnavigatesection--ml-breadcrumb-trail')
], BreadcrumbTrailMolecule);
export { BreadcrumbTrailMolecule };
