var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// LOCATE MAP PICKER MOLECULE
// =============================================================================
// Skill Group: groupLocatePosition
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search location',
    noResults: 'No results found',
    loading: 'Loading...',
    emptyValue: '—',
    useLocation: 'Use current location',
    requiredError: 'Location is required',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let LocateMapPickerMolecule = class LocateMapPickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouplocateposition--ml-locate-map-picker .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-locate-map-picker .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-locate-map-picker .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-locate-map-picker .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
grouplocateposition--ml-locate-map-picker .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-locate-map-picker .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-locate-map-picker .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-locate-map-picker .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
grouplocateposition--ml-locate-map-picker .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouplocateposition--ml-locate-map-picker .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
grouplocateposition--ml-locate-map-picker .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouplocateposition--ml-locate-map-picker .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouplocateposition--ml-locate-map-picker .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
grouplocateposition--ml-locate-map-picker .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
grouplocateposition--ml-locate-map-picker .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
grouplocateposition--ml-locate-map-picker .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
grouplocateposition--ml-locate-map-picker .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
grouplocateposition--ml-locate-map-picker .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        this.uid = `locate-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Suggestions', 'Item', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.showMap = false;
        this.allowGeolocation = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.searchQuery = '';
        this.isOpen = false;
        this.isFocused = false;
        this.isDragging = false;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, _value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.updateSearchQueryFromValue();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    parseValue() {
        if (!this.value)
            return null;
        const [lat, lng] = this.value.split(',').map(Number);
        return isNaN(lat) || isNaN(lng) ? null : { lat, lng };
    }
    getSuggestions() {
        const suggestionsContainer = this.getSlot('Suggestions');
        if (!suggestionsContainer)
            return [];
        return Array.from(suggestionsContainer.querySelectorAll('Item')).map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
        }));
    }
    getLabelForValue(value) {
        if (!value)
            return null;
        const items = this.getSuggestions();
        const match = items.find(item => item.value === value);
        return match ? match.label : null;
    }
    updateSearchQueryFromValue() {
        if (!this.value) {
            this.searchQuery = '';
            return;
        }
        const label = this.getLabelForValue(this.value);
        this.searchQuery = label || this.value;
    }
    getEffectiveQuery() {
        return this.searchQuery || this.getLabelForValue(this.value) || this.value || '';
    }
    isInteractionBlocked() {
        return this.disabled || this.readonly || this.loading || !this.isEditing;
    }
    getInputClasses(hasError) {
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'ml-surface-bg',
            'ml-text',
            'placeholder:ml-text-faint',
            hasError
                ? 'ml-border-error'
                : this.isFocused
                    ? 'ml-border-focus'
                    : 'ml-border',
            '',
            this.disabled || this.loading ? 'ml-disabled' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'absolute z-10 mt-2 w-full rounded-lg border p-2',
            'ml-surface-bg',
            'ml-border',
            'shadow-lg',
        ].join(' ');
    }
    getItemClasses(isSelected, isDisabled) {
        return [
            'w-full rounded-md px-3 py-2 text-sm transition text-left',
            isSelected
                ? 'ml-primary-dim-bg ml-primary-text border ml-border-focus'
                : 'ml-text border border-transparent',
            !isDisabled && !isSelected ? 'hover:ml-surface-dim-bg' : '',
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getMapContainerClasses() {
        return [
            'relative w-full h-48 rounded-lg border overflow-hidden',
            'ml-surface-dim-bg',
            'ml-border',
            this.isInteractionBlocked() ? 'opacity-50' : '',
        ].filter(Boolean).join(' ');
    }
    getMapMarkerStyle() {
        const coords = this.parseValue();
        if (!coords)
            return 'display:none;';
        const x = Math.min(100, Math.max(0, ((coords.lng + 180) / 360) * 100));
        const y = Math.min(100, Math.max(0, ((90 - coords.lat) / 180) * 100));
        return `left:${x}%; top:${y}%;`;
    }
    getErrorMessage() {
        if (!this.isEditing)
            return '';
        if (this.error)
            return this.error;
        if (this.required && !this.value)
            return this.msg.requiredError;
        return '';
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.isInteractionBlocked())
            return;
        const input = e.target;
        this.searchQuery = input.value;
        this.isOpen = true;
        this.dispatchEvent(new CustomEvent('search', {
            bubbles: true,
            composed: true,
            detail: { query: this.searchQuery }
        }));
    }
    handleFocus() {
        if (this.disabled)
            return;
        this.isFocused = true;
        this.isOpen = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.isFocused = false;
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleSelect(value, label) {
        if (this.isInteractionBlocked())
            return;
        this.value = value;
        this.searchQuery = label || value;
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleGeolocation() {
        if (this.isInteractionBlocked() || !this.allowGeolocation)
            return;
        if (!navigator.geolocation)
            return;
        this.loading = true;
        navigator.geolocation.getCurrentPosition((pos) => {
            const coords = `${pos.coords.latitude},${pos.coords.longitude}`;
            this.value = coords;
            this.searchQuery = coords;
            this.loading = false;
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value }
            }));
            this.dispatchEvent(new CustomEvent('search', {
                bubbles: true,
                composed: true,
                detail: { query: coords }
            }));
        }, () => {
            this.loading = false;
        });
    }
    handleMapPointerDown(e) {
        if (this.isInteractionBlocked() || !this.showMap)
            return;
        const target = e.currentTarget;
        if (!target)
            return;
        this.isDragging = true;
        target.setPointerCapture(e.pointerId);
        this.updateValueFromPointer(e);
    }
    handleMapPointerMove(e) {
        if (!this.isDragging)
            return;
        this.updateValueFromPointer(e);
    }
    handleMapPointerUp(e) {
        if (!this.isDragging)
            return;
        this.isDragging = false;
        const target = e.currentTarget;
        if (target)
            target.releasePointerCapture(e.pointerId);
    }
    updateValueFromPointer(e) {
        const container = e.currentTarget;
        const rect = container.getBoundingClientRect();
        const x = Math.min(rect.width, Math.max(0, e.clientX - rect.left));
        const y = Math.min(rect.height, Math.max(0, e.clientY - rect.top));
        const lng = (x / rect.width) * 360 - 180;
        const lat = 90 - (y / rect.height) * 180;
        const value = `${lat.toFixed(6)},${lng.toFixed(6)}`;
        this.value = value;
        this.searchQuery = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
        this.dispatchEvent(new CustomEvent('search', {
            bubbles: true,
            composed: true,
            detail: { query: value }
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<label id="${this.uid}-label" class="${cn('block mb-2 text-sm ml-text-muted', this.getSlotClass('Label'))}">${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    renderHelperOrError() {
        const errorMessage = this.getErrorMessage();
        if (!this.isEditing)
            return html ``;
        if (errorMessage) {
            return html `<p id="${this.uid}-error" class="mt-1 text-xs ml-error-text">${unsafeHTML(String(errorMessage))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="${cn('mt-1 text-xs ml-text-muted', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderSuggestions() {
        if (!this.isEditing || !this.isOpen)
            return html ``;
        const items = this.getSuggestions();
        if (this.loading) {
            return html `<div class="${this.getPanelClasses()}" role="listbox">${this.msg.loading}</div>`;
        }
        if (!items.length) {
            const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noResults;
            return html `<div class="${this.getPanelClasses()}" role="listbox"><div class="px-3 py-2 text-sm ml-text-muted">${unsafeHTML(emptyContent)}</div></div>`;
        }
        return html `
<div class="${this.getPanelClasses()}" role="listbox">
${items.map(item => {
            const isSelected = item.value === this.value;
            return html `
<button
class="${this.getItemClasses(isSelected, this.isInteractionBlocked())}"
role="option"
aria-selected="${isSelected}"
?disabled=${this.isInteractionBlocked()}
@mousedown=${(e) => e.preventDefault()}
@click=${() => this.handleSelect(item.value, item.label)}
>
${unsafeHTML(item.label)}
</button>
`;
        })}
</div>
`;
    }
    renderMap() {
        if (!this.showMap)
            return html ``;
        const coords = this.parseValue();
        return html `
<div
class="${this.getMapContainerClasses()}"
@pointerdown=${this.handleMapPointerDown}
@pointermove=${this.handleMapPointerMove}
@pointerup=${this.handleMapPointerUp}
@pointerleave=${this.handleMapPointerUp}
>
<div class="absolute inset-0 pointer-events-none flex items-center justify-center text-xs ml-text-faint">
${coords ? '' : this.msg.emptyValue}
</div>
<div
class="absolute w-4 h-4 rounded-full border ml-border-focus ml-primary-dim-bg -translate-x-1/2 -translate-y-1/2"
style="${this.getMapMarkerStyle()}"
></div>
</div>
`;
    }
    renderViewMode() {
        const label = this.getLabelForValue(this.value) || this.value;
        const display = label || (this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.emptyValue);
        return html `
${this.renderLabel()}
<div class="text-sm ml-text">${unsafeHTML(String(display))}</div>
${this.renderMap()}
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `<div class="${cn('w-full', this.cssClass)}">${this.renderViewMode()}</div>`;
        }
        const errorMessage = this.getErrorMessage();
        const hasError = Boolean(errorMessage);
        const effectivePlaceholder = this.placeholder || this.msg.placeholder;
        const query = this.getEffectiveQuery();
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div class="relative">
<input
id="${this.uid}-input"
type="text"
name="${this.name}"
class="${this.getInputClasses(hasError)}"
.placeholder=${effectivePlaceholder}
.value=${query}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
role="combobox"
aria-expanded="${this.isOpen}"
aria-autocomplete="list"
aria-labelledby="${this.uid}-label"
aria-invalid="${hasError}"
aria-required="${this.required}"
aria-describedby="${hasError ? `${this.uid}-error` : ''}"
@input=${this.handleInput}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
/>
${this.allowGeolocation ? html `
<button
class="absolute right-2 top-1/2 -translate-y-1/2 text-xs px-2 py-1 rounded-md border ml-border ml-text-muted ml-surface-bg hover:ml-surface-dim-bg"
?disabled=${this.isInteractionBlocked()}
aria-label="${this.msg.useLocation}"
@click=${this.handleGeolocation}
>
${this.hasSlot('Trigger') ? unsafeHTML(this.getSlotContent('Trigger')) : this.msg.useLocation}
</button>
` : html ``}
${this.renderSuggestions()}
</div>
${this.renderMap()}
${this.renderHelperOrError()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-map' })
], LocateMapPickerMolecule.prototype, "showMap", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-geolocation' })
], LocateMapPickerMolecule.prototype, "allowGeolocation", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], LocateMapPickerMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "isFocused", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "isDragging", void 0);
LocateMapPickerMolecule = __decorate([
    customElement('grouplocateposition--ml-locate-map-picker')
], LocateMapPickerMolecule);
export { LocateMapPickerMolecule };
