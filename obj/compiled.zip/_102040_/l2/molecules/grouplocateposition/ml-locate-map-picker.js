var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouplocateposition/ml-locate-map-picker.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// LOCATE MAP PICKER MOLECULE
// =============================================================================
// Skill Group: groupLocatePosition
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search location',
    noResults: 'No results found',
    loading: 'Loading...',
    emptyValue: '—',
    useLocation: 'Use current location',
    requiredError: 'Location is required',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let LocateMapPickerMolecule = class LocateMapPickerMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        this.uid = `locate-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Suggestions', 'Item', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.showMap = false;
        this.allowGeolocation = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.searchQuery = '';
        this.isOpen = false;
        this.isFocused = false;
        this.isDragging = false;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, _value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.updateSearchQueryFromValue();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    parseValue() {
        if (!this.value)
            return null;
        const [lat, lng] = this.value.split(',').map(Number);
        return isNaN(lat) || isNaN(lng) ? null : { lat, lng };
    }
    getSuggestions() {
        const suggestionsContainer = this.getSlot('Suggestions');
        if (!suggestionsContainer)
            return [];
        return Array.from(suggestionsContainer.querySelectorAll('Item')).map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
        }));
    }
    getLabelForValue(value) {
        if (!value)
            return null;
        const items = this.getSuggestions();
        const match = items.find(item => item.value === value);
        return match ? match.label : null;
    }
    updateSearchQueryFromValue() {
        if (!this.value) {
            this.searchQuery = '';
            return;
        }
        const label = this.getLabelForValue(this.value);
        this.searchQuery = label || this.value;
    }
    getEffectiveQuery() {
        return this.searchQuery || this.getLabelForValue(this.value) || this.value || '';
    }
    isInteractionBlocked() {
        return this.disabled || this.readonly || this.loading || !this.isEditing;
    }
    getInputClasses(hasError) {
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            hasError
                ? 'border-red-500 dark:border-red-400'
                : this.isFocused
                    ? 'border-sky-500 dark:border-sky-400'
                    : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled || this.loading ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'absolute z-10 mt-2 w-full rounded-lg border p-2',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
            'shadow-lg',
        ].join(' ');
    }
    getItemClasses(isSelected, isDisabled) {
        return [
            'w-full rounded-md px-3 py-2 text-sm transition text-left',
            isSelected
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border border-sky-500 dark:border-sky-400'
                : 'text-slate-900 dark:text-slate-100 border border-transparent',
            !isDisabled && !isSelected ? 'hover:bg-slate-50 dark:hover:bg-slate-700' : '',
            isDisabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getMapContainerClasses() {
        return [
            'relative w-full h-48 rounded-lg border overflow-hidden',
            'bg-slate-50 dark:bg-slate-900',
            'border-slate-200 dark:border-slate-700',
            this.isInteractionBlocked() ? 'opacity-50' : '',
        ].filter(Boolean).join(' ');
    }
    getMapMarkerStyle() {
        const coords = this.parseValue();
        if (!coords)
            return 'display:none;';
        const x = Math.min(100, Math.max(0, ((coords.lng + 180) / 360) * 100));
        const y = Math.min(100, Math.max(0, ((90 - coords.lat) / 180) * 100));
        return `left:${x}%; top:${y}%;`;
    }
    getErrorMessage() {
        if (!this.isEditing)
            return '';
        if (this.error)
            return this.error;
        if (this.required && !this.value)
            return this.msg.requiredError;
        return '';
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.isInteractionBlocked())
            return;
        const input = e.target;
        this.searchQuery = input.value;
        this.isOpen = true;
        this.dispatchEvent(new CustomEvent('search', {
            bubbles: true,
            composed: true,
            detail: { query: this.searchQuery }
        }));
    }
    handleFocus() {
        if (this.disabled)
            return;
        this.isFocused = true;
        this.isOpen = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.isFocused = false;
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleSelect(value, label) {
        if (this.isInteractionBlocked())
            return;
        this.value = value;
        this.searchQuery = label || value;
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleGeolocation() {
        if (this.isInteractionBlocked() || !this.allowGeolocation)
            return;
        if (!navigator.geolocation)
            return;
        this.loading = true;
        navigator.geolocation.getCurrentPosition((pos) => {
            const coords = `${pos.coords.latitude},${pos.coords.longitude}`;
            this.value = coords;
            this.searchQuery = coords;
            this.loading = false;
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value }
            }));
            this.dispatchEvent(new CustomEvent('search', {
                bubbles: true,
                composed: true,
                detail: { query: coords }
            }));
        }, () => {
            this.loading = false;
        });
    }
    handleMapPointerDown(e) {
        if (this.isInteractionBlocked() || !this.showMap)
            return;
        const target = e.currentTarget;
        if (!target)
            return;
        this.isDragging = true;
        target.setPointerCapture(e.pointerId);
        this.updateValueFromPointer(e);
    }
    handleMapPointerMove(e) {
        if (!this.isDragging)
            return;
        this.updateValueFromPointer(e);
    }
    handleMapPointerUp(e) {
        if (!this.isDragging)
            return;
        this.isDragging = false;
        const target = e.currentTarget;
        if (target)
            target.releasePointerCapture(e.pointerId);
    }
    updateValueFromPointer(e) {
        const container = e.currentTarget;
        const rect = container.getBoundingClientRect();
        const x = Math.min(rect.width, Math.max(0, e.clientX - rect.left));
        const y = Math.min(rect.height, Math.max(0, e.clientY - rect.top));
        const lng = (x / rect.width) * 360 - 180;
        const lat = 90 - (y / rect.height) * 180;
        const value = `${lat.toFixed(6)},${lng.toFixed(6)}`;
        this.value = value;
        this.searchQuery = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
        this.dispatchEvent(new CustomEvent('search', {
            bubbles: true,
            composed: true,
            detail: { query: value }
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<label id="${this.uid}-label" class="block mb-2 text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    renderHelperOrError() {
        const errorMessage = this.getErrorMessage();
        if (!this.isEditing)
            return html ``;
        if (errorMessage) {
            return html `<p id="${this.uid}-error" class="mt-1 text-xs text-red-600 dark:text-red-400">${unsafeHTML(String(errorMessage))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="mt-1 text-xs text-slate-500 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderSuggestions() {
        if (!this.isEditing || !this.isOpen)
            return html ``;
        const items = this.getSuggestions();
        if (this.loading) {
            return html `<div class="${this.getPanelClasses()}" role="listbox">${this.msg.loading}</div>`;
        }
        if (!items.length) {
            const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noResults;
            return html `<div class="${this.getPanelClasses()}" role="listbox"><div class="px-3 py-2 text-sm text-slate-500 dark:text-slate-400">${unsafeHTML(emptyContent)}</div></div>`;
        }
        return html `
<div class="${this.getPanelClasses()}" role="listbox">
${items.map(item => {
            const isSelected = item.value === this.value;
            return html `
<button
class="${this.getItemClasses(isSelected, this.isInteractionBlocked())}"
role="option"
aria-selected="${isSelected}"
?disabled=${this.isInteractionBlocked()}
@mousedown=${(e) => e.preventDefault()}
@click=${() => this.handleSelect(item.value, item.label)}
>
${unsafeHTML(item.label)}
</button>
`;
        })}
</div>
`;
    }
    renderMap() {
        if (!this.showMap)
            return html ``;
        const coords = this.parseValue();
        return html `
<div
class="${this.getMapContainerClasses()}"
@pointerdown=${this.handleMapPointerDown}
@pointermove=${this.handleMapPointerMove}
@pointerup=${this.handleMapPointerUp}
@pointerleave=${this.handleMapPointerUp}
>
<div class="absolute inset-0 pointer-events-none flex items-center justify-center text-xs text-slate-400 dark:text-slate-500">
${coords ? '' : this.msg.emptyValue}
</div>
<div
class="absolute w-4 h-4 rounded-full border border-sky-500 dark:border-sky-400 bg-sky-50 dark:bg-sky-900/40 -translate-x-1/2 -translate-y-1/2"
style="${this.getMapMarkerStyle()}"
></div>
</div>
`;
    }
    renderViewMode() {
        const label = this.getLabelForValue(this.value) || this.value;
        const display = label || (this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.emptyValue);
        return html `
${this.renderLabel()}
<div class="text-sm text-slate-900 dark:text-slate-100">${unsafeHTML(String(display))}</div>
${this.renderMap()}
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `<div class="w-full">${this.renderViewMode()}</div>`;
        }
        const errorMessage = this.getErrorMessage();
        const hasError = Boolean(errorMessage);
        const effectivePlaceholder = this.placeholder || this.msg.placeholder;
        const query = this.getEffectiveQuery();
        return html `
<div class="w-full">
${this.renderLabel()}
<div class="relative">
<input
id="${this.uid}-input"
type="text"
name="${this.name}"
class="${this.getInputClasses(hasError)}"
.placeholder=${effectivePlaceholder}
.value=${query}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
role="combobox"
aria-expanded="${this.isOpen}"
aria-autocomplete="list"
aria-labelledby="${this.uid}-label"
aria-invalid="${hasError}"
aria-required="${this.required}"
aria-describedby="${hasError ? `${this.uid}-error` : ''}"
@input=${this.handleInput}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
/>
${this.allowGeolocation ? html `
<button
class="absolute right-2 top-1/2 -translate-y-1/2 text-xs px-2 py-1 rounded-md border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 bg-white dark:bg-slate-800 hover:bg-slate-50 dark:hover:bg-slate-700"
?disabled=${this.isInteractionBlocked()}
aria-label="${this.msg.useLocation}"
@click=${this.handleGeolocation}
>
${this.hasSlot('Trigger') ? unsafeHTML(this.getSlotContent('Trigger')) : this.msg.useLocation}
</button>
` : html ``}
${this.renderSuggestions()}
</div>
${this.renderMap()}
${this.renderHelperOrError()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], LocateMapPickerMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-map' })
], LocateMapPickerMolecule.prototype, "showMap", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-geolocation' })
], LocateMapPickerMolecule.prototype, "allowGeolocation", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], LocateMapPickerMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], LocateMapPickerMolecule.prototype, "loading", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "isFocused", void 0);
__decorate([
    state()
], LocateMapPickerMolecule.prototype, "isDragging", void 0);
LocateMapPickerMolecule = __decorate([
    customElement('grouplocateposition--ml-locate-map-picker')
], LocateMapPickerMolecule);
export { LocateMapPickerMolecule };
