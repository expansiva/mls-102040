var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/grouplocateposition/ml-address-autocomplete.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ADDRESS AUTOCOMPLETE MOLECULE
// =============================================================================
// Skill Group: groupLocatePosition
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search address',
    empty: 'No results',
    loading: 'Loading...',
    useLocation: 'Use current location',
    noValue: '—',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let AddressAutocompleteMolecule = class AddressAutocompleteMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`grouplocateposition--ml-address-autocomplete .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-address-autocomplete .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-address-autocomplete .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-address-autocomplete .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
grouplocateposition--ml-address-autocomplete .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-address-autocomplete .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-address-autocomplete .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
grouplocateposition--ml-address-autocomplete .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
grouplocateposition--ml-address-autocomplete .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouplocateposition--ml-address-autocomplete .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
grouplocateposition--ml-address-autocomplete .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
grouplocateposition--ml-address-autocomplete .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
grouplocateposition--ml-address-autocomplete .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
grouplocateposition--ml-address-autocomplete .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
grouplocateposition--ml-address-autocomplete .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
grouplocateposition--ml-address-autocomplete .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
grouplocateposition--ml-address-autocomplete .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
grouplocateposition--ml-address-autocomplete .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        this.inputId = `addr-${Math.random().toString(36).slice(2)}`;
        this.labelId = `${this.inputId}-label`;
        this.helperId = `${this.inputId}-helper`;
        this.errorId = `${this.inputId}-error`;
        this.debounceTimer = null;
        this.mutationObserver = null;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Suggestions', 'Item', 'Empty'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.showMap = false;
        this.allowGeolocation = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.searchQuery = '';
        this.isOpen = false;
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    firstUpdated() {
        this.mutationObserver = new MutationObserver(() => {
            this.syncSearchQueryFromValue();
            this.requestUpdate();
        });
        this.mutationObserver.observe(this, { childList: true, subtree: true });
        this.syncSearchQueryFromValue();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.mutationObserver) {
            this.mutationObserver.disconnect();
            this.mutationObserver = null;
        }
    }
    // ==========================================================================
    // STATE CHANGE HANDLER
    // ==========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.syncSearchQueryFromValue(value);
        }
        this.requestUpdate();
    }
    // ==========================================================================
    // PARSING & SUGGESTIONS
    // ==========================================================================
    parseValue() {
        if (!this.value)
            return null;
        const [lat, lng] = this.value.split(',').map(Number);
        return isNaN(lat) || isNaN(lng) ? null : { lat, lng };
    }
    getSuggestions() {
        const suggestionsContainer = this.getSlot('Suggestions');
        if (!suggestionsContainer)
            return [];
        return Array.from(suggestionsContainer.querySelectorAll('Item')).map((el) => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
        }));
    }
    findLabelForValue(val) {
        if (!val)
            return '';
        const items = this.getSuggestions();
        const match = items.find((item) => item.value === val);
        return match ? match.label : val;
    }
    syncSearchQueryFromValue(overrideValue) {
        const currentValue = overrideValue !== undefined ? overrideValue : this.value;
        const label = this.findLabelForValue(currentValue);
        this.searchQuery = label;
    }
    // ==========================================================================
    // EVENTS
    // ==========================================================================
    emitChange(value) {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value },
        }));
    }
    emitSearch(query) {
        this.dispatchEvent(new CustomEvent('search', {
            bubbles: true,
            composed: true,
            detail: { query },
        }));
    }
    emitBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    emitFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    // ==========================================================================
    // HANDLERS
    // ==========================================================================
    handleInput(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        this.searchQuery = input.value;
        this.isOpen = true;
        if (this.searchQuery.trim() === '') {
            this.value = null;
            this.emitChange(null);
            this.emitSearch('');
            return;
        }
        if (this.debounceTimer)
            window.clearTimeout(this.debounceTimer);
        this.debounceTimer = window.setTimeout(() => {
            this.emitSearch(this.searchQuery.trim());
        }, 350);
    }
    handleItemSelect(item) {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.value = item.value;
        this.searchQuery = item.label;
        this.isOpen = false;
        this.emitChange(this.value);
    }
    handleInputFocus() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = true;
        this.emitFocus();
    }
    handleInputBlur() {
        window.setTimeout(() => {
            this.isOpen = false;
            this.requestUpdate();
        }, 150);
        this.emitBlur();
    }
    handleGeoLocation() {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (!navigator.geolocation)
            return;
        navigator.geolocation.getCurrentPosition((pos) => {
            const coords = `${pos.coords.latitude},${pos.coords.longitude}`;
            this.value = coords;
            this.searchQuery = coords;
            this.emitChange(coords);
            this.emitSearch(coords);
        });
    }
    // ==========================================================================
    // RENDER HELPERS
    // ==========================================================================
    getInputClasses(isError) {
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'ml-surface-bg',
            'ml-text',
            'placeholder:ml-text-faint',
            isError
                ? 'ml-border-error'
                : 'ml-border',
            '',
            this.disabled || this.loading ? 'ml-disabled' : '',
            this.readonly ? 'ml-surface-dim-bg' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSuggestionPanelClasses() {
        return [
            'mt-2 max-h-56 overflow-auto rounded-lg border p-2',
            'ml-surface-bg',
            'ml-border',
            this.loading ? 'opacity-50 pointer-events-none' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getSuggestionItemClasses(isSelected) {
        return [
            'w-full rounded-md px-3 py-2 text-sm transition cursor-pointer',
            isSelected
                ? 'ml-primary-dim-bg ml-primary-text border ml-border-focus'
                : 'ml-text border border-transparent',
            !isSelected ? 'hover:ml-surface-dim-bg' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return nothing;
        return html `<label id=${this.labelId} class="${cn('mb-1 block text-sm ml-text-muted', this.getSlotClass('Label'))}">
 ${unsafeHTML(this.getSlotContent('Label'))}
 </label>`;
    }
    renderHelperOrError(isError) {
        if (!this.isEditing)
            return nothing;
        if (isError) {
            return html `<p id=${this.errorId} class="mt-1 text-xs ml-error-text">
 ${unsafeHTML(this.error)}
 </p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id=${this.helperId} class="${cn('mt-1 text-xs ml-text-muted', this.getSlotClass('Helper'))}">
 ${unsafeHTML(this.getSlotContent('Helper'))}
 </p>`;
        }
        return nothing;
    }
    renderEmptyState() {
        const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
        return html `<div class="px-3 py-2 text-sm ml-text-muted">${unsafeHTML(emptyContent)}</div>`;
    }
    renderSuggestionsPanel() {
        if (!this.isOpen || !this.isEditing)
            return nothing;
        const items = this.getSuggestions();
        return html `
 <div class=${this.getSuggestionPanelClasses()} role="listbox">
 ${this.loading
            ? html `<div class="px-3 py-2 text-sm ml-text-muted">${this.msg.loading}</div>`
            : items.length === 0
                ? this.renderEmptyState()
                : items.map((item) => {
                    const selected = item.value === this.value;
                    return html `
 <button
 type="button"
 class=${this.getSuggestionItemClasses(selected)}
 role="option"
 aria-selected=${selected ? 'true' : 'false'}
 @click=${() => this.handleItemSelect(item)}
 >
 ${unsafeHTML(item.label)}
 </button>
 `;
                })}
 </div>
 `;
    }
    renderGeolocationButton() {
        if (!this.allowGeolocation || !this.isEditing)
            return nothing;
        const triggerContent = this.hasSlot('Trigger')
            ? unsafeHTML(this.getSlotContent('Trigger'))
            : html `<span class="text-sm ml-text-muted">${this.msg.useLocation}</span>`;
        return html `
 <button
 type="button"
 class="ml-2 rounded-lg border ml-border ml-surface-bg px-3 py-2 text-sm ml-text hover:ml-surface-dim-bg"
 aria-label=${this.msg.useLocation}
 ?disabled=${this.disabled || this.readonly || this.loading}
 @click=${this.handleGeoLocation}
 >
 ${triggerContent}
 </button>
 `;
    }
    renderMapPreview() {
        if (!this.showMap)
            return nothing;
        const coords = this.parseValue();
        if (!coords)
            return nothing;
        return html `
 <div class="mt-3 rounded-lg border ml-border ml-surface-dim-bg p-3 text-xs ml-text-muted">
 <div class="font-semibold ml-text">${coords.lat}, ${coords.lng}</div>
 <div class="mt-1 ml-text-muted">Map preview</div>
 </div>
 `;
    }
    renderViewMode() {
        const label = this.findLabelForValue(this.value);
        const content = label || (this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noValue);
        return html `
 <div class="${cn('w-full', this.cssClass)}">
 ${this.renderLabel()}
 <div class="rounded-lg border ml-border ml-surface-bg px-3 py-2 text-sm ml-text">
 ${unsafeHTML(content)}
 </div>
 ${this.renderMapPreview()}
 </div>
 `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const isError = Boolean(this.error) || (this.required && !this.value);
        const placeholder = this.placeholder || this.msg.placeholder;
        return html `
 <div class="${cn('w-full', this.cssClass)}">
 ${this.renderLabel()}
 <div class="flex items-center">
 <input
 id=${this.inputId}
 class=${this.getInputClasses(isError)}
 type="text"
 .value=${this.searchQuery}
 placeholder=${placeholder}
 name=${this.name}
 role="combobox"
 aria-expanded=${this.isOpen ? 'true' : 'false'}
 aria-autocomplete="list"
 aria-labelledby=${this.hasSlot('Label') ? this.labelId : nothing}
 aria-describedby=${isError ? this.errorId : this.hasSlot('Helper') ? this.helperId : nothing}
 aria-invalid=${isError ? 'true' : 'false'}
 aria-required=${this.required ? 'true' : 'false'}
 ?disabled=${this.disabled || this.loading}
 ?readonly=${this.readonly}
 @input=${this.handleInput}
 @focus=${this.handleInputFocus}
 @blur=${this.handleInputBlur}
 
 @change=${(e) => e.stopPropagation()}
/>
 ${this.renderGeolocationButton()}
 </div>
 ${this.renderSuggestionsPanel()}
 ${this.renderHelperOrError(isError)}
 ${this.renderMapPreview()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], AddressAutocompleteMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], AddressAutocompleteMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], AddressAutocompleteMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], AddressAutocompleteMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-map' })
], AddressAutocompleteMolecule.prototype, "showMap", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-geolocation' })
], AddressAutocompleteMolecule.prototype, "allowGeolocation", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], AddressAutocompleteMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AddressAutocompleteMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AddressAutocompleteMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AddressAutocompleteMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], AddressAutocompleteMolecule.prototype, "loading", void 0);
__decorate([
    state()
], AddressAutocompleteMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], AddressAutocompleteMolecule.prototype, "isOpen", void 0);
AddressAutocompleteMolecule = __decorate([
    customElement('grouplocateposition--ml-address-autocomplete')
], AddressAutocompleteMolecule);
export { AddressAutocompleteMolecule };
