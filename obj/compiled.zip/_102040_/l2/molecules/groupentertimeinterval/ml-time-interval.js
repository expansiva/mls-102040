/// <mls fileReference="_102040_/l2/molecules/groupentertimeinterval/ml-time-interval.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TIME INTERVAL MOLECULE
// =============================================================================
// Skill Group: groupEnterTimeInterval
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholderStart: 'Start',
    placeholderEnd: 'End',
    noValue: '—',
    nextDay: '(+1)',
    am: 'AM',
    pm: 'PM',
    loading: 'Loading...',
    selectHour: 'Select hour',
    selectMinute: 'Select minute',
    selectSecond: 'Select second',
    selectPeriod: 'Select AM/PM',
};
const messages = {
    en: message_en,
    pt: {
        placeholderStart: 'Início',
        placeholderEnd: 'Fim',
        noValue: '—',
        nextDay: '(+1)',
        am: 'AM',
        pm: 'PM',
        loading: 'Carregando...',
        selectHour: 'Selecionar hora',
        selectMinute: 'Selecionar minuto',
        selectSecond: 'Selecionar segundo',
        selectPeriod: 'Selecionar AM/PM',
    },
};
/// **collab_i18n_end**
let MlTimeIntervalMolecule = class MlTimeIntervalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertimeinterval--ml-time-interval .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupentertimeinterval--ml-time-interval .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertimeinterval--ml-time-interval .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertimeinterval--ml-time-interval .ml-interval-field {
  background-color: var(--surface-bg, #ffffff);
  color: var(--text-strong, #1c1b1f);
  border-color: var(--border-default, #e2e8f0);
  transition: border-color var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
}
groupentertimeinterval--ml-time-interval .ml-interval-field:hover {
  background-color: var(--surface-alt-bg, #f5f5f5);
}
groupentertimeinterval--ml-time-interval .ml-interval-field-active {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupentertimeinterval--ml-time-interval .ml-interval-field-complete {
  border-color: var(--ml-success, #22c55e);
}
groupentertimeinterval--ml-time-interval .ml-interval-picker {
  background-color: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
  box-shadow: var(--shadow-small, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupentertimeinterval--ml-time-interval .ml-interval-option {
  color: var(--text-strong, #1c1b1f);
}
groupentertimeinterval--ml-time-interval .ml-interval-option:hover {
  background-color: var(--surface-alt-bg, #f5f5f5);
}
groupentertimeinterval--ml-time-interval .ml-interval-option-selected {
  background-color: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
  font-weight: var(--font-weight-bold, 500);
}
groupentertimeinterval--ml-time-interval .ml-interval-option-disabled {
  color: var(--text-muted-disabled, #79747e);
  cursor: not-allowed;
}
groupentertimeinterval--ml-time-interval .ml-interval-overnight {
  color: var(--ml-warning, #f59e0b);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // ===========================================================================
        // PROPERTIES — Data
        // ===========================================================================
        this.startTime = null;
        this.endTime = null;
        this.error = '';
        this.name = '';
        // ===========================================================================
        // PROPERTIES — Configuration
        // ===========================================================================
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.allowOvernight = false;
        this.allowSameTime = false;
        // ===========================================================================
        // PROPERTIES — States
        // ===========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.activeField = null;
        this.startHour = 0;
        this.startMinute = 0;
        this.startSecond = 0;
        this.startPeriod = 'AM';
        this.endHour = 0;
        this.endMinute = 0;
        this.endSecond = 0;
        this.endPeriod = 'AM';
        // ===========================================================================
        // EVENT HANDLERS
        // ===========================================================================
        this.handleDocumentClick = (e) => {
            const path = e.composedPath();
            if (!path.includes(this)) {
                this.activeField = null;
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.syncFromStartTime();
        this.syncFromEndTime();
        document.addEventListener('click', this.handleDocumentClick);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.handleDocumentClick);
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const startAttr = this.getAttribute('start-time');
        const endAttr = this.getAttribute('end-time');
        if (startAttr === `{{${key}}}`) {
            this.startTime = value;
            this.syncFromStartTime();
        }
        if (endAttr === `{{${key}}}`) {
            this.endTime = value;
            this.syncFromEndTime();
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // SYNC HELPERS
    // ===========================================================================
    syncFromStartTime() {
        if (this.startTime) {
            const parsed = this.parseTime(this.startTime);
            if (this.hour12) {
                this.startPeriod = parsed.hour >= 12 ? 'PM' : 'AM';
                this.startHour = parsed.hour % 12 || 12;
            }
            else {
                this.startHour = parsed.hour;
            }
            this.startMinute = parsed.minute;
            this.startSecond = parsed.second;
        }
    }
    syncFromEndTime() {
        if (this.endTime) {
            const parsed = this.parseTime(this.endTime);
            if (this.hour12) {
                this.endPeriod = parsed.hour >= 12 ? 'PM' : 'AM';
                this.endHour = parsed.hour % 12 || 12;
            }
            else {
                this.endHour = parsed.hour;
            }
            this.endMinute = parsed.minute;
            this.endSecond = parsed.second;
        }
    }
    // ===========================================================================
    // TIME UTILITIES
    // ===========================================================================
    parseTime(time) {
        const parts = time.split(':').map(Number);
        return {
            hour: parts[0] || 0,
            minute: parts[1] || 0,
            second: parts[2] || 0,
        };
    }
    toMinutes(time) {
        const parsed = this.parseTime(time);
        return parsed.hour * 60 + parsed.minute;
    }
    formatTime24(hour, minute, second) {
        const h = String(hour).padStart(2, '0');
        const m = String(minute).padStart(2, '0');
        if (this.showSeconds) {
            const s = String(second).padStart(2, '0');
            return `${h}:${m}:${s}`;
        }
        return `${h}:${m}`;
    }
    formatTimeDisplay(time) {
        if (!time)
            return this.msg.noValue;
        const parsed = this.parseTime(time);
        if (this.hour12) {
            const period = parsed.hour >= 12 ? this.msg.pm : this.msg.am;
            const displayHour = parsed.hour % 12 || 12;
            const h = String(displayHour).padStart(2, '0');
            const m = String(parsed.minute).padStart(2, '0');
            if (this.showSeconds) {
                const s = String(parsed.second).padStart(2, '0');
                return `${h}:${m}:${s} ${period}`;
            }
            return `${h}:${m} ${period}`;
        }
        return time;
    }
    isOvernight() {
        if (!this.startTime || !this.endTime || !this.allowOvernight)
            return false;
        return this.toMinutes(this.endTime) < this.toMinutes(this.startTime);
    }
    calcDuration() {
        if (!this.startTime || !this.endTime)
            return 0;
        const startMins = this.toMinutes(this.startTime);
        const endMins = this.toMinutes(this.endTime);
        if (this.isOvernight()) {
            return (24 * 60) - startMins + endMins;
        }
        return endMins - startMins;
    }
    convert12To24(hour, period) {
        if (period === 'AM') {
            return hour === 12 ? 0 : hour;
        }
        return hour === 12 ? 12 : hour + 12;
    }
    isTimeDisabled(hour, minute, field) {
        const time24 = this.formatTime24(hour, minute, 0);
        const timeMins = hour * 60 + minute;
        if (this.minTime) {
            const minMins = this.toMinutes(this.minTime);
            if (timeMins < minMins)
                return true;
        }
        if (this.maxTime) {
            const maxMins = this.toMinutes(this.maxTime);
            if (timeMins > maxMins)
                return true;
        }
        if (field === 'end' && this.startTime) {
            const startMins = this.toMinutes(this.startTime);
            if (!this.allowSameTime && timeMins === startMins)
                return true;
            if (!this.allowOvernight && timeMins < startMins)
                return true;
            let duration;
            if (this.allowOvernight && timeMins < startMins) {
                duration = (24 * 60) - startMins + timeMins;
            }
            else {
                duration = timeMins - startMins;
            }
            if (this.minDurationMinutes > 0 && duration < this.minDurationMinutes)
                return true;
            if (this.maxDurationMinutes > 0 && duration > this.maxDurationMinutes)
                return true;
        }
        return false;
    }
    handleFieldClick(field) {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.activeField = this.activeField === field ? null : field;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleHourSelect(hour, field) {
        if (field === 'start') {
            this.startHour = hour;
            this.updateStartTime();
        }
        else {
            this.endHour = hour;
            this.updateEndTime();
        }
    }
    handleMinuteSelect(minute, field) {
        if (field === 'start') {
            this.startMinute = minute;
            this.updateStartTime();
        }
        else {
            this.endMinute = minute;
            this.updateEndTime();
        }
    }
    handleSecondSelect(second, field) {
        if (field === 'start') {
            this.startSecond = second;
            this.updateStartTime();
        }
        else {
            this.endSecond = second;
            this.updateEndTime();
        }
    }
    handlePeriodSelect(period, field) {
        if (field === 'start') {
            this.startPeriod = period;
            this.updateStartTime();
        }
        else {
            this.endPeriod = period;
            this.updateEndTime();
        }
    }
    updateStartTime() {
        let hour24 = this.startHour;
        if (this.hour12) {
            hour24 = this.convert12To24(this.startHour, this.startPeriod);
        }
        this.startTime = this.formatTime24(hour24, this.startMinute, this.startSecond);
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startTime },
        }));
        this.emitChangeIfComplete();
    }
    updateEndTime() {
        let hour24 = this.endHour;
        if (this.hour12) {
            hour24 = this.convert12To24(this.endHour, this.endPeriod);
        }
        this.endTime = this.formatTime24(hour24, this.endMinute, this.endSecond);
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endTime },
        }));
        this.emitChangeIfComplete();
    }
    emitChangeIfComplete() {
        if (this.startTime && this.endTime) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { startTime: this.startTime, endTime: this.endTime },
            }));
        }
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getContainerClasses() {
        return [
            'w-full',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getFieldClasses(field) {
        const isActive = this.activeField === field;
        const hasError = !!this.error;
        const bothFilled = !!this.startTime && !!this.endTime;
        return [
            'flex-1 min-w-0 px-3 py-2 rounded-lg border text-sm transition-all ml-interval-field',
            hasError
                ? 'ml-input-container-error'
                : isActive
                    ? 'ml-interval-field-active'
                    : bothFilled
                        ? 'ml-interval-field-complete'
                        : '',
            !this.disabled && !this.readonly ? 'cursor-pointer' : '',
            this.readonly ? 'cursor-default' : '',
            this.disabled ? 'cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    getPickerClasses() {
        return 'absolute z-50 mt-1 p-3 rounded-lg shadow-lg border ml-interval-picker';
    }
    getColumnClasses() {
        return 'flex flex-col gap-1 max-h-48 overflow-y-auto px-1';
    }
    getOptionClasses(isSelected, isDisabled) {
        return [
            'px-3 py-1.5 rounded text-sm text-center transition-colors',
            isDisabled
                ? 'ml-interval-option-disabled'
                : isSelected
                    ? 'ml-interval-option-selected'
                    : 'ml-interval-option cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
    renderLoading() {
        return html `
      <div class="${cn('flex items-center justify-center py-4 ml-text-muted', this.cssClass)}">
        <svg class="animate-spin h-5 w-5 mr-2" viewBox="0 0 24 24" fill="none">
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
        <span>${this.msg.loading}</span>
      </div>
    `;
    }
    renderViewMode() {
        const label = this.getSlotContent('Label');
        let displayText;
        if (!this.startTime && !this.endTime) {
            displayText = this.msg.noValue;
        }
        else if (this.startTime && !this.endTime) {
            displayText = `${this.formatTimeDisplay(this.startTime)} – ${this.msg.noValue}`;
        }
        else {
            const overnight = this.isOvernight();
            displayText = `${this.formatTimeDisplay(this.startTime)} – ${this.formatTimeDisplay(this.endTime)}${overnight ? ' ' + this.msg.nextDay : ''}`;
        }
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${label ? html `<div class="${cn('text-sm font-medium mb-1 ml-label', this.getSlotClass('Label'))}">${unsafeHTML(label)}</div>` : html ``}
        <div class="ml-text">${displayText}</div>
      </div>
    `;
    }
    renderEditMode() {
        const label = this.getSlotContent('Label');
        const labelStart = this.getSlotContent('LabelStart');
        const labelEnd = this.getSlotContent('LabelEnd');
        const helper = this.getSlotContent('Helper');
        const overnight = this.isOvernight();
        return html `
      <div class="${cn(this.getContainerClasses(), this.cssClass)}" @blur=${this.handleBlur}>
        ${label ? html `<div class="${cn('text-sm font-medium mb-2 ml-label', this.getSlotClass('Label'))}">${unsafeHTML(label)}</div>` : html ``}

        <div class="flex items-center gap-3">
          <!-- Start Time Field -->
          <div class="flex-1 min-w-0 relative">
            ${labelStart ? html `<div class="${cn('text-xs mb-1 ml-text-muted', this.getSlotClass('LabelStart'))}">${unsafeHTML(labelStart)}</div>` : html ``}
            <div
              class="${this.getFieldClasses('start')}"
              @click=${() => this.handleFieldClick('start')}
              role="button"
              tabindex=${this.disabled ? -1 : 0}
              aria-label=${this.msg.placeholderStart}
              aria-invalid=${this.error ? 'true' : 'false'}
              aria-required=${this.required ? 'true' : 'false'}
            >
              ${this.startTime
            ? this.formatTimeDisplay(this.startTime)
            : html `<span class="ml-text-muted">${this.msg.placeholderStart}</span>`}
            </div>
            ${this.activeField === 'start' ? this.renderPicker('start') : html ``}
          </div>

          <!-- Delimiter -->
          <div class="ml-text-muted text-lg font-light">–</div>

          <!-- End Time Field -->
          <div class="flex-1 min-w-0 relative">
            ${labelEnd ? html `<div class="${cn('text-xs mb-1 ml-text-muted', this.getSlotClass('LabelEnd'))}">${unsafeHTML(labelEnd)}</div>` : html ``}
            <div
              class="${this.getFieldClasses('end')}"
              @click=${() => this.handleFieldClick('end')}
              role="button"
              tabindex=${this.disabled ? -1 : 0}
              aria-label=${this.msg.placeholderEnd}
              aria-invalid=${this.error ? 'true' : 'false'}
              aria-required=${this.required ? 'true' : 'false'}
            >
              ${this.endTime
            ? html `${this.formatTimeDisplay(this.endTime)}${overnight ? html `<span class="ml-1 text-xs ml-interval-overnight">${this.msg.nextDay}</span>` : html ``}`
            : html `<span class="ml-text-muted">${this.msg.placeholderEnd}</span>`}
            </div>
            ${this.activeField === 'end' ? this.renderPicker('end') : html ``}
          </div>
        </div>

        ${this.renderFeedback(helper)}
      </div>
    `;
    }
    renderPicker(field) {
        const currentHour = field === 'start' ? this.startHour : this.endHour;
        const currentMinute = field === 'start' ? this.startMinute : this.endMinute;
        const currentSecond = field === 'start' ? this.startSecond : this.endSecond;
        const currentPeriod = field === 'start' ? this.startPeriod : this.endPeriod;
        const hours = this.hour12
            ? Array.from({ length: 12 }, (_, i) => i === 0 ? 12 : i)
            : Array.from({ length: 24 }, (_, i) => i);
        const minutes = [];
        for (let i = 0; i < 60; i += this.minuteStep) {
            minutes.push(i);
        }
        const seconds = Array.from({ length: 60 }, (_, i) => i);
        return html `
      <div class=${this.getPickerClasses()} role="dialog" aria-modal="true">
        <div class="flex gap-2">
          <!-- Hours -->
          <div class=${this.getColumnClasses()} aria-label=${this.msg.selectHour}>
            ${hours.map(h => {
            const hour24 = this.hour12 ? this.convert12To24(h, currentPeriod) : h;
            const disabled = this.isTimeDisabled(hour24, currentMinute, field);
            const selected = h === currentHour;
            return html `
                <div
                  class=${this.getOptionClasses(selected, disabled)}
                  @click=${() => !disabled && this.handleHourSelect(h, field)}
                  role="option"
                  aria-selected=${selected ? 'true' : 'false'}
                  aria-disabled=${disabled ? 'true' : 'false'}
                >
                  ${String(h).padStart(2, '0')}
                </div>
              `;
        })}
          </div>

          <!-- Minutes -->
          <div class=${this.getColumnClasses()} aria-label=${this.msg.selectMinute}>
            ${minutes.map(m => {
            const hour24 = this.hour12 ? this.convert12To24(currentHour, currentPeriod) : currentHour;
            const disabled = this.isTimeDisabled(hour24, m, field);
            const selected = m === currentMinute;
            return html `
                <div
                  class=${this.getOptionClasses(selected, disabled)}
                  @click=${() => !disabled && this.handleMinuteSelect(m, field)}
                  role="option"
                  aria-selected=${selected ? 'true' : 'false'}
                  aria-disabled=${disabled ? 'true' : 'false'}
                >
                  ${String(m).padStart(2, '0')}
                </div>
              `;
        })}
          </div>

          <!-- Seconds (if enabled) -->
          ${this.showSeconds ? html `
            <div class=${this.getColumnClasses()} aria-label=${this.msg.selectSecond}>
              ${seconds.map(s => {
            const selected = s === currentSecond;
            return html `
                  <div
                    class=${this.getOptionClasses(selected, false)}
                    @click=${() => this.handleSecondSelect(s, field)}
                    role="option"
                    aria-selected=${selected ? 'true' : 'false'}
                  >
                    ${String(s).padStart(2, '0')}
                  </div>
                `;
        })}
            </div>
          ` : html ``}

          <!-- AM/PM (if 12-hour) -->
          ${this.hour12 ? html `
            <div class="flex flex-col gap-1 px-1" aria-label=${this.msg.selectPeriod}>
              ${['AM', 'PM'].map(p => {
            const selected = p === currentPeriod;
            return html `
                  <div
                    class=${this.getOptionClasses(selected, false)}
                    @click=${() => this.handlePeriodSelect(p, field)}
                    role="option"
                    aria-selected=${selected ? 'true' : 'false'}
                  >
                    ${p === 'AM' ? this.msg.am : this.msg.pm}
                  </div>
                `;
        })}
            </div>
          ` : html ``}
        </div>
      </div>
    `;
    }
    renderFeedback(helper) {
        if (this.error) {
            return html `<p class="mt-1 text-xs ml-error-text">${unsafeHTML(this.error)}</p>`;
        }
        if (helper) {
            return html `<p class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(helper)}</p>`;
        }
        return html ``;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'start-time' })
], MlTimeIntervalMolecule.prototype, "startTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'end-time' })
], MlTimeIntervalMolecule.prototype, "endTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], MlTimeIntervalMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], MlTimeIntervalMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], MlTimeIntervalMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], MlTimeIntervalMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], MlTimeIntervalMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], MlTimeIntervalMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-overnight' })
], MlTimeIntervalMolecule.prototype, "allowOvernight", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-time' })
], MlTimeIntervalMolecule.prototype, "allowSameTime", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlTimeIntervalMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "activeField", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "startHour", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "startMinute", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "startSecond", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "startPeriod", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "endHour", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "endMinute", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "endSecond", void 0);
__decorate([
    state()
], MlTimeIntervalMolecule.prototype, "endPeriod", void 0);
MlTimeIntervalMolecule = __decorate([
    customElement('groupentertimeinterval--ml-time-interval')
], MlTimeIntervalMolecule);
export { MlTimeIntervalMolecule };
