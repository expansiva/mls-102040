var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-slider.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// TIME INTERVAL SLIDER MOLECULE
// =============================================================================
// Skill Group: enter + time-interval
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    empty: '—',
    nextDay: '(+1)',
    loading: 'Loading...',
    labelStart: 'Start',
    labelEnd: 'End',
};
const messages = {
    en: message_en,
    pt: {
        empty: '—',
        nextDay: '(+1)',
        loading: 'Carregando...',
        labelStart: 'Início',
        labelEnd: 'Fim',
    },
};
/// **collab_i18n_end**
let TimeIntervalSliderMolecule = class TimeIntervalSliderMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertimeinterval--ml-time-interval-slider .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertimeinterval--ml-time-interval-slider .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-slider .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-slider .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-slider .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertimeinterval--ml-time-interval-slider .ml-interval-container {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  transition: border-color var(--ml-transition, 200ms ease);
}
groupentertimeinterval--ml-time-interval-slider .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertimeinterval--ml-time-interval-slider .ml-slider-display {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-slider .ml-input-active {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertimeinterval--ml-time-interval-slider .ml-slider-track {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupentertimeinterval--ml-time-interval-slider .ml-slider-highlight {
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 30%, transparent);
}
groupentertimeinterval--ml-time-interval-slider .ml-slider-thumb::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--ml-primary, #3b82f6);
  cursor: pointer;
}
groupentertimeinterval--ml-time-interval-slider .ml-slider-thumb::-moz-range-thumb {
  width: 16px;
  height: 16px;
  border-radius: 50%;
  background: var(--ml-primary, #3b82f6);
  cursor: pointer;
  border: none;
}
groupentertimeinterval--ml-time-interval-slider .ml-input-focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertimeinterval--ml-time-interval-slider .ml-overnight-badge {
  color: var(--ml-primary, #3b82f6);
}
`);
        this.msg = messages.en;
        this.baseId = `ti-${Math.random().toString(36).slice(2, 9)}`;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // =========================================================================
        // PROPERTIES — Data
        // =========================================================================
        this.startTime = null;
        this.endTime = null;
        this.error = '';
        this.name = '';
        // =========================================================================
        // PROPERTIES — Configuration
        // =========================================================================
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.allowOvernight = false;
        this.allowSameTime = false;
        // =========================================================================
        // PROPERTIES — States
        // =========================================================================
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.activeField = null;
        this.draftStartSeconds = null;
        this.draftEndSeconds = null;
    }
    // =========================================================================
    // STATE CHANGE HANDLER — Sync draft when bound states change
    // =========================================================================
    handleIcaStateChange(key, value) {
        const startAttr = this.getAttribute('start-time');
        const endAttr = this.getAttribute('end-time');
        if (startAttr === `{{${key}}}` || endAttr === `{{${key}}}`) {
            this.syncDraftFromValues();
        }
        this.requestUpdate();
    }
    updated(changed) {
        if (changed.has('startTime') || changed.has('endTime') || changed.has('showSeconds')) {
            this.syncDraftFromValues();
        }
    }
    syncDraftFromValues() {
        this.draftStartSeconds = null;
        this.draftEndSeconds = null;
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleFocus(field) {
        if (!this.isEditing)
            return;
        this.activeField = field;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.activeField = null;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleStartInput(e) {
        if (!this.canInteract())
            return;
        const value = Number(e.target.value);
        this.draftStartSeconds = value;
    }
    handleEndInput(e) {
        if (!this.canInteract())
            return;
        const value = Number(e.target.value);
        this.draftEndSeconds = value;
    }
    handleStartChange(e) {
        if (!this.canInteract())
            return;
        const value = Number(e.target.value);
        if (!this.isValidStart(value)) {
            this.draftStartSeconds = null;
            return;
        }
        const formatted = this.secondsToTime(value);
        this.startTime = formatted;
        this.draftStartSeconds = null;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startTime },
        }));
        if (this.endTime) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { startTime: this.startTime, endTime: this.endTime },
            }));
        }
    }
    handleEndChange(e) {
        if (!this.canInteract())
            return;
        const value = Number(e.target.value);
        if (!this.isValidEnd(value)) {
            this.draftEndSeconds = null;
            return;
        }
        const formatted = this.secondsToTime(value);
        this.endTime = formatted;
        this.draftEndSeconds = null;
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endTime },
        }));
        if (this.startTime) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { startTime: this.startTime, endTime: this.endTime },
            }));
        }
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    canInteract() {
        return this.isEditing && !this.disabled && !this.readonly && !this.loading;
    }
    toSeconds(time) {
        if (!time)
            return null;
        const parts = time.split(':').map((p) => Number(p));
        if (parts.length < 2)
            return null;
        const [h, m, s] = [parts[0] || 0, parts[1] || 0, parts[2] || 0];
        return h * 3600 + m * 60 + s;
    }
    secondsToTime(seconds) {
        const total = Math.max(0, Math.min(86399, seconds));
        const h = Math.floor(total / 3600);
        const m = Math.floor((total % 3600) / 60);
        const s = total % 60;
        const hh = String(h).padStart(2, '0');
        const mm = String(m).padStart(2, '0');
        const ss = String(s).padStart(2, '0');
        return this.showSeconds ? `${hh}:${mm}:${ss}` : `${hh}:${mm}`;
    }
    formatDisplay(time, fallback) {
        if (!time)
            return fallback;
        const seconds = this.toSeconds(time) ?? 0;
        const date = new Date(Date.UTC(1970, 0, 1, 0, 0, 0));
        date.setUTCSeconds(seconds);
        return date.toLocaleTimeString(this.locale || undefined, {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
            timeZone: 'UTC',
        });
    }
    getMinMaxSeconds() {
        const min = this.toSeconds(this.minTime) ?? 0;
        const max = this.toSeconds(this.maxTime) ?? 86399;
        return {
            min: Math.max(0, Math.min(min, 86399)),
            max: Math.max(0, Math.min(max, 86399)),
        };
    }
    getStepSeconds() {
        if (this.showSeconds)
            return 1;
        return Math.max(1, this.minuteStep) * 60;
    }
    getCurrentStartSeconds() {
        if (this.draftStartSeconds !== null)
            return this.draftStartSeconds;
        return this.toSeconds(this.startTime);
    }
    getCurrentEndSeconds() {
        if (this.draftEndSeconds !== null)
            return this.draftEndSeconds;
        return this.toSeconds(this.endTime);
    }
    isOvernight() {
        const start = this.toSeconds(this.startTime);
        const end = this.toSeconds(this.endTime);
        return this.allowOvernight && start !== null && end !== null && end < start;
    }
    durationMinutes(start, end) {
        if (this.allowOvernight && end < start) {
            return (24 * 60) - Math.floor(start / 60) + Math.floor(end / 60);
        }
        return Math.floor((end - start) / 60);
    }
    isValidInterval(start, end) {
        if (!this.allowOvernight) {
            if (end < start)
                return false;
            if (end === start && !this.allowSameTime)
                return false;
            const duration = this.durationMinutes(start, end);
            if (this.minDurationMinutes > 0 && duration < this.minDurationMinutes)
                return false;
            if (this.maxDurationMinutes > 0 && duration > this.maxDurationMinutes)
                return false;
            return true;
        }
        if (end === start && !this.allowSameTime)
            return false;
        const duration = this.durationMinutes(start, end);
        if (this.minDurationMinutes > 0 && duration < this.minDurationMinutes)
            return false;
        if (this.maxDurationMinutes > 0 && duration > this.maxDurationMinutes)
            return false;
        return true;
    }
    isValidStart(startSeconds) {
        const endSeconds = this.toSeconds(this.endTime);
        const { min, max } = this.getMinMaxSeconds();
        if (startSeconds < min || startSeconds > max)
            return false;
        if (endSeconds === null)
            return true;
        return this.isValidInterval(startSeconds, endSeconds);
    }
    isValidEnd(endSeconds) {
        const startSeconds = this.toSeconds(this.startTime);
        const { min, max } = this.getMinMaxSeconds();
        if (endSeconds < min || endSeconds > max)
            return false;
        if (startSeconds === null)
            return true;
        return this.isValidInterval(startSeconds, endSeconds);
    }
    getTrackSegmentStyles(start, end) {
        const total = 86400;
        const left = (start / total) * 100;
        const width = ((end - start) / total) * 100;
        return { left: `${left}%`, width: `${width}%` };
    }
    getContainerClasses() {
        return cn('w-full rounded-lg border p-4 transition', 'ml-interval-container', this.error ? 'ml-input-container-error' : '', this.disabled ? 'ml-disabled' : '', this.cssClass);
    }
    getInputBoxClasses(active) {
        return cn('w-full rounded-md border px-3 py-2 text-sm transition', 'ml-slider-display', active ? 'ml-input-active' : '', this.readonly ? 'cursor-default' : 'cursor-pointer');
    }
    getRangeClasses(active) {
        return cn('absolute left-0 top-0 h-3 w-full appearance-none bg-transparent', 'ml-slider-thumb', active ? 'ml-input-focus' : 'focus:outline-none', this.disabled || this.loading ? 'cursor-not-allowed' : 'cursor-pointer');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const content = this.getSlotContent('Label');
        const required = this.required ? html `<span class="ml-error-text"> *</span>` : nothing;
        return html `
      <div id="${this.baseId}-label" class="${cn('mb-2 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(content)}${required}
      </div>
    `;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${this.baseId}-error" class="mt-2 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.baseId}-helper" class="${cn('mt-2 text-xs ml-text-muted', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderViewMode() {
        const startDisplay = this.formatDisplay(this.startTime, this.msg.empty);
        const endDisplay = this.formatDisplay(this.endTime, this.msg.empty);
        const hasBoth = this.startTime || this.endTime;
        const overnight = this.isOvernight();
        const display = !hasBoth
            ? this.msg.empty
            : `${startDisplay} – ${endDisplay}${overnight ? ` ${this.msg.nextDay}` : ''}`;
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        <div class="text-sm ml-text">${display}</div>
      </div>
    `;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const startSeconds = this.getCurrentStartSeconds();
        const endSeconds = this.getCurrentEndSeconds();
        const startDisplay = startSeconds !== null ? this.formatDisplay(this.secondsToTime(startSeconds), this.msg.empty) : this.msg.empty;
        const endDisplay = endSeconds !== null ? this.formatDisplay(this.secondsToTime(endSeconds), this.msg.empty) : this.msg.empty;
        const overnight = this.isOvernight();
        const { min, max } = this.getMinMaxSeconds();
        const step = this.getStepSeconds();
        const ariaDescribedBy = this.error
            ? `${this.baseId}-error`
            : this.hasSlot('Helper') ? `${this.baseId}-helper` : undefined;
        const labelStart = this.hasSlot('LabelStart') ? unsafeHTML(this.getSlotContent('LabelStart')) : this.msg.labelStart;
        const labelEnd = this.hasSlot('LabelEnd') ? unsafeHTML(this.getSlotContent('LabelEnd')) : this.msg.labelEnd;
        const startId = `${this.baseId}-start-label`;
        const endId = `${this.baseId}-end-label`;
        const highlightSegments = [];
        if (startSeconds !== null && endSeconds !== null) {
            if (!this.allowOvernight || endSeconds >= startSeconds) {
                const seg = this.getTrackSegmentStyles(startSeconds, endSeconds);
                highlightSegments.push(html `
          <div class="absolute top-0 h-3 rounded-full ml-slider-highlight"
            style="left:${seg.left};width:${seg.width};"></div>
        `);
            }
            else {
                const seg1 = this.getTrackSegmentStyles(startSeconds, 86400);
                const seg2 = this.getTrackSegmentStyles(0, endSeconds);
                highlightSegments.push(html `
          <div class="absolute top-0 h-3 rounded-full ml-slider-highlight"
            style="left:${seg1.left};width:${seg1.width};"></div>
          <div class="absolute top-0 h-3 rounded-full ml-slider-highlight"
            style="left:${seg2.left};width:${seg2.width};"></div>
        `);
            }
        }
        return html `
      <div class="${this.getContainerClasses()}" aria-busy="${this.loading ? 'true' : 'false'}">
        ${this.renderLabel()}

        <div class="flex gap-3">
          <div class="flex-1">
            <div id="${startId}" class="${cn('mb-1 text-xs ml-text-muted', this.getSlotClass('LabelStart'))}">${labelStart}</div>
            <div class="${this.getInputBoxClasses(this.activeField === 'start')}" aria-hidden="true">
              ${startDisplay}
            </div>
          </div>
          <div class="flex-1">
            <div id="${endId}" class="${cn('mb-1 text-xs ml-text-muted', this.getSlotClass('LabelEnd'))}">${labelEnd}</div>
            <div class="${this.getInputBoxClasses(this.activeField === 'end')}" aria-hidden="true">
              ${endDisplay}
              ${overnight ? html `<span class="ml-2 text-xs ml-overnight-badge" aria-label="${this.msg.nextDay}">${this.msg.nextDay}</span>` : nothing}
            </div>
          </div>
        </div>

        <div class="mt-4">
          <div class="relative h-3 rounded-full ml-slider-track">
            ${highlightSegments}
            <input
              type="range"
              class="${this.getRangeClasses(this.activeField === 'start')}"
              min="${min}"
              max="${max}"
              step="${step}"
              .value="${startSeconds ?? min}"
              ?disabled="${this.disabled || this.loading}"
              aria-labelledby="${startId}"
              aria-describedby="${ifDefined(ariaDescribedBy)}"
              aria-invalid="${this.error ? 'true' : 'false'}"
              aria-required="${this.required ? 'true' : 'false'}"
              @focus="${() => this.handleFocus('start')}"
              @blur="${this.handleBlur}"
              @input="${this.handleStartInput}"
              @change="${this.handleStartChange}"
            />
            <input
              type="range"
              class="${this.getRangeClasses(this.activeField === 'end')}"
              min="${min}"
              max="${max}"
              step="${step}"
              .value="${endSeconds ?? max}"
              ?disabled="${this.disabled || this.loading}"
              aria-labelledby="${endId}"
              aria-describedby="${ifDefined(ariaDescribedBy)}"
              aria-invalid="${this.error ? 'true' : 'false'}"
              aria-required="${this.required ? 'true' : 'false'}"
              @focus="${() => this.handleFocus('end')}"
              @blur="${this.handleBlur}"
              @input="${this.handleEndInput}"
              @change="${this.handleEndChange}"
            />
          </div>
        </div>

        ${this.loading ? html `<div class="mt-3 text-xs ml-text-muted">${this.msg.loading}</div>` : nothing}
        ${this.renderHelperOrError()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'start-time' })
], TimeIntervalSliderMolecule.prototype, "startTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'end-time' })
], TimeIntervalSliderMolecule.prototype, "endTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], TimeIntervalSliderMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], TimeIntervalSliderMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], TimeIntervalSliderMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour12' })
], TimeIntervalSliderMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], TimeIntervalSliderMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], TimeIntervalSliderMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], TimeIntervalSliderMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], TimeIntervalSliderMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], TimeIntervalSliderMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], TimeIntervalSliderMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-overnight' })
], TimeIntervalSliderMolecule.prototype, "allowOvernight", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-time' })
], TimeIntervalSliderMolecule.prototype, "allowSameTime", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], TimeIntervalSliderMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalSliderMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalSliderMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalSliderMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalSliderMolecule.prototype, "loading", void 0);
__decorate([
    state()
], TimeIntervalSliderMolecule.prototype, "activeField", void 0);
__decorate([
    state()
], TimeIntervalSliderMolecule.prototype, "draftStartSeconds", void 0);
__decorate([
    state()
], TimeIntervalSliderMolecule.prototype, "draftEndSeconds", void 0);
TimeIntervalSliderMolecule = __decorate([
    customElement('groupentertimeinterval--ml-time-interval-slider')
], TimeIntervalSliderMolecule);
export { TimeIntervalSliderMolecule };
