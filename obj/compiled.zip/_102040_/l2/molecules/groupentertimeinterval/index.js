var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertimeinterval/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector';
import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-slider';
import '/_102040_/l2/molecules/groupentertimeinterval/ml-work-shift-interval';
import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-range';
import '/_102040_/l2/molecules/groupentertimeinterval/ml-time-interval';
import '/_102040_/l2/molecules/groupentertimeinterval/ml-enter-time-interval';
import { molecules, scenarios } from '/_102040_/l2/molecules/groupentertimeinterval/index.defs.js';
import { renderCatalogReferenceTable } from '/_102020_/l2/aura/molecules/shared/indexReferenceTable.js';
let GroupEnterTimeIntervalIndex = class GroupEnterTimeIntervalIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        // ── Showcase card states ─────────────────────────────────────
        this.card1Value = {
            startTime: '09:00',
            endTime: '17:30',
        };
        this.card2Value = {
            startTime: '10:00',
            endTime: '14:00',
        };
        this.card3Value = {
            startTime: '22:00',
            endTime: '06:00',
        };
        this.card4Value = {
            startTime: '08:30',
            endTime: '12:00',
        };
        this.card5Value = {
            startTime: '13:00',
            endTime: '15:00',
        };
        this.card6Value = {
            startTime: '23:15',
            endTime: '00:45',
        };
    }
    // ===========================================================================
    // HERO
    renderHero() {
        return html `
      <header
        class="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-8 py-20 text-center"
      >
        <span
          class="inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-600 dark:text-sky-300 rounded-full text-xs font-semibold uppercase tracking-widest mb-6"
        >
          groupEnterTimeInterval
        </span>
        <h1 class="text-5xl font-bold text-slate-900 dark:text-slate-50 mb-5 tracking-tight">
          Enter Time Interval
        </h1>
        <p class="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
          Capture start and end times (no dates) for work shifts, business hours, and recurring
          availability. Choose from picker, slider, range, and grid-like implementations that also
          support overnight intervals crossing midnight.
        </p>
      </header>
    `;
    }
    // ===========================================================================
    // SHOWCASE CARDS
    renderShowcaseCards() {
        return html `
      <section
        class="bg-slate-50 dark:bg-slate-950 px-8 py-12 border-b border-slate-200 dark:border-slate-700"
      >
        <div class="max-w-2xl mx-auto flex flex-col gap-5">
          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-violet-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Time interval selector</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded"
                  >groupentertimeinterval--ml-time-interval-selector</code
                >
              </div>
              <p class="text-xs text-slate-400 mb-5">Dropdown-style picker for standard shift blocks.</p>
              <groupentertimeinterval--ml-time-interval-selector
                name="card-1"
                startTime="${this.card1Value.startTime ?? ''}"
                endTime="${this.card1Value.endTime ?? ''}"
                .minuteStep=${15}
                .required=${true}
                .isEditing=${true}
                @change=${(e) => {
            this.card1Value = { startTime: e.detail.startTime, endTime: e.detail.endTime };
        }}
              >
                <Label>Daily shift</Label>
                <LabelStart>Start time</LabelStart>
                <LabelEnd>End time</LabelEnd>
                <Helper>15-minute increments for standard shifts.</Helper>
              </groupentertimeinterval--ml-time-interval-selector>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-emerald-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Time interval slider</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded"
                  >groupentertimeinterval--ml-time-interval-slider</code
                >
              </div>
              <p class="text-xs text-slate-400 mb-5">Drag handles to set availability windows.</p>
              <groupentertimeinterval--ml-time-interval-slider
                name="card-2"
                startTime="${this.card2Value.startTime ?? ''}"
                endTime="${this.card2Value.endTime ?? ''}"
                minTime="06:00"
                maxTime="22:00"
                .minuteStep=${30}
                .isEditing=${true}
                @change=${(e) => {
            this.card2Value = { startTime: e.detail.startTime, endTime: e.detail.endTime };
        }}
              >
                <Label>Staff availability</Label>
                <LabelStart>Available from</LabelStart>
                <LabelEnd>Available until</LabelEnd>
                <Helper>Drag handles to adjust the window.</Helper>
              </groupentertimeinterval--ml-time-interval-slider>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-amber-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Work shift interval</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded"
                  >groupentertimeinterval--ml-work-shift-interval</code
                >
              </div>
              <p class="text-xs text-slate-400 mb-5">Shift-focused layout with overnight support.</p>
              <groupentertimeinterval--ml-work-shift-interval
                name="card-3"
                startTime="${this.card3Value.startTime ?? ''}"
                endTime="${this.card3Value.endTime ?? ''}"
                locale="en-US"
                .hour12=${true}
                .minuteStep=${15}
                .allowOvernight=${true}
                .minDurationMinutes=${60}
                .isEditing=${true}
                @change=${(e) => {
            this.card3Value = { startTime: e.detail.startTime, endTime: e.detail.endTime };
        }}
              >
                <Label>Overnight coverage</Label>
                <LabelStart>Shift starts</LabelStart>
                <LabelEnd>Shift ends</LabelEnd>
                <Helper>Minimum 1 hour. Overnight shifts are allowed.</Helper>
              </groupentertimeinterval--ml-work-shift-interval>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-rose-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Time interval range</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded"
                  >groupentertimeinterval--ml-time-interval-range</code
                >
              </div>
              <p class="text-xs text-slate-400 mb-5">Compact range entry for short sessions.</p>
              <groupentertimeinterval--ml-time-interval-range
                name="card-4"
                startTime="${this.card4Value.startTime ?? ''}"
                endTime="${this.card4Value.endTime ?? ''}"
                .minuteStep=${5}
                .allowSameTime=${false}
                .isEditing=${true}
                @change=${(e) => {
            this.card4Value = { startTime: e.detail.startTime, endTime: e.detail.endTime };
        }}
              >
                <Label>Class session</Label>
                <LabelStart>Begins</LabelStart>
                <LabelEnd>Ends</LabelEnd>
                <Helper>Ideal for short, fixed sessions.</Helper>
              </groupentertimeinterval--ml-time-interval-range>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-sky-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Time interval</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded"
                  >groupentertimeinterval--ml-time-interval</code
                >
              </div>
              <p class="text-xs text-slate-400 mb-5">General-purpose field for simple ranges.</p>
              <groupentertimeinterval--ml-time-interval
                name="card-5"
                startTime="${this.card5Value.startTime ?? ''}"
                endTime="${this.card5Value.endTime ?? ''}"
                .minuteStep=${10}
                .required=${true}
                .isEditing=${true}
                @change=${(e) => {
            this.card5Value = { startTime: e.detail.startTime, endTime: e.detail.endTime };
        }}
              >
                <Label>Break window</Label>
                <LabelStart>Break starts</LabelStart>
                <LabelEnd>Break ends</LabelEnd>
                <Helper>Required for scheduling breaks.</Helper>
              </groupentertimeinterval--ml-time-interval>
            </div>
          </div>

          <div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
            <div class="h-1 bg-indigo-500 rounded-t-2xl"></div>
            <div class="p-6">
              <div class="flex items-center justify-between mb-1">
                <p class="text-sm font-bold text-slate-900 dark:text-slate-50">Enter time interval</p>
                <code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded"
                  >groupentertimeinterval--ml-enter-time-interval</code
                >
              </div>
              <p class="text-xs text-slate-400 mb-5">Full-featured entry for complex availability rules.</p>
              <groupentertimeinterval--ml-enter-time-interval
                name="card-6"
                startTime="${this.card6Value.startTime ?? ''}"
                endTime="${this.card6Value.endTime ?? ''}"
                locale="en-US"
                .hour12=${true}
                .showSeconds=${true}
                .minuteStep=${15}
                .allowOvernight=${true}
                .minDurationMinutes=${30}
                .isEditing=${true}
                @change=${(e) => {
            this.card6Value = { startTime: e.detail.startTime, endTime: e.detail.endTime };
        }}
              >
                <Label>After-hours support</Label>
                <LabelStart>Opens</LabelStart>
                <LabelEnd>Closes</LabelEnd>
                <Helper>Shows seconds and allows overnight spans.</Helper>
              </groupentertimeinterval--ml-enter-time-interval>
            </div>
          </div>
        </div>
      </section>
    `;
    }
    // ===========================================================================
    // REFERENCE TABLE
    renderReferenceTable() {
        return renderCatalogReferenceTable(molecules, scenarios);
    }
    // ===========================================================================
    // RENDER
    render() {
        return html `
      <div class="font-sans min-h-screen">
        ${this.renderHero()} ${this.renderShowcaseCards()} ${this.renderReferenceTable()}
      </div>
    `;
    }
};
__decorate([
    state()
], GroupEnterTimeIntervalIndex.prototype, "card1Value", void 0);
__decorate([
    state()
], GroupEnterTimeIntervalIndex.prototype, "card2Value", void 0);
__decorate([
    state()
], GroupEnterTimeIntervalIndex.prototype, "card3Value", void 0);
__decorate([
    state()
], GroupEnterTimeIntervalIndex.prototype, "card4Value", void 0);
__decorate([
    state()
], GroupEnterTimeIntervalIndex.prototype, "card5Value", void 0);
__decorate([
    state()
], GroupEnterTimeIntervalIndex.prototype, "card6Value", void 0);
GroupEnterTimeIntervalIndex = __decorate([
    customElement('molecules--groupentertimeinterval--index-102040')
], GroupEnterTimeIntervalIndex);
export { GroupEnterTimeIntervalIndex };
