/// <mls fileReference="_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-selector.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML TIME INTERVAL SELECTOR MOLECULE
// =============================================================================
// Skill Group: enter + time-interval
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholderStart: 'Start time',
    placeholderEnd: 'End time',
    loading: 'Loading...',
    confirm: 'Confirm',
    clear: 'Clear',
    nextDay: '(+1)',
    empty: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholderStart: 'Início',
        placeholderEnd: 'Fim',
        loading: 'Carregando...',
        confirm: 'Confirmar',
        clear: 'Limpar',
        nextDay: '(+1)',
        empty: '—',
    },
};
/// **collab_i18n_end**
let MlTimeIntervalSelectorMolecule = class MlTimeIntervalSelectorMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertimeinterval--ml-time-interval-selector .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentertimeinterval--ml-time-interval-selector .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-selector .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-selector .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-selector .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-time-interval-selector .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertimeinterval--ml-time-interval-selector .ml-input {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentertimeinterval--ml-time-interval-selector .ml-input-focus:focus,
groupentertimeinterval--ml-time-interval-selector .ml-input-focus:focus-within {
  outline: none;
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertimeinterval--ml-time-interval-selector .ml-input-active {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentertimeinterval--ml-time-interval-selector .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertimeinterval--ml-time-interval-selector .ml-interval-picker {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupentertimeinterval--ml-time-interval-selector .ml-interval-btn-secondary {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface-muted, #49454f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupentertimeinterval--ml-time-interval-selector .ml-interval-btn-secondary:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupentertimeinterval--ml-time-interval-selector .ml-interval-btn-confirm {
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupentertimeinterval--ml-time-interval-selector .ml-interval-btn-confirm:hover {
  filter: brightness(0.9);
}
groupentertimeinterval--ml-time-interval-selector .ml-interval-btn-confirm:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
groupentertimeinterval--ml-time-interval-selector .ml-interval-overnight-badge {
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 10%, transparent);
  color: var(--ml-primary, #3b82f6);
}
`);
        this.msg = messages.en;
        this.uid = `ti-${Math.random().toString(36).slice(2)}`;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.startTime = null;
        this.endTime = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.allowOvernight = false;
        this.allowSameTime = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.activeField = null;
        this.tempHour = 0;
        this.tempMinute = 0;
        this.tempSecond = 0;
        this.tempAmPm = 'AM';
    }
    // =========================================================================
    // STATE CHANGE HANDLER
    // =========================================================================
    handleIcaStateChange(key, value) {
        const startAttr = this.getAttribute('startTime');
        const endAttr = this.getAttribute('endTime');
        if ((startAttr === `{{${key}}}` && this.activeField === 'start') || (endAttr === `{{${key}}}` && this.activeField === 'end')) {
            const current = this.activeField === 'start' ? value : value;
            this.initTempFromTime(current);
        }
        this.requestUpdate();
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleOpen(field) {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.activeField = field;
        const current = field === 'start' ? this.startTime : this.endTime;
        this.initTempFromTime(current);
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleClose() {
        if (this.activeField === null)
            return;
        this.activeField = null;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleConfirm() {
        if (this.disabled || this.readonly || this.loading)
            return;
        const time = this.getTimeFromTemp();
        const field = this.activeField;
        if (!field)
            return;
        if (!this.isTimeValidForField(field, time))
            return;
        if (field === 'start') {
            this.startTime = time;
            this.dispatchEvent(new CustomEvent('startChange', {
                bubbles: true,
                composed: true,
                detail: { value: this.startTime },
            }));
            if (this.endTime) {
                this.dispatchEvent(new CustomEvent('change', {
                    bubbles: true,
                    composed: true,
                    detail: { startTime: this.startTime, endTime: this.endTime },
                }));
                this.activeField = null;
            }
            else {
                this.activeField = 'end';
                this.initTempFromTime(this.endTime);
            }
        }
        else {
            this.endTime = time;
            this.dispatchEvent(new CustomEvent('endChange', {
                bubbles: true,
                composed: true,
                detail: { value: this.endTime },
            }));
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { startTime: this.startTime, endTime: this.endTime },
            }));
            this.activeField = null;
        }
    }
    handleClear() {
        if (this.disabled || this.readonly || this.loading)
            return;
        const field = this.activeField;
        if (!field)
            return;
        if (field === 'start') {
            this.startTime = null;
            this.dispatchEvent(new CustomEvent('startChange', {
                bubbles: true,
                composed: true,
                detail: { value: this.startTime },
            }));
        }
        else {
            this.endTime = null;
            this.dispatchEvent(new CustomEvent('endChange', {
                bubbles: true,
                composed: true,
                detail: { value: this.endTime },
            }));
        }
    }
    handleHourChange(e) {
        e.stopPropagation();
        const value = Number(e.target.value);
        this.tempHour = value;
    }
    handleMinuteChange(e) {
        e.stopPropagation();
        const value = Number(e.target.value);
        this.tempMinute = value;
    }
    handleSecondChange(e) {
        e.stopPropagation();
        const value = Number(e.target.value);
        this.tempSecond = value;
    }
    handleAmPmChange(e) {
        e.stopPropagation();
        const value = e.target.value;
        this.tempAmPm = value;
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    parseTime(value) {
        if (!value)
            return null;
        const parts = value.split(':').map((v) => Number(v));
        if (parts.length < 2)
            return null;
        const [hour, minute, second = 0] = parts;
        if (Number.isNaN(hour) || Number.isNaN(minute) || Number.isNaN(second))
            return null;
        return { hour, minute, second };
    }
    formatToStorage(hour, minute, second) {
        const h = String(hour).padStart(2, '0');
        const m = String(minute).padStart(2, '0');
        const s = String(second).padStart(2, '0');
        return this.showSeconds ? `${h}:${m}:${s}` : `${h}:${m}`;
    }
    formatForDisplay(value) {
        if (!value)
            return this.msg.empty;
        const parsed = this.parseTime(value);
        if (!parsed)
            return this.msg.empty;
        const date = new Date(1970, 0, 1, parsed.hour, parsed.minute, parsed.second);
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            hour12: this.hour12,
        };
        if (this.showSeconds) {
            options.second = '2-digit';
        }
        const locale = this.locale || undefined;
        return new Intl.DateTimeFormat(locale, options).format(date);
    }
    initTempFromTime(value) {
        const parsed = this.parseTime(value) || this.parseTime(this.minTime) || { hour: 0, minute: 0, second: 0 };
        if (this.hour12) {
            const { hour12, ampm } = this.toHour12(parsed.hour);
            this.tempHour = hour12;
            this.tempAmPm = ampm;
        }
        else {
            this.tempHour = parsed.hour;
            this.tempAmPm = parsed.hour >= 12 ? 'PM' : 'AM';
        }
        this.tempMinute = parsed.minute;
        this.tempSecond = parsed.second;
    }
    toHour12(hour24) {
        const ampm = hour24 >= 12 ? 'PM' : 'AM';
        const hour = hour24 % 12 || 12;
        return { hour12: hour, ampm };
    }
    toHour24(hour12Value, ampm) {
        const base = hour12Value % 12;
        return ampm === 'PM' ? base + 12 : base;
    }
    getTimeFromTemp() {
        const hour = this.hour12 ? this.toHour24(this.tempHour, this.tempAmPm) : this.tempHour;
        return this.formatToStorage(hour, this.tempMinute, this.showSeconds ? this.tempSecond : 0);
    }
    toSeconds(value) {
        const parsed = this.parseTime(value);
        if (!parsed)
            return 0;
        return parsed.hour * 3600 + parsed.minute * 60 + parsed.second;
    }
    isTimeWithinLimits(value) {
        const seconds = this.toSeconds(value);
        if (this.minTime) {
            const min = this.toSeconds(this.minTime);
            if (seconds < min)
                return false;
        }
        if (this.maxTime) {
            const max = this.toSeconds(this.maxTime);
            if (seconds > max)
                return false;
        }
        return true;
    }
    isOvernight(start, end) {
        if (!start || !end)
            return false;
        return this.allowOvernight && this.toSeconds(end) < this.toSeconds(start);
    }
    calcDurationMinutes(start, end) {
        const startMin = Math.floor(this.toSeconds(start) / 60);
        const endMin = Math.floor(this.toSeconds(end) / 60);
        if (this.allowOvernight && endMin < startMin) {
            return 24 * 60 - startMin + endMin;
        }
        return endMin - startMin;
    }
    isEndTimeValid(endValue) {
        if (!this.startTime)
            return true;
        const startSeconds = this.toSeconds(this.startTime);
        const endSeconds = this.toSeconds(endValue);
        if (!this.allowOvernight) {
            if (this.allowSameTime) {
                if (endSeconds < startSeconds)
                    return false;
            }
            else {
                if (endSeconds <= startSeconds)
                    return false;
            }
        }
        const duration = this.calcDurationMinutes(this.startTime, endValue);
        if (this.minDurationMinutes > 0 && duration < this.minDurationMinutes)
            return false;
        if (this.maxDurationMinutes > 0 && duration > this.maxDurationMinutes)
            return false;
        return true;
    }
    isTimeValidForField(field, value) {
        if (!this.isTimeWithinLimits(value))
            return false;
        if (field === 'end') {
            return this.isEndTimeValid(value);
        }
        return true;
    }
    getRangeDisplay() {
        const startDisplay = this.startTime ? this.formatForDisplay(this.startTime) : this.msg.empty;
        const endDisplay = this.endTime ? this.formatForDisplay(this.endTime) : this.msg.empty;
        const overnight = this.isOvernight(this.startTime, this.endTime);
        const suffix = overnight ? ` ${this.msg.nextDay}` : '';
        return `${startDisplay} – ${endDisplay}${suffix}`;
    }
    getInputClasses(active) {
        return cn('w-full rounded-lg border px-3 py-2 text-sm transition flex items-center justify-between', 'ml-input', active ? 'ml-input-active' : '', this.error ? 'ml-input-container-error' : '', 'ml-input-focus', this.disabled || this.loading ? 'ml-disabled' : 'cursor-pointer');
    }
    getPickerClasses() {
        return cn('mt-2 rounded-lg border p-4', 'ml-interval-picker');
    }
    getSelectClasses() {
        return cn('w-full rounded-md border px-2 py-1 text-sm', 'ml-input', 'ml-input-focus', this.disabled || this.loading ? 'ml-disabled' : '');
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
    renderViewMode() {
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.hasSlot('Label')
            ? html `<div id="${this.uid}-label" class="${cn('mb-2 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
              ${unsafeHTML(this.getSlotContent('Label'))}
            </div>`
            : nothing}
        <div class="text-sm ml-text">
          ${this.getRangeDisplay()}
        </div>
      </div>
    `;
    }
    renderEditMode() {
        const startLabelId = `${this.uid}-start-label`;
        const endLabelId = `${this.uid}-end-label`;
        const errorId = `${this.uid}-error`;
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.hasSlot('Label')
            ? html `<div id="${this.uid}-label" class="${cn('mb-2 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
              ${unsafeHTML(this.getSlotContent('Label'))}
            </div>`
            : nothing}

        <div class="grid grid-cols-2 gap-3">
          <div>
            ${this.hasSlot('LabelStart')
            ? html `<div id="${startLabelId}" class="${cn('mb-1 text-xs font-medium ml-text-muted', this.getSlotClass('LabelStart'))}">
                  ${unsafeHTML(this.getSlotContent('LabelStart'))}
                </div>`
            : nothing}
            <button
              class="${this.getInputClasses(this.activeField === 'start')}"
              type="button"
              aria-haspopup="dialog"
              aria-expanded="${this.activeField === 'start'}"
              aria-labelledby="${startLabelId}"
              aria-describedby="${this.error ? errorId : ''}"
              aria-invalid="${this.error ? 'true' : 'false'}"
              aria-required="${this.required ? 'true' : 'false'}"
              @click="${() => this.handleOpen('start')}"
            >
              <span>
                ${this.startTime ? this.formatForDisplay(this.startTime) : this.msg.placeholderStart}
              </span>
              ${this.renderClockIcon()}
            </button>
          </div>

          <div>
            ${this.hasSlot('LabelEnd')
            ? html `<div id="${endLabelId}" class="${cn('mb-1 text-xs font-medium ml-text-muted', this.getSlotClass('LabelEnd'))}">
                  ${unsafeHTML(this.getSlotContent('LabelEnd'))}
                </div>`
            : nothing}
            <button
              class="${this.getInputClasses(this.activeField === 'end')}"
              type="button"
              aria-haspopup="dialog"
              aria-expanded="${this.activeField === 'end'}"
              aria-labelledby="${endLabelId}"
              aria-describedby="${this.error ? errorId : ''}"
              aria-invalid="${this.error ? 'true' : 'false'}"
              aria-required="${this.required ? 'true' : 'false'}"
              @click="${() => this.handleOpen('end')}"
            >
              <span class="flex items-center gap-2">
                ${this.endTime ? this.formatForDisplay(this.endTime) : this.msg.placeholderEnd}
                ${this.isOvernight(this.startTime, this.endTime)
            ? html `<span class="rounded px-1.5 py-0.5 text-xs ml-interval-overnight-badge" aria-label="${this.msg.nextDay}">
                      ${this.msg.nextDay}
                    </span>`
            : nothing}
              </span>
              ${this.renderClockIcon()}
            </button>
          </div>
        </div>

        ${this.loading
            ? html `<div class="mt-2 text-xs ml-text-muted">${this.msg.loading}</div>`
            : nothing}

        ${this.renderPicker()}
        ${this.renderFeedback(errorId)}
      </div>
    `;
    }
    renderPicker() {
        if (!this.activeField || this.loading)
            return html ``;
        const invalid = !this.isTimeValidForField(this.activeField, this.getTimeFromTemp());
        return html `
      <div class="${this.getPickerClasses()}" role="dialog" aria-modal="true">
        <div class="grid ${this.showSeconds ? 'grid-cols-3' : 'grid-cols-2'} gap-3">
          <div>
            <label class="mb-1 block text-xs ml-text-muted">${this.hour12 ? 'Hour' : 'Hour'}</label>
            <select class="${this.getSelectClasses()}" @change="${this.handleHourChange}" @input="${(e) => e.stopPropagation()}">
              ${this.renderHourOptions()}
            </select>
          </div>
          <div>
            <label class="mb-1 block text-xs ml-text-muted">Minute</label>
            <select class="${this.getSelectClasses()}" @change="${this.handleMinuteChange}" @input="${(e) => e.stopPropagation()}">
              ${this.renderMinuteOptions()}
            </select>
          </div>
          ${this.showSeconds
            ? html `<div>
                <label class="mb-1 block text-xs ml-text-muted">Second</label>
                <select class="${this.getSelectClasses()}" @change="${this.handleSecondChange}" @input="${(e) => e.stopPropagation()}">
                  ${this.renderSecondOptions()}
                </select>
              </div>`
            : nothing}
        </div>

        ${this.hour12
            ? html `<div class="mt-3">
              <label class="mb-1 block text-xs ml-text-muted">AM / PM</label>
              <select class="${this.getSelectClasses()}" @change="${this.handleAmPmChange}" @input="${(e) => e.stopPropagation()}">
                <option value="AM" ?selected="${this.tempAmPm === 'AM'}">AM</option>
                <option value="PM" ?selected="${this.tempAmPm === 'PM'}">PM</option>
              </select>
            </div>`
            : nothing}

        <div class="mt-4 flex items-center gap-2">
          <button
            type="button"
            class="rounded-md border px-3 py-1.5 text-xs ml-interval-btn-secondary"
            @click="${this.handleClear}"
          >
            ${this.msg.clear}
          </button>
          <button
            type="button"
            class="rounded-md px-3 py-1.5 text-xs ml-interval-btn-confirm disabled:opacity-50"
            ?disabled="${invalid}"
            @click="${this.handleConfirm}"
          >
            ${this.msg.confirm}
          </button>
          <button
            type="button"
            class="ml-auto rounded-md border px-3 py-1.5 text-xs ml-interval-btn-secondary"
            @click="${this.handleClose}"
          >
            OK
          </button>
        </div>
      </div>
    `;
    }
    renderHourOptions() {
        if (this.hour12) {
            return Array.from({ length: 12 }, (_, i) => {
                const value = i + 1;
                return html `<option value="${value}" ?selected="${this.tempHour === value}">${String(value).padStart(2, '0')}</option>`;
            });
        }
        return Array.from({ length: 24 }, (_, i) => html `<option value="${i}" ?selected="${this.tempHour === i}">${String(i).padStart(2, '0')}</option>`);
    }
    renderMinuteOptions() {
        const step = Math.max(1, this.minuteStep);
        const options = [];
        for (let i = 0; i < 60; i += step) {
            options.push(html `<option value="${i}" ?selected="${this.tempMinute === i}">${String(i).padStart(2, '0')}</option>`);
        }
        return options;
    }
    renderSecondOptions() {
        return Array.from({ length: 60 }, (_, i) => html `<option value="${i}" ?selected="${this.tempSecond === i}">${String(i).padStart(2, '0')}</option>`);
    }
    renderFeedback(errorId) {
        if (this.error) {
            return html `<p id="${errorId}" class="mt-2 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderClockIcon() {
        return html `
      <svg class="h-4 w-4 ml-text-muted" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <circle cx="12" cy="12" r="9" stroke="currentColor" stroke-width="1.5"></circle>
        <path d="M12 7v5l3 2" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
      </svg>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalSelectorMolecule.prototype, "startTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalSelectorMolecule.prototype, "endTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalSelectorMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalSelectorMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTimeIntervalSelectorMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour12' })
], MlTimeIntervalSelectorMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], MlTimeIntervalSelectorMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], MlTimeIntervalSelectorMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], MlTimeIntervalSelectorMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], MlTimeIntervalSelectorMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], MlTimeIntervalSelectorMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], MlTimeIntervalSelectorMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-overnight' })
], MlTimeIntervalSelectorMolecule.prototype, "allowOvernight", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-time' })
], MlTimeIntervalSelectorMolecule.prototype, "allowSameTime", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlTimeIntervalSelectorMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalSelectorMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalSelectorMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalSelectorMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTimeIntervalSelectorMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTimeIntervalSelectorMolecule.prototype, "activeField", void 0);
__decorate([
    state()
], MlTimeIntervalSelectorMolecule.prototype, "tempHour", void 0);
__decorate([
    state()
], MlTimeIntervalSelectorMolecule.prototype, "tempMinute", void 0);
__decorate([
    state()
], MlTimeIntervalSelectorMolecule.prototype, "tempSecond", void 0);
__decorate([
    state()
], MlTimeIntervalSelectorMolecule.prototype, "tempAmPm", void 0);
MlTimeIntervalSelectorMolecule = __decorate([
    customElement('groupentertimeinterval--ml-time-interval-selector')
], MlTimeIntervalSelectorMolecule);
export { MlTimeIntervalSelectorMolecule };
