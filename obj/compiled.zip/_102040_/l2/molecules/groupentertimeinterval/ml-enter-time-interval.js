var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertimeinterval/ml-enter-time-interval.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ENTER TIME INTERVAL MOLECULE
// =============================================================================
// Skill Group: groupEnterTimeInterval
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    labelStart: 'Start time',
    labelEnd: 'End time',
    placeholder: '—',
    loading: 'Loading...',
    nextDay: '(+1)',
    nextDayAria: 'Ends next day',
};
const messages = {
    en: message_en,
    pt: {
        labelStart: 'Hora inicial',
        labelEnd: 'Hora final',
        placeholder: '—',
        loading: 'Carregando...',
        nextDay: '(+1)',
        nextDayAria: 'Termina no dia seguinte',
    },
};
/// **collab_i18n_end**
let EnterTimeIntervalMolecule = class EnterTimeIntervalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        this.uid = `eti-${Math.random().toString(36).slice(2, 9)}`;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.startTime = null;
        this.endTime = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.allowOvernight = false;
        this.allowSameTime = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.activeField = null;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleStartInput(event) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = event.target;
        this.startTime = input.value ? input.value : null;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startTime }
        }));
        this.emitCombinedChangeIfValid();
    }
    handleEndInput(event) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = event.target;
        this.endTime = input.value ? input.value : null;
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endTime }
        }));
        this.emitCombinedChangeIfValid();
    }
    emitCombinedChangeIfValid() {
        if (!this.isIntervalValid())
            return;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: {
                startTime: this.startTime,
                endTime: this.endTime,
            }
        }));
    }
    handleFocus(field) {
        if (this.disabled || this.loading)
            return;
        this.activeField = field;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.activeField = null;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ==========================================================================
    // VALIDATION & FORMATTING
    // ==========================================================================
    isIntervalValid() {
        if (!this.startTime || !this.endTime)
            return false;
        if (!this.allowSameTime && this.startTime === this.endTime)
            return false;
        const startMinutes = this.toMinutes(this.startTime);
        const endMinutes = this.toMinutes(this.endTime);
        if (startMinutes === null || endMinutes === null)
            return false;
        if (!this.isWithinBounds(startMinutes) || !this.isWithinBounds(endMinutes))
            return false;
        const overnight = endMinutes < startMinutes;
        if (overnight && !this.allowOvernight)
            return false;
        const duration = overnight
            ? (24 * 60) - startMinutes + endMinutes
            : endMinutes - startMinutes;
        if (duration < 0)
            return false;
        if (this.minDurationMinutes > 0 && duration < this.minDurationMinutes)
            return false;
        if (this.maxDurationMinutes > 0 && duration > this.maxDurationMinutes)
            return false;
        return true;
    }
    isWithinBounds(minutes) {
        if (this.minTime) {
            const minMinutes = this.toMinutes(this.minTime);
            if (minMinutes !== null && minutes < minMinutes)
                return false;
        }
        if (this.maxTime) {
            const maxMinutes = this.toMinutes(this.maxTime);
            if (maxMinutes !== null && minutes > maxMinutes)
                return false;
        }
        return true;
    }
    toMinutes(time) {
        const parts = time.split(':').map(Number);
        if (parts.length < 2)
            return null;
        const [h, m, s = 0] = parts;
        if (Number.isNaN(h) || Number.isNaN(m) || Number.isNaN(s))
            return null;
        return h * 60 + m + (s / 60);
    }
    isOvernightInterval() {
        if (!this.allowOvernight || !this.startTime || !this.endTime)
            return false;
        const startMinutes = this.toMinutes(this.startTime);
        const endMinutes = this.toMinutes(this.endTime);
        if (startMinutes === null || endMinutes === null)
            return false;
        return endMinutes < startMinutes;
    }
    formatTimeDisplay(time) {
        if (!time)
            return this.msg.placeholder;
        const parts = time.split(':').map(Number);
        const [h, m, s = 0] = parts;
        const date = new Date(1970, 0, 1, h, m, s);
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
        };
        return date.toLocaleTimeString(this.locale || undefined, options);
    }
    getDisplayRange() {
        const startText = this.formatTimeDisplay(this.startTime);
        const endText = this.formatTimeDisplay(this.endTime);
        if (!this.startTime && !this.endTime) {
            return this.msg.placeholder;
        }
        if (this.startTime && !this.endTime) {
            return `${startText} – ${this.msg.placeholder}`;
        }
        if (!this.startTime && this.endTime) {
            return `${this.msg.placeholder} – ${endText}`;
        }
        const overnight = this.isOvernightInterval();
        return `${startText} – ${endText}${overnight ? ` ${this.msg.nextDay}` : ''}`;
    }
    // ==========================================================================
    // CLASS BUILDERS
    // ==========================================================================
    getContainerClasses() {
        return [
            'w-full',
            this.disabled || this.loading ? 'opacity-50 pointer-events-none' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses(isActive) {
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            this.error
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            isActive ? 'border-sky-500 dark:border-sky-400 focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400' : 'focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.readonly ? 'bg-slate-50 dark:bg-slate-900' : '',
        ].filter(Boolean).join(' ');
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `
<div class="${this.getContainerClasses()}">
<div class="text-sm text-slate-900 dark:text-slate-100">
${this.getDisplayRange()}
</div>
</div>
`;
        }
        const labelId = `label-${this.uid}`;
        const labelStartId = `label-start-${this.uid}`;
        const labelEndId = `label-end-${this.uid}`;
        const errorId = `error-${this.uid}`;
        const helperId = `helper-${this.uid}`;
        const hasError = Boolean(this.error);
        const hasHelper = this.hasSlot('Helper');
        const overnight = this.isOvernightInterval();
        const stepSeconds = this.showSeconds ? 1 : Math.max(1, this.minuteStep) * 60;
        const ariaStartLabelledBy = this.hasSlot('LabelStart')
            ? labelStartId
            : (this.hasSlot('Label') ? labelId : undefined);
        const ariaEndLabelledBy = this.hasSlot('LabelEnd')
            ? labelEndId
            : (this.hasSlot('Label') ? labelId : undefined);
        const ariaDescribedBy = hasError
            ? errorId
            : (hasHelper ? helperId : undefined);
        return html `
<div class="${this.getContainerClasses()}">
${this.hasSlot('Label') ? html `
<label id="${labelId}" class="mb-1 block text-sm font-medium text-slate-600 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Label'))}
</label>
` : html ``}

<div class="grid grid-cols-1 gap-3 sm:grid-cols-2">
<div>
${this.hasSlot('LabelStart') ? html `
<label id="${labelStartId}" class="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('LabelStart'))}
</label>
` : html ``}
<input
class="${this.getInputClasses(this.activeField === 'start')}"
type="time"
.value=${this.startTime ?? ''}
step="${stepSeconds}"
min="${this.minTime || ''}"
max="${this.maxTime || ''}"
name="${this.name ? `${this.name}-start` : ''}"
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
?required=${this.required}
aria-labelledby=${ariaStartLabelledBy || ''}
aria-describedby=${ariaDescribedBy || ''}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@input=${this.handleStartInput}
@focus=${() => this.handleFocus('start')}
@blur=${this.handleBlur}
/>
</div>

<div>
${this.hasSlot('LabelEnd') ? html `
<label id="${labelEndId}" class="mb-1 block text-xs font-medium text-slate-600 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('LabelEnd'))}
</label>
` : html ``}
<input
class="${this.getInputClasses(this.activeField === 'end')}"
type="time"
.value=${this.endTime ?? ''}
step="${stepSeconds}"
min="${this.minTime || ''}"
max="${this.maxTime || ''}"
name="${this.name ? `${this.name}-end` : ''}"
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
?required=${this.required}
aria-labelledby=${ariaEndLabelledBy || ''}
aria-describedby=${ariaDescribedBy || ''}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
@input=${this.handleEndInput}
@focus=${() => this.handleFocus('end')}
@blur=${this.handleBlur}
/>
${overnight ? html `
<p class="mt-1 text-xs text-slate-500 dark:text-slate-400" aria-label="${this.msg.nextDayAria}">
${this.msg.nextDay}
</p>
` : html ``}
</div>
</div>

${this.loading ? html `
<p class="mt-2 text-xs text-slate-500 dark:text-slate-400">${this.msg.loading}</p>
` : html ``}

${hasError ? html `
<p id="${errorId}" class="mt-2 text-xs text-red-600 dark:text-red-400">
${unsafeHTML(String(this.error))}
</p>
` : html ``}

${!hasError && hasHelper ? html `
<p id="${helperId}" class="mt-2 text-xs text-slate-500 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
` : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], EnterTimeIntervalMolecule.prototype, "startTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeIntervalMolecule.prototype, "endTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeIntervalMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeIntervalMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeIntervalMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour12' })
], EnterTimeIntervalMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], EnterTimeIntervalMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], EnterTimeIntervalMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeIntervalMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterTimeIntervalMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], EnterTimeIntervalMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], EnterTimeIntervalMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-overnight' })
], EnterTimeIntervalMolecule.prototype, "allowOvernight", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-time' })
], EnterTimeIntervalMolecule.prototype, "allowSameTime", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EnterTimeIntervalMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeIntervalMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeIntervalMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeIntervalMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterTimeIntervalMolecule.prototype, "loading", void 0);
__decorate([
    state()
], EnterTimeIntervalMolecule.prototype, "activeField", void 0);
EnterTimeIntervalMolecule = __decorate([
    customElement('groupentertimeinterval--ml-enter-time-interval')
], EnterTimeIntervalMolecule);
export { EnterTimeIntervalMolecule };
