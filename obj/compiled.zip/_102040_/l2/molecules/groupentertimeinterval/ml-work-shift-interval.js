var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertimeinterval/ml-work-shift-interval.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// WORK SHIFT INTERVAL MOLECULE
// =============================================================================
// Skill Group: groupEnterTimeInterval
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    startPlaceholder: 'Start time',
    endPlaceholder: 'End time',
    loading: 'Loading...',
    nextDay: '(+1)',
    emptyView: '—',
    rangeSeparator: '–',
};
const messages = {
    en: message_en,
    pt: {
        startPlaceholder: 'Hora inicial',
        endPlaceholder: 'Hora final',
        loading: 'Carregando...',
        nextDay: '(+1)',
        emptyView: '—',
        rangeSeparator: '–',
    },
};
/// **collab_i18n_end**
let WorkShiftIntervalMolecule = class WorkShiftIntervalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentertimeinterval--ml-work-shift-interval .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupentertimeinterval--ml-work-shift-interval .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-work-shift-interval .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-work-shift-interval .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-work-shift-interval .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-work-shift-interval .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentertimeinterval--ml-work-shift-interval .ml-shift-container {
  background-color: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
  transition: border-color var(--transition-fast, 200ms ease);
}
groupentertimeinterval--ml-work-shift-interval .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentertimeinterval--ml-work-shift-interval .ml-input {
  background-color: var(--surface-bg, #ffffff);
  color: var(--text-strong, #1c1b1f);
  border-color: var(--border-default, #e2e8f0);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupentertimeinterval--ml-work-shift-interval .ml-input::placeholder {
  color: var(--text-muted-disabled, #79747e);
}
groupentertimeinterval--ml-work-shift-interval .ml-input:focus {
  outline: none;
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupentertimeinterval--ml-work-shift-interval .ml-shift-input-active {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupentertimeinterval--ml-work-shift-interval .ml-shift-overnight {
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 10%, transparent);
  color: var(--selected-text, #3b82f6);
}
`);
        this.msg = messages.en;
        this.uid = `ws-interval-${Math.random().toString(36).slice(2, 9)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.startTime = null;
        this.endTime = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.allowOvernight = false;
        this.allowSameTime = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.activeField = null;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleStartInput(e) {
        e.stopPropagation();
        if (this.disabled || this.loading || this.readonly)
            return;
        const input = e.target;
        const next = input.value ? this.normalizeValueForStorage(input.value) : null;
        this.startTime = next;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: next },
        }));
        if (this.startTime || this.endTime) {
            this.dispatchChangeIfComplete();
        }
    }
    handleEndInput(e) {
        e.stopPropagation();
        if (this.disabled || this.loading || this.readonly)
            return;
        const input = e.target;
        const next = input.value ? this.normalizeValueForStorage(input.value) : null;
        this.endTime = next;
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: next },
        }));
        if (this.startTime || this.endTime) {
            this.dispatchChangeIfComplete();
        }
    }
    handleFocus(field) {
        if (!this.isEditing)
            return;
        this.activeField = field;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.activeField = null;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    dispatchChangeIfComplete() {
        if (this.startTime !== null && this.endTime !== null) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { startTime: this.startTime, endTime: this.endTime },
            }));
        }
    }
    // ===========================================================================
    // HELPER METHODS
    // ===========================================================================
    normalizeValueForInput(value) {
        if (!value)
            return '';
        if (this.showSeconds) {
            return value.length === 5 ? `${value}:00` : value;
        }
        return value.slice(0, 5);
    }
    normalizeValueForStorage(value) {
        if (this.showSeconds) {
            return value.length === 5 ? `${value}:00` : value;
        }
        return value.slice(0, 5);
    }
    parseToSeconds(value) {
        const [h, m, s] = value.split(':').map((v) => Number(v));
        return (h || 0) * 3600 + (m || 0) * 60 + (s || 0);
    }
    formatFromSeconds(totalSeconds) {
        const h = Math.floor(totalSeconds / 3600) % 24;
        const m = Math.floor((totalSeconds % 3600) / 60);
        const s = Math.floor(totalSeconds % 60);
        const hh = String(h).padStart(2, '0');
        const mm = String(m).padStart(2, '0');
        const ss = String(s).padStart(2, '0');
        return this.showSeconds ? `${hh}:${mm}:${ss}` : `${hh}:${mm}`;
    }
    formatDisplay(value) {
        if (!value)
            return this.msg.emptyView;
        const normalized = this.normalizeValueForInput(value);
        const [h, m, s] = normalized.split(':').map((v) => Number(v));
        const date = new Date();
        date.setHours(h || 0, m || 0, s || 0, 0);
        const options = {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
        };
        return date.toLocaleTimeString(this.locale || undefined, options);
    }
    isOvernightInterval() {
        if (!this.allowOvernight || !this.startTime || !this.endTime)
            return false;
        const start = this.parseToSeconds(this.normalizeValueForInput(this.startTime));
        const end = this.parseToSeconds(this.normalizeValueForInput(this.endTime));
        return end < start;
    }
    getInputStep() {
        const stepMinutes = Math.max(1, this.minuteStep || 1);
        return stepMinutes * 60;
    }
    getEndConstraints() {
        const constraints = {};
        if (this.minTime) {
            constraints.min = this.normalizeValueForInput(this.minTime);
        }
        if (this.maxTime) {
            constraints.max = this.normalizeValueForInput(this.maxTime);
        }
        if (!this.startTime || this.allowOvernight) {
            return constraints;
        }
        const startSeconds = this.parseToSeconds(this.normalizeValueForInput(this.startTime));
        const minDuration = this.minDurationMinutes > 0 ? this.minDurationMinutes : 0;
        const maxDuration = this.maxDurationMinutes > 0 ? this.maxDurationMinutes : 0;
        const minimumStep = this.allowSameTime ? 0 : Math.max(1, this.minuteStep || 1);
        const minOffset = Math.max(minDuration, minimumStep);
        if (minOffset > 0) {
            const minEnd = this.formatFromSeconds(startSeconds + minOffset * 60);
            constraints.min = constraints.min
                ? this.maxTimeValue(constraints.min, minEnd)
                : minEnd;
        }
        if (maxDuration > 0) {
            const maxEnd = this.formatFromSeconds(startSeconds + maxDuration * 60);
            constraints.max = constraints.max
                ? this.minTimeValue(constraints.max, maxEnd)
                : maxEnd;
        }
        return constraints;
    }
    maxTimeValue(a, b) {
        return this.parseToSeconds(a) > this.parseToSeconds(b) ? a : b;
    }
    minTimeValue(a, b) {
        return this.parseToSeconds(a) < this.parseToSeconds(b) ? a : b;
    }
    getWrapperClasses() {
        const hasError = Boolean(this.error);
        const isBlocked = this.disabled || this.loading;
        return [
            'w-full rounded-lg border p-4 transition ml-shift-container',
            hasError ? 'ml-input-container-error' : '',
            isBlocked ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getInputClasses(isActive) {
        const hasError = Boolean(this.error);
        return [
            'w-full rounded-md border px-3 py-2 text-sm transition ml-input',
            hasError
                ? 'ml-input-container-error'
                : isActive
                    ? 'ml-shift-input-active'
                    : '',
        ].filter(Boolean).join(' ');
    }
    getIndicatorClasses() {
        return 'ml-2 inline-flex items-center rounded-full px-2 py-0.5 text-xs ml-shift-overnight';
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div class="${cn('mb-3 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="ml-error-text"> *</span>` : html ``}
      </div>
    `;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${this.uid}-error" class="mt-2 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.uid}-helper" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderViewMode() {
        const startText = this.formatDisplay(this.startTime);
        const endText = this.formatDisplay(this.endTime);
        const overnight = this.isOvernightInterval();
        const range = `${startText} ${this.msg.rangeSeparator} ${endText}`;
        return html `
      <div class="${cn(this.getWrapperClasses(), this.cssClass)}">
        ${this.renderLabel()}
        <div class="text-sm ml-text">
          <span>${range}</span>
          ${overnight ? html `<span class="${this.getIndicatorClasses()}" aria-label="${this.msg.nextDay}">${this.msg.nextDay}</span>` : html ``}
        </div>
      </div>
    `;
    }
    renderEditMode() {
        const startLabelId = `${this.uid}-label-start`;
        const endLabelId = `${this.uid}-label-end`;
        const helperId = this.error ? `${this.uid}-error` : `${this.uid}-helper`;
        const endConstraints = this.getEndConstraints();
        const overnight = this.isOvernightInterval();
        return html `
      <div class="${cn(this.getWrapperClasses(), this.cssClass)}">
        ${this.renderLabel()}
        <div class="grid gap-4 md:grid-cols-2">
          <div>
            ${this.hasSlot('LabelStart')
            ? html `<label id="${startLabelId}" class="${cn('mb-1 block text-xs font-medium ml-text-muted', this.getSlotClass('LabelStart'))}">
                  ${unsafeHTML(this.getSlotContent('LabelStart'))}
                </label>`
            : html ``}
            <input
              class="${this.getInputClasses(this.activeField === 'start')}"
              type="time"
              name="${this.name ? `${this.name}-start` : ''}"
              .value="${this.normalizeValueForInput(this.startTime)}"
              ?disabled=${this.disabled || this.loading}
              ?readonly=${this.readonly}
              aria-labelledby="${this.hasSlot('LabelStart') ? startLabelId : ''}"
              aria-describedby="${this.hasSlot('Helper') || this.error ? helperId : ''}"
              aria-invalid="${this.error ? 'true' : 'false'}"
              aria-required="${this.required ? 'true' : 'false'}"
              step="${this.getInputStep()}"
              min="${this.minTime ? this.normalizeValueForInput(this.minTime) : ''}"
              max="${this.maxTime ? this.normalizeValueForInput(this.maxTime) : ''}"
              placeholder="${this.msg.startPlaceholder}"
              @input=${this.handleStartInput}
              @focus=${() => this.handleFocus('start')}
              @blur=${this.handleBlur}
            
            @change="${(e) => e.stopPropagation()}"
/>
          </div>
          <div>
            ${this.hasSlot('LabelEnd')
            ? html `<label id="${endLabelId}" class="${cn('mb-1 block text-xs font-medium ml-text-muted', this.getSlotClass('LabelEnd'))}">
                  ${unsafeHTML(this.getSlotContent('LabelEnd'))}
                </label>`
            : html ``}
            <div class="flex items-center">
              <input
                class="${this.getInputClasses(this.activeField === 'end')}"
                type="time"
                name="${this.name ? `${this.name}-end` : ''}"
                .value="${this.normalizeValueForInput(this.endTime)}"
                ?disabled=${this.disabled || this.loading}
                ?readonly=${this.readonly}
                aria-labelledby="${this.hasSlot('LabelEnd') ? endLabelId : ''}"
                aria-describedby="${this.hasSlot('Helper') || this.error ? helperId : ''}"
                aria-invalid="${this.error ? 'true' : 'false'}"
                aria-required="${this.required ? 'true' : 'false'}"
                step="${this.getInputStep()}"
                min="${endConstraints.min || ''}"
                max="${endConstraints.max || ''}"
                placeholder="${this.msg.endPlaceholder}"
                @input=${this.handleEndInput}
                @focus=${() => this.handleFocus('end')}
                @blur=${this.handleBlur}
              
              @change="${(e) => e.stopPropagation()}"
/>
              ${overnight ? html `<span class="${this.getIndicatorClasses()}" aria-label="${this.msg.nextDay}">${this.msg.nextDay}</span>` : html ``}
            </div>
          </div>
        </div>
        ${this.loading ? html `<div class="mt-3 text-xs ml-text-muted">${this.msg.loading}</div>` : html ``}
        ${this.renderHelperOrError()}
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return this.isEditing ? this.renderEditMode() : this.renderViewMode();
    }
};
__decorate([
    propertyDataSource({ type: String })
], WorkShiftIntervalMolecule.prototype, "startTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], WorkShiftIntervalMolecule.prototype, "endTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], WorkShiftIntervalMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], WorkShiftIntervalMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], WorkShiftIntervalMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour-12' })
], WorkShiftIntervalMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], WorkShiftIntervalMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], WorkShiftIntervalMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], WorkShiftIntervalMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], WorkShiftIntervalMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], WorkShiftIntervalMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], WorkShiftIntervalMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-overnight' })
], WorkShiftIntervalMolecule.prototype, "allowOvernight", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-time' })
], WorkShiftIntervalMolecule.prototype, "allowSameTime", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], WorkShiftIntervalMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'disabled' })
], WorkShiftIntervalMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'readonly' })
], WorkShiftIntervalMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'required' })
], WorkShiftIntervalMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'loading' })
], WorkShiftIntervalMolecule.prototype, "loading", void 0);
__decorate([
    state()
], WorkShiftIntervalMolecule.prototype, "activeField", void 0);
WorkShiftIntervalMolecule = __decorate([
    customElement('groupentertimeinterval--ml-work-shift-interval')
], WorkShiftIntervalMolecule);
export { WorkShiftIntervalMolecule };
