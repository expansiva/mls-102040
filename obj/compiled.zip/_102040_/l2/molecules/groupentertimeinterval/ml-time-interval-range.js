var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentertimeinterval/ml-time-interval-range.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TIME INTERVAL RANGE MOLECULE
// =============================================================================
// Skill Group: groupEnterTimeInterval
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    label: 'Time Interval',
    labelStart: 'Início',
    labelEnd: 'Fim',
    duration: 'Duração',
    minutes: 'min',
    invalidRange: 'O horário final deve ser posterior ao inicial.',
    required: 'Obrigatório',
    emptyView: '—',
    nextDay: '(+1)',
};
const messages = {
    en: message_en,
    pt: {
        label: 'Intervalo de tempo',
        labelStart: 'Início',
        labelEnd: 'Fim',
        duration: 'Duração',
        minutes: 'min',
        invalidRange: 'O horário final deve ser posterior ao inicial.',
        required: 'Obrigatório',
        emptyView: '—',
        nextDay: '(+1)',
    },
};
/// **collab_i18n_end**
let TimeIntervalRangeMolecule = class TimeIntervalRangeMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.startTime = null;
        this.endTime = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.hour12 = false;
        this.showSeconds = false;
        this.minuteStep = 1;
        this.minTime = '';
        this.maxTime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.allowOvernight = false;
        this.allowSameTime = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.activeField = null;
        this.uid = `tir-${Math.random().toString(36).slice(2)}`;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleStartInput(event) {
        if (this.disabled || this.readonly)
            return;
        const input = event.target;
        this.startTime = input.value ? input.value : null;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startTime },
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { startTime: this.startTime, endTime: this.endTime },
        }));
    }
    handleEndInput(event) {
        if (this.disabled || this.readonly)
            return;
        const input = event.target;
        this.endTime = input.value ? input.value : null;
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endTime },
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { startTime: this.startTime, endTime: this.endTime },
        }));
    }
    handleFocus(field) {
        if (this.disabled)
            return;
        this.activeField = field;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.activeField = null;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ==========================================================================
    // DERIVED HELPERS
    // ==========================================================================
    toMinutes(time) {
        const [h, m] = time.split(':').map(Number);
        return h * 60 + m;
    }
    calcDurationMinutes() {
        if (!this.startTime || !this.endTime)
            return null;
        if (this.allowOvernight && this.isOvernight()) {
            return (24 * 60) - this.toMinutes(this.startTime) + this.toMinutes(this.endTime);
        }
        return this.toMinutes(this.endTime) - this.toMinutes(this.startTime);
    }
    isOvernight() {
        if (!this.startTime || !this.endTime)
            return false;
        return this.allowOvernight && this.toMinutes(this.endTime) < this.toMinutes(this.startTime);
    }
    hasRangeError() {
        if (!this.startTime || !this.endTime)
            return false;
        const duration = this.calcDurationMinutes();
        if (duration === null)
            return false;
        if (!this.allowOvernight) {
            if (this.allowSameTime)
                return duration < 0;
            return duration <= 0;
        }
        if (!this.allowSameTime && this.startTime === this.endTime)
            return true;
        return false;
    }
    hasDurationLimitError() {
        const duration = this.calcDurationMinutes();
        if (duration === null)
            return false;
        if (this.minDurationMinutes > 0 && duration < this.minDurationMinutes)
            return true;
        if (this.maxDurationMinutes > 0 && duration > this.maxDurationMinutes)
            return true;
        return false;
    }
    hasRequiredError() {
        if (!this.required)
            return false;
        return !this.startTime || !this.endTime;
    }
    getValidationError() {
        if (this.error)
            return this.error;
        if (this.hasRequiredError())
            return this.msg.required;
        if (this.hasRangeError())
            return this.msg.invalidRange;
        if (this.hasDurationLimitError())
            return this.msg.invalidRange;
        return '';
    }
    formatTimeDisplay(value) {
        if (!value)
            return this.msg.emptyView;
        if (!this.locale)
            return value;
        const [h, m, s = '00'] = value.split(':');
        const date = new Date();
        date.setHours(Number(h), Number(m), Number(s), 0);
        const formatter = new Intl.DateTimeFormat(this.locale, {
            hour: '2-digit',
            minute: '2-digit',
            second: this.showSeconds ? '2-digit' : undefined,
            hour12: this.hour12,
        });
        return formatter.format(date);
    }
    getInputClasses(isActive, hasError) {
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            hasError
                ? 'border-red-500 dark:border-red-400'
                : isActive
                    ? 'border-sky-500 dark:border-sky-400'
                    : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'bg-slate-50 dark:bg-slate-900' : '',
        ].filter(Boolean).join(' ');
    }
    getWrapperClasses() {
        return [
            'w-full rounded-xl border p-4 transition',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
            this.disabled ? 'opacity-50' : '',
        ].filter(Boolean).join(' ');
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const validationError = this.getValidationError();
        const hasError = Boolean(validationError);
        const startLabelId = `${this.uid}-label-start`;
        const endLabelId = `${this.uid}-label-end`;
        const helperId = `${this.uid}-helper`;
        const errorId = `${this.uid}-error`;
        const duration = this.calcDurationMinutes();
        const durationText = duration === null ? '' : `${duration} ${this.msg.minutes}`;
        return html `
      <div class="${this.getWrapperClasses()}">
        ${this.renderMainLabel()}
        <div class="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div class="flex flex-col gap-2">
            <label id="${startLabelId}" class="text-xs font-medium text-slate-600 dark:text-slate-400">
              ${this.renderLabelStart()}
              ${this.required ? html `<span class="text-red-600 dark:text-red-400">*</span>` : nothing}
            </label>
            <input
              type="time"
              class="${this.getInputClasses(this.activeField === 'start', hasError)}"
              .value=${this.startTime ?? ''}
              step=${this.showSeconds ? 1 : Math.max(60, this.minuteStep * 60)}
              min=${this.minTime || nothing}
              max=${this.maxTime || nothing}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              aria-labelledby=${startLabelId}
              aria-invalid=${hasError ? 'true' : 'false'}
              aria-required=${this.required ? 'true' : 'false'}
              aria-describedby=${hasError ? errorId : this.hasSlot('Helper') ? helperId : nothing}
              @input=${this.handleStartInput}
              @focus=${() => this.handleFocus('start')}
              @blur=${this.handleBlur}
            />
          </div>
          <div class="flex flex-col gap-2">
            <label id="${endLabelId}" class="text-xs font-medium text-slate-600 dark:text-slate-400">
              ${this.renderLabelEnd()}
              ${this.required ? html `<span class="text-red-600 dark:text-red-400">*</span>` : nothing}
            </label>
            <input
              type="time"
              class="${this.getInputClasses(this.activeField === 'end', hasError)}"
              .value=${this.endTime ?? ''}
              step=${this.showSeconds ? 1 : Math.max(60, this.minuteStep * 60)}
              min=${this.minTime || nothing}
              max=${this.maxTime || nothing}
              ?disabled=${this.disabled}
              ?readonly=${this.readonly}
              aria-labelledby=${endLabelId}
              aria-invalid=${hasError ? 'true' : 'false'}
              aria-required=${this.required ? 'true' : 'false'}
              aria-describedby=${hasError ? errorId : this.hasSlot('Helper') ? helperId : nothing}
              @input=${this.handleEndInput}
              @focus=${() => this.handleFocus('end')}
              @blur=${this.handleBlur}
            />
          </div>
        </div>
        <div class="mt-3 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
          <span>${this.msg.duration}</span>
          <span class="text-slate-900 dark:text-slate-100">${durationText || this.msg.emptyView}</span>
        </div>
        ${hasError
            ? html `<p id="${errorId}" class="mt-2 text-xs text-red-600 dark:text-red-400">${unsafeHTML(validationError)}</p>`
            : this.hasSlot('Helper')
                ? html `<p id="${helperId}" class="mt-2 text-xs text-slate-500 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Helper'))}</p>`
                : nothing}
        ${this.loading
            ? html `<div class="mt-2 text-xs text-slate-500 dark:text-slate-400">Loading...</div>`
            : nothing}
      </div>
    `;
    }
    renderMainLabel() {
        if (this.hasSlot('Label')) {
            return html `<div class="mb-3 text-sm font-semibold text-slate-900 dark:text-slate-100">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
        }
        return html `<div class="mb-3 text-sm font-semibold text-slate-900 dark:text-slate-100">${this.msg.label}</div>`;
    }
    renderLabelStart() {
        if (this.hasSlot('LabelStart')) {
            return unsafeHTML(this.getSlotContent('LabelStart'));
        }
        return this.msg.labelStart;
    }
    renderLabelEnd() {
        if (this.hasSlot('LabelEnd')) {
            return unsafeHTML(this.getSlotContent('LabelEnd'));
        }
        return this.msg.labelEnd;
    }
    renderViewMode() {
        const startDisplay = this.formatTimeDisplay(this.startTime);
        const endDisplay = this.formatTimeDisplay(this.endTime);
        const overnight = this.isOvernight();
        const rangeText = `${startDisplay} – ${endDisplay}${overnight ? ` ${this.msg.nextDay}` : ''}`;
        return html `
      <div class="w-full rounded-xl border p-4 bg-white dark:bg-slate-800 border-slate-200 dark:border-slate-700">
        <div class="text-sm font-semibold text-slate-900 dark:text-slate-100">
          ${rangeText.includes(this.msg.emptyView) && !this.startTime && !this.endTime
            ? this.msg.emptyView
            : rangeText}
        </div>
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'start-time' })
], TimeIntervalRangeMolecule.prototype, "startTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'end-time' })
], TimeIntervalRangeMolecule.prototype, "endTime", void 0);
__decorate([
    propertyDataSource({ type: String })
], TimeIntervalRangeMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], TimeIntervalRangeMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], TimeIntervalRangeMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'hour12' })
], TimeIntervalRangeMolecule.prototype, "hour12", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-seconds' })
], TimeIntervalRangeMolecule.prototype, "showSeconds", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], TimeIntervalRangeMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-time' })
], TimeIntervalRangeMolecule.prototype, "minTime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-time' })
], TimeIntervalRangeMolecule.prototype, "maxTime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], TimeIntervalRangeMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], TimeIntervalRangeMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-overnight' })
], TimeIntervalRangeMolecule.prototype, "allowOvernight", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-time' })
], TimeIntervalRangeMolecule.prototype, "allowSameTime", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], TimeIntervalRangeMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalRangeMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalRangeMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalRangeMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], TimeIntervalRangeMolecule.prototype, "loading", void 0);
__decorate([
    state()
], TimeIntervalRangeMolecule.prototype, "activeField", void 0);
TimeIntervalRangeMolecule = __decorate([
    customElement('groupentertimeinterval--ml-time-interval-range')
], TimeIntervalRangeMolecule);
export { TimeIntervalRangeMolecule };
