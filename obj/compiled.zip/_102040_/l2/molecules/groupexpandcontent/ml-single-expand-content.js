/// <mls fileReference="_102040_/l2/molecules/groupexpandcontent/ml-single-expand-content.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SINGLE EXPAND CONTENT MOLECULE
// =============================================================================
// Skill Group: groupExpandContent
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
    },
};
let SingleExpandContentMolecule = class SingleExpandContentMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-single-expand-content .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupexpandcontent--ml-single-expand-content .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-single-expand-content .ml-expand-header {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  transition: background var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-single-expand-content .ml-expand-header:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupexpandcontent--ml-single-expand-content .ml-expand-header:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupexpandcontent--ml-single-expand-content .ml-expand-header-open {
  border-color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface, #ffffff);
}
groupexpandcontent--ml-single-expand-content .ml-expand-content {
  color: var(--ml-on-surface, #1c1b1f);
  background: var(--ml-surface-dim, #f5f5f5);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-single-expand-content .ml-expand-chevron {
  color: var(--ml-on-surface-muted, #49454f);
  transition: transform var(--ml-transition, 200ms ease), color var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-single-expand-content .ml-expand-chevron-open {
  color: var(--ml-primary, #3b82f6);
}
groupexpandcontent--ml-single-expand-content .ml-skeleton {
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: var(--ml-radius-sm, 6px);
}
groupexpandcontent--ml-single-expand-content .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Section'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.multiple = true;
        this.disabled = false;
        this.loading = false;
        this.expanded = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.openSections = new Set();
        this.parsedSections = [];
        this.initialized = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseSections();
        this.initializeExpandedState();
        this.initialized = true;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const expandedAttr = this.getAttribute('expanded');
        if (expandedAttr === `{{${key}}}`) {
            if (value && !this.openSections.has(0)) {
                this.openSections = new Set([0]);
            }
            else if (!value && this.openSections.has(0)) {
                this.openSections = new Set();
            }
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    parseSections() {
        const sectionElements = this.getSlots('Section');
        // Only process the first section as per spec
        const sectionsToProcess = sectionElements.slice(0, 1);
        this.parsedSections = sectionsToProcess.map((el, index) => ({
            index,
            title: el.getAttribute('title') || '',
            disabled: el.hasAttribute('disabled'),
            content: el.innerHTML,
        }));
    }
    initializeExpandedState() {
        const sectionElements = this.getSlots('Section');
        if (sectionElements.length > 0) {
            const firstSection = sectionElements[0];
            // Check both the slot attribute and the component property
            if (firstSection.hasAttribute('expanded') || this.expanded) {
                this.openSections = new Set([0]);
            }
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle(section) {
        if (this.disabled || this.loading || section.disabled)
            return;
        const isCurrentlyOpen = this.openSections.has(section.index);
        const newExpandedState = !isCurrentlyOpen;
        if (newExpandedState) {
            if (this.multiple) {
                this.openSections = new Set([...this.openSections, section.index]);
            }
            else {
                this.openSections = new Set([section.index]);
            }
        }
        else {
            const newSet = new Set(this.openSections);
            newSet.delete(section.index);
            this.openSections = newSet;
        }
        // Update the expanded property to reflect current state
        this.expanded = this.openSections.has(0);
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: {
                index: section.index,
                title: section.title,
                expanded: newExpandedState,
            },
        }));
    }
    handleKeyDown(e, section) {
        if (this.disabled || this.loading || section.disabled)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleToggle(section);
        }
        // Arrow navigation for multiple sections
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const headers = this.querySelectorAll('[role="button"]');
            const currentIndex = Array.from(headers).indexOf(e.target);
            let nextIndex;
            if (e.key === 'ArrowDown') {
                nextIndex = (currentIndex + 1) % headers.length;
            }
            else {
                nextIndex = (currentIndex - 1 + headers.length) % headers.length;
            }
            headers[nextIndex]?.focus();
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getHeaderClasses(section, isExpanded) {
        const isDisabled = this.disabled || section.disabled;
        return [
            'w-full flex items-center justify-between px-4 py-3 text-left transition-all duration-200',
            'ml-expand-header',
            isExpanded ? 'ml-expand-header-open' : '',
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getContentClasses(isExpanded) {
        return [
            'overflow-hidden transition-all duration-300 ease-in-out ml-expand-content',
            isExpanded ? 'max-h-[2000px] opacity-100' : 'max-h-0 opacity-0',
        ].join(' ');
    }
    getContentInnerClasses() {
        return [
            'px-4 py-3 mt-2 ml-expand-content',
        ].join(' ');
    }
    getChevronClasses(isExpanded) {
        return [
            'w-5 h-5 transition-transform duration-200 ml-expand-chevron',
            isExpanded ? 'rotate-180 ml-expand-chevron-open' : 'rotate-0',
        ].join(' ');
    }
    renderChevron(isExpanded) {
        return html `
      <svg
        class="${this.getChevronClasses(isExpanded)}"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
        aria-hidden="true"
      >
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
      </svg>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label')) {
            return html ``;
        }
        const labelContent = this.getSlotContent('Label');
        return html `
      <div class="${cn('mb-3 text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(labelContent)}
      </div>
    `;
    }
    renderLoadingPlaceholder() {
        return html `
      <div class="animate-pulse space-y-3">
        <div class="h-12 ml-skeleton"></div>
        <div class="h-24 ml-skeleton"></div>
      </div>
    `;
    }
    renderSection(section) {
        const isExpanded = this.openSections.has(section.index);
        const isDisabled = this.disabled || section.disabled;
        const headerId = `section-header-${section.index}`;
        const contentId = `section-content-${section.index}`;
        return html `
      <div>
        <div
          id="${headerId}"
          role="button"
          tabindex="${isDisabled ? -1 : 0}"
          aria-expanded="${isExpanded}"
          aria-controls="${contentId}"
          aria-disabled="${isDisabled}"
          class="${this.getHeaderClasses(section, isExpanded)}"
          @click="${() => this.handleToggle(section)}"
          @keydown="${(e) => this.handleKeyDown(e, section)}"
        >
          <span class="text-sm ml-label">${section.title}</span>
          ${this.renderChevron(isExpanded)}
        </div>

        <div
          id="${contentId}"
          role="region"
          aria-labelledby="${headerId}"
          class="${this.getContentClasses(isExpanded)}"
        >
          <div class="${this.getContentInnerClasses()}">
            ${unsafeHTML(section.content)}
          </div>
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel()}
          ${this.renderLoadingPlaceholder()}
        </div>
      `;
        }
        // Re-parse sections if not initialized (for dynamic content)
        if (!this.initialized) {
            this.parseSections();
        }
        return html `
      <div class="${cn('w-full space-y-2', this.cssClass)}">
        ${this.renderLabel()}
        ${this.parsedSections.map(section => this.renderSection(section))}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], SingleExpandContentMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SingleExpandContentMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SingleExpandContentMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SingleExpandContentMolecule.prototype, "expanded", void 0);
__decorate([
    state()
], SingleExpandContentMolecule.prototype, "openSections", void 0);
__decorate([
    state()
], SingleExpandContentMolecule.prototype, "parsedSections", void 0);
__decorate([
    state()
], SingleExpandContentMolecule.prototype, "initialized", void 0);
SingleExpandContentMolecule = __decorate([
    customElement('groupexpandcontent--ml-single-expand-content')
], SingleExpandContentMolecule);
export { SingleExpandContentMolecule };
