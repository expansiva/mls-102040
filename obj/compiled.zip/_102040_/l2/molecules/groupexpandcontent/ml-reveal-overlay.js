var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupexpandcontent/ml-reveal-overlay.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// REVEAL OVERLAY MOLECULE
// =============================================================================
// Skill Group: groupExpandContent
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    reveal: 'Reveal',
    hide: 'Hide',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let RevealOverlayMolecule = class RevealOverlayMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-reveal-overlay .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupexpandcontent--ml-reveal-overlay .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-trigger {
  background: var(--surface-bg, #ffffff);
  color: var(--text-strong, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-small, 6px);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  transition: background var(--transition-fast, 200ms ease), border-color var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-trigger:hover {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-trigger:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-overlay {
  background: var(--ml-surface-overlay, rgba(255, 255, 255, 0.9));
  border-radius: var(--radius-small, 6px);
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-panel {
  background: var(--surface-alt-bg, #f5f5f5);
  color: var(--text-strong, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-small, 6px);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-close {
  background: var(--surface-bg, #ffffff);
  color: var(--text-strong, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-small, 6px);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  transition: background var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-close:hover {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupexpandcontent--ml-reveal-overlay .ml-reveal-close:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupexpandcontent--ml-reveal-overlay .ml-skeleton {
  background: var(--surface-alt-bg, #f5f5f5);
  border-radius: var(--radius-small, 6px);
}
groupexpandcontent--ml-reveal-overlay .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Section'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.multiple = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.openSections = new Set();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        const initial = new Set();
        this.getSlots('Section').forEach((el, index) => {
            if (el.hasAttribute('expanded')) {
                initial.add(index);
            }
        });
        this.openSections = initial;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle(index, title, sectionDisabled) {
        if (this.disabled || sectionDisabled)
            return;
        const next = new Set(this.openSections);
        const isOpen = next.has(index);
        if (isOpen) {
            next.delete(index);
        }
        else {
            if (!this.multiple) {
                next.clear();
            }
            next.add(index);
        }
        this.openSections = next;
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: { index, title, expanded: !isOpen }
        }));
    }
    handleHeaderKeydown(e, index, title, sectionDisabled) {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleToggle(index, title, sectionDisabled);
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const headers = Array.from(this.querySelectorAll('[data-header="true"]'));
            const current = headers.findIndex((el) => Number(el.getAttribute('data-index')) === index);
            if (current === -1)
                return;
            const nextIndex = e.key === 'ArrowDown'
                ? Math.min(headers.length - 1, current + 1)
                : Math.max(0, current - 1);
            headers[nextIndex]?.focus();
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLoading() {
        return html `
<div class="p-4 text-sm ml-skeleton ml-text-muted">
${this.msg.loading}
</div>
`;
    }
    getHeaderClasses(sectionDisabled) {
        return [
            'w-full flex items-center justify-between px-4 py-3 text-sm transition',
            'ml-reveal-trigger',
            (this.disabled || sectionDisabled) ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getContainerClasses(sectionDisabled) {
        return [
            'relative mt-2 ml-reveal-panel',
            (this.disabled || sectionDisabled) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getOverlayClasses(expanded, sectionDisabled) {
        return [
            'absolute inset-0 flex items-center justify-center transition',
            'ml-reveal-overlay',
            'backdrop-blur-sm',
            expanded ? 'opacity-0 pointer-events-none' : 'opacity-100',
            (this.disabled || sectionDisabled) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getActionButtonClasses(sectionDisabled) {
        return [
            'px-4 py-2 text-sm transition',
            'ml-reveal-close',
            (this.disabled || sectionDisabled) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    renderSectionContent(content) {
        return html `
<div class="relative p-4 text-sm ml-reveal-panel">
${unsafeHTML(content)}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        const warning = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const sections = this.getSlots('Section').map((el, index) => ({
            index,
            title: el.getAttribute('title') || '',
            content: el.innerHTML || '',
            sectionDisabled: el.hasAttribute('disabled'),
            expanded: this.openSections.has(index),
        }));
        return html `
<div class="${cn('space-y-4', this.cssClass)}">
${sections.map((section) => {
            const headerId = `reveal-header-${section.index}`;
            const regionId = `reveal-region-${section.index}`;
            const actionLabel = section.expanded
                ? `${this.msg.hide} ${section.title}`
                : `${this.msg.reveal} ${section.title}`;
            return html `
<div>
<button
id=${headerId}
class=${this.getHeaderClasses(section.sectionDisabled)}
role="button"
aria-expanded=${section.expanded ? 'true' : 'false'}
aria-controls=${regionId}
aria-disabled=${(this.disabled || section.sectionDisabled) ? 'true' : 'false'}
data-header="true"
data-index=${section.index}
tabindex=${(this.disabled || section.sectionDisabled) ? '-1' : '0'}
@click=${() => this.handleToggle(section.index, section.title, section.sectionDisabled)}
@keydown=${(e) => this.handleHeaderKeydown(e, section.index, section.title, section.sectionDisabled)}
>
<span>${section.title}</span>
<span class="ml-text-muted">${actionLabel}</span>
</button>
${warning
                ? html `<div class="mt-2 px-4 py-3 text-sm ml-text-muted ml-reveal-panel">${unsafeHTML(warning)}</div>`
                : html ``}
<div
id=${regionId}
class=${this.getContainerClasses(section.sectionDisabled)}
role="region"
aria-labelledby=${headerId}
>
${this.renderSectionContent(section.content)}
<div class=${this.getOverlayClasses(section.expanded, section.sectionDisabled)}>
<button
class=${this.getActionButtonClasses(section.sectionDisabled)}
@click=${() => this.handleToggle(section.index, section.title, section.sectionDisabled)}
?disabled=${this.disabled || section.sectionDisabled}
>
${actionLabel}
</button>
</div>
</div>
</div>
`;
        })}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], RevealOverlayMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], RevealOverlayMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], RevealOverlayMolecule.prototype, "loading", void 0);
__decorate([
    state()
], RevealOverlayMolecule.prototype, "openSections", void 0);
RevealOverlayMolecule = __decorate([
    customElement('groupexpandcontent--ml-reveal-overlay')
], RevealOverlayMolecule);
export { RevealOverlayMolecule };
