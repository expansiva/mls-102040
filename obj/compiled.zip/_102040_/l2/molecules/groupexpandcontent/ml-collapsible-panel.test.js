"use strict";
/// <mls fileReference="_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel.test.ts" enhancement="_blank"/>
