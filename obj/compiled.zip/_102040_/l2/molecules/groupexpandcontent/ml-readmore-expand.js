var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupexpandcontent/ml-readmore-expand.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML READMORE EXPAND MOLECULE
// =============================================================================
// Skill Group: groupExpandContent
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
    },
};
let MlReadmoreExpandMolecule = class MlReadmoreExpandMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-readmore-expand .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupexpandcontent--ml-readmore-expand .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-readmore-expand .ml-readmore-content {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-readmore-expand .ml-readmore-toggle {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  transition: background var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-readmore-expand .ml-readmore-toggle:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupexpandcontent--ml-readmore-expand .ml-readmore-toggle:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupexpandcontent--ml-readmore-expand .ml-readmore-gradient {
  color: var(--ml-on-surface-muted, #49454f);
  transition: transform var(--ml-transition, 200ms ease), color var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-readmore-expand .ml-skeleton {
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: var(--ml-radius-sm, 6px);
}
groupexpandcontent--ml-readmore-expand .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        this.uid = `exp-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================='
        this.slotTags = ['Label', 'Section'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================='
        this.multiple = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================='
        this.openSections = new Set();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        const initialOpen = new Set();
        this.getSlots('Section').forEach((el, index) => {
            if (el.hasAttribute('expanded')) {
                initialOpen.add(index);
            }
        });
        this.openSections = initialOpen;
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle(index, title, sectionDisabled) {
        if (this.disabled || sectionDisabled)
            return;
        const isOpen = this.openSections.has(index);
        let nextOpen = new Set(this.openSections);
        if (isOpen) {
            nextOpen.delete(index);
        }
        else {
            if (!this.multiple) {
                nextOpen = new Set();
            }
            nextOpen.add(index);
        }
        this.openSections = nextOpen;
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: { index, title, expanded: !isOpen }
        }));
    }
    handleKeyDown(e, index, title, sectionDisabled) {
        if (this.disabled)
            return;
        const key = e.key;
        if (key === 'Enter' || key === ' ') {
            e.preventDefault();
            this.handleToggle(index, title, sectionDisabled);
            return;
        }
        if (key === 'ArrowDown' || key === 'ArrowUp') {
            e.preventDefault();
            this.focusNextHeader(key === 'ArrowDown');
        }
    }
    focusNextHeader(forward) {
        const headers = this.getHeaderElements().filter((el) => !el.disabled);
        if (headers.length === 0)
            return;
        const active = document.activeElement;
        const currentIndex = headers.findIndex((el) => el === active);
        const nextIndex = currentIndex === -1
            ? 0
            : (currentIndex + (forward ? 1 : -1) + headers.length) % headers.length;
        headers[nextIndex].focus();
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getHeaderElements() {
        return Array.from(this.querySelectorAll('button[data-index]'));
    }
    getSectionInfo() {
        return this.getSlots('Section').map((el, index) => ({
            index,
            title: el.getAttribute('title') || '',
            disabled: el.hasAttribute('disabled'),
            expanded: this.openSections.has(index),
            content: el.innerHTML || '',
        }));
    }
    getTriggerClasses(expanded, sectionDisabled) {
        return [
            'w-full flex items-center justify-between gap-3 px-4 py-3 text-left transition',
            'ml-readmore-toggle',
            (sectionDisabled || this.disabled) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses(expanded) {
        return [
            'grid transition-all duration-200 ml-readmore-content',
            expanded ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0',
        ].join(' ');
    }
    getPanelInnerClasses() {
        return [
            'overflow-hidden px-4 pb-4 text-sm',
            'ml-readmore-content',
        ].join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const content = this.getSlotContent('Label');
        return html `
<div class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(content)}
</div>
`;
    }
    renderLoading() {
        return html `
<div class="w-full px-4 py-3 text-sm ml-skeleton ml-text-muted">
${this.msg.loading}
</div>
`;
    }
    renderChevron(expanded) {
        const classes = [
            'h-4 w-4 transition-transform ml-readmore-gradient',
            expanded ? 'rotate-180' : 'rotate-0',
        ].join(' ');
        return html `
<svg class="${classes}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
${svg `<path fill-rule="evenodd" d="M5.23 7.21a.75.75 0 0 1 1.06.02L10 10.94l3.71-3.71a.75.75 0 1 1 1.06 1.06l-4.24 4.24a.75.75 0 0 1-1.06 0L5.21 8.29a.75.75 0 0 1 .02-1.08z" clip-rule="evenodd"></path>`}
</svg>
`;
    }
    renderSection(section) {
        const expanded = section.expanded;
        const sectionDisabled = section.disabled || this.disabled;
        const headerId = `${this.uid}-header-${section.index}`;
        const panelId = `${this.uid}-panel-${section.index}`;
        return html `
<div>
<button
class="${this.getTriggerClasses(expanded, sectionDisabled)}"
type="button"
data-index="${section.index}"
?disabled=${sectionDisabled}
aria-expanded="${expanded ? 'true' : 'false'}"
aria-controls="${panelId}"
aria-disabled="${sectionDisabled ? 'true' : 'false'}"
id="${headerId}"
@click=${() => this.handleToggle(section.index, section.title, sectionDisabled)}
@keydown=${(e) => this.handleKeyDown(e, section.index, section.title, sectionDisabled)}
>
<span class="text-sm ml-label">${section.title}</span>
${this.renderChevron(expanded)}
</button>
<div
id="${panelId}"
role="region"
aria-labelledby="${headerId}"
class="${this.getPanelClasses(expanded)}"
>
<div class="${this.getPanelInnerClasses()}">
${unsafeHTML(section.content)}
</div>
</div>
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================='
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const sections = this.getSectionInfo();
        return html `
<div class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
<div class="flex flex-col gap-3">
${this.loading ? this.renderLoading() : sections.map((section) => this.renderSection(section))}
</div>
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlReadmoreExpandMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlReadmoreExpandMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlReadmoreExpandMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlReadmoreExpandMolecule.prototype, "openSections", void 0);
MlReadmoreExpandMolecule = __decorate([
    customElement('groupexpandcontent--ml-readmore-expand')
], MlReadmoreExpandMolecule);
export { MlReadmoreExpandMolecule };
