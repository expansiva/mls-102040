var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupexpandcontent/ml-collapsible-panel.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// COLLAPSIBLE PANEL MOLECULE
// =============================================================================
// Skill Group: groupExpandContent
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlCollapsiblePanelMolecule = class MlCollapsiblePanelMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupexpandcontent--ml-collapsible-panel .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupexpandcontent--ml-collapsible-panel .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-collapsible-panel .ml-panel-header {
  background: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  transition: background var(--ml-transition, 200ms ease), border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-collapsible-panel .ml-panel-header:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupexpandcontent--ml-collapsible-panel .ml-panel-header:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupexpandcontent--ml-collapsible-panel .ml-panel-header-open {
  border-color: var(--ml-primary, #3b82f6);
  background: var(--ml-surface, #ffffff);
}
groupexpandcontent--ml-collapsible-panel .ml-panel-content {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupexpandcontent--ml-collapsible-panel .ml-panel-chevron {
  color: var(--ml-on-surface-muted, #49454f);
  transition: transform var(--ml-transition, 200ms ease), color var(--ml-transition, 200ms ease);
}
groupexpandcontent--ml-collapsible-panel .ml-panel-chevron-open {
  color: var(--ml-primary, #3b82f6);
}
groupexpandcontent--ml-collapsible-panel .ml-skeleton {
  background: var(--ml-surface-dim, #f5f5f5);
  border-radius: var(--ml-radius-sm, 6px);
}
groupexpandcontent--ml-collapsible-panel .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Section'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.multiple = true;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.openSections = new Set();
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.getSlots('Section').forEach((el, index) => {
            if (el.hasAttribute('expanded')) {
                this.openSections.add(index);
            }
        });
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleHeaderClick(index) {
        if (this.loading || this.disabled)
            return;
        const sections = this.getSlots('Section');
        const sectionEl = sections[index];
        if (!sectionEl || sectionEl.hasAttribute('disabled'))
            return;
        const isOpen = this.openSections.has(index);
        if (this.multiple) {
            if (isOpen) {
                this.openSections.delete(index);
            }
            else {
                this.openSections.add(index);
            }
        }
        else {
            this.openSections = new Set(isOpen ? [] : [index]);
        }
        const title = sectionEl.getAttribute('title') || '';
        const expanded = this.openSections.has(index);
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: { index, title, expanded },
        }));
        this.requestUpdate();
    }
    handleHeaderKeydown(event, index) {
        if (this.loading || this.disabled)
            return;
        const key = event.key;
        if (key === 'Enter' || key === ' ') {
            event.preventDefault();
            this.handleHeaderClick(index);
            return;
        }
        if (key === 'ArrowDown' || key === 'ArrowUp') {
            event.preventDefault();
            this.focusAdjacentHeader(index, key === 'ArrowDown' ? 1 : -1);
        }
    }
    focusAdjacentHeader(currentIndex, delta) {
        const headers = Array.from(this.querySelectorAll('[data-header="true"]'));
        if (headers.length === 0)
            return;
        const nextIndex = (currentIndex + delta + headers.length) % headers.length;
        headers[nextIndex]?.focus();
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getSectionContent(el) {
        return el.innerHTML || '';
    }
    getHeaderClasses(isOpen, isDisabled) {
        return [
            'flex w-full items-center justify-between gap-3 px-4 py-3 text-left transition',
            'ml-panel-header',
            isOpen ? 'ml-panel-header-open' : '',
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getChevronClasses(isOpen) {
        return [
            'ml-panel-chevron transition-transform',
            isOpen ? 'rotate-180 ml-panel-chevron-open' : 'rotate-0',
        ].join(' ');
    }
    getContentClasses(isOpen) {
        return [
            'overflow-hidden transition-all duration-300 ease-in-out ml-panel-content',
            isOpen ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel()}
        ${this.loading ? this.renderLoading() : this.renderSections()}
      </div>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderLoading() {
        const items = [0, 1, 2];
        return html `
      <div class="space-y-2" aria-busy="true" aria-live="polite">
        ${items.map(() => html `
            <div
              class="h-12 w-full ml-skeleton animate-pulse"
            ></div>
          `)}
        <div class="sr-only">${this.msg.loading}</div>
      </div>
    `;
    }
    renderSections() {
        const sections = this.getSlots('Section');
        return html `
      <div class="space-y-2">
        ${sections.map((el, index) => {
            const title = el.getAttribute('title') || '';
            const subtitle = el.getAttribute('subtitle') || '';
            const icon = el.getAttribute('icon') || '';
            const isDisabled = this.disabled || el.hasAttribute('disabled');
            const isOpen = this.openSections.has(index);
            const headerId = `${this.localName}-header-${index}`;
            const contentId = `${this.localName}-content-${index}`;
            return html `
            <div class="w-full ml-panel-header" style="border-radius: var(--ml-radius-sm, 6px);">
              <div
                id=${headerId}
                role="button"
                tabindex=${isDisabled ? -1 : 0}
                aria-expanded=${isOpen ? 'true' : 'false'}
                aria-disabled=${isDisabled ? 'true' : 'false'}
                data-header="true"
                class=${this.getHeaderClasses(isOpen, isDisabled)}
                @click=${() => this.handleHeaderClick(index)}
                @keydown=${(e) => this.handleHeaderKeydown(e, index)}
              >
                <div class="flex items-center gap-3">
                  ${icon
                ? html `<span class="ml-text-muted">${unsafeHTML(icon)}</span>`
                : html ``}
                  <div class="flex flex-col">
                    <span class="text-sm ml-label">${title}</span>
                    ${subtitle
                ? html `<span class="text-xs ml-text-muted">${subtitle}</span>`
                : html ``}
                  </div>
                </div>
                <span class=${this.getChevronClasses(isOpen)} aria-hidden="true">
                  <svg viewBox="0 0 20 20" fill="none" class="h-4 w-4">
                    ${svg `<path d="M6 8l4 4 4-4" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />`}
                  </svg>
                </span>
              </div>
              <div
                id=${contentId}
                role="region"
                aria-labelledby=${headerId}
                class=${this.getContentClasses(isOpen)}
              >
                <div class="px-4 pb-4 pt-0 text-sm ml-panel-content">
                  ${unsafeHTML(this.getSectionContent(el))}
                </div>
              </div>
            </div>
          `;
        })}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlCollapsiblePanelMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCollapsiblePanelMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCollapsiblePanelMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlCollapsiblePanelMolecule.prototype, "openSections", void 0);
MlCollapsiblePanelMolecule = __decorate([
    customElement('groupexpandcontent--ml-collapsible-panel')
], MlCollapsiblePanelMolecule);
export { MlCollapsiblePanelMolecule };
