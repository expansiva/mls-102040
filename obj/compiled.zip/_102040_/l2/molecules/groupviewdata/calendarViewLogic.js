/// <mls fileReference="_102040_/l2/molecules/groupviewdata/calendarViewLogic.ts" enhancement="_blank"/>
const DATE_ONLY = /^(\d{4})-(\d{2})-(\d{2})$/u;
const DATE_TIME = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:?\d{2})?$/u;
/** `YYYY-MM-DD` of a date in the local time zone, the one the calendar grid is drawn in. */
export function localDay(date) {
    return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
}
/**
 * The moment of a Row `date` attribute: an ISO 8601 date (`2026-10-07`, an all-day event, no hour) or date-time
 * (`2026-10-07T20:00:00.000Z`, placed on the local day and hour of that instant). Null when absent or unreadable.
 */
export function parseCalendarMoment(value) {
    const text = (value ?? '').trim();
    if (!text)
        return null;
    const dateOnly = DATE_ONLY.exec(text);
    if (dateOnly) {
        const date = new Date(Number(dateOnly[1]), Number(dateOnly[2]) - 1, Number(dateOnly[3]));
        return date.getMonth() === Number(dateOnly[2]) - 1 ? { day: localDay(date) } : null;
    }
    // ISO 8601 only: `new Date('07/10/2026 17:00')` parses too, as July 10 (US order), and would misplace the event.
    if (!DATE_TIME.test(text))
        return null;
    const date = new Date(text);
    if (Number.isNaN(date.getTime()))
        return null;
    return { day: localDay(date), hour: date.getHours() };
}
/** The chip text: the Row `title` attribute, else the visible text of its cells joined by ` · `. */
export function calendarEventTitle(title, cellTexts) {
    const explicit = (title ?? '').trim();
    if (explicit)
        return explicit;
    return cellTexts.map(text => text.replace(/\s+/gu, ' ').trim()).filter(Boolean).join(' · ');
}
