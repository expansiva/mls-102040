var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewdata/ml-card-grid.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML CARD GRID MOLECULE
// =============================================================================
// Skill Group: groupViewData
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No records to display',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhum registro para exibir',
    },
};
let MlCardGridMolecule = class MlCardGridMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewdata--ml-card-grid .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-card-grid .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-card-grid .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-card-grid .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupviewdata--ml-card-grid .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-card-grid .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-card-grid .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-card-grid .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupviewdata--ml-card-grid .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewdata--ml-card-grid .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
groupviewdata--ml-card-grid .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
groupviewdata--ml-card-grid .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
groupviewdata--ml-card-grid .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupviewdata--ml-card-grid .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewdata--ml-card-grid .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewdata--ml-card-grid .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewdata--ml-card-grid .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupviewdata--ml-card-grid .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Columns', 'Column', 'Rows', 'Row', 'Cell', 'Empty', 'Loading'];
        // This molecule TRANSFORMS its slots: it reads Rows > Row > Cell and re-emits each Row as a
        // card. Re-emitting cell content through innerHTML + unsafeHTML killed handlers and bindings,
        // so a button inside a card was dead HTML. With live slots the content is MOVED into the card.
        // Structure is therefore read from the LIVE DOM (getLiveSlot): a projected cell is empty, and a
        // re-snapshot would read it as empty.
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.loading = false;
        this.selectable = false;
        this.hoverable = true;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.selectedIndices = [];
        this.validationDone = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.validateStructure();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleRowActivation(rowIndex, rowElement, isDisabled) {
        if (this.loading || isDisabled)
            return;
        if (this.selectable) {
            const baseSelected = this.selectedIndices.length > 0
                ? new Set(this.selectedIndices)
                : new Set(this.getSelectedFromRows(this.getRowElements()));
            if (baseSelected.has(rowIndex)) {
                baseSelected.delete(rowIndex);
            }
            else {
                baseSelected.add(rowIndex);
            }
            this.selectedIndices = Array.from(baseSelected).sort((a, b) => a - b);
            this.dispatchEvent(new CustomEvent('selection-change', {
                bubbles: true,
                composed: true,
                detail: { selected: this.selectedIndices },
            }));
        }
        this.dispatchEvent(new CustomEvent('row-click', {
            bubbles: true,
            composed: true,
            detail: { index: rowIndex, data: rowElement },
        }));
    }
    // Projected cell content can be interactive (buttons, links, inputs). Their clicks bubble to
    // the card, and must not also toggle selection or fire row-click.
    isFromInteractiveContent(e) {
        const card = e.currentTarget;
        const target = e.target;
        const interactive = target?.closest?.('button, a[href], input, select, textarea, label, [role="button"], [contenteditable="true"]');
        return !!interactive && interactive !== card && card.contains(interactive);
    }
    handleRowClick(e, rowIndex, rowElement, isDisabled) {
        if (this.isFromInteractiveContent(e))
            return;
        this.handleRowActivation(rowIndex, rowElement, isDisabled);
    }
    handleRowKeydown(e, rowIndex, rowElement, isDisabled) {
        if (e.target !== e.currentTarget)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.handleRowActivation(rowIndex, rowElement, isDisabled);
        }
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const columns = this.getColumnDefs();
        const rows = this.getRowElements();
        if (!this.validationDone) {
            this.validateStructure();
            this.validationDone = true;
        }
        if (this.loading) {
            return this.renderLoading();
        }
        if (rows.length === 0) {
            return this.renderEmpty();
        }
        return html `
<div class="${cn('w-full', this.cssClass)}" aria-busy="${this.loading ? 'true' : 'false'}">
${this.renderGrid(rows, columns)}
</div>
`;
    }
    renderLoading() {
        const loadingContent = this.hasSlot('Loading')
            ? this.renderLiveSlot('Loading')
            : html `${this.msg.loading}`;
        return html `
<div class="${cn('w-full rounded-xl border ml-border ml-surface-bg p-6 text-sm ml-text-muted', this.cssClass)}">
${loadingContent}
</div>
`;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty')
            ? this.renderLiveSlot('Empty')
            : html `${this.msg.empty}`;
        return html `
<div class="${cn('w-full rounded-xl border ml-border ml-surface-bg p-6 text-sm ml-text-muted', this.cssClass)}">
${emptyContent}
</div>
`;
    }
    renderGrid(rows, columns) {
        return html `
<div class="grid gap-4 grid-cols-[repeat(auto-fit,minmax(220px,1fr))]">
${rows.map((row, rowIndex) => this.renderCard(row, rowIndex, columns))}
</div>
`;
    }
    renderCard(rowElement, rowIndex, columns) {
        const cells = this.getCellElements(rowElement);
        const isDisabled = this.isTruthyAttr(rowElement.getAttribute('disabled'));
        const isSelected = this.isRowSelected(rowIndex, rowElement);
        const cardClasses = this.getCardClasses(isSelected, isDisabled);
        const tabindex = isDisabled ? -1 : 0;
        return html `
<div
class="${cardClasses}"
role="button"
aria-selected="${isSelected ? 'true' : 'false'}"
aria-disabled="${isDisabled ? 'true' : 'false'}"
tabindex="${tabindex}"
@click=${(e) => this.handleRowClick(e, rowIndex, rowElement, isDisabled)}
@keydown=${(e) => this.handleRowKeydown(e, rowIndex, rowElement, isDisabled)}
>
<div class="grid grid-cols-12 gap-2">
${cells.map((cell, cellIndex) => this.renderCell(cell, cellIndex, columns))}
</div>
</div>
`;
    }
    renderCell(cellElement, cellIndex, columns) {
        const column = columns[cellIndex];
        if (column?.hidden) {
            return html ``;
        }
        const alignClass = column?.align === 'center'
            ? 'text-center'
            : column?.align === 'right'
                ? 'text-right'
                : 'text-left';
        const colspanAttr = cellElement.getAttribute('colspan');
        const colspan = colspanAttr ? Number(colspanAttr) : null;
        const gridSpanStyle = colspan && colspan > 1
            ? `grid-column: span ${colspan} / span ${colspan};`
            : '';
        const widthStyle = column?.width ? `width: ${column.width};` : '';
        const style = `${gridSpanStyle}${widthStyle}`.trim();
        const cellClasses = [
            'col-span-12 text-sm ml-text',
            alignClass,
        ].filter(Boolean).join(' ');
        return html `
<div class="${cellClasses}" style="${style}">
${this.renderLiveSlotFrom(cellElement)}
</div>
`;
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    // Structure comes from the LIVE DOM: always current, and it survives projection — moving a
    // cell's children removes neither the row nor the cell.
    getColumnDefs() {
        const columnsSlot = this.getLiveSlot('Columns');
        if (!columnsSlot)
            return [];
        const columnElements = this.getDirectChildrenByTag(columnsSlot, 'Column');
        return columnElements.map((el) => {
            const field = el.getAttribute('field') || '';
            const header = el.getAttribute('header') || '';
            const width = el.getAttribute('width') || undefined;
            const align = el.getAttribute('align') || undefined;
            const hidden = this.isTruthyAttr(el.getAttribute('hidden'));
            return { field, header, width, align, hidden };
        });
    }
    getRowElements() {
        const rowsSlot = this.getLiveSlot('Rows');
        if (!rowsSlot)
            return [];
        return this.getDirectChildrenByTag(rowsSlot, 'Row');
    }
    getCellElements(rowElement) {
        return this.getDirectChildrenByTag(rowElement, 'Cell');
    }
    getDirectChildrenByTag(parent, tagName) {
        return Array.from(parent.children).filter((child) => child.tagName === tagName.toUpperCase());
    }
    getSelectedFromRows(rows) {
        return rows
            .map((row, index) => (this.isTruthyAttr(row.getAttribute('selected')) ? index : -1))
            .filter((index) => index >= 0);
    }
    isRowSelected(rowIndex, rowElement) {
        if (this.selectedIndices.length > 0) {
            return this.selectedIndices.includes(rowIndex);
        }
        return this.isTruthyAttr(rowElement.getAttribute('selected'));
    }
    isTruthyAttr(value) {
        if (value === null)
            return false;
        if (value.toLowerCase() === 'false')
            return false;
        return true;
    }
    getCardClasses(isSelected, isDisabled) {
        return [
            'rounded-xl border p-4 transition',
            'ml-surface-bg',
            'ml-border',
            'ml-text',
            isSelected
                ? 'ml-primary-dim-bg ml-border-focus'
                : '',
            this.hoverable && !isDisabled && !isSelected
                ? 'hover:ml-surface-dim-bg'
                : '',
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
            '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // VALIDATION
    // ===========================================================================
    validateStructure() {
        const columnsSlot = this.getLiveSlot('Columns');
        const rowsSlot = this.getLiveSlot('Rows');
        if (!columnsSlot) {
            console.error('Missing required slot <Columns>');
        }
        if (!rowsSlot) {
            console.error('Missing required slot <Rows>');
        }
        const columnElements = columnsSlot ? this.getDirectChildrenByTag(columnsSlot, 'Column') : [];
        if (columnsSlot && columnElements.length === 0) {
            console.error('At least 1 <Column> is required inside <Columns>');
        }
        columnElements.forEach((col) => {
            if (!col.getAttribute('field')) {
                console.error('<Column> requires attribute"field"');
            }
            if (!col.getAttribute('header')) {
                console.error('<Column> requires attribute"header"');
            }
        });
        this.validateUnknownTags(columnsSlot, rowsSlot);
    }
    validateUnknownTags(columnsSlot, rowsSlot) {
        const allowedRoot = new Set(['COLUMNS', 'ROWS', 'EMPTY', 'LOADING']);
        Array.from(this.children).forEach((child) => {
            if (!allowedRoot.has(child.tagName)) {
                console.warn(`Unknown slot <${child.tagName}> ignored`);
            }
        });
        if (columnsSlot) {
            Array.from(columnsSlot.children).forEach((child) => {
                if (child.tagName !== 'COLUMN') {
                    console.warn(`Unknown slot <${child.tagName}> ignored`);
                }
            });
        }
        if (rowsSlot) {
            Array.from(rowsSlot.children).forEach((child) => {
                if (child.tagName !== 'ROW') {
                    console.warn(`Unknown slot <${child.tagName}> ignored`);
                }
                if (child.tagName === 'ROW') {
                    Array.from(child.children).forEach((rowChild) => {
                        if (rowChild.tagName !== 'CELL') {
                            console.warn(`Unknown slot <${rowChild.tagName}> ignored`);
                        }
                    });
                }
            });
        }
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardGridMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardGridMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlCardGridMolecule.prototype, "hoverable", void 0);
__decorate([
    state()
], MlCardGridMolecule.prototype, "selectedIndices", void 0);
MlCardGridMolecule = __decorate([
    customElement('groupviewdata--ml-card-grid')
], MlCardGridMolecule);
export { MlCardGridMolecule };
