/// <mls fileReference="_102040_/l2/molecules/groupviewdata/ml-calendar-view.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CALENDAR VIEW MOLECULE
// =============================================================================
// Skill Group: groupViewData
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, property, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No events to display',
    moreEvents: '+{count} more',
    monthView: 'Month',
    weekView: 'Week',
    sunday: 'Sun',
    monday: 'Mon',
    tuesday: 'Tue',
    wednesday: 'Wed',
    thursday: 'Thu',
    friday: 'Fri',
    saturday: 'Sat',
    today: 'Today',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhum evento para exibir',
        moreEvents: '+{count} mais',
        monthView: 'Mês',
        weekView: 'Semana',
        sunday: 'Dom',
        monday: 'Seg',
        tuesday: 'Ter',
        wednesday: 'Qua',
        thursday: 'Qui',
        friday: 'Sex',
        saturday: 'Sáb',
        today: 'Hoje',
    },
};
let CalendarViewMolecule = class CalendarViewMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewdata--ml-calendar-view .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-calendar-view .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-calendar-view .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-calendar-view .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewdata--ml-calendar-view .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-calendar-view .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-calendar-view .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-calendar-view .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewdata--ml-calendar-view .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewdata--ml-calendar-view .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupviewdata--ml-calendar-view .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewdata--ml-calendar-view .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewdata--ml-calendar-view .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewdata--ml-calendar-view .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewdata--ml-calendar-view .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewdata--ml-calendar-view .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewdata--ml-calendar-view .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewdata--ml-calendar-view .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Columns', 'Column', 'Rows', 'Row', 'Cell', 'Empty', 'Loading'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.loading = false;
        this.selectable = false;
        this.hoverable = true;
        this.name = '';
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.viewMode = 'month';
        this.currentDate = new Date();
        this.parsedColumns = [];
        this.parsedRows = [];
        this.MAX_EVENTS_PER_DAY = 3;
        this.HOURS_IN_DAY = 24;
        this.DAYS_IN_WEEK = 7;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseSlotContent();
    }
    updated(changedProperties) {
        if (changedProperties.has('loading')) {
            this.parseSlotContent();
        }
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    parseSlotContent() {
        this.parsedColumns = this.parseColumns();
        this.parsedRows = this.parseRows();
    }
    parseColumns() {
        const columnsSlot = this.getSlot('Columns');
        if (!columnsSlot)
            return [];
        const columnElements = Array.from(columnsSlot.querySelectorAll('Column'));
        return columnElements.map((col) => ({
            field: col.getAttribute('field') || '',
            header: col.getAttribute('header') || '',
            width: col.getAttribute('width') || undefined,
            align: col.getAttribute('align') || 'left',
            hidden: col.hasAttribute('hidden'),
        }));
    }
    parseRows() {
        const rowsSlot = this.getSlot('Rows');
        if (!rowsSlot)
            return [];
        const rowElements = Array.from(rowsSlot.querySelectorAll('Row'));
        return rowElements.map((row) => {
            const cellElements = Array.from(row.querySelectorAll('Cell'));
            const cells = cellElements.map((cell) => ({
                content: cell.innerHTML.trim(),
                colspan: cell.hasAttribute('colspan') ? parseInt(cell.getAttribute('colspan') || '1', 10) : undefined,
            }));
            return {
                cells,
                selected: row.hasAttribute('selected'),
                disabled: row.hasAttribute('disabled'),
                element: row,
            };
        });
    }
    // ===========================================================================
    // CALENDAR HELPERS
    // ===========================================================================
    getWeekDays() {
        return [
            this.msg.sunday,
            this.msg.monday,
            this.msg.tuesday,
            this.msg.wednesday,
            this.msg.thursday,
            this.msg.friday,
            this.msg.saturday,
        ];
    }
    getMonthDays() {
        const year = this.currentDate.getFullYear();
        const month = this.currentDate.getMonth();
        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const today = new Date();
        const weeks = [];
        let currentWeek = [];
        // Fill in days from previous month
        const startDayOfWeek = firstDay.getDay();
        for (let i = startDayOfWeek - 1; i >= 0; i--) {
            const date = new Date(year, month, -i);
            currentWeek.push({
                date,
                isCurrentMonth: false,
                isToday: this.isSameDay(date, today),
                events: this.getEventsForDate(date),
            });
        }
        // Fill in days of current month
        for (let day = 1; day <= lastDay.getDate(); day++) {
            const date = new Date(year, month, day);
            currentWeek.push({
                date,
                isCurrentMonth: true,
                isToday: this.isSameDay(date, today),
                events: this.getEventsForDate(date),
            });
            if (currentWeek.length === 7) {
                weeks.push(currentWeek);
                currentWeek = [];
            }
        }
        // Fill in days from next month
        if (currentWeek.length > 0) {
            let nextMonthDay = 1;
            while (currentWeek.length < 7) {
                const date = new Date(year, month + 1, nextMonthDay++);
                currentWeek.push({
                    date,
                    isCurrentMonth: false,
                    isToday: this.isSameDay(date, today),
                    events: this.getEventsForDate(date),
                });
            }
            weeks.push(currentWeek);
        }
        return weeks;
    }
    getWeekDates() {
        const today = new Date();
        const startOfWeek = new Date(this.currentDate);
        startOfWeek.setDate(this.currentDate.getDate() - this.currentDate.getDay());
        const days = [];
        for (let i = 0; i < this.DAYS_IN_WEEK; i++) {
            const date = new Date(startOfWeek);
            date.setDate(startOfWeek.getDate() + i);
            days.push({
                date,
                isCurrentMonth: date.getMonth() === this.currentDate.getMonth(),
                isToday: this.isSameDay(date, today),
                events: this.getEventsForDate(date),
            });
        }
        return days;
    }
    isSameDay(date1, date2) {
        return (date1.getFullYear() === date2.getFullYear() &&
            date1.getMonth() === date2.getMonth() &&
            date1.getDate() === date2.getDate());
    }
    getEventsForDate(date) {
        const events = [];
        const dateStr = this.formatDateString(date);
        this.parsedRows.forEach((row, rowIndex) => {
            row.cells.forEach((cell, cellIndex) => {
                // Check if cell content contains the date
                if (cell.content.includes(dateStr) || cell.content.includes(date.toISOString().split('T')[0])) {
                    // Extract title from cell content
                    const titleMatch = cell.content.match(/title["']?\s*[:=]\s*["']?([^"'<>]+)/i);
                    const title = titleMatch ? titleMatch[1].trim() : cell.content.replace(/<[^>]*>/g, '').trim();
                    // Extract hour if present
                    const hourMatch = cell.content.match(/hour["']?\s*[:=]\s*["']?(\d+)/i);
                    const hour = hourMatch ? parseInt(hourMatch[1], 10) : undefined;
                    events.push({
                        title: title || 'Event',
                        date: dateStr,
                        hour,
                        rowIndex,
                        cellIndex,
                    });
                }
            });
        });
        return events;
    }
    formatDateString(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    getMonthYearLabel() {
        return this.currentDate.toLocaleDateString(undefined, { month: 'long', year: 'numeric' });
    }
    formatHour(hour) {
        const period = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour % 12 || 12;
        return `${displayHour} ${period}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleViewModeChange(mode) {
        this.viewMode = mode;
    }
    handlePrevious() {
        const newDate = new Date(this.currentDate);
        if (this.viewMode === 'month') {
            newDate.setMonth(newDate.getMonth() - 1);
        }
        else {
            newDate.setDate(newDate.getDate() - 7);
        }
        this.currentDate = newDate;
    }
    handleNext() {
        const newDate = new Date(this.currentDate);
        if (this.viewMode === 'month') {
            newDate.setMonth(newDate.getMonth() + 1);
        }
        else {
            newDate.setDate(newDate.getDate() + 7);
        }
        this.currentDate = newDate;
    }
    handleToday() {
        this.currentDate = new Date();
    }
    handleEventClick(event, e) {
        e.stopPropagation();
        const row = this.parsedRows[event.rowIndex];
        if (row?.disabled)
            return;
        this.dispatchEvent(new CustomEvent('row-click', {
            bubbles: true,
            composed: true,
            detail: { index: event.rowIndex, data: row?.element },
        }));
    }
    handleCellClick(day, hour) {
        this.dispatchEvent(new CustomEvent('row-click', {
            bubbles: true,
            composed: true,
            detail: {
                index: -1,
                data: {
                    date: day.date,
                    hour,
                    isEmpty: true,
                },
            },
        }));
    }
    // ===========================================================================
    // STYLES
    // ===========================================================================
    getContainerClasses() {
        return [
            'w-full rounded-lg border overflow-hidden',
            'ml-surface-bg',
            'ml-border',
        ].join(' ');
    }
    getHeaderClasses() {
        return [
            'flex items-center justify-between p-4 border-b',
            'ml-surface-dim-bg',
            'ml-border',
        ].join(' ');
    }
    getViewToggleClasses(isActive) {
        return [
            'px-3 py-1.5 text-sm font-medium rounded-md transition-colors',
            isActive
                ? 'ml-primary-bg'
                : 'ml-surface-bg ml-text-muted hover:ml-surface-dim-bg',
            'border ml-border',
        ].join(' ');
    }
    getNavButtonClasses() {
        return [
            'p-2 rounded-md transition-colors',
            'ml-text-muted',
            'hover:ml-surface-dim-bg',
            '',
        ].join(' ');
    }
    getTodayButtonClasses() {
        return [
            'px-3 py-1.5 text-sm font-medium rounded-md transition-colors',
            'ml-surface-bg',
            'ml-text-muted',
            'border ml-border',
            'hover:ml-surface-dim-bg',
        ].join(' ');
    }
    getWeekDayHeaderClasses() {
        return [
            'py-2 text-center text-xs font-semibold uppercase tracking-wider',
            'ml-text-muted',
            'ml-surface-dim-bg',
            'border-b ml-border',
        ].join(' ');
    }
    getDayCellClasses(day) {
        return [
            'min-h-[100px] p-1 border-b border-r cursor-pointer transition-colors',
            'ml-border',
            day.isCurrentMonth
                ? 'ml-surface-bg'
                : 'ml-surface-dim-bg',
            this.hoverable ? 'hover:ml-surface-dim-bg' : '',
        ].join(' ');
    }
    getDayNumberClasses(day) {
        return [
            'inline-flex items-center justify-center w-7 h-7 text-sm font-medium rounded-full',
            day.isToday
                ? 'ml-primary-bg'
                : day.isCurrentMonth
                    ? 'ml-text'
                    : 'ml-text-faint',
        ].join(' ');
    }
    getEventChipClasses(rowIndex) {
        const row = this.parsedRows[rowIndex];
        const isSelected = row?.selected || false;
        const isDisabled = row?.disabled || false;
        return [
            'block w-full px-2 py-0.5 mb-0.5 text-xs rounded truncate transition-colors',
            isDisabled
                ? 'ml-surface-dim-bg ml-text-faint cursor-not-allowed opacity-50'
                : isSelected
                    ? 'ml-primary-bg cursor-pointer'
                    : 'ml-primary-dim-bg ml-primary-text hover:ml-surface-dim-bg cursor-pointer',
        ].join(' ');
    }
    getMoreEventsClasses() {
        return [
            'text-xs font-medium mt-1',
            'ml-text-muted',
        ].join(' ');
    }
    getHourCellClasses() {
        return [
            'h-12 border-b border-r relative cursor-pointer transition-colors',
            'ml-border',
            'ml-surface-bg',
            this.hoverable ? 'hover:ml-surface-dim-bg' : '',
        ].join(' ');
    }
    getHourLabelClasses() {
        return [
            'w-16 h-12 flex items-start justify-end pr-2 pt-1 text-xs border-b border-r',
            'ml-text-muted',
            'ml-surface-dim-bg',
            'ml-border',
        ].join(' ');
    }
    getWeekHeaderCellClasses(day) {
        return [
            'flex-1 py-2 text-center border-b border-r',
            'ml-border',
            'ml-surface-dim-bg',
        ].join(' ');
    }
    getWeekHeaderDateClasses(day) {
        return [
            'inline-flex items-center justify-center w-8 h-8 text-sm font-semibold rounded-full',
            day.isToday
                ? 'ml-primary-bg'
                : 'ml-text',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER METHODS
    // ===========================================================================
    renderHeader() {
        return html `
 <div class=${this.getHeaderClasses()}>
 <div class="flex items-center gap-2">
 <button
 type="button"
 class=${this.getNavButtonClasses()}
 @click=${this.handlePrevious}
 aria-label="Previous"
 >
 ${this.renderChevronLeft()}
 </button>
 <button
 type="button"
 class=${this.getNavButtonClasses()}
 @click=${this.handleNext}
 aria-label="Next"
 >
 ${this.renderChevronRight()}
 </button>
 <button
 type="button"
 class=${this.getTodayButtonClasses()}
 @click=${this.handleToday}
 >
 ${this.msg.today}
 </button>
 <h2 class="ml-4 text-lg font-semibold ml-text">
 ${this.getMonthYearLabel()}
 </h2>
 </div>
 <div class="flex items-center gap-1">
 <button
 type="button"
 class=${this.getViewToggleClasses(this.viewMode === 'month')}
 @click=${() => this.handleViewModeChange('month')}
 >
 ${this.msg.monthView}
 </button>
 <button
 type="button"
 class=${this.getViewToggleClasses(this.viewMode === 'week')}
 @click=${() => this.handleViewModeChange('week')}
 >
 ${this.msg.weekView}
 </button>
 </div>
 </div>
 `;
    }
    renderChevronLeft() {
        return html `
 <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
 ${svg `<path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd" />`}
 </svg>
 `;
    }
    renderChevronRight() {
        return html `
 <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
 ${svg `<path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd" />`}
 </svg>
 `;
    }
    renderMonthView() {
        const weeks = this.getMonthDays();
        const weekDays = this.getWeekDays();
        return html `
 <div class="w-full">
 <div class="grid grid-cols-7">
 ${weekDays.map((day) => html `
 <div class=${this.getWeekDayHeaderClasses()}>${day}</div>
 `)}
 </div>
 <div class="grid grid-cols-7">
 ${weeks.map((week) => week.map((day) => this.renderMonthDayCell(day)))}
 </div>
 </div>
 `;
    }
    renderMonthDayCell(day) {
        const visibleEvents = day.events.slice(0, this.MAX_EVENTS_PER_DAY);
        const hiddenCount = day.events.length - this.MAX_EVENTS_PER_DAY;
        return html `
 <div
 class=${this.getDayCellClasses(day)}
 @click=${() => this.handleCellClick(day)}
 >
 <div class="flex justify-end mb-1">
 <span class=${this.getDayNumberClasses(day)}>
 ${day.date.getDate()}
 </span>
 </div>
 <div class="space-y-0.5">
 ${visibleEvents.map((event) => html `
 <button
 type="button"
 class=${this.getEventChipClasses(event.rowIndex)}
 @click=${(e) => this.handleEventClick(event, e)}
 title=${event.title}
 ?disabled=${this.parsedRows[event.rowIndex]?.disabled}
 aria-selected=${this.parsedRows[event.rowIndex]?.selected ? 'true' : 'false'}
 aria-disabled=${this.parsedRows[event.rowIndex]?.disabled ? 'true' : 'false'}
 >
 ${event.title}
 </button>
 `)}
 ${hiddenCount > 0
            ? html `
 <div class=${this.getMoreEventsClasses()}>
 ${this.msg.moreEvents.replace('{count}', String(hiddenCount))}
 </div>
 `
            : html ``}
 </div>
 </div>
 `;
    }
    renderWeekView() {
        const weekDays = this.getWeekDates();
        const dayNames = this.getWeekDays();
        const hours = Array.from({ length: this.HOURS_IN_DAY }, (_, i) => i);
        return html `
 <div class="w-full overflow-auto">
 <div class="flex">
 <div class="w-16 flex-shrink-0"></div>
 ${weekDays.map((day, index) => html `
 <div class=${this.getWeekHeaderCellClasses(day)} style="flex: 1;">
 <div class="text-xs ml-text-muted mb-1">
 ${dayNames[index]}
 </div>
 <span class=${this.getWeekHeaderDateClasses(day)}>
 ${day.date.getDate()}
 </span>
 </div>
 `)}
 </div>
 <div class="flex flex-col">
 ${hours.map((hour) => this.renderWeekHourRow(hour, weekDays))}
 </div>
 </div>
 `;
    }
    renderWeekHourRow(hour, weekDays) {
        return html `
 <div class="flex">
 <div class=${this.getHourLabelClasses()}>
 ${this.formatHour(hour)}
 </div>
 ${weekDays.map((day) => this.renderWeekHourCell(day, hour))}
 </div>
 `;
    }
    renderWeekHourCell(day, hour) {
        const eventsAtHour = day.events.filter((e) => e.hour === hour);
        return html `
 <div
 class=${this.getHourCellClasses()}
 style="flex: 1;"
 @click=${() => this.handleCellClick(day, hour)}
 >
 ${eventsAtHour.map((event) => html `
 <button
 type="button"
 class=${this.getEventChipClasses(event.rowIndex)}
 @click=${(e) => this.handleEventClick(event, e)}
 title=${event.title}
 ?disabled=${this.parsedRows[event.rowIndex]?.disabled}
 aria-selected=${this.parsedRows[event.rowIndex]?.selected ? 'true' : 'false'}
 aria-disabled=${this.parsedRows[event.rowIndex]?.disabled ? 'true' : 'false'}
 >
 ${event.title}
 </button>
 `)}
 </div>
 `;
    }
    renderLoading() {
        const loadingContent = this.getSlotContent('Loading');
        if (loadingContent) {
            return html `
 <div class="flex items-center justify-center p-8">
 ${unsafeHTML(loadingContent)}
 </div>
 `;
        }
        return html `
 <div class="flex items-center justify-center p-8">
 <div class="flex items-center gap-2 ml-text-muted">
 <svg class="w-5 h-5 animate-spin" viewBox="0 0 24 24" fill="none">
 ${svg `
 <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
 <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
 `}
 </svg>
 <span>${this.msg.loading}</span>
 </div>
 </div>
 `;
    }
    renderEmpty() {
        const emptyContent = this.getSlotContent('Empty');
        if (emptyContent) {
            return html `
 <div class="flex items-center justify-center p-8 ml-text-muted">
 ${unsafeHTML(emptyContent)}
 </div>
 `;
        }
        return html `
 <div class="flex items-center justify-center p-8 ml-text-muted">
 ${this.msg.empty}
 </div>
 `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.parseSlotContent();
        if (this.loading) {
            return html `
 <div class=${cn(this.getContainerClasses(), this.cssClass)} aria-busy="true">
 ${this.renderHeader()}
 ${this.renderLoading()}
 </div>
 `;
        }
        const hasRows = this.parsedRows.length > 0;
        return html `
 <div class=${cn(this.getContainerClasses(), this.cssClass)} aria-busy="false">
 ${this.renderHeader()}
 ${hasRows
            ? this.viewMode === 'month'
                ? this.renderMonthView()
                : this.renderWeekView()
            : this.renderEmpty()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], CalendarViewMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CalendarViewMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CalendarViewMolecule.prototype, "hoverable", void 0);
__decorate([
    property({ type: String })
], CalendarViewMolecule.prototype, "name", void 0);
__decorate([
    state()
], CalendarViewMolecule.prototype, "viewMode", void 0);
__decorate([
    state()
], CalendarViewMolecule.prototype, "currentDate", void 0);
__decorate([
    state()
], CalendarViewMolecule.prototype, "parsedColumns", void 0);
__decorate([
    state()
], CalendarViewMolecule.prototype, "parsedRows", void 0);
CalendarViewMolecule = __decorate([
    customElement('groupviewdata--ml-calendar-view')
], CalendarViewMolecule);
export { CalendarViewMolecule };
