/// <mls fileReference="_102040_/l2/molecules/groupviewdata/ml-kanban-board.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// KANBAN BOARD MOLECULE
// =============================================================================
// Skill Group: groupViewData
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No items to display',
    addCard: 'Add card',
    dropHere: 'Drop here',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Nenhum item para exibir',
        addCard: 'Adicionar cartão',
        dropHere: 'Solte aqui',
    },
};
let MlKanbanBoardMolecule = class MlKanbanBoardMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewdata--ml-kanban-board .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-kanban-board .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-kanban-board .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-kanban-board .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupviewdata--ml-kanban-board .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-kanban-board .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-kanban-board .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewdata--ml-kanban-board .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupviewdata--ml-kanban-board .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewdata--ml-kanban-board .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
groupviewdata--ml-kanban-board .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
groupviewdata--ml-kanban-board .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
groupviewdata--ml-kanban-board .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupviewdata--ml-kanban-board .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewdata--ml-kanban-board .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewdata--ml-kanban-board .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewdata--ml-kanban-board .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupviewdata--ml-kanban-board .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupviewdata--ml-kanban-board .ml-spinner-border {
  border-top-color: var(--button-primary-bg, #3b82f6);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Columns', 'Column', 'Rows', 'Row', 'Cell', 'Empty', 'Loading'];
        // This molecule TRANSFORMS its slots: it reads Columns > Column and Rows > Row > Cell and
        // re-emits them as board columns and cards. Re-emitting content through innerHTML + unsafeHTML
        // killed handlers and bindings, so a button inside a card was dead HTML. With live slots the
        // content is MOVED into the card. Structure is therefore read from the LIVE DOM (getLiveSlot):
        // a projected cell is empty, and a re-snapshot would read it as empty.
        this.usesLiveSlots = true;
        // Whether a source element has content, remembered from before projection — afterwards its
        // innerHTML is empty and can no longer answer.
        this.contentPresence = new WeakMap();
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.loading = false;
        this.selectable = false;
        this.hoverable = true;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.selectedIndices = [];
        this.draggedCard = null;
        this.dropTargetRowIndex = null;
        this.parsedColumns = [];
        this.parsedRows = [];
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseSlotContent();
    }
    updated(changedProperties) {
        if (changedProperties.has('loading')) {
            this.parseSlotContent();
        }
    }
    // ===========================================================================
    // PARSING
    // ===========================================================================
    hasSourceContent(el) {
        if (el.dataset.mlLiveSource) {
            return this.contentPresence.get(el) ?? true;
        }
        const has = el.innerHTML.trim() !== '';
        this.contentPresence.set(el, has);
        return has;
    }
    parseSlotContent() {
        this.parsedColumns = this.parseColumns();
        this.parsedRows = this.parseRows();
    }
    parseColumns() {
        const columnsSlot = this.getLiveSlot('Columns');
        if (!columnsSlot)
            return [];
        const columnElements = Array.from(columnsSlot.querySelectorAll('Column'));
        return columnElements
            .map((col) => {
            const field = col.getAttribute('field') || '';
            const header = col.getAttribute('header') || '';
            const width = col.getAttribute('width') || 'auto';
            const alignAttr = col.getAttribute('align');
            const align = alignAttr === 'center' || alignAttr === 'right' ? alignAttr : 'left';
            const hidden = col.hasAttribute('hidden');
            const hasContent = this.hasSourceContent(col);
            return { field, header, width, align, hidden, element: col, hasContent };
        })
            .filter((col) => !col.hidden);
    }
    parseRows() {
        const rowsSlot = this.getLiveSlot('Rows');
        if (!rowsSlot)
            return [];
        const rowElements = Array.from(rowsSlot.querySelectorAll('Row'));
        return rowElements.map((row, index) => {
            const selected = row.hasAttribute('selected');
            const disabled = row.hasAttribute('disabled');
            const cellElements = Array.from(row.querySelectorAll('Cell'));
            const cells = cellElements.map((cell) => {
                const colspanAttr = cell.getAttribute('colspan');
                const colspan = colspanAttr ? parseInt(colspanAttr, 10) : 1;
                const isAddAction = cell.hasAttribute('add-action');
                const hasContent = this.hasSourceContent(cell);
                return { element: cell, hasContent, colspan, isAddAction };
            });
            return { element: row, index, selected, disabled, cells };
        });
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    // Projected cell content can be interactive (buttons, links, inputs). Their clicks bubble to
    // the card, and must not also toggle selection or fire row-click.
    isFromInteractiveContent(e) {
        const cardEl = e.currentTarget;
        const target = e.target;
        const interactive = target?.closest?.('button, a[href], input, select, textarea, label, [role="button"], [contenteditable="true"]');
        return !!interactive && interactive !== cardEl && cardEl.contains(interactive);
    }
    handleRowClick(e, rowIndex, cellElement) {
        if (this.isFromInteractiveContent(e))
            return;
        const row = this.parsedRows[rowIndex];
        if (!row || row.disabled)
            return;
        if (this.selectable) {
            this.toggleSelection(rowIndex);
        }
        this.dispatchEvent(new CustomEvent('row-click', {
            bubbles: true,
            composed: true,
            detail: { index: rowIndex, data: cellElement },
        }));
    }
    toggleSelection(rowIndex) {
        const idx = this.selectedIndices.indexOf(rowIndex);
        if (idx === -1) {
            this.selectedIndices = [...this.selectedIndices, rowIndex];
        }
        else {
            this.selectedIndices = this.selectedIndices.filter((i) => i !== rowIndex);
        }
        this.dispatchEvent(new CustomEvent('selection-change', {
            bubbles: true,
            composed: true,
            detail: { selected: this.selectedIndices },
        }));
    }
    handleDragStart(e, rowIndex, cellIndex, cell) {
        if (cell.isAddAction) {
            e.preventDefault();
            return;
        }
        const row = this.parsedRows[rowIndex];
        if (row.disabled) {
            e.preventDefault();
            return;
        }
        this.draggedCard = { rowIndex, cellIndex, element: cell.element };
        if (e.dataTransfer) {
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/plain', `${rowIndex}-${cellIndex}`);
        }
    }
    handleDragOver(e, rowIndex) {
        const row = this.parsedRows[rowIndex];
        if (row.disabled || !this.draggedCard) {
            return;
        }
        e.preventDefault();
        if (e.dataTransfer) {
            e.dataTransfer.dropEffect = 'move';
        }
        this.dropTargetRowIndex = rowIndex;
    }
    handleDragLeave() {
        this.dropTargetRowIndex = null;
    }
    handleDrop(e, rowIndex) {
        e.preventDefault();
        this.dropTargetRowIndex = null;
        const row = this.parsedRows[rowIndex];
        if (row.disabled || !this.draggedCard) {
            this.draggedCard = null;
            return;
        }
        if (this.draggedCard.rowIndex !== rowIndex) {
            this.dispatchEvent(new CustomEvent('row-click', {
                bubbles: true,
                composed: true,
                detail: { index: rowIndex, data: this.draggedCard.element },
            }));
        }
        this.draggedCard = null;
    }
    handleDragEnd() {
        this.draggedCard = null;
        this.dropTargetRowIndex = null;
    }
    handleAddCardClick(e, rowIndex, cell) {
        if (this.isFromInteractiveContent(e))
            return;
        const row = this.parsedRows[rowIndex];
        if (row.disabled)
            return;
        this.dispatchEvent(new CustomEvent('row-click', {
            bubbles: true,
            composed: true,
            detail: { index: rowIndex, data: cell.element },
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getColumnHeaderClasses() {
        return [
            'flex-shrink-0 p-3 rounded-t-lg',
            'ml-surface-dim-bg',
            'border-b ml-border',
        ].join(' ');
    }
    getColumnClasses(isDropTarget) {
        return [
            'flex flex-col flex-shrink-0 w-72 min-h-96',
            'ml-surface-dim-bg',
            'border ml-border',
            'rounded-lg',
            isDropTarget ? 'ml-focus-ring' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCardClasses(row, isDragging) {
        const isSelected = this.selectedIndices.includes(row.index) || row.selected;
        return [
            'p-3 rounded-lg border transition-all cursor-grab',
            'ml-surface-bg',
            isSelected
                ? 'ml-border-focus ml-primary-dim-bg'
                : 'ml-border',
            row.disabled ? 'ml-disabled' : '',
            !row.disabled && this.hoverable ? 'hover:shadow-md hover:ml-border' : '',
            isDragging ? 'opacity-50 scale-95' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getAddCardClasses(disabled) {
        return [
            'flex items-center justify-center gap-2 p-3 rounded-lg border-2 border-dashed transition-all cursor-pointer',
            'ml-border',
            'ml-text-muted',
            disabled ? 'ml-disabled' : 'hover:ml-border-focus hover:ml-primary-text',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getDropZoneClasses() {
        return [
            'flex items-center justify-center p-4 rounded-lg border-2 border-dashed',
            'ml-border-focus',
            'ml-primary-dim-bg',
            'ml-primary-text',
            'text-sm font-medium',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        this.parseSlotContent();
        if (this.loading) {
            return this.renderLoading();
        }
        if (this.parsedRows.length === 0) {
            return this.renderEmpty();
        }
        return this.renderBoard();
    }
    renderLoading() {
        const content = this.hasSlot('Loading')
            ? this.renderLiveSlot('Loading')
            : html `${this.msg.loading}`;
        return html `
 <div
 class="${cn('flex items-center justify-center min-h-96 ml-surface-dim-bg rounded-lg border ml-border', this.cssClass)}"
 aria-busy="true"
 >
 <div class="flex flex-col items-center gap-3 ml-text-muted">
 <div class="w-8 h-8 border-4 ml-border ml-spinner-border rounded-full animate-spin"></div>
 <span class="text-sm">${content}</span>
 </div>
 </div>
 `;
    }
    renderEmpty() {
        const content = this.hasSlot('Empty')
            ? this.renderLiveSlot('Empty')
            : html `${this.msg.empty}`;
        return html `
 <div
 class="${cn('flex items-center justify-center min-h-96 ml-surface-dim-bg rounded-lg border ml-border', this.cssClass)}"
 >
 <div class="ml-text-muted text-sm">
 ${content}
 </div>
 </div>
 `;
    }
    renderBoard() {
        return html `
 <div class="${cn('flex gap-4 overflow-x-auto p-4 ml-surface-dim-bg rounded-lg min-h-96', this.cssClass)}">
 ${this.parsedColumns.map((column, colIndex) => this.renderColumn(column, colIndex))}
 </div>
 `;
    }
    renderColumn(column, colIndex) {
        const row = this.parsedRows[colIndex];
        const isDropTarget = this.dropTargetRowIndex === colIndex;
        const columnClasses = this.getColumnClasses(isDropTarget);
        const isSelected = this.selectedIndices.includes(colIndex) || !!row?.selected;
        return html `
 <div
 class=${columnClasses}
 style="width: ${column.width !== 'auto' ? column.width : '18rem'}"
 @dragover=${(e) => this.handleDragOver(e, colIndex)}
 @dragleave=${this.handleDragLeave}
 @drop=${(e) => this.handleDrop(e, colIndex)}
 aria-disabled=${ifDefined(row?.disabled ? 'true' : undefined)}
 aria-selected=${ifDefined(isSelected ? 'true' : undefined)}
 >
 ${this.renderColumnHeader(column)}
 ${this.renderColumnContent(row, colIndex, isDropTarget)}
 </div>
 `;
    }
    renderColumnHeader(column) {
        const headerClasses = this.getColumnHeaderClasses();
        return html `
 <div class=${headerClasses}>
 <div class="flex items-center justify-between">
 <h3 class="font-semibold ml-text text-sm">
 ${column.header}
 </h3>
 ${column.hasContent
            ? html `<div class="text-xs ml-text-muted">${this.renderLiveSlotFrom(column.element)}</div>`
            : html ``}
 </div>
 </div>
 `;
    }
    renderColumnContent(row, colIndex, isDropTarget) {
        if (!row) {
            return html `
 <div class="flex-1 p-3">
 <div class="ml-text-faint text-sm text-center py-4">
 ${this.msg.empty}
 </div>
 </div>
 `;
        }
        const cards = row.cells.filter((cell) => !cell.isAddAction);
        const addActionCell = row.cells.find((cell) => cell.isAddAction);
        return html `
 <div class="flex-1 flex flex-col gap-2 p-3 overflow-y-auto">
 ${isDropTarget && this.draggedCard
            ? html `<div class=${this.getDropZoneClasses()}>${this.msg.dropHere}</div>`
            : html ``}
 ${cards.map((cell, cellIndex) => this.renderCard(row, cell, colIndex, cellIndex))}
 ${addActionCell ? this.renderAddCard(row, addActionCell, colIndex) : html ``}
 </div>
 `;
    }
    renderCard(row, cell, rowIndex, cellIndex) {
        const isDragging = this.draggedCard?.rowIndex === rowIndex && this.draggedCard?.cellIndex === cellIndex;
        const cardClasses = this.getCardClasses(row, isDragging);
        return html `
 <div
 class=${cardClasses}
 draggable=${row.disabled ? 'false' : 'true'}
 @dragstart=${(e) => this.handleDragStart(e, rowIndex, cellIndex, cell)}
 @dragend=${this.handleDragEnd}
 @click=${(e) => this.handleRowClick(e, rowIndex, cell.element)}
 >
 <div class="ml-text text-sm">
 ${this.renderLiveSlotFrom(cell.element)}
 </div>
 </div>
 `;
    }
    renderAddCard(row, cell, rowIndex) {
        const addCardClasses = this.getAddCardClasses(row.disabled);
        return html `
 <div
 class=${addCardClasses}
 @click=${(e) => this.handleAddCardClick(e, rowIndex, cell)}
 >
 <svg
 class="w-4 h-4"
 fill="none"
 stroke="currentColor"
 viewBox="0 0 24 24"
 xmlns="http://www.w3.org/2000/svg"
 >
 <path
 stroke-linecap="round"
 stroke-linejoin="round"
 stroke-width="2"
 d="M12 4v16m8-8H4"
 ></path>
 </svg>
 <span class="text-sm font-medium">
 ${cell.hasContent ? this.renderLiveSlotFrom(cell.element) : this.msg.addCard}
 </span>
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlKanbanBoardMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlKanbanBoardMolecule.prototype, "selectable", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlKanbanBoardMolecule.prototype, "hoverable", void 0);
__decorate([
    state()
], MlKanbanBoardMolecule.prototype, "selectedIndices", void 0);
__decorate([
    state()
], MlKanbanBoardMolecule.prototype, "draggedCard", void 0);
__decorate([
    state()
], MlKanbanBoardMolecule.prototype, "dropTargetRowIndex", void 0);
__decorate([
    state()
], MlKanbanBoardMolecule.prototype, "parsedColumns", void 0);
__decorate([
    state()
], MlKanbanBoardMolecule.prototype, "parsedRows", void 0);
MlKanbanBoardMolecule = __decorate([
    customElement('groupviewdata--ml-kanban-board')
], MlKanbanBoardMolecule);
export { MlKanbanBoardMolecule };
