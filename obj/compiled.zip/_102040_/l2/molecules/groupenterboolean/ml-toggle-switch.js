var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupenterboolean/ml-toggle-switch.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TOGGLE SWITCH MOLECULE
// =============================================================================
// Skill Group: groupEnterBoolean
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    yes: 'Yes',
    no: 'No',
};
const messages = {
    en: message_en,
    pt: {
        yes: 'Sim',
        no: 'Não',
    },
};
/// **collab_i18n_end**
let ToggleSwitchMolecule = class ToggleSwitchMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterboolean--ml-toggle-switch .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupenterboolean--ml-toggle-switch .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupenterboolean--ml-toggle-switch .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupenterboolean--ml-toggle-switch .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupenterboolean--ml-toggle-switch .ml-toggle-track {
  background: var(--border-default, #e2e8f0);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--border-default, #e2e8f0);
  border-radius: var(--radius-pill, 9999px);
  transition: background var(--transition-fast, 200ms ease), border-color var(--transition-fast, 200ms ease);
}
groupenterboolean--ml-toggle-switch .ml-toggle-track:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupenterboolean--ml-toggle-switch .ml-toggle-track-on {
  background: var(--button-primary-bg, #3b82f6);
  border-color: var(--selected-border, #3b82f6);
}
groupenterboolean--ml-toggle-switch .ml-toggle-track-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupenterboolean--ml-toggle-switch .ml-toggle-thumb {
  background: var(--surface-bg, #ffffff);
  border-radius: var(--radius-pill, 9999px);
  transition: transform var(--transition-fast, 200ms ease);
  box-shadow: var(--shadow-small, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupenterboolean--ml-toggle-switch .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        this.uid = `toggle-${Math.random().toString(36).slice(2, 9)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = false;
        this.error = '';
        this.name = '';
        this.isEditing = true;
        this.disabled = false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle() {
        if (!this.isEditing || this.disabled)
            return;
        this.value = !this.value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleFocus() {
        if (!this.isEditing || this.disabled)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleBlur() {
        if (!this.isEditing || this.disabled)
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    handleKeydown(event) {
        if (!this.isEditing || this.disabled)
            return;
        if (event.key === ' ' || event.key === 'Spacebar' || event.key === 'Enter') {
            event.preventDefault();
            this.handleToggle();
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div id=${labelId || ''} class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderHelper(helperId) {
        if (!this.hasSlot('Helper'))
            return html ``;
        if (this.error)
            return html ``;
        return html `
      <div id=${helperId || ''} class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">
        ${unsafeHTML(this.getSlotContent('Helper'))}
      </div>
    `;
    }
    renderError(errorId) {
        if (!this.error)
            return html ``;
        return html `
      <div id=${errorId || ''} class="mt-2 text-xs ml-error-text">
        ${unsafeHTML(String(this.error))}
      </div>
    `;
    }
    getToggleButtonClasses() {
        return [
            'relative inline-flex h-6 w-11 items-center',
            'ml-toggle-track',
            this.value ? 'ml-toggle-track-on' : '',
            this.error ? 'ml-toggle-track-error' : '',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getThumbClasses() {
        return [
            'inline-block h-4 w-4 transform ml-toggle-thumb',
            this.value ? 'translate-x-6' : 'translate-x-1',
        ].join(' ');
    }
    renderViewMode() {
        const labelId = this.hasSlot('Label') ? `${this.uid}-label` : undefined;
        const viewValue = this.value ? this.msg.yes : this.msg.no;
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel(labelId)}
        <div class="text-sm ml-text">${viewValue}</div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const labelId = this.hasSlot('Label') ? `${this.uid}-label` : undefined;
        const helperId = this.hasSlot('Helper') ? `${this.uid}-helper` : undefined;
        const errorId = this.error ? `${this.uid}-error` : undefined;
        const describedBy = this.error ? errorId : helperId;
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel(labelId)}
        <button
          type="button"
          class=${this.getToggleButtonClasses()}
          role="switch"
          aria-checked=${this.value ? 'true' : 'false'}
          aria-labelledby=${labelId || undefined}
          aria-describedby=${describedBy || undefined}
          aria-invalid=${this.error ? 'true' : 'false'}
          aria-disabled=${this.disabled ? 'true' : 'false'}
          ?disabled=${this.disabled}
          tabindex=${this.disabled ? -1 : 0}
          @click=${this.handleToggle}
          @focus=${this.handleFocus}
          @blur=${this.handleBlur}
          @keydown=${this.handleKeydown}
        >
          <span class=${this.getThumbClasses()}></span>
        </button>
        ${this.renderError(errorId)}
        ${this.renderHelper(helperId)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], ToggleSwitchMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], ToggleSwitchMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], ToggleSwitchMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], ToggleSwitchMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'disabled' })
], ToggleSwitchMolecule.prototype, "disabled", void 0);
ToggleSwitchMolecule = __decorate([
    customElement('groupenterboolean--ml-toggle-switch')
], ToggleSwitchMolecule);
export { ToggleSwitchMolecule };
