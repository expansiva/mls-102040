var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var CheckboxPreferenceMolecule_1;
/// <mls fileReference="_102040_/l2/molecules/groupenterboolean/ml-checkbox-preference.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// CHECKBOX PREFERENCE MOLECULE
// =============================================================================
// Skill Group: groupEnterBoolean
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    yes: 'Yes',
    no: 'No',
};
const messages = {
    en: message_en,
    pt: {
        yes: 'Sim',
        no: 'Não',
    },
};
/// **collab_i18n_end**
let CheckboxPreferenceMolecule = CheckboxPreferenceMolecule_1 = class CheckboxPreferenceMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = false;
        this.error = '';
        this.name = '';
        this.isEditing = true;
        this.disabled = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.inputId = `chk-${CheckboxPreferenceMolecule_1.nextId++}`;
        this.labelId = `lbl-${CheckboxPreferenceMolecule_1.nextId++}`;
        this.helperId = `hlp-${CheckboxPreferenceMolecule_1.nextId++}`;
        this.errorId = `err-${CheckboxPreferenceMolecule_1.nextId++}`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggle(e) {
        if (!this.isEditing || this.disabled)
            return;
        e.stopPropagation();
        const input = e.target;
        this.value = input.checked;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    handleFocus() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        if (!this.isEditing)
            return;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label
id=${this.labelId}
for=${this.inputId}
class="text-sm font-medium text-slate-900 dark:text-slate-100"
>
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `
<p id=${this.errorId} class="mt-1 text-xs text-red-600 dark:text-red-400">
${unsafeHTML(String(this.error))}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p id=${this.helperId} class="mt-1 text-xs text-slate-500 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    getCheckboxClasses() {
        return [
            'h-4 w-4 rounded border transition cursor-pointer',
            'bg-white dark:bg-slate-900',
            'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            'checked:bg-sky-600 checked:border-sky-600 dark:checked:bg-sky-400 dark:checked:border-sky-400',
            this.error ? 'border-red-500 dark:border-red-400' : '',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `
<div class="w-full">
${this.hasSlot('Label') ? html `
<div class="mb-1">
${this.renderLabel()}
</div>
` : html ``}
<div class="text-sm text-slate-900 dark:text-slate-100">
${this.value ? this.msg.yes : this.msg.no}
</div>
</div>
`;
        }
        const describedBy = this.error
            ? this.errorId
            : (this.hasSlot('Helper') ? this.helperId : '');
        return html `
<div class="w-full">
<div class="flex items-start gap-3">
<input
id=${this.inputId}
class=${this.getCheckboxClasses()}
name=${this.name}
type="checkbox"
?checked=${this.value}
?disabled=${this.disabled}
aria-labelledby=${this.hasSlot('Label') ? this.labelId : ''}
aria-describedby=${describedBy}
aria-invalid=${this.error ? 'true' : 'false'}
aria-disabled=${this.disabled ? 'true' : 'false'}
@change=${this.handleToggle}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
/>
<div class="flex-1">
${this.renderLabel()}
${this.renderHelperOrError()}
</div>
</div>
</div>
`;
    }
};
CheckboxPreferenceMolecule.nextId = 0;
__decorate([
    propertyDataSource({ type: Boolean })
], CheckboxPreferenceMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], CheckboxPreferenceMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], CheckboxPreferenceMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], CheckboxPreferenceMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], CheckboxPreferenceMolecule.prototype, "disabled", void 0);
__decorate([
    state()
], CheckboxPreferenceMolecule.prototype, "inputId", void 0);
__decorate([
    state()
], CheckboxPreferenceMolecule.prototype, "labelId", void 0);
__decorate([
    state()
], CheckboxPreferenceMolecule.prototype, "helperId", void 0);
__decorate([
    state()
], CheckboxPreferenceMolecule.prototype, "errorId", void 0);
CheckboxPreferenceMolecule = CheckboxPreferenceMolecule_1 = __decorate([
    customElement('groupenterboolean--ml-checkbox-preference')
], CheckboxPreferenceMolecule);
export { CheckboxPreferenceMolecule };
