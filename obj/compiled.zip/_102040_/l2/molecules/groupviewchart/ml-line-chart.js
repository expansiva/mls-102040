/// <mls fileReference="_102040_/l2/molecules/groupviewchart/ml-line-chart.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// LINE CHART MOLECULE
// =============================================================================
// Skill Group: groupViewChart
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    noData: 'No data available',
    loading: 'Loading chart...',
    chartLabel: 'Line chart',
    dataPoint: 'Data point',
};
const messages = {
    en: message_en,
    pt: {
        noData: 'Nenhum dado disponível',
        loading: 'Carregando gráfico...',
        chartLabel: 'Gráfico de linhas',
        dataPoint: 'Ponto de dados',
    },
};
const DEFAULT_COLORS = [
    '#0ea5e9', // sky-500
    '#8b5cf6', // violet-500
    '#f59e0b', // amber-500
    '#10b981', // emerald-500
    '#ef4444', // red-500
    '#ec4899', // pink-500
    '#06b6d4', // cyan-500
    '#84cc16', // lime-500
];
let MlLineChartMolecule = class MlLineChartMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewchart--ml-line-chart .ml-chart-container {
  background: var(--surface-bg, #fff);
  border-color: var(--border-default, #e2e8f0);
}
groupviewchart--ml-line-chart .ml-chart-legend {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewchart--ml-line-chart .ml-chart-tooltip {
  background: var(--ml-on-surface, #1c1b1f);
  color: var(--ml-surface, #fff);
}
groupviewchart--ml-line-chart .ml-chart-tooltip-detail {
  opacity: 0.7;
}
groupviewchart--ml-line-chart .ml-chart-axis {
  fill: var(--text-muted, #49454f);
  stroke: var(--border-default, #e2e8f0);
}
groupviewchart--ml-line-chart .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupviewchart--ml-line-chart .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Series', 'Point', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.showLegend = true;
        this.showValues = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.tooltip = null;
        // ===========================================================================
        // CHART DIMENSIONS
        // ===========================================================================
        this.chartWidth = 600;
        this.chartHeight = 300;
        this.padding = { top: 20, right: 30, bottom: 50, left: 60 };
    }
    // ===========================================================================
    // DATA PARSING
    // ===========================================================================
    parseData() {
        const seriesElements = this.getSlots('Series');
        const standalonePoints = this.getSlots('Point').filter((p) => !p.closest('Series'));
        const series = [];
        const allLabelsSet = new Set();
        // Parse series with nested points
        seriesElements.forEach((seriesEl, index) => {
            const name = seriesEl.getAttribute('name') || `Series ${index + 1}`;
            const color = seriesEl.getAttribute('color') || DEFAULT_COLORS[index % DEFAULT_COLORS.length];
            const pointElements = Array.from(seriesEl.querySelectorAll('Point'));
            const points = [];
            pointElements.forEach((pointEl) => {
                const label = pointEl.getAttribute('label') || '';
                const valueStr = pointEl.getAttribute('value');
                const value = valueStr ? parseFloat(valueStr) : 0;
                if (label) {
                    points.push({ label, value });
                    allLabelsSet.add(label);
                }
            });
            if (points.length > 0) {
                series.push({ name, color, points });
            }
        });
        // Parse standalone points as a single series
        if (standalonePoints.length > 0) {
            const points = [];
            standalonePoints.forEach((pointEl) => {
                const label = pointEl.getAttribute('label') || '';
                const valueStr = pointEl.getAttribute('value');
                const value = valueStr ? parseFloat(valueStr) : 0;
                const color = pointEl.getAttribute('color') || undefined;
                if (label) {
                    points.push({ label, value, color });
                    allLabelsSet.add(label);
                }
            });
            if (points.length > 0) {
                series.push({
                    name: 'Data',
                    color: DEFAULT_COLORS[0],
                    points,
                });
            }
        }
        // Preserve order of labels as they appear
        const allLabels = [];
        series.forEach((s) => {
            s.points.forEach((p) => {
                if (!allLabels.includes(p.label)) {
                    allLabels.push(p.label);
                }
            });
        });
        return { series, allLabels };
    }
    calculateScale(series) {
        let min = Infinity;
        let max = -Infinity;
        series.forEach((s) => {
            s.points.forEach((p) => {
                if (p.value < min)
                    min = p.value;
                if (p.value > max)
                    max = p.value;
            });
        });
        if (min === Infinity) {
            min = 0;
            max = 100;
        }
        // Add padding to scale
        const range = max - min || 1;
        const paddingAmount = range * 0.1;
        min = Math.floor(min - paddingAmount);
        max = Math.ceil(max + paddingAmount);
        // Generate ticks
        const tickCount = 5;
        const step = (max - min) / (tickCount - 1);
        const ticks = [];
        for (let i = 0; i < tickCount; i++) {
            ticks.push(Math.round(min + step * i));
        }
        return { min, max, ticks };
    }
    // ===========================================================================
    // COORDINATE HELPERS
    // ===========================================================================
    getX(index, totalLabels) {
        const plotWidth = this.chartWidth - this.padding.left - this.padding.right;
        if (totalLabels <= 1)
            return this.padding.left + plotWidth / 2;
        return this.padding.left + (index / (totalLabels - 1)) * plotWidth;
    }
    getY(value, min, max) {
        const plotHeight = this.chartHeight - this.padding.top - this.padding.bottom;
        const range = max - min || 1;
        return this.padding.top + plotHeight - ((value - min) / range) * plotHeight;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handlePointMouseEnter(e, point, seriesName) {
        const target = e.target;
        const rect = target.getBoundingClientRect();
        const containerRect = this.getBoundingClientRect();
        this.tooltip = {
            label: point.label,
            value: point.value,
            series: seriesName,
            x: rect.left - containerRect.left + rect.width / 2,
            y: rect.top - containerRect.top - 10,
        };
    }
    handlePointMouseLeave() {
        this.tooltip = null;
    }
    handlePointClick(point, seriesName) {
        this.dispatchEvent(new CustomEvent('pointClick', {
            bubbles: true,
            composed: true,
            detail: {
                label: point.label,
                value: point.value,
                series: seriesName,
            },
        }));
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLoading() {
        const classes = cn('flex items-center justify-center', 'w-full h-64', 'ml-chart-container', 'rounded-lg', 'animate-pulse');
        return html `
      <div class=${classes}>
        <div class="flex flex-col items-center gap-2">
          <div class="w-8 h-8 border-2 ml-chart-axis border-t-transparent rounded-full animate-spin"></div>
          <span class="text-sm ml-text-muted">${this.msg.loading}</span>
        </div>
      </div>
    `;
    }
    renderEmpty() {
        const content = this.hasSlot('Empty')
            ? this.getSlotContent('Empty')
            : this.msg.noData;
        const classes = cn('flex items-center justify-center', 'w-full h-64', 'ml-chart-container', 'rounded-lg', 'ml-text-muted', 'text-sm');
        return html `
      <div class=${classes}>
        ${unsafeHTML(content)}
      </div>
    `;
    }
    renderGridLines(ticks, min, max) {
        return html `
      ${ticks.map((tick) => {
            const y = this.getY(tick, min, max);
            return svg `
          <line
            x1=${this.padding.left}
            y1=${y}
            x2=${this.chartWidth - this.padding.right}
            y2=${y}
            class="ml-chart-axis"
            stroke-width="1"
            stroke-dasharray="4,4"
          />
        `;
        })}
    `;
    }
    renderYAxis(ticks, min, max) {
        return html `
      ${ticks.map((tick) => {
            const y = this.getY(tick, min, max);
            return svg `
          <text
            x=${this.padding.left - 10}
            y=${y}
            text-anchor="end"
            dominant-baseline="middle"
            class="ml-chart-axis text-xs"
          >${tick}</text>
        `;
        })}
    `;
    }
    renderXAxis(labels) {
        return html `
      ${labels.map((label, index) => {
            const x = this.getX(index, labels.length);
            const y = this.chartHeight - this.padding.bottom + 20;
            return svg `
          <text
            x=${x}
            y=${y}
            text-anchor="middle"
            class="ml-chart-axis text-xs"
          >${label}</text>
        `;
        })}
    `;
    }
    renderLine(series, allLabels, min, max) {
        const pathData = series.points
            .map((point, index) => {
            const labelIndex = allLabels.indexOf(point.label);
            const x = this.getX(labelIndex, allLabels.length);
            const y = this.getY(point.value, min, max);
            return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
        })
            .join(' ');
        return svg `
      <path
        d=${pathData}
        fill="none"
        stroke=${series.color}
        stroke-width="2"
        stroke-linecap="round"
        stroke-linejoin="round"
      />
    `;
    }
    renderPoints(series, allLabels, min, max) {
        return html `
      ${series.points.map((point) => {
            const labelIndex = allLabels.indexOf(point.label);
            const x = this.getX(labelIndex, allLabels.length);
            const y = this.getY(point.value, min, max);
            const pointColor = point.color || series.color;
            return svg `
          <circle
            cx=${x}
            cy=${y}
            r="6"
            fill=${pointColor}
            class="cursor-pointer transition-all hover:r-8"
            stroke="white"
            stroke-width="2"
            role="button"
            aria-label="${this.msg.dataPoint}: ${point.label}, ${point.value}"
            tabindex="0"
            @mouseenter=${(e) => this.handlePointMouseEnter(e, point, series.name)}
            @mouseleave=${() => this.handlePointMouseLeave()}
            @click=${() => this.handlePointClick(point, series.name)}
            @keydown=${(e) => {
                if (e.key === 'Enter' || e.key === ' ') {
                    this.handlePointClick(point, series.name);
                }
            }}
          />
          ${this.showValues
                ? svg `
              <text
                x=${x}
                y=${y - 12}
                text-anchor="middle"
                class="ml-chart-axis text-xs font-medium pointer-events-none"
              >${point.value}</text>
            `
                : ''}
        `;
        })}
    `;
    }
    renderTooltip() {
        if (!this.tooltip)
            return html ``;
        const classes = cn('absolute z-10 px-3 py-2 rounded-lg shadow-lg', 'ml-chart-tooltip', 'text-xs', 'pointer-events-none', 'transform -translate-x-1/2 -translate-y-full');
        return html `
      <div
        class=${classes}
        style="left: ${this.tooltip.x}px; top: ${this.tooltip.y}px;"
      >
        <div class="font-medium">${this.tooltip.label}</div>
        <div class="ml-chart-tooltip-detail">
          ${this.tooltip.series ? `${this.tooltip.series}: ` : ''}${this.tooltip.value}
        </div>
      </div>
    `;
    }
    renderLegend(series) {
        if (!this.showLegend || series.length === 0)
            return html ``;
        const classes = [
            'flex flex-wrap justify-center gap-4 mt-4',
        ].join(' ');
        return html `
      <div class=${classes}>
        ${series.map((s) => {
            const itemClasses = cn('flex items-center gap-2 text-sm', 'ml-chart-legend');
            return html `
            <div class=${itemClasses}>
              <span
                class="w-3 h-3 rounded-full"
                style="background-color: ${s.color};"
              ></span>
              <span>${s.name}</span>
            </div>
          `;
        })}
      </div>
    `;
    }
    renderAccessibleTable(series, allLabels) {
        return html `
      <table class="sr-only">
        <caption>${this.hasSlot('Label') ? this.getSlotContent('Label') : this.msg.chartLabel}</caption>
        <thead>
          <tr>
            <th scope="col">Category</th>
            ${series.map((s) => html `<th scope="col">${s.name}</th>`)}
          </tr>
        </thead>
        <tbody>
          ${allLabels.map((label) => html `
            <tr>
              <th scope="row">${label}</th>
              ${series.map((s) => {
            const point = s.points.find((p) => p.label === label);
            return html `<td>${point ? point.value : '-'}</td>`;
        })}
            </tr>
          `)}
        </tbody>
      </table>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        const { series, allLabels } = this.parseData();
        if (series.length === 0 || allLabels.length === 0) {
            return this.renderEmpty();
        }
        const { min, max, ticks } = this.calculateScale(series);
        const labelContent = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const containerClasses = cn('relative w-full', 'ml-chart-container', 'rounded-lg p-4', 'border', this.cssClass);
        const titleClasses = cn('text-lg font-semibold text-center mb-4', 'ml-label', this.getSlotClass('Label'));
        return html `
      <div class=${containerClasses}>
        ${labelContent
            ? html `<div class=${titleClasses}>${unsafeHTML(labelContent)}</div>`
            : ''}

        <div class="relative">
          <svg
            viewBox="0 0 ${this.chartWidth} ${this.chartHeight}"
            class="w-full h-auto"
            role="img"
            aria-label=${labelContent || this.msg.chartLabel}
          >
            ${this.renderGridLines(ticks, min, max)}
            ${this.renderYAxis(ticks, min, max)}
            ${this.renderXAxis(allLabels)}
            ${series.map((s) => this.renderLine(s, allLabels, min, max))}
            ${series.map((s) => this.renderPoints(s, allLabels, min, max))}
          </svg>

          ${this.renderTooltip()}
        </div>

        ${this.renderLegend(series)}
        ${this.renderAccessibleTable(series, allLabels)}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-legend' })
], MlLineChartMolecule.prototype, "showLegend", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-values' })
], MlLineChartMolecule.prototype, "showValues", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlLineChartMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlLineChartMolecule.prototype, "tooltip", void 0);
MlLineChartMolecule = __decorate([
    customElement('groupviewchart--ml-line-chart')
], MlLineChartMolecule);
export { MlLineChartMolecule };
