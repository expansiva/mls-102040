/// <mls fileReference="_102040_/l2/molecules/groupviewchart/ml-bar-chart.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// BAR CHART MOLECULE
// =============================================================================
// Skill Group: groupViewChart
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading chart...',
    empty: 'No data available',
    chartLabel: 'Bar chart',
    legend: 'Legend',
    value: 'Value',
    label: 'Label',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando gráfico...',
        empty: 'Nenhum dado disponível',
        chartLabel: 'Gráfico de barras',
        legend: 'Legenda',
        value: 'Valor',
        label: 'Rótulo',
    },
};
let MlBarChartMolecule = class MlBarChartMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewchart--ml-bar-chart .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewchart--ml-bar-chart .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewchart--ml-bar-chart .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewchart--ml-bar-chart .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewchart--ml-bar-chart .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewchart--ml-bar-chart .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupviewchart--ml-bar-chart .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewchart--ml-bar-chart .ml-chart-legend {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Series', 'Point', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.showLegend = true;
        this.showValues = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.tooltip = null;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handlePointMouseEnter(point, event) {
        const target = event.currentTarget;
        const container = this.querySelector('[data-chart-container]');
        if (!container || !target)
            return;
        const rect = target.getBoundingClientRect();
        const containerRect = container.getBoundingClientRect();
        const left = rect.left - containerRect.left + rect.width / 2;
        const top = rect.top - containerRect.top - 8;
        this.tooltip = {
            label: point.label,
            value: point.value,
            series: point.series,
            left,
            top,
        };
    }
    handlePointMouseLeave() {
        this.tooltip = null;
    }
    handlePointClick(point) {
        this.dispatchEvent(new CustomEvent('pointClick', {
            bubbles: true,
            composed: true,
            detail: {
                label: point.label,
                value: point.value,
                series: point.series,
            },
        }));
    }
    handlePointKeyDown(point, event) {
        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            this.handlePointClick(point);
        }
    }
    // ===========================================================================
    // DATA PARSING
    // ===========================================================================
    parsePoint(el, seriesName, seriesColor) {
        const label = el.getAttribute('label') || '';
        const rawValue = el.getAttribute('value') || '0';
        const value = Number(rawValue);
        const color = el.getAttribute('color') || undefined;
        return {
            label,
            value: Number.isNaN(value) ? 0 : value,
            color,
            series: seriesName,
            seriesColor,
        };
    }
    readSeries() {
        const seriesElements = this.getSlots('Series');
        return seriesElements.map((seriesEl) => {
            const name = seriesEl.getAttribute('name') || '';
            const color = seriesEl.getAttribute('color') || undefined;
            const points = Array.from(seriesEl.querySelectorAll('Point')).map((pointEl) => this.parsePoint(pointEl, name, color));
            return { name, color, points };
        });
    }
    readStandalonePoints() {
        const pointElements = this.getSlots('Point');
        const rootPoints = pointElements.filter((pointEl) => pointEl.parentElement?.tagName !== 'SERIES');
        return rootPoints.map((pointEl) => this.parsePoint(pointEl));
    }
    getCategories(series, points) {
        if (series.length > 0) {
            const labels = [];
            series.forEach((s) => {
                s.points.forEach((p) => {
                    if (!labels.includes(p.label))
                        labels.push(p.label);
                });
            });
            return labels;
        }
        return points.map((p) => p.label);
    }
    getMaxValue(series, points) {
        const values = [];
        series.forEach((s) => s.points.forEach((p) => values.push(p.value)));
        points.forEach((p) => values.push(p.value));
        return Math.max(0, ...values);
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div class="${cn('mb-2 text-sm font-semibold ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderLoading() {
        return html `
<div class="mt-4 flex flex-col gap-3 animate-pulse">
<div class="h-4 w-1/3 rounded ml-surface-dim-bg"></div>
<div class="h-40 w-full rounded ml-surface-dim-bg"></div>
<div class="h-4 w-1/2 rounded ml-surface-dim-bg"></div>
<span class="text-xs ml-text-muted">${this.msg.loading}</span>
</div>
`;
    }
    renderEmpty() {
        const content = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
        return html `
<div class="${cn('mt-4 rounded-md border border-dashed ml-border ml-surface-dim-bg px-4 py-6 text-center text-sm ml-text-muted', this.getSlotClass('Empty'))}">
${unsafeHTML(content)}
</div>
`;
    }
    renderTooltip() {
        if (!this.tooltip)
            return html ``;
        const seriesInfo = this.tooltip.series ? ` • ${this.tooltip.series}` : '';
        return html `
<div
class="absolute z-10 rounded-md border ml-border ml-surface-bg px-3 py-2 text-xs ml-text shadow-lg"
style=${ifDefined(`left:${this.tooltip.left}px; top:${this.tooltip.top}px; transform: translate(-50%, -100%);`)}
>
<span class="font-semibold">${this.tooltip.label}</span>
<span class="ml-text-muted">${seriesInfo}</span>
<div class="mt-1 ml-text">${this.formatNumber(this.tooltip.value)}</div>
</div>
`;
    }
    renderLegend(series, points) {
        if (!this.showLegend)
            return html ``;
        if (series.length === 0 && points.length === 0)
            return html ``;
        const items = series.length > 0
            ? series.map((s) => ({ label: s.name, color: s.color }))
            : points.map((p) => ({ label: p.label, color: p.color }));
        return html `
<div class="mt-4">
<div class="text-xs font-semibold ml-text-muted mb-2">${this.msg.legend}</div>
<div class="flex flex-wrap gap-3">
${items.map((item) => html `
<div class="flex items-center gap-2 text-xs ml-chart-legend">
<span
class="h-3 w-3 rounded-full border ml-border"
style=${ifDefined(item.color ? `background-color:${item.color};` : undefined)}
></span>
<span>${item.label}</span>
</div>
`)}
</div>
</div>
`;
    }
    renderDataTable(series, points) {
        const categories = this.getCategories(series, points);
        if (series.length > 0) {
            return html `
<table class="sr-only">
<caption>${this.getAriaLabel()}</caption>
<thead>
<tr>
<th>${this.msg.label}</th>
${series.map((s) => html `<th>${s.name}</th>`)}
</tr>
</thead>
<tbody>
${categories.map((cat) => html `
<tr>
<td>${cat}</td>
${series.map((s) => {
                const point = s.points.find((p) => p.label === cat);
                const value = point ? point.value : 0;
                return html `<td>${this.formatNumber(value)}</td>`;
            })}
</tr>
`)}
</tbody>
</table>
`;
        }
        return html `
<table class="sr-only">
<caption>${this.getAriaLabel()}</caption>
<thead>
<tr>
<th>${this.msg.label}</th>
<th>${this.msg.value}</th>
</tr>
</thead>
<tbody>
${points.map((p) => html `
<tr>
<td>${p.label}</td>
<td>${this.formatNumber(p.value)}</td>
</tr>
`)}
</tbody>
</table>
`;
    }
    getAriaLabel() {
        const content = this.getSlotContent('Label');
        if (!content)
            return this.msg.chartLabel;
        const div = document.createElement('div');
        div.innerHTML = content;
        return div.textContent?.trim() || this.msg.chartLabel;
    }
    formatNumber(value) {
        const lang = this.getMessageKey(messages) === 'pt' ? 'pt-BR' : 'en-US';
        return new Intl.NumberFormat(lang, { maximumFractionDigits: 2 }).format(value);
    }
    getBarWidth(seriesCount) {
        if (seriesCount <= 1)
            return 'w-8';
        if (seriesCount === 2)
            return 'w-6';
        if (seriesCount === 3)
            return 'w-5';
        return 'w-4';
    }
    getBarClasses() {
        return [
            'rounded-t-md transition',
            'ml-primary-bg',
        ].join(' ');
    }
    getCategoryLabelClasses() {
        return [
            'pt-2 text-xs ml-text-muted text-center',
            'whitespace-nowrap',
        ].join(' ');
    }
    renderChart(series, points) {
        const categories = this.getCategories(series, points);
        const maxValue = this.getMaxValue(series, points);
        const hasSeries = series.length > 0;
        const seriesCount = hasSeries ? series.length : 1;
        const barWidth = this.getBarWidth(seriesCount);
        return html `
<div class="relative" data-chart-container>
<div class="flex items-end gap-4 h-56 border-b ml-border">
${categories.map((category) => html `
<div class="flex flex-1 flex-col items-center justify-end h-full">
<div class="flex items-end gap-2 h-full">
${hasSeries
            ? series.map((s) => {
                const point = s.points.find((p) => p.label === category) || { label: category, value: 0, series: s.name, seriesColor: s.color };
                const height = maxValue > 0 ? (point.value / maxValue) * 100 : 0;
                const color = point.color || s.color;
                const style = `height:${height}%;${color ? `background-color:${color};` : ''} min-height:${height > 0 ? '2px' : '0'};`;
                const aria = `${point.label}: ${this.formatNumber(point.value)}${s.name ? ` - ${s.name}` : ''}`;
                return html `
<div class="flex flex-col items-center justify-end h-full">
${this.showValues ? html `<span class="mb-1 text-xs ml-text-muted">${this.formatNumber(point.value)}</span>` : html ``}
<div
class="${this.getBarClasses()} ${barWidth} cursor-pointer"
style=${ifDefined(style)}
role="button"
aria-label=${aria}
tabindex="0"
@mouseenter=${(e) => this.handlePointMouseEnter({ ...point, series: s.name, seriesColor: s.color }, e)}
@mouseleave=${this.handlePointMouseLeave}
@keydown=${(e) => this.handlePointKeyDown({ ...point, series: s.name, seriesColor: s.color }, e)}
@click=${() => this.handlePointClick({ ...point, series: s.name, seriesColor: s.color })}
></div>
</div>
`;
            })
            : points.filter((p) => p.label === category).map((point) => {
                const height = maxValue > 0 ? (point.value / maxValue) * 100 : 0;
                const style = `height:${height}%;${point.color ? `background-color:${point.color};` : ''} min-height:${height > 0 ? '2px' : '0'};`;
                const aria = `${point.label}: ${this.formatNumber(point.value)}`;
                return html `
<div class="flex flex-col items-center justify-end h-full">
${this.showValues ? html `<span class="mb-1 text-xs ml-text-muted">${this.formatNumber(point.value)}</span>` : html ``}
<div
class="${this.getBarClasses()} ${barWidth} cursor-pointer"
style=${ifDefined(style)}
role="button"
aria-label=${aria}
tabindex="0"
@mouseenter=${(e) => this.handlePointMouseEnter(point, e)}
@mouseleave=${this.handlePointMouseLeave}
@keydown=${(e) => this.handlePointKeyDown(point, e)}
@click=${() => this.handlePointClick(point)}
></div>
</div>
`;
            })}
</div>
<div class="${this.getCategoryLabelClasses()}">${category}</div>
</div>
`)}
</div>
${this.renderTooltip()}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const series = this.readSeries().filter((s) => s.points.length > 0);
        const standalonePoints = this.readStandalonePoints();
        const isEmpty = series.length === 0 && standalonePoints.length === 0;
        return html `
<div role="img" aria-label="${this.getAriaLabel()}" class="${cn('w-full', this.cssClass)}">
${this.renderLabel()}
${this.loading
            ? this.renderLoading()
            : isEmpty
                ? this.renderEmpty()
                : html `
${this.renderChart(series, standalonePoints)}
${this.renderLegend(series, standalonePoints)}
${this.renderDataTable(series, standalonePoints)}
`}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-legend' })
], MlBarChartMolecule.prototype, "showLegend", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-values' })
], MlBarChartMolecule.prototype, "showValues", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlBarChartMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlBarChartMolecule.prototype, "tooltip", void 0);
MlBarChartMolecule = __decorate([
    customElement('groupviewchart--ml-bar-chart')
], MlBarChartMolecule);
export { MlBarChartMolecule };
