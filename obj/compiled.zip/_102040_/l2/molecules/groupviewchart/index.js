var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewchart/index.ts" enhancement="_102020_/l2/enhancementAura"/>
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { StateLitElement } from '/_102029_/l2/stateLitElement.js';
import '/_102040_/l2/molecules/groupviewchart/ml-area-chart';
import '/_102040_/l2/molecules/groupviewchart/ml-bar-chart';
import '/_102040_/l2/molecules/groupviewchart/ml-line-chart';
import '/_102040_/l2/molecules/groupviewchart/ml-pie-chart';
import '/_102040_/l2/molecules/groupviewchart/ml-scatter-plot';
import '/_102040_/l2/molecules/groupviewchart/ml-radar-chart';
import { molecules, scenarios } from '/_102040_/l2/molecules/groupviewchart/index.defs.js';
import { renderCatalogReferenceTable } from '/_102020_/l2/aura/molecules/shared/indexReferenceTable.js';
let GroupViewChartIndex = class GroupViewChartIndex extends StateLitElement {
    constructor() {
        super(...arguments);
        // ── Showcase card states ─────────────────────────────────────
        this.cardArea = 0;
        this.cardBar = 0;
        this.cardLine = 0;
        this.cardPie = 0;
        this.cardScatter = 0;
        this.cardRadar = 0;
    }
    // ===========================================================================
    // HERO
    renderHero() {
        return html `
<header class="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-700 px-8 py-20 text-center">
<span
class="inline-block px-3 py-1 bg-sky-100 dark:bg-sky-900 text-sky-600 dark:text-sky-300 rounded-full text-xs font-semibold uppercase tracking-widest mb-6"
>
groupViewChart
</span>
<h1 class="text-5xl font-bold text-slate-900 dark:text-slate-50 mb-5 tracking-tight">
View Charts
</h1>
<p class="text-lg text-slate-500 dark:text-slate-400 max-w-2xl mx-auto leading-relaxed">
Displays data through graphical representation. Data provided via Series and Point slot tags. All chart implementations share the same data contract — swap the component tag to change visualization.
</p>
</header>
`;
    }
    // ===========================================================================
    // SHOWCASE CARDS
    renderShowcaseCards() {
        return html `
<section class="bg-slate-50 dark:bg-slate-950 px-8 py-12 border-b border-slate-200 dark:border-slate-700">
<div class="max-w-2xl mx-auto flex flex-col gap-5">
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
<div class="h-1 bg-violet-500 rounded-t-2xl"></div>
<div class="p-6">
<div class="flex items-center justify-between mb-1">
<p class="text-sm font-bold text-slate-900 dark:text-slate-50">Area chart</p>
<code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupviewchart--ml-area-chart</code>
</div>
<p class="text-xs text-slate-400 mb-5">Use for stacked trends with multiple series over time.</p>
<groupviewchart--ml-area-chart
name="card-1"
.value=${this.cardArea}
.isEditing=${true}
.showLegend=${true}
.showValues=${false}
@change=${(e) => {
            this.cardArea = e.detail.value;
        }}
>
<Label>Customer Growth</Label>
<Series name="Free" color="#7c3aed">
<Point label="Jan" value="120" />
<Point label="Feb" value="180" />
<Point label="Mar" value="260" />
</Series>
<Series name="Pro" color="#22c55e">
<Point label="Jan" value="60" />
<Point label="Feb" value="110" />
<Point label="Mar" value="150" />
</Series>
<Empty>No customer data yet.</Empty>
</groupviewchart--ml-area-chart>
</div>
</div>
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
<div class="h-1 bg-emerald-500 rounded-t-2xl"></div>
<div class="p-6">
<div class="flex items-center justify-between mb-1">
<p class="text-sm font-bold text-slate-900 dark:text-slate-50">Bar chart</p>
<code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupviewchart--ml-bar-chart</code>
</div>
<p class="text-xs text-slate-400 mb-5">Compare categories side by side in a monthly snapshot.</p>
<groupviewchart--ml-bar-chart
name="card-2"
.value=${this.cardBar}
.isEditing=${true}
.showLegend=${true}
.showValues=${true}
@change=${(e) => {
            this.cardBar = e.detail.value;
        }}
>
<Label>Monthly Revenue</Label>
<Series name="2024" color="#10b981">
<Point label="Jan" value="1200" />
<Point label="Feb" value="1800" />
<Point label="Mar" value="950" />
</Series>
<Series name="2025" color="#f59e0b">
<Point label="Jan" value="1500" />
<Point label="Feb" value="2100" />
<Point label="Mar" value="1300" />
</Series>
<Empty>No revenue data available.</Empty>
</groupviewchart--ml-bar-chart>
</div>
</div>
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
<div class="h-1 bg-amber-500 rounded-t-2xl"></div>
<div class="p-6">
<div class="flex items-center justify-between mb-1">
<p class="text-sm font-bold text-slate-900 dark:text-slate-50">Line chart</p>
<code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupviewchart--ml-line-chart</code>
</div>
<p class="text-xs text-slate-400 mb-5">Best for precise trend lines with multiple series.</p>
<groupviewchart--ml-line-chart
name="card-3"
.value=${this.cardLine}
.isEditing=${true}
.showLegend=${true}
.showValues=${false}
@change=${(e) => {
            this.cardLine = e.detail.value;
        }}
>
<Label>Support Tickets</Label>
<Series name="Opened" color="#f97316">
<Point label="Mon" value="34" />
<Point label="Tue" value="42" />
<Point label="Wed" value="28" />
<Point label="Thu" value="55" />
</Series>
<Series name="Resolved" color="#0ea5e9">
<Point label="Mon" value="18" />
<Point label="Tue" value="30" />
<Point label="Wed" value="26" />
<Point label="Thu" value="48" />
</Series>
<Empty>No ticket data yet.</Empty>
</groupviewchart--ml-line-chart>
</div>
</div>
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
<div class="h-1 bg-rose-500 rounded-t-2xl"></div>
<div class="p-6">
<div class="flex items-center justify-between mb-1">
<p class="text-sm font-bold text-slate-900 dark:text-slate-50">Pie chart</p>
<code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupviewchart--ml-pie-chart</code>
</div>
<p class="text-xs text-slate-400 mb-5">Single-series share of total across categories.</p>
<groupviewchart--ml-pie-chart
name="card-4"
.value=${this.cardPie}
.isEditing=${true}
.showLegend=${true}
.showValues=${true}
@change=${(e) => {
            this.cardPie = e.detail.value;
        }}
>
<Label>Channel Mix</Label>
<Point label="Organic" value="42" color="#ec4899" />
<Point label="Paid" value="28" color="#8b5cf6" />
<Point label="Referral" value="18" color="#14b8a6" />
<Point label="Partner" value="12" color="#f97316" />
<Empty>No channel data yet.</Empty>
</groupviewchart--ml-pie-chart>
</div>
</div>
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
<div class="h-1 bg-sky-500 rounded-t-2xl"></div>
<div class="p-6">
<div class="flex items-center justify-between mb-1">
<p class="text-sm font-bold text-slate-900 dark:text-slate-50">Scatter plot</p>
<code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupviewchart--ml-scatter-plot</code>
</div>
<p class="text-xs text-slate-400 mb-5">Reveal correlation between two metrics across segments.</p>
<groupviewchart--ml-scatter-plot
name="card-5"
.value=${this.cardScatter}
.isEditing=${true}
.showLegend=${true}
.showValues=${false}
@change=${(e) => {
            this.cardScatter = e.detail.value;
        }}
>
<Label>Latency vs. Satisfaction</Label>
<Series name="Enterprise" color="#0ea5e9">
<Point label="A" value="82" />
<Point label="B" value="68" />
<Point label="C" value="74" />
</Series>
<Series name="SMB" color="#f97316">
<Point label="D" value="56" />
<Point label="E" value="63" />
<Point label="F" value="71" />
</Series>
<Empty>No correlation data yet.</Empty>
</groupviewchart--ml-scatter-plot>
</div>
</div>
<div class="bg-white dark:bg-slate-800 rounded-2xl border border-slate-200 dark:border-slate-700 shadow-sm">
<div class="h-1 bg-indigo-500 rounded-t-2xl"></div>
<div class="p-6">
<div class="flex items-center justify-between mb-1">
<p class="text-sm font-bold text-slate-900 dark:text-slate-50">Radar chart</p>
<code class="text-xs bg-slate-100 dark:bg-slate-700 text-slate-500 dark:text-slate-400 px-2 py-0.5 rounded">groupviewchart--ml-radar-chart</code>
</div>
<p class="text-xs text-slate-400 mb-5">Compare balanced performance across multiple dimensions.</p>
<groupviewchart--ml-radar-chart
name="card-6"
.value=${this.cardRadar}
.isEditing=${true}
.showLegend=${true}
.showValues=${false}
@change=${(e) => {
            this.cardRadar = e.detail.value;
        }}
>
<Label>Team Skill Matrix</Label>
<Series name="Design" color="#6366f1">
<Point label="Research" value="78" />
<Point label="Visual" value="92" />
<Point label="Systems" value="65" />
</Series>
<Series name="Engineering" color="#14b8a6">
<Point label="Research" value="55" />
<Point label="Visual" value="64" />
<Point label="Systems" value="88" />
</Series>
<Empty>No team data yet.</Empty>
</groupviewchart--ml-radar-chart>
</div>
</div>
</div>
</section>
`;
    }
    // ===========================================================================
    // REFERENCE TABLE
    renderReferenceTable() {
        return renderCatalogReferenceTable(molecules, scenarios);
    }
    // ===========================================================================
    // RENDER
    render() {
        return html `
<div class="font-sans min-h-screen">
${this.renderHero()}
${this.renderShowcaseCards()}
${this.renderReferenceTable()}
</div>
`;
    }
};
__decorate([
    state()
], GroupViewChartIndex.prototype, "cardArea", void 0);
__decorate([
    state()
], GroupViewChartIndex.prototype, "cardBar", void 0);
__decorate([
    state()
], GroupViewChartIndex.prototype, "cardLine", void 0);
__decorate([
    state()
], GroupViewChartIndex.prototype, "cardPie", void 0);
__decorate([
    state()
], GroupViewChartIndex.prototype, "cardScatter", void 0);
__decorate([
    state()
], GroupViewChartIndex.prototype, "cardRadar", void 0);
GroupViewChartIndex = __decorate([
    customElement('molecules--groupviewchart--index-102040')
], GroupViewChartIndex);
export { GroupViewChartIndex };
