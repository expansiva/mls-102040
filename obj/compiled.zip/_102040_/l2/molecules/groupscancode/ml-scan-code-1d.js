var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupscancode/ml-scan-code-1d.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML SCAN CODE 1D MOLECULE
// =============================================================================
// Skill Group: groupScanCode
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state, query } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    open: 'Open camera scanner',
    capture: 'Capture',
    close: 'Close',
    processing: 'Processing...',
    noResult: 'No result',
    permissionDenied: 'Camera permission denied',
    notSupported: 'Camera not supported on this device',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlScanCode1dMolecule = class MlScanCode1dMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupscancode--ml-scan-code-1d .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code-1d .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code-1d .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code-1d .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupscancode--ml-scan-code-1d .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code-1d .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code-1d .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code-1d .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupscancode--ml-scan-code-1d .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code-1d .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupscancode--ml-scan-code-1d .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code-1d .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code-1d .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupscancode--ml-scan-code-1d .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupscancode--ml-scan-code-1d .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupscancode--ml-scan-code-1d .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code-1d .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupscancode--ml-scan-code-1d .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Result'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.facing = 'environment';
        this.autoCapture = false;
        this.captureInterval = 500;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.isCapturing = false;
        this.hasSupport = true;
        this.lastEmittedValue = null;
        this.stream = null;
        this.autoCaptureTimer = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        this.stopCamera();
        this.stopAutoCapture();
    }
    updated(changed) {
        if (changed.has('autoCapture') || changed.has('captureInterval') || changed.has('isOpen')) {
            this.handleAutoCaptureState();
        }
        if (changed.has('disabled') && this.disabled) {
            this.closeCamera();
        }
        if (changed.has('value')) {
            this.emitValueChange(this.value);
            if (this.value && this.isOpen) {
                this.closeCamera();
            }
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            this.emitValueChange(value);
            if (value && this.isOpen) {
                this.closeCamera();
            }
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HELPERS
    // ===========================================================================
    emitValueChange(value) {
        if (value === this.lastEmittedValue)
            return;
        this.lastEmittedValue = value;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value },
        }));
    }
    emitCapture(image) {
        this.dispatchEvent(new CustomEvent('capture', {
            bubbles: true,
            composed: true,
            detail: { image },
        }));
    }
    emitDetect(format, value) {
        this.dispatchEvent(new CustomEvent('detect', {
            bubbles: true,
            composed: true,
            detail: { format, value },
        }));
    }
    emitOpen() {
        this.dispatchEvent(new CustomEvent('open', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    emitClose() {
        this.dispatchEvent(new CustomEvent('close', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    // ===========================================================================
    // CAMERA CONTROLS
    // ===========================================================================
    async openCamera() {
        if (this.disabled || this.loading || this.isOpen)
            return;
        if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
            this.hasSupport = false;
            this.error = this.msg.notSupported;
            return;
        }
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facing || 'environment' },
            });
            this.stream = stream;
            this.isOpen = true;
            this.hasSupport = true;
            this.error = '';
            this.emitOpen();
            if (this.videoEl) {
                this.videoEl.srcObject = stream;
                await this.videoEl.play();
            }
        }
        catch (err) {
            this.error = this.msg.permissionDenied;
        }
    }
    closeCamera() {
        if (!this.isOpen)
            return;
        this.stopCamera();
        this.isOpen = false;
        this.emitClose();
    }
    stopCamera() {
        if (this.stream) {
            this.stream.getTracks().forEach((t) => t.stop());
            this.stream = null;
        }
        if (this.videoEl) {
            this.videoEl.pause();
            this.videoEl.srcObject = null;
        }
    }
    // ===========================================================================
    // CAPTURE FLOW
    // ===========================================================================
    handleAutoCaptureState() {
        if (!this.isOpen || !this.autoCapture || this.disabled) {
            this.stopAutoCapture();
            return;
        }
        if (this.autoCaptureTimer !== null) {
            this.stopAutoCapture();
        }
        const interval = Math.max(200, this.captureInterval || 500);
        this.autoCaptureTimer = window.setInterval(() => {
            if (!this.isOpen || this.loading || this.disabled)
                return;
            this.captureFrame();
        }, interval);
    }
    stopAutoCapture() {
        if (this.autoCaptureTimer !== null) {
            window.clearInterval(this.autoCaptureTimer);
            this.autoCaptureTimer = null;
        }
    }
    async captureFrame() {
        if (!this.videoEl || !this.isOpen)
            return;
        const canvas = document.createElement('canvas');
        const width = this.videoEl.videoWidth || 640;
        const height = this.videoEl.videoHeight || 480;
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        ctx.drawImage(this.videoEl, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/png');
        this.emitCapture(dataUrl);
        this.flashCapture();
        await this.tryLocalDecode(canvas);
    }
    flashCapture() {
        this.isCapturing = true;
        window.setTimeout(() => {
            this.isCapturing = false;
        }, 180);
    }
    async tryLocalDecode(canvas) {
        const Detector = window.BarcodeDetector;
        if (!Detector)
            return;
        try {
            const formats = ['ean_13', 'ean_8', 'upc_a', 'code_128', 'code_39', 'itf'];
            const detector = new Detector({ formats });
            const results = await detector.detect(canvas);
            if (results && results.length > 0) {
                const result = results[0];
                if (result.rawValue && result.format) {
                    this.value = result.rawValue;
                    this.emitDetect(result.format, result.rawValue);
                    this.emitValueChange(result.rawValue);
                    this.closeCamera();
                }
            }
        }
        catch (err) {
            // silent: local decoding is optional
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        if (this.isOpen) {
            this.closeCamera();
        }
        else {
            this.openCamera();
        }
    }
    handleTriggerKeydown(event) {
        if (event.key === 'Enter' || event.key === '') {
            event.preventDefault();
            this.handleTriggerClick();
        }
    }
    handleCloseKeydown(event) {
        if (event.key === 'Escape') {
            this.closeCamera();
        }
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="${cn('mb-2 text-sm ml-text-muted', this.getSlotClass('Label'))}">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `<div class="${cn('mt-2 text-xs ml-text-muted', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</div>`;
    }
    renderError() {
        if (!this.error)
            return html ``;
        return html `<div class="mt-2 text-xs ml-error-text" role="alert">${unsafeHTML(String(this.error))}</div>`;
    }
    renderResult() {
        if (!this.value)
            return html ``;
        if (this.hasSlot('Result')) {
            return html `<div class="mt-3">${unsafeHTML(this.getSlotContent('Result'))}</div>`;
        }
        return html `
<div class="mt-3 rounded-lg border ml-border ml-surface-dim-bg px-3 py-2 text-sm ml-text" aria-live="polite">
${this.value}
</div>
`;
    }
    renderTriggerContent() {
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        return html `<span>${this.isOpen ? this.msg.close : this.msg.open}</span>`;
    }
    getFrameClasses() {
        return [
            'relative w-full rounded-xl border transition',
            'ml-surface-bg',
            this.error ? 'ml-border-error' : 'ml-border',
            this.isCapturing ? 'ml-focus-ring' : '',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getVideoWrapperClasses() {
        return [
            'relative w-full overflow-hidden rounded-lg border',
            'ml-border',
            'ml-surface-dim-bg',
            this.isOpen ? 'block' : 'hidden',
        ].filter(Boolean).join(' ');
    }
    getTriggerClasses() {
        return [
            'inline-flex items-center justify-center rounded-lg border px-3 py-2 text-sm transition',
            'ml-border',
            'ml-surface-bg',
            'ml-text',
            'hover:ml-surface-dim-bg',
            '',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getCaptureButtonClasses() {
        return [
            'inline-flex items-center justify-center rounded-lg border px-3 py-2 text-sm transition',
            'ml-border-focus',
            'ml-primary-dim-bg',
            'ml-primary-text',
            'hover:ml-surface-dim-bg',
            '',
            this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasResult = Boolean(this.value);
        return html `
<div class="${cn('w-full', this.cssClass)}" @keydown=${this.handleCloseKeydown}>
${this.renderLabel()}
<div class=${this.getFrameClasses()}>
<div class="flex items-center justify-between px-4 py-3">
<button
class=${this.getTriggerClasses()}
role="button"
aria-label=${this.msg.open}
?disabled=${this.disabled}
@click=${this.handleTriggerClick}
@keydown=${this.handleTriggerKeydown}
>
${this.renderTriggerContent()}
</button>
${this.isOpen ? html `
<button
class=${this.getCaptureButtonClasses()}
aria-label=${this.msg.capture}
?disabled=${this.loading}
@click=${this.captureFrame}
>
${this.msg.capture}
</button>
` : html ``}
</div>
<div class=${this.getVideoWrapperClasses()} aria-hidden="true">
<video class="w-full h-64 object-cover"></video>
</div>
${this.loading ? html `
<div class="px-4 py-3 text-sm ml-text-muted">
${this.msg.processing}
</div>
` : html ``}
${!this.isOpen && hasResult ? this.renderResult() : html ``}
${!this.isOpen && !hasResult && !this.loading ? html `
<div class="px-4 pb-3 text-xs ml-text-faint">${this.msg.noResult}</div>
` : html ``}
</div>
${this.renderError()}
${this.renderHelper()}
${this.name ? html `<input type="hidden" name=${this.name} .value=${this.value ?? ''} />` : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlScanCode1dMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCode1dMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCode1dMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCode1dMolecule.prototype, "facing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'auto-capture' })
], MlScanCode1dMolecule.prototype, "autoCapture", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'capture-interval' })
], MlScanCode1dMolecule.prototype, "captureInterval", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanCode1dMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanCode1dMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlScanCode1dMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlScanCode1dMolecule.prototype, "isCapturing", void 0);
__decorate([
    state()
], MlScanCode1dMolecule.prototype, "hasSupport", void 0);
__decorate([
    state()
], MlScanCode1dMolecule.prototype, "lastEmittedValue", void 0);
__decorate([
    query('video')
], MlScanCode1dMolecule.prototype, "videoEl", void 0);
MlScanCode1dMolecule = __decorate([
    customElement('groupscancode--ml-scan-code-1d')
], MlScanCode1dMolecule);
export { MlScanCode1dMolecule };
