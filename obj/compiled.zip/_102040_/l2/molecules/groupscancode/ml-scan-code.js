/// <mls fileReference="_102040_/l2/molecules/groupscancode/ml-scan-code.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// ML SCAN CODE MOLECULE
// =============================================================================
// Skill Group: scan + code
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    openCamera: 'Open camera',
    capture: 'Capture',
    close: 'Close',
    scanAgain: 'Scan again',
    loading: 'Processing...',
    autoCapture: 'Auto scanning...',
    permissionDenied: 'Camera permission denied',
    cameraUnavailable: 'Camera unavailable',
    unknownError: 'Unable to open camera',
};
const messages = {
    en: message_en,
    pt: {
        openCamera: 'Abrir câmera',
        capture: 'Capturar',
        close: 'Fechar',
        scanAgain: 'Ler novamente',
        loading: 'Processando...',
        autoCapture: 'Escaneando automaticamente...',
        permissionDenied: 'Permissão da câmera negada',
        cameraUnavailable: 'Câmera indisponível',
        unknownError: 'Não foi possível abrir a câmera',
    },
};
/// **collab_i18n_end**
let MlScanCodeMolecule = class MlScanCodeMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupscancode--ml-scan-code .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupscancode--ml-scan-code .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-code .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupscancode--ml-scan-code .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupscancode--ml-scan-code .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupscancode--ml-scan-code .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupscancode--ml-scan-code .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupscancode--ml-scan-code .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-code .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupscancode--ml-scan-code .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        this.stream = null;
        this.autoTimer = null;
        this.errorId = `scan-error-${Math.random().toString(36).slice(2)}`;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Result'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.facing = 'environment';
        this.autoCapture = false;
        this.captureInterval = 500;
        this.disabled = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.isOpen = false;
        this.isCapturing = false;
        this.cameraReady = false;
    }
    // =========================================================================
    // LIFECYCLE
    // =========================================================================
    disconnectedCallback() {
        this.stopCamera();
        super.disconnectedCallback();
    }
    updated(changedProps) {
        if (changedProps.has('value')) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            if (this.value !== null && this.isOpen) {
                this.closeCamera();
            }
        }
        if ((changedProps.has('autoCapture') || changedProps.has('captureInterval')) && this.isOpen) {
            this.setupAutoCapture();
        }
    }
    // =========================================================================
    // CAMERA CONTROL
    // =========================================================================
    async openCamera() {
        if (this.disabled || this.isOpen)
            return;
        this.isOpen = true;
        this.cameraReady = false;
        await this.updateComplete;
        await this.startCamera();
    }
    closeCamera() {
        if (this.disabled)
            return;
        this.stopCamera();
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('close', {
            bubbles: true,
            composed: true,
            detail: {},
        }));
    }
    async startCamera() {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facing },
            });
            this.stream = stream;
            const video = this.getVideoElement();
            if (video) {
                video.srcObject = stream;
                await video.play();
            }
            this.cameraReady = true;
            this.setupAutoCapture();
            this.dispatchEvent(new CustomEvent('open', {
                bubbles: true,
                composed: true,
                detail: {},
            }));
        }
        catch (err) {
            const error = err;
            if (error?.name === 'NotAllowedError' || error?.name === 'PermissionDeniedError') {
                this.error = this.msg.permissionDenied;
            }
            else if (error?.name === 'NotFoundError' || error?.name === 'OverconstrainedError') {
                this.error = this.msg.cameraUnavailable;
            }
            else {
                this.error = this.msg.unknownError;
            }
            this.isOpen = false;
        }
    }
    stopCamera() {
        if (this.autoTimer !== null) {
            window.clearInterval(this.autoTimer);
            this.autoTimer = null;
        }
        if (this.stream) {
            this.stream.getTracks().forEach((track) => track.stop());
            this.stream = null;
        }
        this.cameraReady = false;
    }
    setupAutoCapture() {
        if (!this.isOpen || !this.autoCapture) {
            if (this.autoTimer !== null) {
                window.clearInterval(this.autoTimer);
                this.autoTimer = null;
            }
            return;
        }
        if (this.autoTimer !== null) {
            window.clearInterval(this.autoTimer);
            this.autoTimer = null;
        }
        this.autoTimer = window.setInterval(() => {
            if (!this.isOpen || this.loading || this.disabled)
                return;
            this.captureFrame();
        }, this.captureInterval);
    }
    captureFrame() {
        if (this.disabled || this.loading || !this.cameraReady || this.isCapturing)
            return;
        const video = this.getVideoElement();
        if (!video || video.videoWidth === 0 || video.videoHeight === 0)
            return;
        const canvas = document.createElement('canvas');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const image = canvas.toDataURL('image/png');
        this.isCapturing = true;
        window.setTimeout(() => {
            this.isCapturing = false;
        }, 200);
        this.dispatchEvent(new CustomEvent('capture', {
            bubbles: true,
            composed: true,
            detail: { image },
        }));
    }
    getVideoElement() {
        return this.querySelector('video[data-role="scanner"]');
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleTriggerClick() {
        if (this.disabled)
            return;
        this.openCamera();
    }
    handleCaptureClick() {
        this.captureFrame();
    }
    handleScanAgain() {
        if (this.disabled)
            return;
        this.value = null;
        this.openCamera();
    }
    handleKeydown(e) {
        if (e.key === 'Escape' && this.isOpen) {
            this.closeCamera();
        }
    }
    // =========================================================================
    // RENDER HELPERS
    // =========================================================================
    getRootClasses() {
        return [
            'w-full rounded-xl border p-4 space-y-3',
            'ml-surface-bg',
            'ml-border',
            'ml-text',
            this.disabled ? 'ml-disabled' : 'cursor-default',
        ].filter(Boolean).join(' ');
    }
    getActionButtonClasses() {
        return [
            'inline-flex items-center justify-center rounded-lg px-4 py-2 text-sm font-medium border transition',
            'ml-surface-bg',
            'ml-text',
            'ml-border',
            'hover:ml-surface-dim-bg',
            '',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getCaptureButtonClasses() {
        return [
            'inline-flex items-center justify-center rounded-full w-14 h-14 border-4 transition',
            'ml-surface-bg',
            'ml-border-focus',
            'ml-text',
            '',
            this.isCapturing ? 'scale-95' : '',
            this.disabled || this.loading ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getViewfinderClasses() {
        return [
            'relative w-full aspect-video rounded-xl overflow-hidden border',
            'ml-surface-dim-bg',
            'ml-border',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="${cn('text-sm ml-text-muted', this.getSlotClass('Label'))}">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderHelperOrError() {
        if (this.error) {
            return html `<p id="${this.errorId}" class="text-xs ml-error-text">${this.error}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="${cn('text-xs ml-text-muted', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderTrigger() {
        const content = this.hasSlot('Trigger')
            ? html `${unsafeHTML(this.getSlotContent('Trigger'))}`
            : html `<span>${this.msg.openCamera}</span>`;
        return html `
 <button
 type="button"
 class="${this.getActionButtonClasses()}"
 ?disabled=${this.disabled}
 role="button"
 aria-label="${this.msg.openCamera}"
 aria-describedby=${ifDefined(this.error ? this.errorId : undefined)}
 @click=${this.handleTriggerClick}
 >
 ${content}
 </button>
 `;
    }
    renderResult() {
        const resultContent = this.hasSlot('Result')
            ? html `${unsafeHTML(this.getSlotContent('Result'))}`
            : html `<span class="text-sm ml-text">${this.value ?? ''}</span>`;
        return html `
 <div class="space-y-3" aria-live="polite">
 <div class="rounded-lg border p-3 ml-surface-bg ml-border">
 ${resultContent}
 </div>
 <button
 type="button"
 class="${this.getActionButtonClasses()}"
 ?disabled=${this.disabled}
 @click=${this.handleScanAgain}
 >
 ${this.msg.scanAgain}
 </button>
 </div>
 `;
    }
    renderViewfinder() {
        return html `
 <div class="${this.getViewfinderClasses()}" @keydown=${this.handleKeydown} tabindex="0">
 <video data-role="scanner" class="w-full h-full object-cover" aria-hidden="true" autoplay muted playsinline></video>
 ${this.loading
            ? html `
 <div class="absolute inset-0 flex items-center justify-center ml-surface-bg/70">
 <div class="text-sm ml-text">${this.msg.loading}</div>
 </div>
 `
            : nothing}
 </div>
 <div class="flex items-center justify-between">
 ${this.autoCapture
            ? html `<span class="text-xs ml-text-muted">${this.msg.autoCapture}</span>`
            : html `
 <button
 type="button"
 class="${this.getCaptureButtonClasses()}"
 aria-label="${this.msg.capture}"
 ?disabled=${this.disabled || this.loading}
 @click=${this.handleCaptureClick}
 ></button>
 `}
 <button
 type="button"
 class="${this.getActionButtonClasses()}"
 aria-label="${this.msg.close}"
 ?disabled=${this.disabled}
 @click=${this.closeCamera}
 >
 ${this.msg.close}
 </button>
 </div>
 `;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasValue = this.value !== null;
        return html `
 <div class="${cn(this.getRootClasses(), this.cssClass)}" aria-describedby=${ifDefined(this.error ? this.errorId : undefined)}>
 ${this.renderLabel()}
 <div class="space-y-3">
 ${this.isOpen
            ? this.renderViewfinder()
            : hasValue
                ? this.renderResult()
                : this.renderTrigger()}
 </div>
 ${this.renderHelperOrError()}
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanCodeMolecule.prototype, "facing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'auto-capture' })
], MlScanCodeMolecule.prototype, "autoCapture", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'capture-interval' })
], MlScanCodeMolecule.prototype, "captureInterval", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanCodeMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanCodeMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlScanCodeMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlScanCodeMolecule.prototype, "isCapturing", void 0);
__decorate([
    state()
], MlScanCodeMolecule.prototype, "cameraReady", void 0);
MlScanCodeMolecule = __decorate([
    customElement('groupscancode--ml-scan-code')
], MlScanCodeMolecule);
export { MlScanCodeMolecule };
