var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupscancode/ml-scan-document.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML SCAN DOCUMENT MOLECULE
// =============================================================================
// Skill Group: groupScanCode
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, query, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
/// **collab_i18n_start**
const message_en = {
    openCamera: 'Open camera scanner',
    capture: 'Capture',
    loading: 'Processing...',
    result: 'Scan result',
    permissionDenied: 'Camera permission denied',
    cameraUnavailable: 'Camera unavailable',
    noResult: 'No result yet',
};
const messages = {
    en: message_en,
    pt: {
        openCamera: 'Abrir câmera',
        capture: 'Capturar',
        loading: 'Processando...',
        result: 'Resultado da leitura',
        permissionDenied: 'Permissão de câmera negada',
        cameraUnavailable: 'Câmera indisponível',
        noResult: 'Nenhum resultado',
    },
};
let MlScanDocumentMolecule = class MlScanDocumentMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupscancode--ml-scan-document .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-document .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-document .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-document .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupscancode--ml-scan-document .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-document .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-document .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupscancode--ml-scan-document .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupscancode--ml-scan-document .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-document .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupscancode--ml-scan-document .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-document .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-document .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupscancode--ml-scan-document .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupscancode--ml-scan-document .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupscancode--ml-scan-document .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupscancode--ml-scan-document .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupscancode--ml-scan-document .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Result'];
        // O slot Trigger carrega CONTROLES do consumidor, não conteúdo
        // decorativo — precisa de nó vivo, com handler e componente preservados.
        // Os demais slots continuam vindo pelo caminho de snapshot: são conteúdo.
        this.usesLiveSlots = true;
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.facing = 'environment';
        this.autoCapture = false;
        this.captureInterval = 500;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.corners = [];
        this.manualOverride = false;
        this.isCapturing = false;
        this.videoReady = false;
        this.stream = null;
        this.detectionTimer = null;
        this.autoCaptureTimer = null;
        this.draggingIndex = null;
        this.errorId = `scan-error-${Math.random().toString(36).slice(2, 8)}`;
        this.boundPointerMove = (event) => this.handlePointerMove(event);
        this.boundPointerUp = () => this.handlePointerUp();
        this.boundEscape = (event) => this.handleEscapeKey(event);
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        if (this.isOpen) {
            this.bindEscapeListener();
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.closeCamera();
    }
    updated(changed) {
        if (changed.has('value')) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            if (this.value && this.isOpen) {
                this.closeCamera();
            }
        }
        if (changed.has('disabled') && this.disabled && this.isOpen) {
            this.closeCamera();
        }
        if (changed.has('autoCapture') || changed.has('captureInterval') || changed.has('isOpen')) {
            this.setupAutoCapture();
        }
    }
    // ===========================================================================
    // CAMERA CONTROLS
    // ===========================================================================
    async openCamera() {
        if (this.disabled || this.loading || this.isOpen)
            return;
        this.error = '';
        try {
            this.stream = await navigator.mediaDevices.getUserMedia({
                video: { facingMode: this.facing },
            });
            this.isOpen = true;
            this.videoReady = false;
            this.manualOverride = false;
            this.setDefaultCorners();
            const video = this.videoEl;
            if (video) {
                video.srcObject = this.stream;
                video.onloadedmetadata = () => {
                    this.videoReady = true;
                    video.play();
                    this.setDefaultCorners();
                    this.startDetectionLoop();
                };
            }
            this.dispatchEvent(new CustomEvent('open', { bubbles: true, composed: true, detail: {} }));
            this.bindEscapeListener();
        }
        catch (err) {
            const name = String(err?.name || '');
            this.error = name === 'NotAllowedError' ? this.msg.permissionDenied : this.msg.cameraUnavailable;
        }
    }
    closeCamera() {
        if (this.stream) {
            this.stream.getTracks().forEach((track) => track.stop());
        }
        this.stream = null;
        this.isOpen = false;
        this.videoReady = false;
        this.isCapturing = false;
        this.manualOverride = false;
        this.stopDetectionLoop();
        this.clearAutoCapture();
        this.unbindEscapeListener();
        this.dispatchEvent(new CustomEvent('close', { bubbles: true, composed: true, detail: {} }));
    }
    handleEscapeKey(event) {
        if (event.key === 'Escape' && this.isOpen) {
            this.closeCamera();
        }
    }
    bindEscapeListener() {
        document.addEventListener('keydown', this.boundEscape);
    }
    unbindEscapeListener() {
        document.removeEventListener('keydown', this.boundEscape);
    }
    // ===========================================================================
    // CORNER DETECTION (SIMULATED)
    // ===========================================================================
    startDetectionLoop() {
        this.stopDetectionLoop();
        this.detectionTimer = window.setInterval(() => {
            if (!this.isOpen || this.manualOverride)
                return;
            this.setDefaultCorners();
        }, 1000);
    }
    stopDetectionLoop() {
        if (this.detectionTimer) {
            window.clearInterval(this.detectionTimer);
        }
        this.detectionTimer = null;
    }
    setDefaultCorners() {
        this.corners = [
            { x: 0.08, y: 0.12 },
            { x: 0.92, y: 0.12 },
            { x: 0.92, y: 0.88 },
            { x: 0.08, y: 0.88 },
        ];
    }
    // ===========================================================================
    // CAPTURE
    // ===========================================================================
    async captureFrame() {
        if (this.disabled || this.loading || !this.isOpen || !this.videoEl)
            return;
        const video = this.videoEl;
        if (!this.videoReady || video.videoWidth === 0 || video.videoHeight === 0)
            return;
        const width = video.videoWidth;
        const height = video.videoHeight;
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        ctx.drawImage(video, 0, 0, width, height);
        const bounds = this.getCornerBounds(width, height);
        const output = document.createElement('canvas');
        output.width = bounds.width;
        output.height = bounds.height;
        const outCtx = output.getContext('2d');
        if (!outCtx)
            return;
        outCtx.drawImage(canvas, bounds.x, bounds.y, bounds.width, bounds.height, 0, 0, bounds.width, bounds.height);
        const dataUrl = output.toDataURL('image/png');
        this.isCapturing = true;
        setTimeout(() => (this.isCapturing = false), 180);
        this.dispatchEvent(new CustomEvent('capture', {
            bubbles: true,
            composed: true,
            detail: { image: dataUrl },
        }));
    }
    getCornerBounds(width, height) {
        const xs = this.corners.map((c) => c.x * width);
        const ys = this.corners.map((c) => c.y * height);
        const minX = Math.max(0, Math.min(...xs));
        const maxX = Math.min(width, Math.max(...xs));
        const minY = Math.max(0, Math.min(...ys));
        const maxY = Math.min(height, Math.max(...ys));
        const boxWidth = Math.max(1, maxX - minX);
        const boxHeight = Math.max(1, maxY - minY);
        return { x: minX, y: minY, width: boxWidth, height: boxHeight };
    }
    setupAutoCapture() {
        this.clearAutoCapture();
        if (!this.isOpen || !this.autoCapture || this.disabled)
            return;
        this.autoCaptureTimer = window.setInterval(() => {
            if (this.loading || this.disabled)
                return;
            this.captureFrame();
        }, Math.max(200, this.captureInterval));
    }
    clearAutoCapture() {
        if (this.autoCaptureTimer) {
            window.clearInterval(this.autoCaptureTimer);
        }
        this.autoCaptureTimer = null;
    }
    // ===========================================================================
    // CORNER DRAGGING
    // ===========================================================================
    handleCornerPointerDown(index, event) {
        if (this.disabled || this.loading || !this.isOpen)
            return;
        this.draggingIndex = index;
        this.manualOverride = true;
        window.addEventListener('pointermove', this.boundPointerMove);
        window.addEventListener('pointerup', this.boundPointerUp);
        event.target.setPointerCapture(event.pointerId);
    }
    handlePointerMove(event) {
        if (this.draggingIndex === null || !this.overlayEl)
            return;
        const rect = this.overlayEl.getBoundingClientRect();
        const x = (event.clientX - rect.left) / rect.width;
        const y = (event.clientY - rect.top) / rect.height;
        const clamped = { x: Math.min(0.98, Math.max(0.02, x)), y: Math.min(0.98, Math.max(0.02, y)) };
        const updated = [...this.corners];
        updated[this.draggingIndex] = clamped;
        this.corners = updated;
    }
    handlePointerUp() {
        this.draggingIndex = null;
        window.removeEventListener('pointermove', this.boundPointerMove);
        window.removeEventListener('pointerup', this.boundPointerUp);
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getWrapperClasses() {
        return [
            'group relative w-full rounded-xl border p-4 transition',
            'ml-surface-bg',
            'ml-border',
            this.disabled ? 'ml-disabled' : 'opacity-100',
        ].filter(Boolean).join(' ');
    }
    getViewfinderClasses() {
        return [
            'relative w-full overflow-hidden rounded-lg border',
            'ml-surface-dim-bg',
            'ml-border',
        ].join(' ');
    }
    getTriggerClasses() {
        return [
            'inline-flex items-center justify-center rounded-md px-4 py-2 text-sm font-medium transition',
            'ml-primary-bg',
            'hover:opacity-90',
            '',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getCaptureClasses() {
        return [
            'inline-flex items-center justify-center rounded-md px-3 py-2 text-xs font-semibold transition',
            'ml-surface-bg ml-text',
            'hover:ml-surface-dim-bg',
            '',
            (this.disabled || this.loading) ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getCornerHandleClasses() {
        return [
            'absolute h-4 w-4 rounded-full border-2 shadow',
            'ml-border-focus',
            'ml-surface-bg',
            'cursor-grab',
        ].join(' ');
    }
    hasResult() {
        return this.value !== null && this.value !== '';
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div class="${cn('mb-3 text-sm ml-text-muted', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        return html `
<div class="${cn('mt-3 text-xs ml-text-muted', this.getSlotClass('Helper'))}">
${unsafeHTML(this.getSlotContent('Helper'))}
</div>
`;
    }
    renderError() {
        if (!this.error)
            return html ``;
        return html `
<p id="${this.errorId}" class="mt-2 text-xs ml-error-text">
${unsafeHTML(String(this.error))}
</p>
`;
    }
    renderTrigger() {
        const content = this.hasSlot('Trigger') ? this.renderLiveSlot('Trigger') : this.msg.openCamera;
        return html `
<button
class="${this.getTriggerClasses()}"
?disabled=${this.disabled}
role="button"
aria-label="${this.msg.openCamera}"
@keydown=${this.handleTriggerKeydown}
@click=${this.handleTriggerClick}
>
${content}
</button>
`;
    }
    renderResult() {
        const content = this.hasSlot('Result')
            ? unsafeHTML(this.getSlotContent('Result'))
            : unsafeHTML(this.value || this.msg.noResult);
        return html `
<div class="w-full rounded-lg border ml-border ml-surface-bg p-4">
<div class="text-xs ml-text-muted mb-2">${this.msg.result}</div>
<div class="text-sm ml-text" aria-live="polite">${content}</div>
</div>
`;
    }
    renderViewfinder() {
        const points = this.corners.map((c) => `${c.x * 100},${c.y * 100}`).join(' ');
        return html `
<div class="${this.getViewfinderClasses()}" aria-describedby=${this.error ? this.errorId : ''}>
<div class="relative aspect-[4/3] w-full">
<video
class="h-full w-full object-cover"
autoplay
playsinline
aria-hidden="true"
></video>
<div class="ml-scan-overlay absolute inset-0">
<svg viewBox="0 0 100 100" class="h-full w-full">
${svg `
<polygon
points="${points}"
fill="rgba(14, 165, 233, 0.08)"
stroke="rgba(14, 165, 233, 0.85)"
stroke-width="1.2"
/>
`}
</svg>
${this.corners.map((corner, index) => html `
<div
class="${this.getCornerHandleClasses()}"
style="left: calc(${corner.x * 100}% - 8px); top: calc(${corner.y * 100}% - 8px);"
@pointerdown=${(event) => this.handleCornerPointerDown(index, event)}
></div>
`)}
</div>
${this.isCapturing ? html `<div class="absolute inset-0 ml-surface-bg/40"></div>` : html ``}
${this.loading ? html `
<div class="absolute inset-0 flex items-center justify-center ml-surface-bg/70">
<div class="text-sm ml-text-muted">${this.msg.loading}</div>
</div>
` : html ``}
</div>
<div class="mt-3 flex items-center justify-between">
<button
class="${this.getCaptureClasses()}"
aria-label="${this.msg.capture}"
?disabled=${this.disabled || this.loading}
@click=${this.handleCaptureClick}
>
${this.msg.capture}
</button>
<button
class="text-xs ml-text-muted hover:ml-text"
@click=${this.handleCloseClick}
>
Close
</button>
</div>
</div>
`;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        this.openCamera();
    }
    handleTriggerKeydown(event) {
        if (event.key === 'Enter' || event.key === '') {
            event.preventDefault();
            this.openCamera();
        }
    }
    handleCaptureClick() {
        this.captureFrame();
    }
    handleCloseClick() {
        this.closeCamera();
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        return html `
<div class="${cn(this.getWrapperClasses(), this.cssClass)}">
${this.renderLabel()}
${this.hasResult() ? this.renderResult() : (this.isOpen ? this.renderViewfinder() : this.renderTrigger())}
${this.renderError()}
${this.renderHelper()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlScanDocumentMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanDocumentMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanDocumentMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlScanDocumentMolecule.prototype, "facing", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'auto-capture' })
], MlScanDocumentMolecule.prototype, "autoCapture", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'capture-interval' })
], MlScanDocumentMolecule.prototype, "captureInterval", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanDocumentMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlScanDocumentMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlScanDocumentMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlScanDocumentMolecule.prototype, "corners", void 0);
__decorate([
    state()
], MlScanDocumentMolecule.prototype, "manualOverride", void 0);
__decorate([
    state()
], MlScanDocumentMolecule.prototype, "isCapturing", void 0);
__decorate([
    state()
], MlScanDocumentMolecule.prototype, "videoReady", void 0);
__decorate([
    query('video')
], MlScanDocumentMolecule.prototype, "videoEl", void 0);
__decorate([
    query('.ml-scan-overlay')
], MlScanDocumentMolecule.prototype, "overlayEl", void 0);
MlScanDocumentMolecule = __decorate([
    customElement('groupscancode--ml-scan-document')
], MlScanDocumentMolecule);
export { MlScanDocumentMolecule };
