var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupsearchcontent/ml-faceted-search.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// FACETED SEARCH MOLECULE
// =============================================================================
// Skill Group: groupSearchContent
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search',
    loading: 'Loading...',
    empty: 'No options available',
    clear: 'Clear search',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let FacetedSearchMolecule = class FacetedSearchMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        this.instanceId = Math.random().toString(36).slice(2);
        this.isPointerDown = false;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Suggestion', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.debounce = 300;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.query = '';
        this.isOpen = false;
        this.highlightedIndex = -1;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    updated(changed) {
        if (changed.has('value')) {
            this.updateQueryFromValue();
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.disabled)
            return;
        const input = e.target;
        const next = input.value;
        this.query = next;
        this.highlightedIndex = -1;
        if (next.trim() === '') {
            this.clearValue();
            return;
        }
        this.isOpen = true;
        this.scheduleSearch();
    }
    handleKeyDown(e) {
        if (this.disabled)
            return;
        const items = this.getSuggestionItems();
        const total = items.length;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (!this.isOpen)
                this.isOpen = true;
            if (total === 0)
                return;
            this.highlightedIndex = (this.highlightedIndex + 1) % total;
            return;
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (!this.isOpen)
                this.isOpen = true;
            if (total === 0)
                return;
            this.highlightedIndex = (this.highlightedIndex - 1 + total) % total;
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            if (this.highlightedIndex >= 0 && items[this.highlightedIndex]) {
                this.confirmSelection(items[this.highlightedIndex]);
            }
            else {
                this.confirmFreeText();
            }
            return;
        }
        if (e.key === 'Escape') {
            e.preventDefault();
            this.isOpen = false;
            this.highlightedIndex = -1;
        }
    }
    handleFocus() {
        if (this.disabled)
            return;
        this.isOpen = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        window.setTimeout(() => {
            if (this.isPointerDown)
                return;
            this.isOpen = false;
            this.highlightedIndex = -1;
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        }, 120);
    }
    handleClear() {
        if (this.disabled)
            return;
        this.clearValue();
    }
    handleSuggestionClick(item) {
        if (this.disabled)
            return;
        this.confirmSelection(item);
    }
    handlePanelPointerDown() {
        this.isPointerDown = true;
    }
    handlePanelPointerUp() {
        this.isPointerDown = false;
    }
    // ===========================================================================
    // LOGIC
    // ===========================================================================
    scheduleSearch() {
        if (this.disabled)
            return;
        if (this.searchTimer)
            window.clearTimeout(this.searchTimer);
        const delay = Math.max(0, Number(this.debounce) || 0);
        this.searchTimer = window.setTimeout(() => {
            if (this.disabled)
                return;
            if (this.query.trim() === '')
                return;
            this.dispatchEvent(new CustomEvent('search', {
                bubbles: true,
                composed: true,
                detail: { query: this.query },
            }));
        }, delay);
    }
    confirmSelection(item) {
        this.value = item.value;
        this.query = item.labelText;
        this.isOpen = false;
        this.highlightedIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    confirmFreeText() {
        const trimmed = this.query.trim();
        if (trimmed === '') {
            this.clearValue();
            return;
        }
        this.value = trimmed;
        this.isOpen = false;
        this.highlightedIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    clearValue() {
        this.value = null;
        this.query = '';
        this.isOpen = false;
        this.highlightedIndex = -1;
        if (this.searchTimer)
            window.clearTimeout(this.searchTimer);
        this.dispatchEvent(new CustomEvent('clear', { bubbles: true, composed: true }));
    }
    updateQueryFromValue() {
        if (this.value === null || this.value === undefined || this.value === '') {
            this.query = '';
            return;
        }
        const match = this.getSuggestionItems().find((item) => item.value === this.value);
        if (match) {
            this.query = match.labelText;
        }
        else {
            this.query = String(this.value);
        }
    }
    // ===========================================================================
    // DATA PARSING
    // ===========================================================================
    getSuggestionItems() {
        return this.getSlots('Suggestion').map((el, index) => {
            const value = el.getAttribute('value') || '';
            const labelHtml = el.innerHTML || '';
            const labelText = el.textContent || '';
            return {
                id: `option-${this.instanceId}-${index}`,
                value,
                labelHtml,
                labelText,
            };
        });
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const suggestions = this.getSuggestionItems();
        const labelId = this.hasSlot('Label')
            ? `label-${this.instanceId}`
            : '';
        const errorId = this.error ? `error-${this.instanceId}` : '';
        const listboxId = `listbox-${this.instanceId}`;
        const panelOpen = this.isOpen || this.loading;
        const activeDescendant = this.highlightedIndex >= 0 && suggestions[this.highlightedIndex]
            ? suggestions[this.highlightedIndex].id
            : '';
        return html `
      <div class="w-full">
        ${this.renderLabel(labelId)}

        <div class="relative">
          <input
            class="${this.getInputClasses()}"
            .value=${this.query}
            name=${this.name}
            placeholder=${this.placeholder || this.msg.placeholder}
            role="combobox"
            aria-expanded=${panelOpen ? 'true' : 'false'}
            aria-autocomplete="list"
            aria-controls=${listboxId}
            aria-activedescendant=${activeDescendant}
            aria-labelledby=${labelId || nothing}
            aria-describedby=${errorId || nothing}
            aria-invalid=${this.error ? 'true' : 'false'}
            ?disabled=${this.disabled}
            @input=${this.handleInput}
            @keydown=${this.handleKeyDown}
            @focus=${this.handleFocus}
            @blur=${this.handleBlur}
          />

          ${this.query.length > 0 && !this.disabled
            ? html `
                <button
                  type="button"
                  class="${this.getClearButtonClasses()}"
                  aria-label=${this.msg.clear}
                  @click=${this.handleClear}
                >
                  ×
                </button>
              `
            : nothing}

          ${panelOpen
            ? html `
                <div
                  class="${this.getPanelClasses()}"
                  role="listbox"
                  id=${listboxId}
                  @mousedown=${this.handlePanelPointerDown}
                  @mouseup=${this.handlePanelPointerUp}
                >
                  ${this.loading
                ? html `
                        <div class="px-3 py-2 text-sm text-slate-500 dark:text-slate-400">
                          ${this.msg.loading}
                        </div>
                      `
                : this.renderSuggestions(suggestions)}
                </div>
              `
            : nothing}
        </div>

        ${this.renderFeedback(errorId)}
      </div>
    `;
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <div
        id=${labelId}
        class="mb-2 text-sm text-slate-600 dark:text-slate-400"
      >
        ${unsafeHTML(this.getSlotContent('Label'))}
      </div>
    `;
    }
    renderSuggestions(items) {
        if (items.length === 0) {
            const content = this.hasSlot('Empty')
                ? this.getSlotContent('Empty')
                : this.msg.empty;
            return html `
        <div class="px-3 py-2 text-sm text-slate-500 dark:text-slate-400">
          ${unsafeHTML(content)}
        </div>
      `;
        }
        return html `
      ${items.map((item, index) => {
            const isActive = index === this.highlightedIndex;
            return html `
          <div
            id=${item.id}
            role="option"
            aria-selected=${isActive ? 'true' : 'false'}
            class="${this.getItemClasses(isActive)}"
            @click=${() => this.handleSuggestionClick(item)}
          >
            ${unsafeHTML(item.labelHtml)}
          </div>
        `;
        })}
    `;
    }
    renderFeedback(errorId) {
        if (this.error) {
            return html `
        <p
          id=${errorId}
          class="mt-1 text-xs text-red-600 dark:text-red-400"
        >
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    // ===========================================================================
    // CLASSES
    // ===========================================================================
    getInputClasses() {
        return [
            'w-full rounded-lg px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            this.error
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
            this.query.length > 0 && !this.disabled ? 'pr-9' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getClearButtonClasses() {
        return [
            'absolute right-2 top-1/2 -translate-y-1/2',
            'h-6 w-6 rounded-full text-slate-500 dark:text-slate-400',
            'hover:bg-slate-100 dark:hover:bg-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
        ].join(' ');
    }
    getPanelClasses() {
        return [
            'absolute z-10 mt-2 w-full rounded-lg border',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
            'shadow-sm',
            'max-h-60 overflow-auto',
        ].join(' ');
    }
    getItemClasses(isActive) {
        return [
            'px-3 py-2 text-sm cursor-pointer transition',
            'text-slate-900 dark:text-slate-100',
            isActive
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border border-sky-500 dark:border-sky-400'
                : 'border border-transparent',
            !isActive ? 'hover:bg-slate-50 dark:hover:bg-slate-700' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
};
__decorate([
    propertyDataSource({ type: String })
], FacetedSearchMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], FacetedSearchMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], FacetedSearchMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], FacetedSearchMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number })
], FacetedSearchMolecule.prototype, "debounce", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], FacetedSearchMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], FacetedSearchMolecule.prototype, "loading", void 0);
__decorate([
    state()
], FacetedSearchMolecule.prototype, "query", void 0);
__decorate([
    state()
], FacetedSearchMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], FacetedSearchMolecule.prototype, "highlightedIndex", void 0);
FacetedSearchMolecule = __decorate([
    customElement('groupsearchcontent--ml-faceted-search')
], FacetedSearchMolecule);
export { FacetedSearchMolecule };
