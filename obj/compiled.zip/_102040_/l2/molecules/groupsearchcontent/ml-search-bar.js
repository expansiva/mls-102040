var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupsearchcontent/ml-search-bar.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML-SEARCH-BAR MOLECULE
// =============================================================================
// Skill Group: groupSearchContent
// This molecule does NOT contain business logic.
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search',
    loading: 'Loading...',
    noResults: 'No results found',
    clear: 'Clear search',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlSearchBarMolecule = class MlSearchBarMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupsearchcontent--ml-search-bar .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupsearchcontent--ml-search-bar .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupsearchcontent--ml-search-bar .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupsearchcontent--ml-search-bar .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupsearchcontent--ml-search-bar .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupsearchcontent--ml-search-bar .ml-search-container {
  background: var(--ml-surface, #fff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupsearchcontent--ml-search-bar .ml-search-input {
  background: var(--ml-surface, #fff);
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupsearchcontent--ml-search-bar .ml-search-input::placeholder {
  color: var(--ml-on-surface-muted, #49454f);
}
groupsearchcontent--ml-search-bar .ml-search-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupsearchcontent--ml-search-bar .ml-error-border {
  border-color: var(--ml-error, #ef4444);
}
groupsearchcontent--ml-search-bar .ml-search-focus:focus {
  outline: none;
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupsearchcontent--ml-search-bar .ml-search-icon {
  color: var(--ml-on-surface-muted, #49454f);
}
groupsearchcontent--ml-search-bar .ml-search-clear {
  color: var(--ml-on-surface-muted, #49454f);
}
groupsearchcontent--ml-search-bar .ml-search-clear:hover {
  color: var(--ml-on-surface, #1c1b1f);
}
groupsearchcontent--ml-search-bar .ml-filter-chip-active {
  background: var(--ml-primary, #3b82f6);
  background: color-mix(in srgb, var(--ml-primary, #3b82f6) 10%, transparent);
  color: var(--ml-primary, #3b82f6);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-primary, #3b82f6);
}
`);
        this.msg = messages.en;
        this.debounceTimer = null;
        this.componentId = `ml-search-bar-${Math.random().toString(36).slice(2)}`;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Suggestion', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.debounce = 300;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.query = '';
        this.isOpen = false;
        this.highlightIndex = -1;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            const stringValue = value ?? '';
            const suggestions = this.getSuggestions();
            const matched = suggestions.find((s) => s.value === stringValue);
            this.query = matched ? matched.labelText : String(stringValue);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        e.stopPropagation();
        if (this.disabled)
            return;
        const input = e.target;
        this.query = input.value;
        this.isOpen = true;
        this.highlightIndex = -1;
        if (!this.query) {
            this.value = null;
            this.dispatchEvent(new CustomEvent('clear', { bubbles: true, composed: true }));
        }
        this.scheduleSearch();
    }
    handleFocus() {
        if (this.disabled)
            return;
        this.isOpen = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        window.setTimeout(() => {
            this.isOpen = false;
            this.highlightIndex = -1;
        }, 100);
    }
    handleKeyDown(e) {
        if (this.disabled)
            return;
        const suggestions = this.getSuggestions();
        const maxIndex = suggestions.length - 1;
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.isOpen = true;
            this.highlightIndex = Math.min(maxIndex, this.highlightIndex + 1);
            return;
        }
        if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.isOpen = true;
            this.highlightIndex = Math.max(-1, this.highlightIndex - 1);
            return;
        }
        if (e.key === 'Enter') {
            e.preventDefault();
            if (this.highlightIndex >= 0 && suggestions[this.highlightIndex]) {
                this.confirmSuggestion(suggestions[this.highlightIndex]);
            }
            else {
                this.confirmQuery();
            }
            return;
        }
        if (e.key === 'Escape') {
            this.isOpen = false;
            this.highlightIndex = -1;
        }
    }
    handleClearClick() {
        if (this.disabled)
            return;
        this.query = '';
        this.value = null;
        this.isOpen = false;
        this.highlightIndex = -1;
        this.dispatchEvent(new CustomEvent('clear', { bubbles: true, composed: true }));
    }
    handleSuggestionClick(index) {
        if (this.disabled)
            return;
        const suggestions = this.getSuggestions();
        const suggestion = suggestions[index];
        if (suggestion) {
            this.confirmSuggestion(suggestion);
        }
    }
    // ===========================================================================
    // DATA + ACTIONS
    // ===========================================================================
    scheduleSearch() {
        if (this.debounceTimer) {
            window.clearTimeout(this.debounceTimer);
        }
        this.debounceTimer = window.setTimeout(() => {
            if (this.disabled)
                return;
            this.dispatchEvent(new CustomEvent('search', {
                bubbles: true,
                composed: true,
                detail: { query: this.query },
            }));
        }, this.debounce);
    }
    confirmQuery() {
        if (this.disabled)
            return;
        if (!this.query) {
            this.value = null;
            this.dispatchEvent(new CustomEvent('clear', { bubbles: true, composed: true }));
            return;
        }
        this.value = this.query;
        this.isOpen = false;
        this.highlightIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    confirmSuggestion(suggestion) {
        this.value = suggestion.value;
        this.query = suggestion.labelText;
        this.isOpen = false;
        this.highlightIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    // ===========================================================================
    // RENDERING HELPERS
    // ===========================================================================
    getSuggestions() {
        return this.getSlots('Suggestion').map((el) => ({
            value: el.getAttribute('value') || '',
            labelHtml: el.innerHTML,
            labelText: el.textContent || '',
        }));
    }
    getInputClasses() {
        return [
            'w-full rounded-lg pl-10 pr-10 py-2 text-sm border transition',
            'ml-search-input',
            this.error
                ? 'ml-error-border'
                : 'ml-search-border',
            'ml-search-focus',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'rounded-lg border mt-2 p-2 space-y-1',
            'ml-search-container',
            this.isOpen ? 'block' : 'hidden',
        ].filter(Boolean).join(' ');
    }
    getSuggestionClasses(isActive) {
        return [
            'w-full text-left rounded-md px-3 py-2 text-sm transition',
            isActive
                ? 'ml-filter-chip-active'
                : 'ml-text border border-transparent',
            !this.disabled && !isActive ? 'ml-search-icon' : '',
            this.disabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const labelId = `${this.componentId}-label`;
        return html `
<label id=${labelId} class=${cn('block mb-1 text-sm ml-label', this.getSlotClass('Label'))}>
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderHelperOrError() {
        if (this.error) {
            const errorId = `${this.componentId}-error`;
            return html `<p id=${errorId} class="mt-1 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            const helperId = `${this.componentId}-helper`;
            return html `<p id=${helperId} class=${cn('mt-1 text-xs ml-text-muted', this.getSlotClass('Helper'))}>${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderSuggestions() {
        const suggestions = this.getSuggestions();
        const hasSuggestions = suggestions.length > 0;
        const showEmpty = !this.loading && !hasSuggestions && this.query;
        return html `
<div id=${`${this.componentId}-list`} class=${this.getPanelClasses()} role="listbox">
${this.loading ? html `
<div class="px-3 py-2 text-sm ml-text-muted">
${this.msg.loading}
</div>
` : html ``}
${hasSuggestions ? suggestions.map((item, index) => html `
<button
class=${this.getSuggestionClasses(index === this.highlightIndex)}
role="option"
aria-selected=${index === this.highlightIndex}
?disabled=${this.disabled}
@mousedown=${(e) => e.preventDefault()}
@click=${() => this.handleSuggestionClick(index)}
>
${unsafeHTML(item.labelHtml)}
</button>
`) : html ``}
${showEmpty ? html `
<div class=${cn('px-3 py-2 text-sm ml-text-muted', this.getSlotClass('Empty'))}>
${unsafeHTML(this.getSlotContent('Empty') || this.msg.noResults)}
</div>
` : html ``}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelId = this.hasSlot('Label') ? `${this.componentId}-label` : undefined;
        const errorId = this.error ? `${this.componentId}-error` : undefined;
        const helperId = !this.error && this.hasSlot('Helper') ? `${this.componentId}-helper` : undefined;
        const describedBy = [errorId, helperId].filter(Boolean).join(' ') || undefined;
        const inputPlaceholder = this.placeholder || this.msg.placeholder;
        const showClear = !!this.query && !this.disabled;
        return html `
<div class=${cn('w-full', this.cssClass)}>
${this.renderLabel()}
<div class="relative">
<span class="absolute left-3 top-1/2 -translate-y-1/2 ml-search-icon">
<svg width="16" height="16" viewBox="0 0 24 24" aria-hidden="true">
${svg `<path d="M10.5 3a7.5 7.5 0 1 1-4.24 13.68l-3.97 3.97a1 1 0 1 1-1.42-1.42l3.97-3.97A7.5 7.5 0 0 1 10.5 3zm0 2a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11z" fill="currentColor" />`}
</svg>
</span>
<input
class=${this.getInputClasses()}
type="text"
name=${this.name}
.placeholder=${inputPlaceholder}
.value=${this.query}
?disabled=${this.disabled}
role="combobox"
aria-expanded=${this.isOpen}
aria-autocomplete="list"
aria-controls=${`${this.componentId}-list`}
aria-labelledby=${labelId || ''}
aria-describedby=${describedBy || ''}
aria-invalid=${this.error ? 'true' : 'false'}
@input=${this.handleInput}
@focus=${this.handleFocus}
@blur=${this.handleBlur}
@keydown=${this.handleKeyDown}

@change=${(e) => e.stopPropagation()}
/>
${showClear ? html `
<button
class="absolute right-3 top-1/2 -translate-y-1/2 ml-search-clear"
aria-label=${this.msg.clear}
@mousedown=${(e) => e.preventDefault()}
@click=${this.handleClearClick}
>
<svg width="14" height="14" viewBox="0 0 24 24" aria-hidden="true">
${svg `<path d="M6.7 5.3a1 1 0 0 1 1.4 0L12 9.17l3.9-3.88a1 1 0 1 1 1.4 1.42L13.42 10.6l3.88 3.9a1 1 0 0 1-1.42 1.4L12 12.02l-3.9 3.88a1 1 0 1 1-1.4-1.42l3.88-3.9-3.88-3.88a1 1 0 0 1 0-1.4z" fill="currentColor" />`}
</svg>
</button>
` : html ``}
</div>
${this.renderSuggestions()}
${this.renderHelperOrError()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlSearchBarMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number })
], MlSearchBarMolecule.prototype, "debounce", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSearchBarMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlSearchBarMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlSearchBarMolecule.prototype, "query", void 0);
__decorate([
    state()
], MlSearchBarMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlSearchBarMolecule.prototype, "highlightIndex", void 0);
MlSearchBarMolecule = __decorate([
    customElement('groupsearchcontent--ml-search-bar')
], MlSearchBarMolecule);
export { MlSearchBarMolecule };
