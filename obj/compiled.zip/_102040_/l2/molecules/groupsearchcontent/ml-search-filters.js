/// <mls fileReference="_102040_/l2/molecules/groupsearchcontent/ml-search-filters.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// SEARCH FILTERS MOLECULE
// =============================================================================
// Skill Group: groupSearchContent
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Search...',
    filters: 'Filters',
    clearSearch: 'Clear search',
    removeSelection: 'Remove selection',
    noResults: 'No results found',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Buscar...',
        filters: 'Filtros',
        clearSearch: 'Limpar busca',
        removeSelection: 'Remover seleção',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
    },
};
let SearchFiltersMolecule = class SearchFiltersMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Suggestion', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.debounce = 300;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.query = '';
        this.isOpen = false;
        this.selectedLabel = '';
        this.highlightedIndex = -1;
        this.debounceTimer = null;
        this.inputId = `search-input-${Math.random().toString(36).substring(2, 9)}`;
        this.listboxId = `listbox-${Math.random().toString(36).substring(2, 9)}`;
        this.labelId = `label-${Math.random().toString(36).substring(2, 9)}`;
        this.errorId = `error-${Math.random().toString(36).substring(2, 9)}`;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        if (valueAttr === `{{${key}}}`) {
            if (value === null || value === '') {
                this.query = '';
                this.selectedLabel = '';
            }
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getSuggestions() {
        return this.getSlots('Suggestion').map(el => ({
            value: el.getAttribute('value') || '',
            label: el.innerHTML,
        }));
    }
    getActiveSelectionCount() {
        return this.value ? 1 : 0;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleInput(e) {
        if (this.disabled)
            return;
        const input = e.target;
        this.query = input.value;
        if (this.debounceTimer) {
            clearTimeout(this.debounceTimer);
        }
        this.debounceTimer = setTimeout(() => {
            this.dispatchEvent(new CustomEvent('search', {
                bubbles: true,
                composed: true,
                detail: { query: this.query }
            }));
        }, this.debounce);
    }
    handleKeyDown(e) {
        if (this.disabled)
            return;
        const suggestions = this.getSuggestions();
        switch (e.key) {
            case 'Enter':
                e.preventDefault();
                if (this.isOpen && this.highlightedIndex >= 0 && suggestions[this.highlightedIndex]) {
                    this.selectSuggestion(suggestions[this.highlightedIndex]);
                }
                else if (this.query.trim()) {
                    this.confirmQuery();
                }
                break;
            case 'Escape':
                if (this.isOpen) {
                    e.preventDefault();
                    this.isOpen = false;
                    this.highlightedIndex = -1;
                }
                break;
            case 'ArrowDown':
                if (this.isOpen && suggestions.length > 0) {
                    e.preventDefault();
                    this.highlightedIndex = Math.min(this.highlightedIndex + 1, suggestions.length - 1);
                }
                break;
            case 'ArrowUp':
                if (this.isOpen && suggestions.length > 0) {
                    e.preventDefault();
                    this.highlightedIndex = Math.max(this.highlightedIndex - 1, 0);
                }
                break;
        }
    }
    confirmQuery() {
        this.value = this.query;
        this.selectedLabel = this.query;
        this.isOpen = false;
        this.highlightedIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    selectSuggestion(suggestion) {
        if (this.disabled)
            return;
        this.value = suggestion.value;
        this.query = this.stripHtml(suggestion.label);
        this.selectedLabel = suggestion.label;
        this.isOpen = false;
        this.highlightedIndex = -1;
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value }
        }));
    }
    stripHtml(html) {
        const tmp = document.createElement('div');
        tmp.innerHTML = html;
        return tmp.textContent || tmp.innerText || '';
    }
    handleClear() {
        if (this.disabled)
            return;
        this.query = '';
        this.value = null;
        this.selectedLabel = '';
        this.highlightedIndex = -1;
        this.dispatchEvent(new CustomEvent('clear', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: null }
        }));
    }
    handleRemoveChip() {
        if (this.disabled)
            return;
        this.query = '';
        this.value = null;
        this.selectedLabel = '';
        this.dispatchEvent(new CustomEvent('clear', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: null }
        }));
    }
    handleTogglePanel() {
        if (this.disabled)
            return;
        this.isOpen = !this.isOpen;
        if (!this.isOpen) {
            this.highlightedIndex = -1;
        }
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
            detail: {}
        }));
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getContainerClasses() {
        return [
            'w-full flex flex-col gap-2',
        ].join(' ');
    }
    getLabelClasses() {
        return [
            'text-sm font-medium',
            'text-slate-700 dark:text-slate-300',
        ].join(' ');
    }
    getInputRowClasses() {
        return [
            'flex items-center gap-2',
        ].join(' ');
    }
    getInputWrapperClasses() {
        return [
            'flex-1 relative',
        ].join(' ');
    }
    getInputClasses() {
        return [
            'w-full rounded-lg px-3 py-2 pr-10 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            this.error
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2',
            this.error
                ? 'focus:ring-red-500 dark:focus:ring-red-400'
                : 'focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled ? 'opacity-50 cursor-not-allowed bg-slate-100 dark:bg-slate-800' : '',
        ].filter(Boolean).join(' ');
    }
    getClearButtonClasses() {
        return [
            'absolute right-2 top-1/2 -translate-y-1/2',
            'p-1 rounded-full transition',
            'text-slate-400 dark:text-slate-500',
            'hover:text-slate-600 dark:hover:text-slate-300',
            'hover:bg-slate-100 dark:hover:bg-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getFilterButtonClasses() {
        return [
            'flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition',
            'border',
            this.isOpen
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border-sky-500 dark:border-sky-400'
                : 'bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700',
            !this.disabled && !this.isOpen ? 'hover:bg-slate-50 dark:hover:bg-slate-700' : '',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getBadgeClasses() {
        return [
            'inline-flex items-center justify-center min-w-5 h-5 px-1.5 rounded-full text-xs font-medium',
            'bg-sky-500 dark:bg-sky-400 text-white dark:text-slate-900',
        ].join(' ');
    }
    getChipsContainerClasses() {
        return [
            'flex flex-wrap gap-2',
        ].join(' ');
    }
    getChipClasses() {
        return [
            'inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-sm',
            'bg-sky-50 dark:bg-sky-900/40',
            'text-sky-700 dark:text-sky-300',
            'border border-sky-200 dark:border-sky-700',
        ].join(' ');
    }
    getChipRemoveClasses() {
        return [
            'p-0.5 rounded-full transition',
            'text-sky-500 dark:text-sky-400',
            'hover:text-sky-700 dark:hover:text-sky-200',
            'hover:bg-sky-100 dark:hover:bg-sky-800',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'mt-2 rounded-lg border shadow-lg overflow-hidden',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
        ].join(' ');
    }
    getPanelContentClasses() {
        return [
            'max-h-60 overflow-y-auto p-2',
        ].join(' ');
    }
    getSuggestionClasses(index, isSelected) {
        return [
            'w-full px-3 py-2 rounded-md text-sm text-left transition cursor-pointer',
            'text-slate-900 dark:text-slate-100',
            isSelected
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300'
                : '',
            this.highlightedIndex === index && !isSelected
                ? 'bg-slate-100 dark:bg-slate-700'
                : '',
            !isSelected && this.highlightedIndex !== index
                ? 'hover:bg-slate-50 dark:hover:bg-slate-700'
                : '',
            'focus:outline-none focus:ring-2 focus:ring-inset focus:ring-sky-500 dark:focus:ring-sky-400',
        ].filter(Boolean).join(' ');
    }
    getEmptyClasses() {
        return [
            'px-3 py-4 text-sm text-center',
            'text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    getLoadingClasses() {
        return [
            'flex items-center justify-center gap-2 px-3 py-4 text-sm',
            'text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    getHelperClasses() {
        return [
            'text-xs',
            'text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    getErrorClasses() {
        return [
            'text-xs',
            'text-red-600 dark:text-red-400',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER METHODS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label')) {
            return html ``;
        }
        return html `
      <label
        id=${this.labelId}
        class=${this.getLabelClasses()}
      >
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderClearButton() {
        if (!this.query) {
            return html ``;
        }
        return html `
      <button
        type="button"
        class=${this.getClearButtonClasses()}
        aria-label=${this.msg.clearSearch}
        @click=${this.handleClear}
        ?disabled=${this.disabled}
      >
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
        </svg>
      </button>
    `;
    }
    renderFilterButton() {
        const count = this.getActiveSelectionCount();
        return html `
      <button
        type="button"
        class=${this.getFilterButtonClasses()}
        aria-expanded=${this.isOpen}
        aria-controls=${this.listboxId}
        @click=${this.handleTogglePanel}
        ?disabled=${this.disabled}
      >
        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z"></path>
        </svg>
        <span>${this.msg.filters}</span>
        <span class=${this.getBadgeClasses()}>${count}</span>
      </button>
    `;
    }
    renderChips() {
        if (!this.value || !this.selectedLabel) {
            return html ``;
        }
        return html `
      <div class=${this.getChipsContainerClasses()}>
        <span class=${this.getChipClasses()}>
          <span>${unsafeHTML(this.selectedLabel)}</span>
          <button
            type="button"
            class=${this.getChipRemoveClasses()}
            aria-label=${this.msg.removeSelection}
            @click=${this.handleRemoveChip}
            ?disabled=${this.disabled}
          >
            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
          </button>
        </span>
      </div>
    `;
    }
    renderPanel() {
        if (!this.isOpen) {
            return html ``;
        }
        return html `
      <div
        id=${this.listboxId}
        class=${this.getPanelClasses()}
        role="listbox"
        aria-labelledby=${this.labelId}
      >
        <div class=${this.getPanelContentClasses()}>
          ${this.renderPanelContent()}
        </div>
      </div>
    `;
    }
    renderPanelContent() {
        if (this.loading) {
            return html `
        <div class=${this.getLoadingClasses()}>
          <svg class="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <span>${this.msg.loading}</span>
        </div>
      `;
        }
        const suggestions = this.getSuggestions();
        if (suggestions.length === 0) {
            const emptyContent = this.hasSlot('Empty')
                ? this.getSlotContent('Empty')
                : this.msg.noResults;
            return html `
        <div class=${this.getEmptyClasses()}>
          ${unsafeHTML(emptyContent)}
        </div>
      `;
        }
        return html `
      ${suggestions.map((suggestion, index) => this.renderSuggestion(suggestion, index))}
    `;
    }
    renderSuggestion(suggestion, index) {
        const isSelected = this.value === suggestion.value;
        return html `
      <button
        type="button"
        class=${this.getSuggestionClasses(index, isSelected)}
        role="option"
        aria-selected=${isSelected}
        @click=${() => this.selectSuggestion(suggestion)}
        @mouseenter=${() => { this.highlightedIndex = index; }}
      >
        ${unsafeHTML(suggestion.label)}
      </button>
    `;
    }
    renderFeedback() {
        if (this.error) {
            return html `
        <p id=${this.errorId} class=${this.getErrorClasses()}>
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class=${this.getHelperClasses()}>
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const placeholderText = this.placeholder || this.msg.placeholder;
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()}

        <div class=${this.getInputRowClasses()}>
          <div class=${this.getInputWrapperClasses()}>
            <input
              id=${this.inputId}
              type="text"
              class=${this.getInputClasses()}
              placeholder=${placeholderText}
              .value=${this.query}
              ?disabled=${this.disabled}
              role="combobox"
              aria-expanded=${this.isOpen}
              aria-autocomplete="list"
              aria-controls=${this.listboxId}
              aria-labelledby=${this.hasSlot('Label') ? this.labelId : ''}
              aria-describedby=${this.error ? this.errorId : ''}
              aria-invalid=${this.error ? 'true' : 'false'}
              @input=${this.handleInput}
              @keydown=${this.handleKeyDown}
              @focus=${this.handleFocus}
              @blur=${this.handleBlur}
            />
            ${this.renderClearButton()}
          </div>
          ${this.renderFilterButton()}
        </div>

        ${this.renderChips()}
        ${this.renderPanel()}
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], SearchFiltersMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], SearchFiltersMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], SearchFiltersMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], SearchFiltersMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Number })
], SearchFiltersMolecule.prototype, "debounce", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SearchFiltersMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], SearchFiltersMolecule.prototype, "loading", void 0);
__decorate([
    state()
], SearchFiltersMolecule.prototype, "query", void 0);
__decorate([
    state()
], SearchFiltersMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], SearchFiltersMolecule.prototype, "selectedLabel", void 0);
__decorate([
    state()
], SearchFiltersMolecule.prototype, "highlightedIndex", void 0);
SearchFiltersMolecule = __decorate([
    customElement('groupsearchcontent--ml-search-filters')
], SearchFiltersMolecule);
export { SearchFiltersMolecule };
