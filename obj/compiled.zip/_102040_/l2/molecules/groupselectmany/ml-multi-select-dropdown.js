var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectmany/ml-multi-select-dropdown.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MULTI SELECT DROPDOWN MOLECULE
// =============================================================================
// Skill Group: groupSelectMany
// This molecule does NOT contain business logic.
import { html, render as litRender } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select options',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    empty: 'No options available',
    selectedCount: 'selected',
    requiredError: 'Select at least one option',
    minSelectionError: 'Select at least {min} options',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione opções',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        empty: 'Nenhuma opção disponível',
        selectedCount: 'selecionado(s)',
        requiredError: 'Selecione pelo menos uma opção',
        minSelectionError: 'Selecione pelo menos {min} opções',
    },
};
let MultiSelectDropdownMolecule = class MultiSelectDropdownMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-multi-select-dropdown .ml-label,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupselectmany--ml-multi-select-dropdown .ml-helper,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-multi-select-dropdown .ml-error-text,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-multi-select-dropdown .ml-text,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-multi-select-dropdown .ml-text-muted,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-multi-select-dropdown .ml-disabled,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-multi-select-dropdown .ml-select-trigger,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-trigger {
  background-color: var(--button-secondary-bg, #ffffff);
  color: var(--button-secondary-text, #1c1b1f);
  border-color: var(--button-secondary-border, #e2e8f0);
}
groupselectmany--ml-multi-select-dropdown .ml-select-trigger-error,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-trigger-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupselectmany--ml-multi-select-dropdown .ml-select-trigger-focus:focus,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-trigger-focus:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupselectmany--ml-multi-select-dropdown .ml-select-panel,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-panel {
  background-color: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
}
groupselectmany--ml-multi-select-dropdown .ml-select-item,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-item {
  color: var(--text-strong, #1c1b1f);
}
groupselectmany--ml-multi-select-dropdown .ml-select-item-selected,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-item-selected {
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 8%, var(--ml-surface, #ffffff));
  color: var(--selected-text, #3b82f6);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--selected-border, #3b82f6);
}
groupselectmany--ml-multi-select-dropdown .ml-select-item-hover:hover,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-item-hover:hover {
  background-color: var(--surface-alt-bg, #f5f5f5);
}
groupselectmany--ml-multi-select-dropdown .ml-select-tag,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-tag {
  background-color: var(--surface-alt-bg, #f5f5f5);
  color: var(--text-strong, #1c1b1f);
}
groupselectmany--ml-multi-select-dropdown .ml-select-check,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-check {
  color: var(--selected-text, #3b82f6);
}
groupselectmany--ml-multi-select-dropdown .ml-select-search,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-search {
  border-color: var(--border-default, #e2e8f0);
  background-color: var(--input-bg, #ffffff);
  color: var(--text-strong, #1c1b1f);
}
groupselectmany--ml-multi-select-dropdown .ml-select-search::placeholder,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-search::placeholder {
  color: var(--text-muted, #49454f);
}
groupselectmany--ml-multi-select-dropdown .ml-select-search:focus,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-search:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupselectmany--ml-multi-select-dropdown .ml-select-view,
div[data-widget="groupselectmany--ml-multi-select-dropdown"] .ml-select-view {
  border-color: var(--border-default, #e2e8f0);
  background-color: var(--surface-alt-bg, #f5f5f5);
  color: var(--text-strong, #1c1b1f);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.minSelection = 0;
        this.maxSelection = 0;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.isOpen = false;
        this.searchQuery = '';
        this.uid = `msd-${Math.random().toString(36).slice(2)}`;
        this.labelId = `${this.uid}-label`;
        this.helperId = `${this.uid}-helper`;
        this.errorId = `${this.uid}-error`;
        this.panelId = `${this.uid}-panel`;
        this.hasFocus = false;
        this.portalContainer = null;
        this.portalWidgetName = 'groupselectmany--ml-multi-select-dropdown';
        this.boundUpdatePosition = () => this.updatePanelPosition();
        this.handleDocumentClick = (e) => {
            const target = e.target;
            if (!target || (!this.contains(target) && !this.portalContainer?.contains(target))) {
                this.closePanel();
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================
    connectedCallback() {
        super.connectedCallback();
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        this.unregisterOutsideClick();
        this.destroyPortal();
    }
    updated(_changedProperties) {
        super.updated(_changedProperties);
        if (this.isOpen && this.portalContainer) {
            this.renderPortalContent();
            this.updatePanelPosition();
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleTriggerClick() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        this.toggleOpen();
    }
    handleTriggerKeydown(e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            this.toggleOpen();
        }
    }
    handlePanelKeydown(e) {
        if (!this.isOpen)
            return;
        if (e.key === 'Escape') {
            e.preventDefault();
            this.closePanel();
            this.focusTrigger();
            return;
        }
        if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
            e.preventDefault();
            const direction = e.key === 'ArrowDown' ? 1 : -1;
            this.moveOptionFocus(direction);
            return;
        }
        if (e.key === ' ' || e.key === 'Enter') {
            const active = document.activeElement;
            if (active && active.dataset.optionValue) {
                e.preventDefault();
                this.toggleSelection(active.dataset.optionValue);
            }
        }
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
    }
    handleOptionClick(value) {
        this.toggleSelection(value);
    }
    handleFocusIn() {
        if (!this.isEditing || this.disabled || this.readonly)
            return;
        if (!this.hasFocus) {
            this.hasFocus = true;
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
    }
    handleFocusOut(e) {
        if (!this.isEditing)
            return;
        const related = e.relatedTarget;
        if (this.hasFocus && (!related || (!this.contains(related) && !this.portalContainer?.contains(related)))) {
            this.hasFocus = false;
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            this.closePanel();
        }
    }
    // ===========================================================================
    // SELECTION LOGIC
    // ==========================================================================
    toggleSelection(value) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const selected = this.getSelectedValues();
        const isSelected = selected.includes(value);
        const maxReached = this.maxSelection > 0 && selected.length >= this.maxSelection;
        if (!isSelected && maxReached)
            return;
        const updated = isSelected
            ? selected.filter(v => v !== value)
            : [...selected, value];
        this.value = updated.join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    // ===========================================================================
    // OPEN/CLOSE
    // ==========================================================================
    toggleOpen() {
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.registerOutsideClick();
            this.createPortal();
            if (this.searchable) {
                setTimeout(() => this.focusSearchInput(), 0);
            }
        }
        else {
            this.closePanel();
        }
    }
    closePanel() {
        if (!this.isOpen)
            return;
        this.isOpen = false;
        this.searchQuery = '';
        this.unregisterOutsideClick();
        this.destroyPortal();
    }
    registerOutsideClick() {
        document.addEventListener('pointerdown', this.handleDocumentClick);
    }
    unregisterOutsideClick() {
        document.removeEventListener('pointerdown', this.handleDocumentClick);
    }
    focusSearchInput() {
        const container = this.portalContainer || this;
        const input = container.querySelector('input[data-search]');
        input?.focus();
    }
    focusTrigger() {
        const trigger = this.querySelector('[data-trigger]');
        trigger?.focus();
    }
    moveOptionFocus(direction) {
        const container = this.portalContainer || this;
        const options = Array.from(container.querySelectorAll('[data-option]'));
        if (!options.length)
            return;
        const activeIndex = options.findIndex(el => el === document.activeElement);
        const nextIndex = activeIndex === -1
            ? 0
            : (activeIndex + direction + options.length) % options.length;
        options[nextIndex]?.focus();
    }
    // ===========================================================================
    // PORTAL
    // ==========================================================================
    createPortal() {
        if (this.portalContainer)
            return;
        this.portalContainer = document.createElement('div');
        if (this.portalWidgetName) {
            this.portalContainer.setAttribute('data-widget', this.portalWidgetName);
        }
        document.body.appendChild(this.portalContainer);
        this.updatePanelPosition();
        this.renderPortalContent();
        window.addEventListener('scroll', this.boundUpdatePosition, true);
        window.addEventListener('resize', this.boundUpdatePosition);
    }
    destroyPortal() {
        if (!this.portalContainer)
            return;
        window.removeEventListener('scroll', this.boundUpdatePosition, true);
        window.removeEventListener('resize', this.boundUpdatePosition);
        this.portalContainer.remove();
        this.portalContainer = null;
    }
    updatePanelPosition() {
        if (!this.portalContainer)
            return;
        const trigger = this.querySelector('button[role="combobox"]');
        if (!trigger)
            return;
        const rect = trigger.getBoundingClientRect();
        Object.assign(this.portalContainer.style, {
            position: 'fixed',
            top: `${rect.bottom + 8}px`,
            left: `${rect.left}px`,
            width: `${rect.width}px`,
            zIndex: '9999',
        });
    }
    renderPortalContent() {
        if (!this.portalContainer)
            return;
        litRender(this.getPortalTemplate(), this.portalContainer, { host: this });
    }
    getPortalTemplate() {
        const groups = this.getGroupedItems();
        const items = this.getUngroupedItems();
        const selectedValues = this.getSelectedValues();
        return html `
<div class="${this.getPanelClasses()}" @keydown=${(e) => this.handlePanelKeydown(e)}>
${this.searchable ? html `
<div class="p-2">
<input
class="w-full rounded-md border ml-select-search px-3 py-2 text-sm focus:outline-none focus:ring-2"
type="text"
placeholder="${this.msg.searchPlaceholder}"
.value=${this.searchQuery}
@input=${(e) => { e.stopPropagation(); this.handleSearchInput(e); }}
data-search

@change="${(e) => e.stopPropagation()}"
/>
</div>
` : html ``}
${this.renderOptionList(groups, items, selectedValues)}
</div>
`;
    }
    // ===========================================================================
    // PARSING
    // ==========================================================================
    getSelectedValues() {
        return this.value
            .split(',')
            .map(v => v.trim())
            .filter(v => v.length > 0);
    }
    parseItem(el, groupLabel) {
        const value = el.getAttribute('value') || '';
        const disabled = el.hasAttribute('disabled');
        const labelHtml = el.innerHTML || value;
        const labelText = (el.textContent || value).trim();
        return { value, labelHtml, labelText, disabled, groupLabel };
    }
    getGroupedItems() {
        const groups = this.getSlots('Group');
        return groups
            .map(groupEl => {
            const label = groupEl.getAttribute('label') || '';
            const items = Array.from(groupEl.querySelectorAll('Item'))
                .map(itemEl => this.parseItem(itemEl, label))
                .filter(item => item.value);
            return { label, items };
        })
            .filter(group => group.items.length > 0);
    }
    getUngroupedItems() {
        const items = Array.from(this.querySelectorAll('Item'))
            .filter(itemEl => !itemEl.closest('Group'))
            .map(itemEl => this.parseItem(itemEl))
            .filter(item => item.value);
        return items;
    }
    getAllItems() {
        const grouped = this.getGroupedItems().flatMap(g => g.items);
        const ungrouped = this.getUngroupedItems();
        return [...grouped, ...ungrouped];
    }
    // ===========================================================================
    // RENDER HELPERS
    // ==========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label id="${this.labelId}" class=${cn('mb-1 block text-sm font-medium ml-label', this.getSlotClass('Label'))}>
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderHelperOrError(errorMessage) {
        if (!this.isEditing)
            return html ``;
        if (errorMessage) {
            return html `
<p id="${this.errorId}" class="mt-1 text-xs ml-error-text">
${unsafeHTML(errorMessage)}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p id="${this.helperId}" class=${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}>
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderSelectedTags(items, selectedValues) {
        const selectedItems = selectedValues
            .map(value => items.find(item => item.value === value) || { value, labelHtml: value, labelText: value, disabled: false })
            .filter(Boolean);
        if (selectedItems.length === 0) {
            const placeholder = this.placeholder || this.msg.placeholder;
            return html `<span class="ml-text-muted">${placeholder}</span>`;
        }
        if (selectedItems.length > 3) {
            return html `<span class="ml-text-muted">${selectedItems.length} ${this.msg.selectedCount}</span>`;
        }
        return html `
<div class="flex flex-wrap gap-1">
${selectedItems.map(item => html `
<span class="rounded-md ml-select-tag px-2 py-0.5 text-xs">
${unsafeHTML(item.labelHtml)}
</span>
`)}
</div>
`;
    }
    getTriggerClasses(hasError) {
        return [
            'w-full rounded-lg border px-3 py-2 text-sm flex flex-wrap items-center gap-2 transition',
            'ml-select-trigger',
            hasError
                ? 'ml-select-trigger-error'
                : '',
            'focus:outline-none focus:ring-2 ml-select-trigger-focus',
            (this.disabled || this.readonly || this.loading) ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'w-full rounded-lg border shadow-lg',
            'ml-select-panel',
        ].join(' ');
    }
    getItemClasses(item, isSelected, isDisabled) {
        return [
            'flex w-full items-center justify-between rounded-md px-3 py-2 text-sm transition',
            isSelected
                ? 'ml-select-item-selected'
                : 'ml-select-item border border-transparent',
            !isDisabled && !isSelected ? 'ml-select-item-hover' : '',
            isDisabled ? 'ml-disabled' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    renderOptionList(groups, items, selectedValues) {
        const query = this.searchQuery.trim().toLowerCase();
        const filterItem = (item) => !query || item.labelText.toLowerCase().includes(query);
        const filteredGroups = groups
            .map(group => ({ ...group, items: group.items.filter(filterItem) }))
            .filter(group => group.items.length > 0);
        const filteredItems = items.filter(filterItem);
        if (!filteredGroups.length && !filteredItems.length) {
            const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
            return html `
<div class="px-3 py-4 text-sm ml-text-muted">
${unsafeHTML(emptyContent)}
</div>
`;
        }
        const maxReached = this.maxSelection > 0 && selectedValues.length >= this.maxSelection;
        return html `
<div class="max-h-60 overflow-auto p-2" role="listbox" aria-multiselectable="true" id="${this.panelId}">
${filteredGroups.map(group => html `
<div class="mb-2">
${group.label ? html `<div class="px-2 py-1 text-xs font-semibold ml-text-muted">${group.label}</div>` : html ``}
${group.items.map(item => {
            const isSelected = selectedValues.includes(item.value);
            const isDisabled = item.disabled || (!isSelected && maxReached);
            return html `
<button
class="${this.getItemClasses(item, isSelected, isDisabled)}"
role="option"
aria-selected="${isSelected}"
aria-disabled="${isDisabled}"
type="button"
?disabled=${isDisabled}
@mousedown=${(e) => e.preventDefault()}
@click=${() => this.handleOptionClick(item.value)}
.data-option=${true}
.data-option-value=${item.value}
>
<span>${unsafeHTML(item.labelHtml)}</span>
${isSelected ? html `<span class="ml-select-check">✓</span>` : html ``}
</button>
`;
        })}
</div>
`)}
${filteredItems.map(item => {
            const isSelected = selectedValues.includes(item.value);
            const isDisabled = item.disabled || (!isSelected && maxReached);
            return html `
<button
class="${this.getItemClasses(item, isSelected, isDisabled)}"
role="option"
aria-selected="${isSelected}"
aria-disabled="${isDisabled}"
type="button"
?disabled=${isDisabled}
@mousedown=${(e) => e.preventDefault()}
@click=${() => this.handleOptionClick(item.value)}
.data-option=${true}
.data-option-value=${item.value}
>
<span>${unsafeHTML(item.labelHtml)}</span>
${isSelected ? html `<span class="ml-select-check">✓</span>` : html ``}
</button>
`;
        })}
</div>
`;
    }
    renderTriggerContent(items, selectedValues) {
        if (this.hasSlot('Trigger')) {
            return html `${unsafeHTML(this.getSlotContent('Trigger'))}`;
        }
        return this.renderSelectedTags(items, selectedValues);
    }
    getComputedError(selectedCount) {
        if (this.error)
            return this.error;
        if (this.minSelection > 0 && selectedCount < this.minSelection) {
            return this.msg.minSelectionError.replace('{min}', String(this.minSelection));
        }
        if (this.required && selectedCount === 0) {
            return this.msg.requiredError;
        }
        return '';
    }
    renderViewMode() {
        const items = this.getAllItems();
        const selectedValues = this.getSelectedValues();
        return html `
<div class=${cn('w-full', this.cssClass)}>
${this.renderLabel()}
<div class="rounded-lg border ml-select-view px-3 py-2 text-sm">
${this.renderSelectedTags(items, selectedValues)}
</div>
${this.name ? html `<input type="hidden" name="${this.name}" value="${this.value}" />` : html ``}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const groups = this.getGroupedItems();
        const items = this.getUngroupedItems();
        const allItems = [...groups.flatMap(g => g.items), ...items];
        const selectedValues = this.getSelectedValues();
        const errorMessage = this.getComputedError(selectedValues.length);
        const hasError = Boolean(errorMessage);
        const describedBy = hasError
            ? this.errorId
            : this.hasSlot('Helper')
                ? this.helperId
                : undefined;
        const labelAttr = this.hasSlot('Label') ? this.labelId : undefined;
        const isPanelOpen = this.isOpen && !this.loading;
        return html `
<div
class=${cn('w-full', this.cssClass)}
@focusin=${this.handleFocusIn}
@focusout=${this.handleFocusOut}
@keydown=${this.handlePanelKeydown}
>
${this.renderLabel()}
<div class="relative">
<button
class="${this.getTriggerClasses(hasError)}"
type="button"
role="combobox"
aria-expanded="${isPanelOpen}"
aria-haspopup="listbox"
aria-required="${this.required}"
aria-invalid="${hasError}"
${labelAttr ? html `aria-labelledby="${labelAttr}"` : html `aria-label="${this.placeholder || this.msg.placeholder}"`}
${describedBy ? html `aria-describedby="${describedBy}"` : html ``}
@keydown=${this.handleTriggerKeydown}
@click=${this.handleTriggerClick}
.data-trigger=${true}
>
${this.loading ? html `<span class="ml-text-muted">${this.msg.loading}</span>` : this.renderTriggerContent(allItems, selectedValues)}
</button>
</div>
${this.renderHelperOrError(errorMessage)}
${this.name ? html `<input type="hidden" name="${this.name}" value="${this.value}" />` : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MultiSelectDropdownMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-selection' })
], MultiSelectDropdownMolecule.prototype, "minSelection", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-selection' })
], MultiSelectDropdownMolecule.prototype, "maxSelection", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MultiSelectDropdownMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MultiSelectDropdownMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MultiSelectDropdownMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MultiSelectDropdownMolecule.prototype, "searchQuery", void 0);
MultiSelectDropdownMolecule = __decorate([
    customElement('groupselectmany--ml-multi-select-dropdown')
], MultiSelectDropdownMolecule);
export { MultiSelectDropdownMolecule };
