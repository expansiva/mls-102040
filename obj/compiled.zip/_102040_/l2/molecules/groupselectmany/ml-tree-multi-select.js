/// <mls fileReference="_102040_/l2/molecules/groupselectmany/ml-tree-multi-select.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// TREE MULTI-SELECT MOLECULE
// =============================================================================
// Skill Group: groupSelectMany
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'No items selected',
    noResults: 'No results found',
    loading: 'Loading...',
    searchPlaceholder: 'Search...',
    selectedCount: 'items selected',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Nenhum item selecionado',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        searchPlaceholder: 'Buscar...',
        selectedCount: 'itens selecionados',
    },
};
let MlTreeMultiSelectMolecule = class MlTreeMultiSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-tree-multi-select .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-tree-multi-select .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-tree-multi-select .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-tree-multi-select .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-tree-multi-select .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-tree-multi-select .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-tree-multi-select .ml-tree-node {
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectmany--ml-tree-multi-select .ml-tree-node-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupselectmany--ml-tree-multi-select .ml-tree-node-selected {
  background: var(--ml-primary-container, rgba(59, 130, 246, 0.1));
  color: var(--ml-primary, #3b82f6);
}
groupselectmany--ml-tree-multi-select .ml-tree-node-hover:hover {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupselectmany--ml-tree-multi-select .ml-tree-checkbox {
  background: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectmany--ml-tree-multi-select .ml-tree-checkbox-checked {
  background: var(--ml-primary, #3b82f6);
  border-color: var(--ml-primary, #3b82f6);
}
groupselectmany--ml-tree-multi-select .ml-tree-expand {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectmany--ml-tree-multi-select .ml-tree-search {
  background: var(--ml-surface-dim, #f5f5f5);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectmany--ml-tree-multi-select .ml-tree-search::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupselectmany--ml-tree-multi-select .ml-tree-search:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupselectmany--ml-tree-multi-select .ml-tree-spinner {
  color: var(--ml-primary, #3b82f6);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.minSelection = 0;
        this.maxSelection = 0;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.searchQuery = '';
        this.expandedNodes = new Set();
        this.treeNodes = [];
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parseTreeStructure();
    }
    updated(changedProperties) {
        if (changedProperties.has('value')) {
            this.requestUpdate();
        }
    }
    // ===========================================================================
    // TREE PARSING
    // ===========================================================================
    parseTreeStructure() {
        const items = this.getSlots('Item');
        const groups = this.getSlots('Group');
        const nodes = [];
        // Parse groups first
        groups.forEach((group) => {
            const groupLabel = group.getAttribute('label') || '';
            const groupItems = Array.from(group.querySelectorAll('Item'));
            const groupNodes = this.parseItems(groupItems, null, groupLabel);
            nodes.push(...groupNodes);
        });
        // Parse standalone items (not inside groups)
        const standaloneItems = items.filter((item) => !item.closest('Group'));
        const standaloneNodes = this.parseItems(Array.from(standaloneItems), null);
        nodes.push(...standaloneNodes);
        this.treeNodes = nodes;
        // Auto-expand all nodes initially
        this.expandAllNodes(nodes);
    }
    parseItems(items, parent, groupLabel) {
        const nodes = [];
        items.forEach((item) => {
            const value = item.getAttribute('value') || '';
            const label = item.innerHTML.trim();
            const disabled = item.hasAttribute('disabled');
            const childItems = Array.from(item.querySelectorAll(':scope > Item'));
            const node = {
                value,
                label,
                disabled,
                children: [],
                parent,
                groupLabel,
            };
            if (childItems.length > 0) {
                node.children = this.parseItems(childItems, node);
            }
            nodes.push(node);
        });
        return nodes;
    }
    expandAllNodes(nodes) {
        nodes.forEach((node) => {
            if (node.children.length > 0) {
                this.expandedNodes.add(node.value);
                this.expandAllNodes(node.children);
            }
        });
    }
    // ===========================================================================
    // VALUE HELPERS
    // ===========================================================================
    getSelectedValues() {
        if (!this.value || this.value.trim() === '') {
            return new Set();
        }
        return new Set(this.value.split(',').filter(Boolean));
    }
    getSelectedCount() {
        return this.getSelectedValues().size;
    }
    isNodeSelected(node) {
        return this.getSelectedValues().has(node.value);
    }
    isNodeIndeterminate(node) {
        if (node.children.length === 0)
            return false;
        const allDescendants = this.getAllDescendants(node);
        const selectedCount = allDescendants.filter((n) => this.isNodeSelected(n)).length;
        return selectedCount > 0 && selectedCount < allDescendants.length;
    }
    getAllDescendants(node) {
        const descendants = [];
        node.children.forEach((child) => {
            descendants.push(child);
            descendants.push(...this.getAllDescendants(child));
        });
        return descendants;
    }
    getAllLeafDescendants(node) {
        if (node.children.length === 0) {
            return [node];
        }
        const leaves = [];
        node.children.forEach((child) => {
            leaves.push(...this.getAllLeafDescendants(child));
        });
        return leaves;
    }
    canSelectMore() {
        if (this.maxSelection === 0)
            return true;
        return this.getSelectedCount() < this.maxSelection;
    }
    // ===========================================================================
    // SEARCH HELPERS
    // ===========================================================================
    matchesSearch(node) {
        if (!this.searchQuery)
            return true;
        const query = this.searchQuery.toLowerCase();
        const labelText = node.label.replace(/<[^>]*>/g, '').toLowerCase();
        if (labelText.includes(query))
            return true;
        return node.children.some((child) => this.matchesSearch(child));
    }
    getFilteredNodes() {
        if (!this.searchQuery)
            return this.treeNodes;
        return this.filterNodes(this.treeNodes);
    }
    filterNodes(nodes) {
        return nodes.filter((node) => this.matchesSearch(node));
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleToggleExpand(node, e) {
        e.stopPropagation();
        if (this.expandedNodes.has(node.value)) {
            this.expandedNodes.delete(node.value);
        }
        else {
            this.expandedNodes.add(node.value);
        }
        this.expandedNodes = new Set(this.expandedNodes);
    }
    handleNodeSelect(node, e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading || node.disabled)
            return;
        const selectedValues = this.getSelectedValues();
        const isCurrentlySelected = selectedValues.has(node.value);
        if (node.children.length > 0) {
            // Parent node: cascade selection to all descendants
            const allDescendants = this.getAllDescendants(node);
            const selectableDescendants = allDescendants.filter((n) => !n.disabled);
            if (isCurrentlySelected || this.isNodeIndeterminate(node)) {
                // Deselect all descendants
                selectableDescendants.forEach((n) => selectedValues.delete(n.value));
                selectedValues.delete(node.value);
            }
            else {
                // Select all descendants (respecting maxSelection)
                const nodesToSelect = [node, ...selectableDescendants];
                for (const n of nodesToSelect) {
                    if (this.maxSelection === 0 || selectedValues.size < this.maxSelection) {
                        selectedValues.add(n.value);
                    }
                }
            }
        }
        else {
            // Leaf node
            if (isCurrentlySelected) {
                selectedValues.delete(node.value);
            }
            else {
                if (!this.canSelectMore())
                    return;
                selectedValues.add(node.value);
            }
        }
        // Update parent states
        this.updateParentStates(node, selectedValues);
        this.value = Array.from(selectedValues).join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    updateParentStates(node, selectedValues) {
        let parent = node.parent;
        while (parent) {
            const allDescendants = this.getAllDescendants(parent);
            const allSelected = allDescendants.every((n) => selectedValues.has(n.value) || n.disabled);
            const noneSelected = allDescendants.every((n) => !selectedValues.has(n.value));
            if (allSelected) {
                selectedValues.add(parent.value);
            }
            else if (noneSelected) {
                selectedValues.delete(parent.value);
            }
            else {
                selectedValues.delete(parent.value);
            }
            parent = parent.parent;
        }
    }
    handleSearchInput(e) {
        const input = e.target;
        this.searchQuery = input.value;
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // CSS HELPERS
    // ===========================================================================
    getContainerClasses() {
        return [
            'w-full rounded-lg border transition ml-tree-node',
            this.error ? 'ml-tree-node-error' : '',
            this.disabled ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getNodeClasses(node, isSelected) {
        const isDisabled = node.disabled || this.disabled || this.readonly || this.loading;
        const isMaxReached = !isSelected && !this.canSelectMore();
        return [
            'flex items-center gap-2 px-2 py-1.5 rounded-md transition cursor-pointer',
            'text-sm ml-text',
            isSelected ? 'ml-tree-node-selected' : '',
            !isDisabled && !isMaxReached && !isSelected ? 'ml-tree-node-hover' : '',
            isDisabled || isMaxReached ? 'ml-disabled' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCheckboxClasses(isSelected, isIndeterminate) {
        return [
            'w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 transition ml-tree-checkbox',
            isSelected || isIndeterminate ? 'ml-tree-checkbox-checked' : '',
        ].filter(Boolean).join(' ');
    }
    getExpandIconClasses(isExpanded) {
        return [
            'w-4 h-4 flex-shrink-0 transition-transform duration-200 ml-tree-expand',
            isExpanded ? 'rotate-90' : '',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label class="${cn('block text-sm font-medium mb-1 ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="ml-error-text">*</span>` : html ``}
      </label>
    `;
    }
    renderSearch() {
        if (!this.searchable || !this.isEditing)
            return html ``;
        const inputClasses = [
            'w-full px-3 py-2 text-sm rounded-t-lg border-b ml-tree-search',
            'focus:outline-none',
            this.disabled ? 'cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
        return html `
      <div class="sticky top-0 z-10">
        <input
          type="text"
          class=${inputClasses}
          placeholder=${this.msg.searchPlaceholder}
          .value=${this.searchQuery}
          @input=${this.handleSearchInput}
          ?disabled=${this.disabled || this.loading}
        />
      </div>
    `;
    }
    renderCheckIcon() {
        return html `
      <svg class="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7" />
      </svg>
    `;
    }
    renderIndeterminateIcon() {
        return html `
      <svg class="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 12h14" />
      </svg>
    `;
    }
    renderExpandIcon() {
        return html `
      <svg fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
      </svg>
    `;
    }
    renderNode(node, depth = 0) {
        if (!this.matchesSearch(node))
            return html ``;
        const isSelected = this.isNodeSelected(node);
        const isIndeterminate = this.isNodeIndeterminate(node);
        const hasChildren = node.children.length > 0;
        const isExpanded = this.expandedNodes.has(node.value);
        const paddingLeft = depth * 20 + 8;
        return html `
      <div class="select-none">
        <div
          class=${this.getNodeClasses(node, isSelected)}
          style="padding-left: ${paddingLeft}px"
          @click=${(e) => this.handleNodeSelect(node, e)}
          role="option"
          aria-selected=${isSelected}
          aria-disabled=${node.disabled || this.disabled}
        >
          ${hasChildren
            ? html `
                <span
                  class=${this.getExpandIconClasses(isExpanded)}
                  @click=${(e) => this.handleToggleExpand(node, e)}
                >
                  ${this.renderExpandIcon()}
                </span>
              `
            : html `<span class="w-4 flex-shrink-0"></span>`}

          <span class=${this.getCheckboxClasses(isSelected, isIndeterminate)}>
            ${isSelected
            ? this.renderCheckIcon()
            : isIndeterminate
                ? this.renderIndeterminateIcon()
                : html ``}
          </span>

          <span class="flex-1 truncate">${unsafeHTML(node.label)}</span>
        </div>

        ${hasChildren && isExpanded
            ? html `
              <div class="ml-2">
                ${node.children.map((child) => this.renderNode(child, depth + 1))}
              </div>
            `
            : html ``}
      </div>
    `;
    }
    renderTree() {
        const filteredNodes = this.getFilteredNodes();
        if (filteredNodes.length === 0) {
            return this.renderEmpty();
        }
        return html `
      <div
        class="p-2 max-h-64 overflow-y-auto"
        role="listbox"
        aria-multiselectable="true"
        @focus=${this.handleFocus}
        @blur=${this.handleBlur}
        tabindex="0"
      >
        ${filteredNodes.map((node) => this.renderNode(node, 0))}
      </div>
    `;
    }
    renderEmpty() {
        const content = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.noResults;
        return html `
      <div class="p-4 text-center text-sm ml-text-muted">
        ${unsafeHTML(content)}
      </div>
    `;
    }
    renderHelper() {
        if (this.error) {
            return html `
        <p class="mt-1 text-xs ml-error-text">${unsafeHTML(this.error)}</p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderLoading() {
        return html `
      <div class="p-4 text-center text-sm ml-text-muted">
        <div class="inline-flex items-center gap-2">
          <svg
            class="animate-spin h-4 w-4 ml-tree-spinner"
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
          >
            <circle
              class="opacity-25"
              cx="12"
              cy="12"
              r="10"
              stroke="currentColor"
              stroke-width="4"
            ></circle>
            <path
              class="opacity-75"
              fill="currentColor"
              d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
            ></path>
          </svg>
          <span>${this.msg.loading}</span>
        </div>
      </div>
    `;
    }
    renderViewMode() {
        const selectedValues = this.getSelectedValues();
        if (selectedValues.size === 0) {
            const placeholderText = this.placeholder || this.msg.placeholder;
            return html `
        <div class="text-sm ml-text-muted">${placeholderText}</div>
      `;
        }
        const selectedLabels = this.getSelectedLabels(selectedValues);
        return html `
      <div class="flex flex-wrap gap-1">
        ${selectedLabels.map((label) => html `
            <span
              class="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ml-tree-node-selected"
            >
              ${unsafeHTML(label)}
            </span>
          `)}
      </div>
    `;
    }
    getSelectedLabels(selectedValues) {
        const labels = [];
        const findLabels = (nodes) => {
            nodes.forEach((node) => {
                if (selectedValues.has(node.value)) {
                    labels.push(node.label);
                }
                if (node.children.length > 0) {
                    findLabels(node.children);
                }
            });
        };
        findLabels(this.treeNodes);
        return labels;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Re-parse tree structure on each render to pick up slot changes
        this.parseTreeStructure();
        if (!this.isEditing) {
            return html `
        <div>
          ${this.renderLabel()}
          ${this.renderViewMode()}
        </div>
      `;
        }
        return html `
      <div
        class="${cn('w-full', this.cssClass)}"
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
      >
        ${this.renderLabel()}

        <div class=${this.getContainerClasses()}>
          ${this.renderSearch()}
          ${this.loading ? this.renderLoading() : this.renderTree()}
        </div>

        ${this.renderHelper()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTreeMultiSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTreeMultiSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTreeMultiSelectMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTreeMultiSelectMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTreeMultiSelectMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-selection' })
], MlTreeMultiSelectMolecule.prototype, "minSelection", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-selection' })
], MlTreeMultiSelectMolecule.prototype, "maxSelection", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlTreeMultiSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTreeMultiSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTreeMultiSelectMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTreeMultiSelectMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTreeMultiSelectMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlTreeMultiSelectMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlTreeMultiSelectMolecule.prototype, "expandedNodes", void 0);
__decorate([
    state()
], MlTreeMultiSelectMolecule.prototype, "treeNodes", void 0);
MlTreeMultiSelectMolecule = __decorate([
    customElement('groupselectmany--ml-tree-multi-select')
], MlTreeMultiSelectMolecule);
export { MlTreeMultiSelectMolecule };
