var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupselectmany/ml-table-multi-select.ts" enhancement="_blank"/>
// =============================================================================
// GROUPSELECTMANY – ML TABLE MULTI SELECT MOLECULE
// =============================================================================
// Skill Group: groupSelectMany (multi‑select table variant)
// This molecule does NOT contain business logic – it only renders UI.
import { html, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'No items selected',
    noResults: 'No results found',
    loading: 'Loading...',
    selectedCount: 'selected',
    requiredError: 'Select at least one option',
    minSelectionError: 'Select at least {min} options',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Nenhum item selecionado',
        noResults: 'Nenhum resultado encontrado',
        loading: 'Carregando...',
        selectedCount: 'selecionado(s)',
        requiredError: 'Selecione pelo menos uma opção',
        minSelectionError: 'Selecione pelo menos {min} opções',
    },
};
/// **collab_i18n_end**
let MlTableMultiSelectMolecule = class MlTableMultiSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ---------------------------------------------------------------------------
        // i18n
        // ---------------------------------------------------------------------------
        this.msg = messages.en;
        // ---------------------------------------------------------------------------
        // SLOT TAGS
        // ---------------------------------------------------------------------------
        this.slotTags = [
            'Label',
            'Helper',
            'Trigger', // not used in table variant but kept for contract
            'Item',
            'Cell',
            'Column',
            'Group', // not used in table variant but kept for contract
            'Empty',
        ];
        // ---------------------------------------------------------------------------
        // PROPERTIES – data contract
        // ---------------------------------------------------------------------------
        this.value = '';
        this.error = '';
        this.name = '';
        this.disabled = false;
        this.readonly = false;
        this.loading = false;
        this.isEditing = true;
        this.required = false;
        this.minSelection = 0;
        this.maxSelection = 0;
        // ---------------------------------------------------------------------------
        // CONFIGURATION PROPERTIES
        // ---------------------------------------------------------------------------
        this.placeholder = '';
        this.searchable = false;
        // ---------------------------------------------------------------------------
        // STATE PROPERTIES
        // ---------------------------------------------------------------------------
        this.searchQuery = '';
    }
    // ---------------------------------------------------------------------------
    // HELPERS – selection
    // ---------------------------------------------------------------------------
    getSelectedSet() {
        if (!this.value)
            return new Set();
        return new Set(this.value.split(',').map(v => v.trim()).filter(Boolean));
    }
    updateValueFromSet(set) {
        this.value = Array.from(set).join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    // ---------------------------------------------------------------------------
    // HELPERS – parsing slot content
    // ---------------------------------------------------------------------------
    getItems() {
        const itemEls = this.getSlots('Item');
        return itemEls.map((el) => {
            const value = el.getAttribute('value') ?? '';
            const disabled = el.hasAttribute('disabled');
            const cellEls = Array.from(el.children).filter((c) => this.slotTags.map((t) => t.toUpperCase()).includes(c.tagName));
            const cells = cellEls.map((c) => c.innerHTML.trim());
            return { value, disabled, cells };
        });
    }
    getHeaders() {
        const columnEls = this.getSlots('Column');
        return columnEls.map((c) => c.textContent?.trim() ?? '');
    }
    getFilteredItems() {
        if (!this.searchable || !this.searchQuery)
            return this.getItems();
        const q = this.searchQuery.toLowerCase();
        return this.getItems().filter((item) => item.cells.some((cell) => cell.toLowerCase().includes(q)));
    }
    // ---------------------------------------------------------------------------
    // VALIDATION
    // ---------------------------------------------------------------------------
    getComputedError() {
        if (this.error)
            return this.error;
        const count = this.getSelectedSet().size;
        if (this.required && count === 0)
            return this.msg.requiredError;
        if (this.minSelection > 0 && count < this.minSelection) {
            return this.msg.minSelectionError.replace('{min}', String(this.minSelection));
        }
        return '';
    }
    // ---------------------------------------------------------------------------
    // EVENT HANDLERS
    // ---------------------------------------------------------------------------
    handleRowToggle(item) {
        if (this.disabled || this.readonly || item.disabled)
            return;
        const selected = this.getSelectedSet();
        const isSelected = selected.has(item.value);
        const maxReached = this.maxSelection > 0 && selected.size >= this.maxSelection;
        if (!isSelected && maxReached)
            return;
        if (isSelected) {
            selected.delete(item.value);
        }
        else {
            selected.add(item.value);
        }
        this.updateValueFromSet(selected);
    }
    handleSelectAll(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly)
            return;
        const checked = e.target.checked;
        const items = this.getFilteredItems();
        const selected = this.getSelectedSet();
        if (checked) {
            for (const item of items) {
                if (!item.disabled) {
                    if (this.maxSelection > 0 && selected.size >= this.maxSelection)
                        break;
                    selected.add(item.value);
                }
            }
        }
        else {
            for (const item of items) {
                selected.delete(item.value);
            }
        }
        this.updateValueFromSet(selected);
    }
    handleSearchInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.searchQuery = input.value;
    }
    handleBlur() {
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handleFocus() {
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    // ---------------------------------------------------------------------------
    // RENDER HELPERS – CSS class builders
    // ---------------------------------------------------------------------------
    getTableClasses() {
        return [
            'w-full border-collapse ml-table-row',
        ].join(' ');
    }
    getHeaderCellClasses() {
        return [
            'px-3 py-2 text-left text-sm font-medium ml-table-header',
        ].join(' ');
    }
    getRowClasses(item, isSelected) {
        return [
            'cursor-pointer ml-table-row',
            isSelected ? 'ml-table-row-selected' : '',
            item.disabled ? 'ml-disabled' : 'ml-table-row-hover',
        ].filter(Boolean).join(' ');
    }
    getCellClasses() {
        return [
            'px-3 py-2 text-sm ml-table-cell',
        ].join(' ');
    }
    getInputClasses() {
        return [
            'w-full rounded-md px-3 py-2 text-sm border transition ml-table-search',
            'focus:outline-none',
            this.disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    // ---------------------------------------------------------------------------
    // RENDER
    // ---------------------------------------------------------------------------
    renderLoading() {
        return html `<div class="text-sm ml-text-muted">${this.msg.loading}</div>`;
    }
    renderHelperOrError() {
        const errorMessage = this.getComputedError();
        if (errorMessage) {
            return html `<p class="mt-1 text-xs ml-error-text">${unsafeHTML(errorMessage)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderEmpty() {
        const content = this.getSlotContent('Empty') || this.msg.noResults;
        return html `<div class="${cn('p-4 text-center ml-text-muted', this.getSlotClass('Empty'))}">${unsafeHTML(content)}</div>`;
    }
    renderViewMode() {
        const selectedSet = this.getSelectedSet();
        if (selectedSet.size === 0) {
            const placeholder = this.placeholder || this.msg.placeholder;
            return html `<div class="ml-text-muted">${placeholder}</div>`;
        }
        const items = this.getItems().filter(i => selectedSet.has(i.value));
        return html `
<div class="space-y-1">
${items.map((item) => html `
<div class="ml-text">
${item.cells.map((c, i) => html `${i > 0 ? html ` — ` : nothing}${unsafeHTML(c)}`)}
</div>
`)}
</div>
`;
    }
    renderTable() {
        const items = this.getFilteredItems();
        const headers = this.getHeaders();
        const hasHeaders = headers.length > 0;
        const selectedSet = this.getSelectedSet();
        const enabledItems = items.filter(i => !i.disabled);
        const allSelected = enabledItems.length > 0 && enabledItems.every(i => selectedSet.has(i.value));
        const someSelected = enabledItems.some(i => selectedSet.has(i.value));
        const maxReached = this.maxSelection > 0 && selectedSet.size >= this.maxSelection;
        return html `
${this.searchable
            ? html `
<input
type="text"
class="${this.getInputClasses()} mb-2"
placeholder="Search..."
.value=${this.searchQuery}
@input=${this.handleSearchInput}
@focus=${this.handleFocus}
@blur=${this.handleBlur}

@change="${(e) => e.stopPropagation()}"
/>
`
            : nothing}
<table class="${this.getTableClasses()}">
${hasHeaders
            ? html `
<thead>
<tr>
<th class="${this.getHeaderCellClasses()}">
<input
type="checkbox"
.checked=${allSelected}
.indeterminate=${someSelected && !allSelected}
?disabled=${this.disabled || this.readonly}
@change=${this.handleSelectAll}

@input=${(e) => e.stopPropagation()}
/>
</th>
${headers.map((h) => html `<th class="${this.getHeaderCellClasses()}">${unsafeHTML(h)}</th>`)}
</tr>
</thead>
`
            : nothing}
<tbody>
${items.length
            ? items.map((item) => {
                const isSelected = selectedSet.has(item.value);
                const isDisabled = item.disabled || (!isSelected && maxReached);
                return html `
<tr
class="${this.getRowClasses({ disabled: isDisabled }, isSelected)}"
@click=${() => !isDisabled && this.handleRowToggle(item)}
>
<td class="${this.getCellClasses()}">
<input
type="checkbox"
.checked=${isSelected}
?disabled=${isDisabled || this.disabled || this.readonly}
@click=${(e) => e.stopPropagation()}
@change=${(e) => { e.stopPropagation(); this.handleRowToggle(item); }}

@input=${(e) => e.stopPropagation()}
/>
</td>
${item.cells.map((c) => html `<td class="${this.getCellClasses()}">${unsafeHTML(c)}</td>`)}
</tr>
`;
            })
            : html `<tr><td colspan="${hasHeaders ? headers.length + 1 : 1}" class="${this.getCellClasses()}">${this.renderEmpty()}</td></tr>`}
</tbody>
</table>
${this.renderHelperOrError()}
`;
    }
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `<div class="p-2">${this.renderLoading()}</div>`;
        }
        if (!this.isEditing) {
            return html `
<div class="groupselectmany--ml-table-multi-select-view">
${this.renderViewMode()}
</div>
`;
        }
        return html `
<div class="${cn('groupselectmany--ml-table-multi-select', this.cssClass)}">
${this.hasSlot('Label')
            ? html `<label class="${cn('block mb-1 text-sm font-medium ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</label>`
            : nothing}
${this.renderTable()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlTableMultiSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTableMultiSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTableMultiSelectMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableMultiSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableMultiSelectMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableMultiSelectMolecule.prototype, "loading", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableMultiSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlTableMultiSelectMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-selection' })
], MlTableMultiSelectMolecule.prototype, "minSelection", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-selection' })
], MlTableMultiSelectMolecule.prototype, "maxSelection", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlTableMultiSelectMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'searchable' })
], MlTableMultiSelectMolecule.prototype, "searchable", void 0);
__decorate([
    state()
], MlTableMultiSelectMolecule.prototype, "searchQuery", void 0);
MlTableMultiSelectMolecule = __decorate([
    customElement('groupselectmany--ml-table-multi-select')
], MlTableMultiSelectMolecule);
export { MlTableMultiSelectMolecule };
