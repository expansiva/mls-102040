/// <mls fileReference="_102040_/l2/molecules/groupselectmany/ml-dual-list-select.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML DUAL LIST SELECT MOLECULE
// =============================================================================
// Skill Group: groupSelectMany (select + many)
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: 'Select items',
    empty: 'No items available',
    loading: 'Loading...',
    availableTitle: 'Available',
    selectedTitle: 'Selected',
    add: 'Add',
    remove: 'Remove',
    addAll: 'Add all',
    removeAll: 'Remove all',
    searchPlaceholder: 'Search items',
    noSelection: '—',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: 'Selecione itens',
        empty: 'Nenhum item disponível',
        loading: 'Carregando...',
        availableTitle: 'Disponíveis',
        selectedTitle: 'Selecionados',
        add: 'Adicionar',
        remove: 'Remover',
        addAll: 'Adicionar todos',
        removeAll: 'Remover todos',
        searchPlaceholder: 'Buscar itens',
        noSelection: '—',
    },
};
let MlDualListSelectMolecule = class MlDualListSelectMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupselectmany--ml-dual-list-select .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-dual-list-select .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-dual-list-select .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-dual-list-select .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-dual-list-select .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupselectmany--ml-dual-list-select .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupselectmany--ml-dual-list-select .ml-dual-container {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectmany--ml-dual-list-select .ml-dual-container-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupselectmany--ml-dual-list-select .ml-dual-container-focus:focus-within {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectmany--ml-dual-list-select .ml-dual-container-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
}
groupselectmany--ml-dual-list-select .ml-dual-panel {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupselectmany--ml-dual-list-select .ml-dual-item {
  background-color: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-dual-list-select .ml-dual-item-selected {
  background-color: color-mix(in srgb, var(--ml-primary, #3b82f6) 8%, var(--ml-surface, #ffffff));
  border-color: var(--ml-primary, #3b82f6);
  color: var(--ml-primary, #3b82f6);
}
groupselectmany--ml-dual-list-select .ml-dual-item-hover:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupselectmany--ml-dual-list-select .ml-dual-button {
  border-color: var(--ml-outline-variant, #e2e8f0);
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-dual-list-select .ml-dual-button-hover:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
groupselectmany--ml-dual-list-select .ml-dual-search {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface, #1c1b1f);
}
groupselectmany--ml-dual-list-select .ml-dual-search::placeholder {
  color: var(--ml-on-surface-muted, #49454f);
}
groupselectmany--ml-dual-list-select .ml-dual-search:focus {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupselectmany--ml-dual-list-select .ml-dual-view-tag {
  background-color: var(--ml-surface-dim, #f5f5f5);
  border-color: var(--ml-outline-variant, #e2e8f0);
  color: var(--ml-on-surface, #1c1b1f);
}
`);
        this.msg = messages.en;
        this.uid = `ml-dual-${Math.random().toString(36).slice(2, 9)}`;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================='
        this.slotTags = ['Label', 'Helper', 'Trigger', 'Item', 'Group', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================='
        this.value = '';
        this.error = '';
        this.name = '';
        this.placeholder = '';
        this.searchable = false;
        this.minSelection = 0;
        this.maxSelection = 0;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================='
        this.searchQuery = '';
        this.hasFocus = false;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================='
    handleAddItem(value) {
        if (!this.isEditing || this.isInteractionBlocked())
            return;
        const selectedValues = this.getSelectedValues();
        if (selectedValues.includes(value))
            return;
        if (!this.canAddMore(selectedValues.length))
            return;
        const nextValues = [...selectedValues, value];
        this.updateValue(nextValues);
    }
    handleRemoveItem(value) {
        if (!this.isEditing || this.isInteractionBlocked())
            return;
        const selectedValues = this.getSelectedValues();
        if (!selectedValues.includes(value))
            return;
        const minSelection = this.getMinSelection();
        if (selectedValues.length - 1 < minSelection)
            return;
        const nextValues = selectedValues.filter((item) => item !== value);
        this.updateValue(nextValues);
    }
    handleAddAll() {
        if (!this.isEditing || this.isInteractionBlocked())
            return;
        const items = this.getParsedItems();
        const selectedValues = this.getSelectedValues();
        const selectedSet = new Set(selectedValues);
        let remaining = this.getMaxSelection() > 0 ? this.getMaxSelection() - selectedValues.length : Infinity;
        if (remaining <= 0)
            return;
        const toAdd = [];
        for (const item of items) {
            if (item.disabled || selectedSet.has(item.value))
                continue;
            if (remaining <= 0)
                break;
            toAdd.push(item.value);
            remaining -= 1;
        }
        if (toAdd.length === 0)
            return;
        this.updateValue([...selectedValues, ...toAdd]);
    }
    handleRemoveAll() {
        if (!this.isEditing || this.isInteractionBlocked())
            return;
        const items = this.getParsedItems();
        const selectedValues = this.getSelectedValues();
        const minSelection = this.getMinSelection();
        if (selectedValues.length <= minSelection)
            return;
        const disabledMap = new Set(items.filter((item) => item.disabled).map((item) => item.value));
        const nextValues = [...selectedValues];
        for (let i = nextValues.length - 1; i >= 0; i -= 1) {
            if (nextValues.length <= minSelection)
                break;
            const value = nextValues[i];
            if (disabledMap.has(value))
                continue;
            nextValues.splice(i, 1);
        }
        if (nextValues.length === selectedValues.length)
            return;
        this.updateValue(nextValues);
    }
    handleSearchInput(event) {
        event.stopPropagation();
        const input = event.target;
        this.searchQuery = input.value;
    }
    handleFocusIn() {
        if (!this.isEditing)
            return;
        if (this.hasFocus)
            return;
        this.hasFocus = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleFocusOut(event) {
        if (!this.isEditing)
            return;
        const related = event.relatedTarget;
        if (related && this.contains(related))
            return;
        if (!this.hasFocus)
            return;
        this.hasFocus = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // HELPERS
    // ==========================================================================='
    isInteractionBlocked() {
        return this.disabled || this.readonly || this.loading;
    }
    getMinSelection() {
        return Math.max(this.minSelection, this.required ? 1 : 0);
    }
    getMaxSelection() {
        return this.maxSelection > 0 ? this.maxSelection : 0;
    }
    canAddMore(selectedCount) {
        const maxSelection = this.getMaxSelection();
        if (maxSelection === 0)
            return true;
        return selectedCount < maxSelection;
    }
    updateValue(nextValues) {
        this.value = nextValues.join(',');
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    getSelectedValues() {
        if (!this.value)
            return [];
        return this.value
            .split(',')
            .map((val) => val.trim())
            .filter((val) => val.length > 0);
    }
    mapItemElement(itemEl, groupLabel) {
        const value = itemEl.getAttribute('value');
        if (!value)
            return null;
        const labelHtml = (itemEl.innerHTML || '').trim() || value;
        const labelText = (itemEl.textContent || value).trim();
        const disabled = itemEl.hasAttribute('disabled');
        return { value, labelHtml, labelText, disabled, groupLabel };
    }
    getParsedItems() {
        const items = [];
        const groupedElements = new Set();
        const groups = this.getSlots('Group');
        for (const group of groups) {
            const groupLabel = group.getAttribute('label') || '';
            const itemEls = Array.from(group.querySelectorAll('Item'));
            for (const itemEl of itemEls) {
                const parsed = this.mapItemElement(itemEl, groupLabel || null);
                if (parsed)
                    items.push(parsed);
                groupedElements.add(itemEl);
            }
        }
        const standaloneItems = this.getSlots('Item').filter((item) => {
            if (groupedElements.has(item))
                return false;
            return !item.closest('Group');
        });
        for (const item of standaloneItems) {
            const parsed = this.mapItemElement(item, null);
            if (parsed)
                items.push(parsed);
        }
        return items;
    }
    getFilteredItems(items) {
        const query = this.searchQuery.trim().toLowerCase();
        if (!query)
            return items;
        return items.filter((item) => item.labelText.toLowerCase().includes(query));
    }
    buildGroups(items, hasGroups) {
        if (!hasGroups) {
            return [{ label: null, items }];
        }
        const groups = [];
        const groupMap = new Map();
        for (const item of items) {
            const key = item.groupLabel || '__ungrouped__';
            if (!groupMap.has(key)) {
                const block = { label: item.groupLabel, items: [] };
                groupMap.set(key, block);
                groups.push(block);
            }
            groupMap.get(key).items.push(item);
        }
        return groups;
    }
    getContainerClasses(hasError) {
        return [
            'w-full rounded-lg border p-4 transition',
            'ml-dual-container',
            hasError ? 'ml-dual-container-error' : '',
            'ml-dual-container-focus',
            this.isInteractionBlocked() ? 'ml-dual-container-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getPanelClasses() {
        return [
            'rounded-lg border p-3',
            'ml-dual-panel',
        ].join(' ');
    }
    getItemRowClasses(isSelectedList, disabled) {
        return [
            'flex items-center justify-between gap-2 rounded-md border px-2 py-1.5 text-sm transition',
            isSelectedList
                ? 'ml-dual-item-selected'
                : 'ml-dual-item',
            !disabled ? 'ml-dual-item-hover' : '',
            disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    getActionButtonClasses(disabled) {
        return [
            'rounded-md border px-2 py-1 text-xs font-medium transition',
            'ml-dual-button',
            !disabled ? 'ml-dual-button-hover' : '',
            disabled ? 'ml-disabled' : '',
        ].filter(Boolean).join(' ');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label id="${this.uid}-label" class=${cn('mb-2 block text-sm font-medium ml-label', this.getSlotClass('Label'))}>
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderEmpty() {
        const content = this.getSlotContent('Empty') || this.msg.empty;
        return html `
<div class=${cn('text-sm ml-text-muted', this.getSlotClass('Empty'))}>
${unsafeHTML(content)}
</div>
`;
    }
    renderSearch() {
        return html `
<div class="mb-3">
<input
class="w-full rounded-md border px-3 py-2 text-sm transition ml-dual-search focus:outline-none focus:ring-2"
.type="text"
placeholder="${this.msg.searchPlaceholder}"
.value="${this.searchQuery}"
@input="${this.handleSearchInput}"
?disabled="${this.isInteractionBlocked()}"

@change="${(e) => e.stopPropagation()}"
/>
</div>
`;
    }
    renderFeedback() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `
<p id="${this.uid}-error" class="mt-2 text-xs ml-error-text">
${unsafeHTML(String(this.error))}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p class=${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}>
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderList(items, selectedSet, selectedCount, minSelection, maxSelection, hasGroups, listTitle, isSelectedList) {
        const groups = this.buildGroups(items, hasGroups);
        return html `
<div class="${this.getPanelClasses()}" role="listbox" aria-multiselectable="true">
<div class="mb-2 flex items-center justify-between">
<h4 class="text-sm font-medium ml-label">${listTitle}</h4>
<span class="text-xs ml-text-muted">${items.length}</span>
</div>
${items.length === 0
            ? this.renderEmpty()
            : html `
<div class="space-y-2">
${groups.map((group) => html `
<div class="space-y-2">
${hasGroups && group.label
                ? html `<div class="text-xs font-semibold ml-text-muted">${group.label}</div>`
                : html ``}
${group.items.map((item) => {
                const isSelected = selectedSet.has(item.value);
                const itemDisabled = this.isInteractionBlocked() || item.disabled;
                const addDisabled = itemDisabled || !this.canAddMore(selectedCount);
                const removeDisabled = itemDisabled || selectedCount - 1 < minSelection;
                const isActionDisabled = isSelectedList ? removeDisabled : addDisabled;
                const rowClasses = this.getItemRowClasses(isSelectedList, itemDisabled || isActionDisabled);
                const actionLabel = isSelectedList ? this.msg.remove : this.msg.add;
                return html `
<div class="${rowClasses}" role="option" aria-selected="${isSelected}" aria-disabled="${itemDisabled}">
<div class="flex-1 text-sm">${unsafeHTML(item.labelHtml)}</div>
<button
class="${this.getActionButtonClasses(isActionDisabled)}"
type="button"
?disabled="${isActionDisabled}"
aria-label="${actionLabel}"
@click="${() => (isSelectedList ? this.handleRemoveItem(item.value) : this.handleAddItem(item.value))}"
>
${actionLabel}
</button>
</div>
`;
            })}
</div>
`)}
</div>
`}
</div>
`;
    }
    renderActionColumn(availableItems, selectedItems, selectedCount, minSelection) {
        const canAddAll = !this.isInteractionBlocked() &&
            availableItems.some((item) => !item.disabled) &&
            this.canAddMore(selectedCount);
        const canRemoveAll = !this.isInteractionBlocked() &&
            selectedCount > minSelection &&
            selectedItems.some((item) => !item.disabled);
        return html `
<div class="flex flex-col items-center justify-center gap-2">
<button
class="${this.getActionButtonClasses(!canAddAll)}"
type="button"
?disabled="${!canAddAll}"
@click="${this.handleAddAll}"
>
${this.msg.addAll}
</button>
<button
class="${this.getActionButtonClasses(!canRemoveAll)}"
type="button"
?disabled="${!canRemoveAll}"
@click="${this.handleRemoveAll}"
>
${this.msg.removeAll}
</button>
</div>
`;
    }
    renderViewMode() {
        const items = this.getParsedItems();
        const selectedValues = this.getSelectedValues();
        const selectedSet = new Set(selectedValues);
        const selectedItems = items.filter((item) => selectedSet.has(item.value));
        const placeholder = this.placeholder || this.msg.placeholder || this.msg.noSelection;
        return html `
<div class=${cn('w-full', this.cssClass)}>
${this.renderLabel()}
${selectedItems.length === 0
            ? html `<div class="text-sm ml-text-muted">${placeholder || this.msg.noSelection}</div>`
            : html `
<div class="flex flex-wrap gap-2">
${selectedItems.map((item) => html `
<span class="rounded-md border px-2 py-1 text-xs ml-dual-view-tag">
${unsafeHTML(item.labelHtml)}
</span>
`)}
</div>
`}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================='
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const items = this.getParsedItems();
        const filteredItems = this.getFilteredItems(items);
        const selectedValues = this.getSelectedValues();
        const selectedSet = new Set(selectedValues);
        const selectedItems = filteredItems.filter((item) => selectedSet.has(item.value));
        const availableItems = filteredItems.filter((item) => !selectedSet.has(item.value));
        const hasGroups = items.some((item) => item.groupLabel);
        const minSelection = this.getMinSelection();
        const maxSelection = this.getMaxSelection();
        const placeholder = this.placeholder || this.msg.placeholder;
        return html `
<div
class="${cn(this.getContainerClasses(!!this.error), this.cssClass)}"
role="group"
aria-labelledby="${this.hasSlot('Label') ? `${this.uid}-label` : ''}"
aria-describedby="${this.error ? `${this.uid}-error` : ''}"
aria-invalid="${this.error ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
aria-busy="${this.loading ? 'true' : 'false'}"
@focusin="${this.handleFocusIn}"
@focusout="${this.handleFocusOut}"
>
${this.renderLabel()}
${this.loading
            ? html `<div class="mb-2 text-xs ml-text-muted">${this.msg.loading}</div>`
            : html ``}
${this.searchable ? this.renderSearch() : html ``}
${!selectedValues.length && placeholder
            ? html `<div class="mb-3 text-xs ml-text-muted">${placeholder}</div>`
            : html ``}
<div class="grid grid-cols-1 items-start gap-3 md:grid-cols-[1fr_auto_1fr]">
${this.renderList(availableItems, selectedSet, selectedValues.length, minSelection, maxSelection, hasGroups, this.msg.availableTitle, false)}
${this.renderActionColumn(availableItems, selectedItems, selectedValues.length, minSelection)}
${this.renderList(selectedItems, selectedSet, selectedValues.length, minSelection, maxSelection, hasGroups, this.msg.selectedTitle, true)}
</div>
${this.renderFeedback()}
${this.name
            ? html `<input type="hidden" name="${this.name}" value="${this.value}" />`
            : html ``}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], MlDualListSelectMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDualListSelectMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDualListSelectMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDualListSelectMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDualListSelectMolecule.prototype, "searchable", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-selection' })
], MlDualListSelectMolecule.prototype, "minSelection", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-selection' })
], MlDualListSelectMolecule.prototype, "maxSelection", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDualListSelectMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDualListSelectMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDualListSelectMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDualListSelectMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDualListSelectMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlDualListSelectMolecule.prototype, "searchQuery", void 0);
__decorate([
    state()
], MlDualListSelectMolecule.prototype, "hasFocus", void 0);
MlDualListSelectMolecule = __decorate([
    customElement('groupselectmany--ml-dual-list-select')
], MlDualListSelectMolecule);
export { MlDualListSelectMolecule };
