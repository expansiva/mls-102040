var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentermoney/ml-enter-money-br.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ENTER MONEY BR MOLECULE
// =============================================================================
// Skill Group: groupEnterMoney
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    placeholder: '0,00',
    empty: '—',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        placeholder: '0,00',
        empty: '—',
        loading: 'Carregando...',
    },
};
/// **collab_i18n_end**
let EnterMoneyBrMolecule = class EnterMoneyBrMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentermoney--ml-enter-money-br .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentermoney--ml-enter-money-br .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentermoney--ml-enter-money-br .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentermoney--ml-enter-money-br .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-enter-money-br .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentermoney--ml-enter-money-br .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentermoney--ml-enter-money-br .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-enter-money-br .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-enter-money-br .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-enter-money-br .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-enter-money-br .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Helper'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.currency = 'BRL';
        this.locale = 'pt-BR';
        this.decimals = 2;
        this.min = null;
        this.max = null;
        this.showSymbol = false;
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.rawValue = '';
    }
    // =========================================================================
    // STATE CHANGE HANDLER
    // =========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const localeAttr = this.getAttribute('locale');
        const decimalsAttr = this.getAttribute('decimals');
        if (valueAttr === `{{${key}}}` || localeAttr === `{{${key}}}` || decimalsAttr === `{{${key}}}`) {
            this.rawValue = this.formatNumberToRaw(value);
        }
        this.requestUpdate();
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    handleFocus(e) {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const input = e.target;
        input.select();
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleInput(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const input = e.target;
        const digits = this.extractDigits(input.value);
        const parsed = this.parseDigitsToNumber(digits);
        this.value = parsed;
        this.rawValue = digits.length ? this.formatNumberToRaw(parsed) : '';
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleBlur() {
        if (this.disabled || this.readonly || this.loading || !this.isEditing)
            return;
        const digits = this.extractDigits(this.rawValue);
        let nextValue = this.parseDigitsToNumber(digits);
        if (nextValue === null) {
            this.value = null;
            this.rawValue = '';
        }
        else {
            nextValue = this.applyMinMax(nextValue);
            this.value = nextValue;
            this.rawValue = this.formatNumberToRaw(nextValue);
        }
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    getLocale() {
        return this.locale || 'pt-BR';
    }
    getDecimals() {
        return Number.isFinite(this.decimals) ? this.decimals : 2;
    }
    extractDigits(value) {
        return String(value || '').replace(/\D+/g, '');
    }
    parseDigitsToNumber(digits) {
        if (!digits)
            return null;
        const d = this.getDecimals();
        const intValue = parseInt(digits, 10);
        if (isNaN(intValue))
            return null;
        if (d <= 0)
            return intValue;
        return intValue / Math.pow(10, d);
    }
    formatNumberToRaw(value) {
        if (value === null || value === undefined || isNaN(value))
            return '';
        const formatter = new Intl.NumberFormat(this.getLocale(), {
            style: 'decimal',
            minimumFractionDigits: this.getDecimals(),
            maximumFractionDigits: this.getDecimals(),
        });
        return formatter.format(value);
    }
    formatNumberToView(value) {
        if (value === null || value === undefined || isNaN(value))
            return this.msg.empty;
        const formatter = new Intl.NumberFormat(this.getLocale(), {
            style: 'decimal',
            minimumFractionDigits: this.getDecimals(),
            maximumFractionDigits: this.getDecimals(),
        });
        return formatter.format(value);
    }
    applyMinMax(value) {
        if (this.min !== null && value < this.min)
            return this.min;
        if (this.max !== null && value > this.max)
            return this.max;
        return value;
    }
    getInputClasses() {
        const hasError = !!this.error;
        const isBlocked = this.disabled || this.loading;
        return [
            'w-full flex-1 bg-transparent outline-none text-sm ml-input',
            isBlocked ? 'cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getContainerClasses() {
        return [
            'relative flex w-full items-center gap-2 ml-input-container py-2 px-3',
            this.error ? 'ml-input-container-error' : '',
            (this.disabled || this.loading) ? 'ml-disabled' : 'cursor-text',
        ].filter(Boolean).join(' ');
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label id=${labelId} class="${cn('mb-1 block text-sm ml-label', this.getSlotClass('Label'))}">
        ${unsafeHTML(this.getSlotContent('Label'))}
      </label>
    `;
    }
    renderHelper(helperId) {
        if (this.error) {
            return html `
        <p id=${helperId} class="mt-1 text-xs ml-error-text">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p id=${helperId} class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderLoading() {
        if (!this.loading)
            return html ``;
        return html `
      <div class="mt-2 text-xs ml-text-muted">${this.msg.loading}</div>
    `;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelId = `label-${this.id || 'enter-money-br'}`;
        const helperId = `helper-${this.id || 'enter-money-br'}`;
        if (!this.isEditing) {
            return html `
        <div class="${cn('w-full', this.cssClass)}">
          ${this.renderLabel(labelId)}
          <div
            class="text-sm ml-text"
            aria-labelledby=${labelId}
          >
            ${this.formatNumberToView(this.value)}
          </div>
        </div>
      `;
        }
        const placeholder = this.placeholder || this.msg.placeholder;
        const ariaInvalid = this.error ? 'true' : 'false';
        return html `
      <div class="${cn('w-full', this.cssClass)}">
        ${this.renderLabel(labelId)}
        <div class="${this.getContainerClasses()}">
          <input
            class=${this.getInputClasses()}
            type="text"
            inputmode="decimal"
            .value=${this.rawValue}
            placeholder=${placeholder}
            name=${this.name}
            ?disabled=${this.disabled || this.loading}
            ?readonly=${this.readonly}
            aria-labelledby=${this.hasSlot('Label') ? labelId : ''}
            aria-describedby=${this.error || this.hasSlot('Helper') ? helperId : ''}
            aria-invalid=${ariaInvalid}
            aria-required=${this.required ? 'true' : 'false'}
            @focus=${this.handleFocus}
            @input=${this.handleInput}
            @blur=${this.handleBlur}
          
          @change=${(e) => e.stopPropagation()}
/>
        </div>
        ${this.renderHelper(helperId)}
        ${this.renderLoading()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyBrMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyBrMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyBrMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyBrMolecule.prototype, "currency", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyBrMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyBrMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyBrMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyBrMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-symbol' })
], EnterMoneyBrMolecule.prototype, "showSymbol", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyBrMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EnterMoneyBrMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyBrMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyBrMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyBrMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyBrMolecule.prototype, "loading", void 0);
__decorate([
    state()
], EnterMoneyBrMolecule.prototype, "rawValue", void 0);
EnterMoneyBrMolecule = __decorate([
    customElement('groupentermoney--ml-enter-money-br')
], EnterMoneyBrMolecule);
export { EnterMoneyBrMolecule };
