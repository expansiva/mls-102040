var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentermoney/ml-enter-money-minimal.ts" enhancement="_102020_/l2/enhancementAura" />
// =============================================================================
// ENTER MONEY MINIMAL MOLECULE
// =============================================================================
// Skill Group: groupEnterMoney
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
let EnterMoneyMinimalMolecule = class EnterMoneyMinimalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.currency = 'USD';
        this.locale = '';
        this.decimals = 2;
        this.min = null;
        this.max = null;
        this.showSymbol = true;
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.rawValue = '';
        this.uid = `em-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.rawValue = this.formatToRaw(this.value);
    }
    // ===========================================================================
    // STATE CHANGE HANDLER — for derived rawValue
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueAttr = this.getAttribute('value');
        const localeAttr = this.getAttribute('locale');
        const decimalsAttr = this.getAttribute('decimals');
        if (valueAttr === `{{${key}}}` || localeAttr === `{{${key}}}` || decimalsAttr === `{{${key}}}`) {
            this.rawValue = this.formatToRaw(this.value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleFocus(e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        input.select();
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleInput(e) {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        this.rawValue = input.value;
        this.value = this.parseLocaleNumber(this.rawValue);
        this.dispatchEvent(new CustomEvent('input', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
    }
    handleBlur() {
        if (!this.isEditing || this.disabled || this.readonly || this.loading)
            return;
        const trimmed = this.rawValue.trim();
        if (trimmed === '') {
            this.value = null;
            this.rawValue = '';
        }
        else {
            const parsed = this.parseLocaleNumber(this.rawValue);
            if (parsed === null) {
                this.value = null;
                this.rawValue = '';
            }
            else {
                const clamped = this.clampValue(parsed);
                this.value = clamped;
                this.rawValue = this.formatToRaw(clamped);
            }
        }
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { value: this.value },
        }));
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getSeparators() {
        if (!this.locale)
            return { decimal: '.', group: '' };
        const parts = new Intl.NumberFormat(this.locale).formatToParts(1000.1);
        const decimal = parts.find((p) => p.type === 'decimal')?.value || '.';
        const group = parts.find((p) => p.type === 'group')?.value || ',';
        return { decimal, group };
    }
    parseLocaleNumber(raw) {
        if (!raw)
            return null;
        const { decimal, group } = this.getSeparators();
        const escDecimal = decimal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        const escGroup = group.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        let cleaned = raw;
        if (group)
            cleaned = cleaned.replace(new RegExp(escGroup, 'g'), '');
        cleaned = cleaned.replace(new RegExp(`[^0-9${escDecimal}-]`, 'g'), '');
        if (decimal !== '.')
            cleaned = cleaned.replace(new RegExp(escDecimal, 'g'), '.');
        const num = parseFloat(cleaned);
        if (isNaN(num))
            return null;
        const fixed = Number(num.toFixed(this.decimals));
        return isNaN(fixed) ? null : fixed;
    }
    formatToRaw(value) {
        if (value === null || value === undefined)
            return '';
        return new Intl.NumberFormat(this.locale || undefined, {
            style: 'decimal',
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        }).format(value);
    }
    clampValue(value) {
        let next = value;
        if (this.min !== null && this.min !== undefined && next < this.min)
            next = this.min;
        if (this.max !== null && this.max !== undefined && next > this.max)
            next = this.max;
        return next;
    }
    getCurrencySymbol() {
        try {
            const parts = new Intl.NumberFormat(this.locale || undefined, {
                style: 'currency',
                currency: this.currency,
                currencyDisplay: 'symbol',
                minimumFractionDigits: 0,
                maximumFractionDigits: 0,
            }).formatToParts(0);
            const symbol = parts.find((p) => p.type === 'currency')?.value;
            return symbol || this.currency;
        }
        catch {
            return this.currency;
        }
    }
    getAriaLabel() {
        const label = this.stripHtml(this.getSlotContent('Label'));
        const base = label || 'Amount';
        return `${base} ${this.currency}`;
    }
    stripHtml(content) {
        return content.replace(/<[^>]*>/g, '').trim();
    }
    getContainerClasses() {
        return [
            'w-full flex flex-col gap-1',
            this.disabled || this.loading ? 'opacity-50' : '',
        ].filter(Boolean).join(' ');
    }
    getInputClasses(isInvalid) {
        return [
            'w-full rounded-md px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
            isInvalid
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.readonly ? 'bg-slate-50 dark:bg-slate-900' : '',
        ].filter(Boolean).join(' ');
    }
    getSymbolClasses() {
        return [
            'px-2 text-sm',
            'text-slate-600 dark:text-slate-400',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        if (!this.isEditing)
            return this.renderViewMode();
        return this.renderEditMode();
    }
    renderViewMode() {
        const labelId = `${this.uid}-label`;
        const valueText = this.value === null ? '—' : this.formatToRaw(this.value);
        return html `
<div class="${this.getContainerClasses()}">
${this.renderLabel(labelId)}
<div class="flex items-center gap-1 text-sm text-slate-900 dark:text-slate-100">
${this.showSymbol && this.value !== null ? html `<span class="${this.getSymbolClasses()}">${this.getCurrencySymbol()}</span>` : html ``}
<span>${valueText}</span>
</div>
</div>
`;
    }
    renderEditMode() {
        const labelId = `${this.uid}-label`;
        const errorId = `${this.uid}-error`;
        const helperId = `${this.uid}-helper`;
        const isInvalid = (this.error && this.error.trim() !== '') || (this.required && this.value === null);
        const describedBy = this.error && this.error.trim() !== ''
            ? errorId
            : this.hasSlot('Helper') ? helperId : '';
        return html `
<div class="${this.getContainerClasses()}">
${this.renderLabel(labelId)}
<div class="flex items-stretch">
${this.showSymbol ? html `<span class="${this.getSymbolClasses()}">${this.getCurrencySymbol()}</span>` : html ``}
<input
class="${this.getInputClasses(isInvalid)}"
type="text"
inputmode="decimal"
.name=${this.name}
.placeholder=${this.placeholder}
.value=${this.rawValue}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
aria-labelledby=${this.hasSlot('Label') ? labelId : ''}
aria-describedby=${describedBy}
aria-invalid=${isInvalid ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
aria-label=${this.getAriaLabel()}
@focus=${this.handleFocus}
@input=${this.handleInput}
@blur=${this.handleBlur}
/>
</div>
${this.loading ? html `<div class="mt-1 text-xs text-slate-500 dark:text-slate-400">Loading...</div>` : html ``}
${this.renderFeedback(errorId, helperId)}
</div>
`;
    }
    renderLabel(labelId) {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<label id="${labelId}" class="text-sm text-slate-600 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Label'))}</label>`;
    }
    renderFeedback(errorId, helperId) {
        if (!this.isEditing)
            return html ``;
        if (this.error && this.error.trim() !== '') {
            return html `<p id="${errorId}" class="text-xs text-red-600 dark:text-red-400">${unsafeHTML(this.error)}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${helperId}" class="text-xs text-slate-500 dark:text-slate-400">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyMinimalMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyMinimalMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyMinimalMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyMinimalMolecule.prototype, "currency", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyMinimalMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'decimals' })
], EnterMoneyMinimalMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyMinimalMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], EnterMoneyMinimalMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-symbol' })
], EnterMoneyMinimalMolecule.prototype, "showSymbol", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterMoneyMinimalMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EnterMoneyMinimalMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyMinimalMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyMinimalMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyMinimalMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterMoneyMinimalMolecule.prototype, "loading", void 0);
__decorate([
    state()
], EnterMoneyMinimalMolecule.prototype, "rawValue", void 0);
__decorate([
    state()
], EnterMoneyMinimalMolecule.prototype, "uid", void 0);
EnterMoneyMinimalMolecule = __decorate([
    customElement('groupentermoney--ml-enter-money-minimal')
], EnterMoneyMinimalMolecule);
export { EnterMoneyMinimalMolecule };
