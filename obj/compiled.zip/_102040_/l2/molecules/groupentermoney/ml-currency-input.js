var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentermoney/ml-currency-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// groupentermoney--ml-currency-input MOLECULE
// =============================================================================
// Skill Group: groupEnterMoney (currency input)
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    placeholder: 'Enter amount',
    noValue: '—',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let GroupEnterMoneyMlCurrencyInputMolecule = class GroupEnterMoneyMlCurrencyInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.currency = 'USD';
        this.locale = '';
        this.decimals = 2;
        this.min = null;
        this.max = null;
        this.showSymbol = true;
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.rawValue = '';
        // ===========================================================================
        // EVENT HANDLERS
        // ===========================================================================
        this.onFocus = (e) => {
            if (this.disabled || this.readonly)
                return;
            const input = e.target;
            input.select();
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        };
        this.onInput = (e) => {
            if (this.disabled || this.readonly)
                return;
            const input = e.target;
            this.rawValue = input.value;
            const parsed = this.parseRawToNumber(this.rawValue);
            this.value = parsed;
            this.dispatchEvent(new CustomEvent('input', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
        };
        this.onBlur = () => {
            if (this.disabled || this.readonly)
                return;
            const parsed = this.parseRawToNumber(this.rawValue);
            let newValue = parsed;
            if (newValue !== null) {
                newValue = Number(newValue.toFixed(this.decimals));
            }
            newValue = this.clampValue(newValue);
            this.value = newValue;
            this.rawValue = this.formatToRaw(this.value);
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        };
    }
    // ===========================================================================
    // STATE CHANGE HANDLER – keep rawValue in sync when external state changes
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueBinding = this.getAttribute('value');
        if (valueBinding === `{{${key}}}`) {
            this.rawValue = this.formatToRaw(this.value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS – Formatting & Parsing
    // ===========================================================================
    getEffectiveLocale() {
        return this.locale || 'en-US';
    }
    formatNumber(num) {
        if (num === null)
            return '';
        const opts = {
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        };
        if (this.showSymbol) {
            opts.style = 'currency';
            opts.currency = this.currency;
        }
        return new Intl.NumberFormat(this.getEffectiveLocale(), opts).format(num);
    }
    // Raw value for the INPUT – locale formatted without currency symbol
    formatToRaw(num) {
        if (num === null)
            return '';
        const opts = {
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        };
        return new Intl.NumberFormat(this.getEffectiveLocale(), opts).format(num);
    }
    /**
     * Parses the raw string entered by the user, interpreting it as an integer of cents
     * (or the appropriate fraction based on `decimals`). Returns a number or null.
     * Supports up to 20 digits by using BigInt for the intermediate integer value.
     */
    parseRawToNumber(raw) {
        // Remove everything except digits and minus sign
        const digits = raw.replace(/[^0-9\-]/g, '');
        if (digits === '' || digits === '-')
            return null;
        try {
            // Use BigInt to safely handle up to 20 digits
            const bigIntVal = BigInt(digits);
            const divisor = BigInt(10) ** BigInt(this.decimals);
            // Convert back to Number (may lose precision beyond safe integer range, but fulfills requirement)
            return Number(bigIntVal) / Number(divisor);
        }
        catch {
            // Fallback to regular parsing if BigInt fails (e.g., too large for environment)
            const intVal = parseInt(digits, 10);
            if (isNaN(intVal))
                return null;
            const divisor = Math.pow(10, this.decimals);
            return intVal / divisor;
        }
    }
    clampValue(val) {
        if (val === null)
            return null;
        let result = val;
        if (this.min !== null && result < this.min)
            result = this.min;
        if (this.max !== null && result > this.max)
            result = this.max;
        return result;
    }
    // ===========================================================================
    // CSS CLASS BUILDERS (dark mode aware)
    // ===========================================================================
    getInputClasses() {
        const base = [
            'w-full rounded-md px-3 py-2 text-sm border transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            'placeholder:text-slate-400 dark:placeholder:text-slate-500',
        ];
        if (this.error) {
            base.push('border-red-500 dark:border-red-400');
        }
        else {
            base.push('border-slate-200 dark:border-slate-700');
        }
        if (this.disabled) {
            base.push('opacity-50 cursor-not-allowed');
        }
        else {
            base.push('focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400');
        }
        if (this.readonly) {
            base.push('bg-slate-50 dark:bg-slate-900');
        }
        return base.filter(Boolean).join(' ');
    }
    getContainerClasses() {
        return [
            'relative',
            this.loading ? 'opacity-50 pointer-events-none' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return nothing;
        const labelId = `${this.id}-label`;
        return html `<label id="${labelId}" class="block mb-1 text-sm font-medium text-slate-700 dark:text-slate-200">
      ${unsafeHTML(this.getSlotContent('Label'))}
    </label>`;
    }
    renderHelperOrError() {
        const describedId = `${this.id}-desc`;
        if (this.error) {
            return html `<p id="${describedId}" class="mt-1 text-xs text-red-600 dark:text-red-400">
        ${unsafeHTML(this.error)}
      </p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${describedId}" class="mt-1 text-xs text-slate-500 dark:text-slate-400">
        ${unsafeHTML(this.getSlotContent('Helper'))}
      </p>`;
        }
        return nothing;
    }
    renderInput() {
        const inputId = `${this.id}-input`;
        const describedId = this.error || this.hasSlot('Helper') ? `${this.id}-desc` : undefined;
        const placeholder = this.placeholder || this.getSlotAttr('Label', 'placeholder') || this.msg.placeholder;
        return html `
      <input
        id="${inputId}"
        name="${this.name}"
        class="${this.getInputClasses()}"
        .value=${this.rawValue}
        ?disabled=${this.disabled || this.loading}
        ?readonly=${this.readonly}
        placeholder="${placeholder}"
        maxlength="20"
        aria-labelledby="${this.hasSlot('Label') ? `${this.id}-label` : undefined}"
        aria-describedby="${describedId}"
        aria-invalid="${this.error ? 'true' : 'false'}"
        aria-required="${this.required ? 'true' : 'false'}"
        @focus="${this.onFocus}"
        @input="${this.onInput}"
        @blur="${this.onBlur}"
      />
    `;
    }
    renderViewMode() {
        const display = this.value === null ? this.msg.noValue : this.formatNumber(this.value);
        return html `<span class="block w-full text-sm text-slate-900 dark:text-slate-100">${unsafeHTML(display)}</span>`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Sync rawValue when value changes externally (initial render)
        if (this.rawValue === '' && this.value !== null) {
            this.rawValue = this.formatToRaw(this.value);
        }
        const containerClasses = this.getContainerClasses();
        return html `
      <div class="${containerClasses}">
        ${this.renderLabel()}
        ${this.isEditing ? this.renderInput() : this.renderViewMode()}
        ${this.renderHelperOrError()}
        ${this.loading
            ? html `<div class="absolute inset-0 flex items-center justify-center bg-white bg-opacity-50 dark:bg-slate-800 dark:bg-opacity-50">
              <span class="text-sm text-slate-600 dark:text-slate-300">${this.msg.loading}</span>
            </div>`
            : nothing}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "currency", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-symbol' })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "showSymbol", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "rawValue", void 0);
GroupEnterMoneyMlCurrencyInputMolecule = __decorate([
    customElement('groupentermoney--ml-currency-input')
], GroupEnterMoneyMlCurrencyInputMolecule);
export { GroupEnterMoneyMlCurrencyInputMolecule };
