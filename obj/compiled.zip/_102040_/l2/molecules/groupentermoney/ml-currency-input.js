var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupentermoney/ml-currency-input.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// groupentermoney--ml-currency-input MOLECULE
// =============================================================================
// Skill Group: groupEnterMoney (currency input)
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    placeholder: 'Enter amount',
    noValue: '—',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let GroupEnterMoneyMlCurrencyInputMolecule = class GroupEnterMoneyMlCurrencyInputMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupentermoney--ml-currency-input .ml-input-container {
  background: var(--ml-surface, #ffffff);
  border: var(--ml-border-width, 1px) var(--ml-border-style, solid) var(--ml-outline-variant, #e2e8f0);
  border-radius: var(--ml-radius-sm, 6px);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupentermoney--ml-currency-input .ml-input-container:focus-within {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupentermoney--ml-currency-input .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupentermoney--ml-currency-input .ml-input {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-currency-input .ml-input::placeholder {
  color: var(--ml-on-surface-faint, #79747e);
}
groupentermoney--ml-currency-input .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupentermoney--ml-currency-input .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-currency-input .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-currency-input .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-currency-input .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupentermoney--ml-currency-input .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupentermoney--ml-currency-input .ml-loading-overlay {
  background: var(--ml-surface, #ffffff);
  opacity: 0.5;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.value = null;
        this.error = '';
        this.name = '';
        this.currency = 'USD';
        this.locale = '';
        this.decimals = 2;
        this.min = null;
        this.max = null;
        this.showSymbol = true;
        this.placeholder = '';
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.rawValue = '';
        // ===========================================================================
        // EVENT HANDLERS
        // ===========================================================================
        this.onFocus = (e) => {
            if (this.disabled || this.readonly)
                return;
            const input = e.target;
            input.select();
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        };
        this.onInput = (e) => {
            if (this.disabled || this.readonly)
                return;
            const input = e.target;
            this.rawValue = input.value;
            const parsed = this.parseRawToNumber(this.rawValue);
            this.value = parsed;
            this.dispatchEvent(new CustomEvent('input', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
        };
        this.onBlur = () => {
            if (this.disabled || this.readonly)
                return;
            const parsed = this.parseRawToNumber(this.rawValue);
            let newValue = parsed;
            if (newValue !== null) {
                newValue = Number(newValue.toFixed(this.decimals));
            }
            newValue = this.clampValue(newValue);
            this.value = newValue;
            this.rawValue = this.formatToRaw(this.value);
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { value: this.value },
            }));
            this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
        };
    }
    // ===========================================================================
    // STATE CHANGE HANDLER – keep rawValue in sync when external state changes
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const valueBinding = this.getAttribute('value');
        if (valueBinding === `{{${key}}}`) {
            this.rawValue = this.formatToRaw(this.value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // HELPERS – Formatting & Parsing
    // ===========================================================================
    getEffectiveLocale() {
        return this.locale || 'en-US';
    }
    formatNumber(num) {
        if (num === null)
            return '';
        const opts = {
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        };
        if (this.showSymbol) {
            opts.style = 'currency';
            opts.currency = this.currency;
        }
        return new Intl.NumberFormat(this.getEffectiveLocale(), opts).format(num);
    }
    // Raw value for the INPUT – locale formatted without currency symbol
    formatToRaw(num) {
        if (num === null)
            return '';
        const opts = {
            minimumFractionDigits: this.decimals,
            maximumFractionDigits: this.decimals,
        };
        return new Intl.NumberFormat(this.getEffectiveLocale(), opts).format(num);
    }
    /**
     * Parses the raw string entered by the user, interpreting it as an integer of cents
     * (or the appropriate fraction based on `decimals`). Returns a number or null.
     * Supports up to 20 digits by using BigInt for the intermediate integer value.
     */
    parseRawToNumber(raw) {
        // Remove everything except digits and minus sign
        const digits = raw.replace(/[^0-9\-]/g, '');
        if (digits === '' || digits === '-')
            return null;
        try {
            // Use BigInt to safely handle up to 20 digits
            const bigIntVal = BigInt(digits);
            const divisor = BigInt(10) ** BigInt(this.decimals);
            // Convert back to Number (may lose precision beyond safe integer range, but fulfills requirement)
            return Number(bigIntVal) / Number(divisor);
        }
        catch {
            // Fallback to regular parsing if BigInt fails (e.g., too large for environment)
            const intVal = parseInt(digits, 10);
            if (isNaN(intVal))
                return null;
            const divisor = Math.pow(10, this.decimals);
            return intVal / divisor;
        }
    }
    clampValue(val) {
        if (val === null)
            return null;
        let result = val;
        if (this.min !== null && result < this.min)
            result = this.min;
        if (this.max !== null && result > this.max)
            result = this.max;
        return result;
    }
    // ===========================================================================
    // CSS CLASS BUILDERS (dark mode aware)
    // ===========================================================================
    getInputClasses() {
        return [
            'w-full flex-1 bg-transparent outline-none text-sm ml-input',
            this.disabled ? 'cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
        ].filter(Boolean).join(' ');
    }
    getContainerClasses() {
        return [
            'relative flex w-full items-center gap-2 ml-input-container py-2 px-3',
            this.error ? 'ml-input-container-error' : '',
            (this.disabled || this.loading) ? 'ml-disabled' : 'cursor-text',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return nothing;
        const labelId = `${this.id}-label`;
        return html `<label id="${labelId}" class="${cn('block mb-1 text-sm ml-label', this.getSlotClass('Label'))}">
      ${unsafeHTML(this.getSlotContent('Label'))}
    </label>`;
    }
    renderHelperOrError() {
        const describedId = `${this.id}-desc`;
        if (this.error) {
            return html `<p id="${describedId}" class="mt-1 text-xs ml-error-text">
        ${unsafeHTML(this.error)}
      </p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${describedId}" class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">
        ${unsafeHTML(this.getSlotContent('Helper'))}
      </p>`;
        }
        return nothing;
    }
    renderInput() {
        const inputId = `${this.id}-input`;
        const describedId = this.error || this.hasSlot('Helper') ? `${this.id}-desc` : undefined;
        const placeholder = this.placeholder || this.getSlotAttr('Label', 'placeholder') || this.msg.placeholder;
        return html `
      <div class="${this.getContainerClasses()}">
        <input
          id="${inputId}"
          name="${this.name}"
          class="${this.getInputClasses()}"
          .value=${this.rawValue}
          ?disabled=${this.disabled || this.loading}
          ?readonly=${this.readonly}
          placeholder="${placeholder}"
          maxlength="20"
          aria-labelledby="${this.hasSlot('Label') ? `${this.id}-label` : undefined}"
          aria-describedby="${describedId}"
          aria-invalid="${this.error ? 'true' : 'false'}"
          aria-required="${this.required ? 'true' : 'false'}"
          @focus="${this.onFocus}"
          @input="${this.onInput}"
          @blur="${this.onBlur}"
        />
      </div>
    `;
    }
    renderViewMode() {
        const display = this.value === null ? this.msg.noValue : this.formatNumber(this.value);
        return html `<span class="block w-full text-sm ml-text">${unsafeHTML(display)}</span>`;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        // Sync rawValue when value changes externally (initial render)
        if (this.rawValue === '' && this.value !== null) {
            this.rawValue = this.formatToRaw(this.value);
        }
        return html `
      <div class="${cn('relative w-full', this.cssClass)}">
        ${this.renderLabel()}
        ${this.isEditing ? this.renderInput() : this.renderViewMode()}
        ${this.renderHelperOrError()}
        ${this.loading
            ? html `<div class="absolute inset-0 flex items-center justify-center ml-loading-overlay">
              <span class="text-sm ml-text-muted">${this.msg.loading}</span>
            </div>`
            : nothing}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "value", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "currency", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "decimals", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "min", void 0);
__decorate([
    propertyDataSource({ type: Number })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "max", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'show-symbol' })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "showSymbol", void 0);
__decorate([
    propertyDataSource({ type: String })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "placeholder", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "loading", void 0);
__decorate([
    state()
], GroupEnterMoneyMlCurrencyInputMolecule.prototype, "rawValue", void 0);
GroupEnterMoneyMlCurrencyInputMolecule = __decorate([
    customElement('groupentermoney--ml-currency-input')
], GroupEnterMoneyMlCurrencyInputMolecule);
export { GroupEnterMoneyMlCurrencyInputMolecule };
