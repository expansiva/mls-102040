var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-tree-diagram.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// HIERARCHY TREE DIAGRAM MOLECULE
// =============================================================================
// Skill Group: view + hierarchy
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    empty: 'No items.',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        empty: 'Sem itens.',
    },
};
let HierarchyTreeDiagramMolecule = class HierarchyTreeDiagramMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewhierarchy--ml-hierarchy-tree-diagram .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-text-faint {
  color: var(--text-muted-disabled, #79747e);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-primary-text {
  color: var(--link-text, #3b82f6);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-surface-bg {
  background: var(--surface-bg, #ffffff);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-surface-dim-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-primary-bg {
  background: var(--button-primary-bg, #3b82f6);
  color: var(--button-primary-text, #ffffff);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-primary-dim-bg {
  background: var(--selected-bg, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-error-dim-bg {
  background: var(--status-error-bg, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-border {
  border-color: var(--border-default, #e2e8f0);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-hover-bg {
  background: var(--surface-alt-bg, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupviewhierarchy--ml-hierarchy-tree-diagram .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Node', 'Empty'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.multiple = true;
        this.expandAll = false;
        this.disabled = false;
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.focusedId = null;
        this.expandedMap = {};
        this.nodeIndex = {};
        this.visibleNodeIds = [];
    }
    // ==========================================================================
    // LIFECYCLE
    // ==========================================================================
    createRenderRoot() {
        return this;
    }
    updated(changedProps) {
        if (changedProps.has('expandAll') && this.expandAll) {
            this.expandedMap = {};
        }
        this.refreshVisibleNodes();
        if (changedProps.has('focusedId')) {
            this.focusCurrentNode();
        }
    }
    // ==========================================================================
    // TREE PARSING
    // ==========================================================================
    buildTree() {
        const allNodes = this.getSlots('Node');
        const roots = allNodes.filter((el) => !this.isNestedNode(el));
        const rootNodes = roots.map((el, index) => this.parseNode(el, [index], null));
        this.nodeIndex = {};
        const register = (node) => {
            this.nodeIndex[node.id] = node;
            node.children.forEach(register);
        };
        rootNodes.forEach(register);
        return rootNodes;
    }
    isNestedNode(el) {
        const parent = el.parentElement;
        return !!parent && parent.tagName.toLowerCase() === 'node';
    }
    parseNode(el, path, parentId) {
        const id = path.join('-');
        const value = el.getAttribute('value');
        const disabled = el.hasAttribute('disabled');
        const expandedDefault = el.hasAttribute('expanded');
        const childrenEls = Array.from(el.children).filter((c) => c.tagName.toLowerCase() === 'node');
        const labelHtml = this.getNodeLabelHtml(el) || value || '';
        const children = childrenEls.map((child, index) => this.parseNode(child, [...path, index], id));
        return { id, value, labelHtml, children, disabled, expandedDefault, parentId };
    }
    getNodeLabelHtml(el) {
        const clone = el.cloneNode(true);
        Array.from(clone.querySelectorAll('node')).forEach((n) => n.remove());
        return (clone.innerHTML || '').trim();
    }
    isExpanded(node) {
        if (this.expandAll)
            return true;
        const state = this.expandedMap[node.id];
        if (state !== undefined)
            return state;
        return node.expandedDefault;
    }
    refreshVisibleNodes() {
        const roots = this.buildTree();
        const ids = [];
        const walk = (node) => {
            ids.push(node.id);
            if (node.children.length && this.isExpanded(node)) {
                node.children.forEach(walk);
            }
        };
        roots.forEach(walk);
        this.visibleNodeIds = ids;
    }
    // ==========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleNodeClick(node) {
        if (this.disabled || node.disabled)
            return;
        this.focusedId = node.id;
        this.dispatchEvent(new CustomEvent('nodeClick', {
            bubbles: true,
            composed: true,
            detail: { value: node.value ?? null },
        }));
    }
    handleToggle(node) {
        if (this.disabled || node.disabled)
            return;
        if (!node.children.length)
            return;
        const current = this.isExpanded(node);
        const next = !current;
        const nextMap = { ...this.expandedMap, [node.id]: next };
        if (!this.multiple && next) {
            Object.values(this.nodeIndex).forEach((n) => {
                if (n.parentId === node.parentId && n.id !== node.id) {
                    nextMap[n.id] = false;
                }
            });
        }
        this.expandedMap = nextMap;
        this.focusedId = node.id;
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: { value: node.value ?? null, expanded: next },
        }));
        this.requestUpdate();
    }
    handleNodeKeydown(e, node) {
        if (this.disabled || node.disabled)
            return;
        const key = e.key;
        if (['ArrowDown', 'ArrowUp', 'ArrowRight', 'ArrowLeft', 'Enter'].includes(key)) {
            e.preventDefault();
        }
        if (key === 'ArrowDown') {
            this.moveFocus(1);
        }
        else if (key === 'ArrowUp') {
            this.moveFocus(-1);
        }
        else if (key === 'ArrowRight') {
            if (node.children.length && !this.isExpanded(node)) {
                this.handleToggle(node);
            }
        }
        else if (key === 'ArrowLeft') {
            if (node.children.length && this.isExpanded(node)) {
                this.handleToggle(node);
            }
        }
        else if (key === 'Enter') {
            if (node.children.length) {
                this.handleToggle(node);
            }
        }
    }
    moveFocus(direction) {
        if (!this.visibleNodeIds.length)
            return;
        const currentIndex = this.focusedId
            ? this.visibleNodeIds.indexOf(this.focusedId)
            : -1;
        const nextIndex = Math.min(this.visibleNodeIds.length - 1, Math.max(0, currentIndex + direction));
        this.focusedId = this.visibleNodeIds[nextIndex];
    }
    focusCurrentNode() {
        if (!this.focusedId)
            return;
        const el = this.querySelector(`[data-node-id="${this.focusedId}"]`);
        if (el)
            el.focus();
    }
    // ==========================================================================
    // RENDER HELPERS
    // ==========================================================================
    getToggleClasses(disabled) {
        return [
            'h-5 w-5 rounded-full border flex items-center justify-center transition',
            'ml-surface-bg',
            'ml-border',
            disabled ? 'ml-disabled' : 'hover:ml-surface-dim-bg',
            '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getLabelClasses(disabled) {
        return [
            'rounded-md px-2 py-1 text-sm transition',
            'ml-text',
            '',
            disabled ? 'ml-disabled' : 'cursor-pointer hover:ml-surface-dim-bg',
        ]
            .filter(Boolean)
            .join(' ');
    }
    getCircleClasses(disabled, expanded) {
        return [
            'h-3 w-3 rounded-full border',
            expanded
                ? 'ml-primary-dim-bg ml-border-focus'
                : 'ml-surface-bg ml-border',
            disabled ? 'opacity-50' : '',
        ]
            .filter(Boolean)
            .join(' ');
    }
    renderToggleIcon(expanded) {
        return html `
 <svg class="h-3 w-3 ml-text-muted" viewBox="0 0 20 20" fill="currentColor">
 ${svg `
 <path
 d="M6 8l4 4 4-4"
 stroke="currentColor"
 stroke-width="2"
 fill="none"
 stroke-linecap="round"
 stroke-linejoin="round"
 transform="${expanded ? 'rotate(180 10 10)' : 'rotate(0 10 10)'}"
 ></path>
 `}
 </svg>
 `;
    }
    renderConnector() {
        return html `
 <svg class="mt-3" width="24" height="24" viewBox="0 0 24 24" aria-hidden="true">
 ${svg `
 <path
 d="M0 12 Q12 0 24 12"
 fill="none"
 stroke="currentColor"
 stroke-width="2"
 class="ml-text-muted"
 ></path>
 `}
 </svg>
 `;
    }
    renderNode(node, depth) {
        const expanded = this.isExpanded(node);
        const hasChildren = node.children.length > 0;
        const nodeDisabled = this.disabled || node.disabled;
        const ariaExpanded = hasChildren ? String(expanded) : nothing;
        const tabindex = this.focusedId === node.id || (!this.focusedId && depth === 0) ? 0 : -1;
        return html `
 <div class="flex items-start">
 <div class="flex items-start gap-3">
 ${hasChildren
            ? html `
 <button
 class="${this.getToggleClasses(nodeDisabled)}"
 @click=${(e) => {
                e.stopPropagation();
                this.handleToggle(node);
            }}
 aria-label="Toggle"
 ?disabled=${nodeDisabled}
 >
 ${this.renderToggleIcon(expanded)}
 </button>
 `
            : html `<div class="h-5 w-5"></div>`}

 <div class="flex items-center gap-2">
 <span class="${this.getCircleClasses(nodeDisabled, expanded)}"></span>
 <div
 class="${this.getLabelClasses(nodeDisabled)}"
 role="treeitem"
 data-node-id="${node.id}"
 aria-expanded=${ariaExpanded}
 aria-disabled=${nodeDisabled ? 'true' : 'false'}
 tabindex=${tabindex}
 @click=${() => this.handleNodeClick(node)}
 @focus=${() => (this.focusedId = node.id)}
 @keydown=${(e) => this.handleNodeKeydown(e, node)}
 >
 ${unsafeHTML(node.labelHtml)}
 </div>
 </div>
 </div>

 ${hasChildren && expanded
            ? html `
 <div role="group" class="ml-8 mt-1 flex flex-col gap-4">
 ${node.children.map((child) => html `
 <div class="flex items-start gap-4">
 ${this.renderConnector()} ${this.renderNode(child, depth + 1)}
 </div>
 `)}
 </div>
 `
            : html ``}
 </div>
 `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
 <div class="${cn('mb-3 text-sm font-semibold ml-text', this.getSlotClass('Label'))}">
 ${unsafeHTML(this.getSlotContent('Label'))}
 </div>
 `;
    }
    renderEmpty() {
        const content = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
        return html `
 <div class="${cn('text-sm ml-text-muted', this.getSlotClass('Empty'))}">
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderLoading() {
        return html `
 <div class="text-sm ml-text-muted">${this.msg.loading}</div>
 `;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return html `<div class="w-full">${this.renderLoading()}</div>`;
        }
        const roots = this.buildTree();
        if (!roots.length) {
            return html `<div class="w-full">${this.renderEmpty()}</div>`;
        }
        return html `
 <div class="${cn('w-full', this.cssClass)}">
 ${this.renderLabel()}
 <div role="tree" class="space-y-4">
 ${roots.map((node) => this.renderNode(node, 0))}
 </div>
 </div>
 `;
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], HierarchyTreeDiagramMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'expand-all' })
], HierarchyTreeDiagramMolecule.prototype, "expandAll", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], HierarchyTreeDiagramMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], HierarchyTreeDiagramMolecule.prototype, "loading", void 0);
__decorate([
    state()
], HierarchyTreeDiagramMolecule.prototype, "focusedId", void 0);
HierarchyTreeDiagramMolecule = __decorate([
    customElement('groupviewhierarchy--ml-hierarchy-tree-diagram')
], HierarchyTreeDiagramMolecule);
export { HierarchyTreeDiagramMolecule };
