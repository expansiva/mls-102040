var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewhierarchy/ml-hierarchy-orgchart.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// HIERARCHY ORGCHART MOLECULE
// =============================================================================
// Skill Group: view + hierarchy
// This molecule does NOT contain business logic.
import { html, svg, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
/// **collab_i18n_start**
const message_en = {
    empty: 'No hierarchy available',
    loading: 'Loading...',
    expand: 'Expand',
    collapse: 'Collapse',
};
const messages = {
    en: message_en,
};
let HierarchyOrgchartMolecule = class HierarchyOrgchartMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewhierarchy--ml-hierarchy-orgchart .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewhierarchy--ml-hierarchy-orgchart .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Node', 'Empty'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.multiple = true;
        this.expandAll = false;
        this.disabled = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.expandedState = {};
        this.focusedPath = null;
    }
    // ===========================================================================
    // LIFECYCLE
    // ==========================================================================
    firstUpdated() {
        const tree = this.buildTree();
        if (tree.length > 0 && !this.focusedPath) {
            this.focusedPath = tree[0].path;
        }
    }
    updated() {
        this.ensureFocusPath();
    }
    // ===========================================================================
    // TREE BUILDING
    // ==========================================================================
    buildTree() {
        const roots = this.getRootNodeElements();
        return roots.map((node, index) => this.createNodeModel(node, `${index}`, null, 0));
    }
    createNodeModel(node, path, parentPath, depth) {
        const childrenElements = this.getChildNodeElements(node);
        const hasChildren = childrenElements.length > 0;
        const expanded = this.getExpandedForPath(path, node);
        const labelHtml = this.getNodeLabelHtml(node);
        const value = node.getAttribute('value');
        const disabled = node.hasAttribute('disabled');
        const children = childrenElements.map((child, index) => this.createNodeModel(child, `${path}-${index}`, path, depth + 1));
        return {
            element: node,
            path,
            parentPath,
            depth,
            value,
            disabled,
            expanded,
            hasChildren,
            labelHtml,
            children,
        };
    }
    getRootNodeElements() {
        const nodes = this.getSlots('Node');
        return nodes.filter((node) => {
            const parent = node.parentElement;
            return !parent || parent.tagName.toLowerCase() !== 'node';
        });
    }
    getChildNodeElements(node) {
        return Array.from(node.children).filter((child) => child.tagName.toLowerCase() === 'node');
    }
    getNodeLabelHtml(node) {
        const clone = node.cloneNode(true);
        const nested = Array.from(clone.querySelectorAll('Node'));
        nested.forEach((n) => n.remove());
        return clone.innerHTML.trim();
    }
    getExpandedForPath(path, node) {
        if (Object.prototype.hasOwnProperty.call(this.expandedState, path)) {
            return this.expandedState[path];
        }
        if (this.expandAll)
            return true;
        return node.hasAttribute('expanded');
    }
    // ===========================================================================
    // FOCUS MANAGEMENT
    // ==========================================================================
    ensureFocusPath() {
        const buttons = Array.from(this.querySelectorAll('.gvh-node-button'));
        const paths = buttons.map((b) => b.dataset.path || '');
        if (paths.length === 0)
            return;
        if (!this.focusedPath || !paths.includes(this.focusedPath)) {
            this.focusedPath = paths[0];
        }
    }
    focusButton(button) {
        if (!button)
            return;
        this.focusedPath = button.dataset.path || null;
        button.focus();
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================
    handleNodeClick(event, model) {
        if (this.disabled || model.disabled)
            return;
        const target = event.currentTarget;
        this.focusedPath = target.dataset.path || model.path;
        this.dispatchEvent(new CustomEvent('nodeClick', {
            bubbles: true,
            composed: true,
            detail: { value: model.value || null },
        }));
    }
    handleToggleClick(event, model) {
        event.stopPropagation();
        if (this.disabled || model.disabled)
            return;
        const nextExpanded = !model.expanded;
        this.applyToggle(model.path, model.value, nextExpanded, model.parentPath);
    }
    applyToggle(path, value, expanded, parentPath) {
        const next = { ...this.expandedState, [path]: expanded };
        if (!this.multiple && expanded) {
            const parentKey = parentPath ?? '';
            const siblings = Array.from(this.querySelectorAll(`.gvh-node-button[data-parent="${parentKey}"]`));
            siblings.forEach((el) => {
                const siblingPath = el.dataset.path;
                if (siblingPath && siblingPath !== path) {
                    next[siblingPath] = false;
                }
            });
        }
        this.expandedState = next;
        this.dispatchEvent(new CustomEvent('toggle', {
            bubbles: true,
            composed: true,
            detail: { value: value || null, expanded },
        }));
    }
    handleKeyDown(event) {
        if (this.disabled)
            return;
        const target = event.target;
        const button = target.closest('.gvh-node-button');
        if (!button)
            return;
        const buttons = Array.from(this.querySelectorAll('.gvh-node-button'));
        const currentIndex = buttons.indexOf(button);
        const hasChildren = button.dataset.hasChildren === 'true';
        const expanded = button.dataset.expanded === 'true';
        const path = button.dataset.path || '';
        const value = button.dataset.value || null;
        const parentPath = button.dataset.parent || null;
        const isDisabled = button.getAttribute('aria-disabled') === 'true';
        if (event.key === 'ArrowDown') {
            event.preventDefault();
            this.focusButton(buttons[currentIndex + 1] || null);
            return;
        }
        if (event.key === 'ArrowUp') {
            event.preventDefault();
            this.focusButton(buttons[currentIndex - 1] || null);
            return;
        }
        if (event.key === 'ArrowRight') {
            event.preventDefault();
            if (!isDisabled && hasChildren && !expanded) {
                this.applyToggle(path, value, true, parentPath);
                return;
            }
            this.focusButton(buttons[currentIndex + 1] || null);
            return;
        }
        if (event.key === 'ArrowLeft') {
            event.preventDefault();
            if (!isDisabled && hasChildren && expanded) {
                this.applyToggle(path, value, false, parentPath);
                return;
            }
            const parent = parentPath
                ? this.querySelector(`.gvh-node-button[data-path="${parentPath}"]`)
                : null;
            this.focusButton(parent);
            return;
        }
        if (event.key === 'Enter') {
            event.preventDefault();
            if (isDisabled)
                return;
            if (hasChildren) {
                this.applyToggle(path, value, !expanded, parentPath);
                return;
            }
            this.dispatchEvent(new CustomEvent('nodeClick', {
                bubbles: true,
                composed: true,
                detail: { value },
            }));
        }
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const labelContent = this.hasSlot('Label') ? this.getSlotContent('Label') : '';
        const tree = this.buildTree();
        return html `
<div class="${cn('w-full text-sm ml-text', this.cssClass)}" role="tree" @keydown=${this.handleKeyDown}>
${labelContent
            ? html `<div class="${cn('mb-3 text-base font-semibold ml-text', this.getSlotClass('Label'))}">${unsafeHTML(labelContent)}</div>`
            : nothing}
${this.loading
            ? this.renderLoading()
            : tree.length === 0
                ? this.renderEmpty()
                : html `<div class="space-y-3">${tree.map((node) => this.renderNode(node))}</div>`}
</div>
`;
    }
    renderLoading() {
        return html `
<div class="space-y-3" role="status" aria-live="polite">
<div class="h-4 w-48 animate-pulse rounded ml-surface-dim-bg"></div>
<div class="h-4 w-56 animate-pulse rounded ml-surface-dim-bg"></div>
<div class="h-4 w-40 animate-pulse rounded ml-surface-dim-bg"></div>
<div class="text-xs ml-text-muted">${this.msg.loading}</div>
</div>
`;
    }
    renderEmpty() {
        const emptyContent = this.hasSlot('Empty') ? this.getSlotContent('Empty') : this.msg.empty;
        return html `<div class="${cn('text-sm ml-text-muted', this.getSlotClass('Empty'))}">${unsafeHTML(emptyContent)}</div>`;
    }
    renderNode(model) {
        const nodeDisabled = this.disabled || model.disabled;
        const buttonClasses = this.getNodeButtonClasses(nodeDisabled);
        const toggleClasses = this.getToggleButtonClasses(nodeDisabled);
        const connectorClasses = [
            'absolute -left-4 top-1/2 w-4 border-t',
            'ml-border',
        ].join(' ');
        return html `
<div class="gvh-node-row">
<div class="relative flex items-center gap-2">
${model.depth > 0 ? html `<span class="${connectorClasses}"></span>` : nothing}
${model.hasChildren
            ? html `
<button
class="${toggleClasses}"
?disabled=${nodeDisabled}
aria-label=${model.expanded ? this.msg.collapse : this.msg.expand}
@click=${(e) => this.handleToggleClick(e, model)}
type="button"
>
${this.renderChevron(model.expanded)}
</button>
`
            : html `<span class="inline-block w-6"></span>`}
<button
class="${buttonClasses} gvh-node-button"
data-path=${model.path}
data-parent=${model.parentPath ?? ''}
data-value=${ifDefined(model.value ?? undefined)}
data-has-children=${model.hasChildren ? 'true' : 'false'}
data-expanded=${model.expanded ? 'true' : 'false'}
role="treeitem"
aria-disabled=${nodeDisabled ? 'true' : 'false'}
aria-expanded=${ifDefined(model.hasChildren ? String(model.expanded) : undefined)}
tabindex=${this.focusedPath === model.path ? '0' : '-1'}
@click=${(e) => this.handleNodeClick(e, model)}
@focus=${() => (this.focusedPath = model.path)}
type="button"
>
${unsafeHTML(model.labelHtml)}
</button>
</div>
${model.hasChildren && model.expanded
            ? html `
<div role="group" class="ml-6 space-y-3 border-l ml-border pl-4">
${model.children.map((child) => this.renderNode(child))}
</div>
`
            : nothing}
</div>
`;
    }
    renderChevron(expanded) {
        const iconClasses = [
            'h-4 w-4 ml-text-muted transition-transform',
            expanded ? 'rotate-90' : 'rotate-0',
        ].join(' ');
        return html `
<svg class="${iconClasses}" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
${svg `<path d="M7.25 4.75L12.5 10l-5.25 5.25-1.5-1.5L9.5 10 5.75 6.25z" />`}
</svg>
`;
    }
    getNodeButtonClasses(nodeDisabled) {
        return [
            'flex items-center gap-2 rounded-md px-3 py-1.5 text-sm border transition',
            'ml-surface-bg',
            'ml-text',
            'ml-border',
            '',
            nodeDisabled ? 'ml-disabled' : 'hover:ml-surface-dim-bg',
        ].filter(Boolean).join(' ');
    }
    getToggleButtonClasses(nodeDisabled) {
        return [
            'flex h-6 w-6 items-center justify-center rounded-md transition',
            'ml-surface-dim-bg',
            'border ml-border',
            '',
            nodeDisabled ? 'ml-disabled' : 'hover:ml-surface-dim-bg',
        ].filter(Boolean).join(' ');
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], HierarchyOrgchartMolecule.prototype, "multiple", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'expand-all' })
], HierarchyOrgchartMolecule.prototype, "expandAll", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], HierarchyOrgchartMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], HierarchyOrgchartMolecule.prototype, "loading", void 0);
__decorate([
    state()
], HierarchyOrgchartMolecule.prototype, "expandedState", void 0);
__decorate([
    state()
], HierarchyOrgchartMolecule.prototype, "focusedPath", void 0);
HierarchyOrgchartMolecule = __decorate([
    customElement('groupviewhierarchy--ml-hierarchy-orgchart')
], HierarchyOrgchartMolecule);
export { HierarchyOrgchartMolecule };
