var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102033_/l2/molecules/groupenterdateinterval/ml-date-interval-drag.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATE INTERVAL DRAG MOLECULE
// =============================================================================
// Skill Group: enter + date-interval
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    startLabel: 'Start',
    endLabel: 'End',
    rangeSeparator: '–',
    empty: '—',
    prevMonth: 'Previous month',
    nextMonth: 'Next month',
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        startLabel: 'Início',
        endLabel: 'Fim',
        rangeSeparator: '–',
        empty: '—',
        prevMonth: 'Mês anterior',
        nextMonth: 'Próximo mês',
    },
};
/// **collab_i18n_end**
let DateIntervalDragMolecule = class DateIntervalDragMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.startDate = null;
        this.endDate = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.minDate = '';
        this.maxDate = '';
        this.minRangeDays = 0;
        this.maxRangeDays = 0;
        this.firstDayOfWeek = 0;
        this.allowSameDay = true;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = true;
        this.selectingEnd = false;
        this.hoverDate = null;
        this.isDragging = false;
        this.hoverValid = true;
        this.currentMonth = new Date();
        this.hasFocus = false;
        // ===========================================================================
        // INTERNAL IDS
        // ===========================================================================
        this.labelId = `lbl-${Math.random().toString(36).slice(2, 9)}`;
        this.errorId = `err-${Math.random().toString(36).slice(2, 9)}`;
        this.helperId = `hlp-${Math.random().toString(36).slice(2, 9)}`;
        this.handleWindowPointerUp = () => {
            if (!this.isDragging)
                return;
            this.finishDrag(this.hoverDate);
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    connectedCallback() {
        super.connectedCallback();
        this.syncCurrentMonth();
    }
    updated(changed) {
        if (changed.has('startDate') || changed.has('endDate')) {
            this.syncCurrentMonth();
        }
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleDayPointerDown(e, iso) {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (!this.isDateSelectableForStart(iso))
            return;
        e.preventDefault();
        this.isDragging = true;
        this.selectingEnd = true;
        this.hoverDate = iso;
        this.hoverValid = this.isDateSelectableForEnd(iso);
        this.startDate = iso;
        this.endDate = null;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startDate },
        }));
        window.addEventListener('pointerup', this.handleWindowPointerUp);
        window.addEventListener('pointercancel', this.handleWindowPointerUp);
    }
    handleDayPointerEnter(iso) {
        if (!this.isDragging || !this.selectingEnd)
            return;
        this.hoverDate = iso;
        this.hoverValid = this.isDateSelectableForEnd(iso);
    }
    handleDayPointerUp(e, iso) {
        if (!this.isDragging)
            return;
        e.preventDefault();
        this.finishDrag(iso);
    }
    finishDrag(candidateIso) {
        this.isDragging = false;
        window.removeEventListener('pointerup', this.handleWindowPointerUp);
        window.removeEventListener('pointercancel', this.handleWindowPointerUp);
        if (!this.startDate || !candidateIso)
            return;
        if (!this.isDateSelectableForEnd(candidateIso)) {
            this.hoverDate = null;
            this.selectingEnd = true;
            return;
        }
        const ordered = this.getOrderedRange(this.startDate, candidateIso);
        const swapped = ordered.start !== this.startDate;
        this.startDate = ordered.start;
        this.endDate = ordered.end;
        this.selectingEnd = false;
        this.hoverDate = null;
        if (swapped) {
            this.dispatchEvent(new CustomEvent('startChange', {
                bubbles: true,
                composed: true,
                detail: { value: this.startDate },
            }));
        }
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endDate },
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { startDate: this.startDate, endDate: this.endDate },
        }));
    }
    handlePrevMonth() {
        if (!this.canNavigatePrev())
            return;
        this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() - 1, 1);
    }
    handleNextMonth() {
        if (!this.canNavigateNext())
            return;
        this.currentMonth = new Date(this.currentMonth.getFullYear(), this.currentMonth.getMonth() + 1, 1);
    }
    handleFocusIn() {
        if (this.hasFocus)
            return;
        this.hasFocus = true;
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    handleFocusOut() {
        if (!this.hasFocus)
            return;
        this.hasFocus = false;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    // ===========================================================================
    // HELPERS
    // ===========================================================================
    getLocale() {
        return this.locale || navigator.language || 'en-US';
    }
    syncCurrentMonth() {
        const baseIso = this.startDate || this.endDate;
        if (!baseIso)
            return;
        const d = this.parseIsoDate(baseIso);
        if (d) {
            this.currentMonth = new Date(d.getFullYear(), d.getMonth(), 1);
        }
    }
    parseIsoDate(value) {
        if (!value)
            return null;
        const parts = value.split('-').map((p) => Number(p));
        if (parts.length !== 3)
            return null;
        const [y, m, d] = parts;
        if (!y || !m || !d)
            return null;
        return new Date(y, m - 1, d);
    }
    formatIsoDate(date) {
        const y = date.getFullYear();
        const m = String(date.getMonth() + 1).padStart(2, '0');
        const d = String(date.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
    }
    formatDisplayDate(value) {
        const date = this.parseIsoDate(value);
        if (!date)
            return this.msg.empty;
        const formatter = new Intl.DateTimeFormat(this.getLocale(), {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
        });
        return formatter.format(date);
    }
    diffInDays(a, b) {
        const da = this.parseIsoDate(a);
        const db = this.parseIsoDate(b);
        if (!da || !db)
            return 0;
        const ua = Date.UTC(da.getFullYear(), da.getMonth(), da.getDate());
        const ub = Date.UTC(db.getFullYear(), db.getMonth(), db.getDate());
        return Math.abs(Math.round((ub - ua) / 86400000));
    }
    compareIso(a, b) {
        return this.formatIsoDate(this.parseIsoDate(a)).localeCompare(this.formatIsoDate(this.parseIsoDate(b)));
    }
    getOrderedRange(a, b) {
        return this.compareIso(a, b) <= 0 ? { start: a, end: b } : { start: b, end: a };
    }
    isWithinMinMax(iso) {
        const min = this.minDate ? this.minDate : null;
        const max = this.maxDate ? this.maxDate : null;
        if (min && this.compareIso(iso, min) < 0)
            return false;
        if (max && this.compareIso(iso, max) > 0)
            return false;
        return true;
    }
    isDateSelectableForStart(iso) {
        return this.isWithinMinMax(iso);
    }
    isDateSelectableForEnd(iso) {
        if (!this.startDate)
            return false;
        if (!this.isWithinMinMax(iso))
            return false;
        const diff = this.diffInDays(this.startDate, iso);
        if (!this.allowSameDay && diff === 0)
            return false;
        if (this.minRangeDays > 0 && diff < this.minRangeDays)
            return false;
        if (this.maxRangeDays > 0 && diff > this.maxRangeDays)
            return false;
        return true;
    }
    getWeekdayLabels() {
        const locale = this.getLocale();
        const base = new Date(2021, 7, 1); // Sunday
        const formatter = new Intl.DateTimeFormat(locale, { weekday: 'short' });
        const labels = [];
        for (let i = 0; i < 7; i += 1) {
            const offset = (i + this.firstDayOfWeek) % 7;
            const date = new Date(base);
            date.setDate(base.getDate() + offset);
            labels.push(formatter.format(date));
        }
        return labels;
    }
    getCalendarDays() {
        const year = this.currentMonth.getFullYear();
        const month = this.currentMonth.getMonth();
        const monthStart = new Date(year, month, 1);
        const firstWeekday = (monthStart.getDay() - this.firstDayOfWeek + 7) % 7;
        const daysInMonth = new Date(year, month + 1, 0).getDate();
        const cells = [];
        for (let i = 0; i < 42; i += 1) {
            const dayNumber = i - firstWeekday + 1;
            const date = new Date(year, month, dayNumber);
            const iso = this.formatIsoDate(date);
            const isOutside = dayNumber < 1 || dayNumber > daysInMonth;
            cells.push({ date, iso, isOutside });
        }
        return cells;
    }
    getActiveRange() {
        if (this.selectingEnd && this.startDate && this.hoverDate && this.hoverValid) {
            const range = this.getOrderedRange(this.startDate, this.hoverDate);
            return { start: range.start, end: range.end, preview: true };
        }
        if (this.startDate && this.endDate) {
            const range = this.getOrderedRange(this.startDate, this.endDate);
            return { start: range.start, end: range.end, preview: false };
        }
        return { start: null, end: null, preview: false };
    }
    isInRange(iso, start, end) {
        if (!start || !end)
            return false;
        return this.compareIso(iso, start) >= 0 && this.compareIso(iso, end) <= 0;
    }
    getMonthLabel() {
        const formatter = new Intl.DateTimeFormat(this.getLocale(), { month: 'long', year: 'numeric' });
        return formatter.format(this.currentMonth);
    }
    canNavigatePrev() {
        if (!this.minDate)
            return true;
        const min = this.parseIsoDate(this.minDate);
        if (!min)
            return true;
        const minMonth = new Date(min.getFullYear(), min.getMonth(), 1);
        return this.currentMonth.getTime() > minMonth.getTime();
    }
    canNavigateNext() {
        if (!this.maxDate)
            return true;
        const max = this.parseIsoDate(this.maxDate);
        if (!max)
            return true;
        const maxMonth = new Date(max.getFullYear(), max.getMonth(), 1);
        return this.currentMonth.getTime() < maxMonth.getTime();
    }
    getRangeSummary() {
        const start = this.startDate ? this.formatDisplayDate(this.startDate) : this.msg.empty;
        const end = this.endDate ? this.formatDisplayDate(this.endDate) : this.msg.empty;
        if (!this.startDate && !this.endDate)
            return this.msg.empty;
        return `${start} ${this.msg.rangeSeparator} ${end}`;
    }
    getDayClasses(options) {
        const classes = [
            'flex h-9 w-9 items-center justify-center rounded-md text-sm transition',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            options.isOutside ? 'text-slate-400 dark:text-slate-600' : 'text-slate-900 dark:text-slate-100',
            !options.isDisabled ? 'hover:bg-slate-50 dark:hover:bg-slate-700 cursor-pointer' : 'cursor-not-allowed opacity-50',
            options.isInRange
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300'
                : 'bg-transparent',
            options.isStart || options.isEnd
                ? 'bg-sky-500 dark:bg-sky-400 text-white dark:text-slate-900'
                : '',
            options.isHover && options.isHoverInvalid ? 'bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400' : '',
        ].filter(Boolean);
        return classes.join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        const hasError = Boolean(this.error);
        const hasHelper = !hasError && this.hasSlot('Helper');
        const describedBy = hasError ? this.errorId : hasHelper ? this.helperId : undefined;
        const wrapperClasses = [
            'relative rounded-lg border p-3',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
            hasError ? 'border-red-500 dark:border-red-400' : '',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'bg-slate-50 dark:bg-slate-900' : '',
        ].filter(Boolean).join(' ');
        return html `
<div class="w-full">
${this.renderOverallLabel()}
<div
class="${wrapperClasses}"
role="group"
aria-labelledby=${ifDefined(this.hasSlot('Label') ? this.labelId : undefined)}
aria-describedby=${ifDefined(describedBy)}
aria-invalid=${ifDefined(hasError ? 'true' : undefined)}
aria-required=${ifDefined(this.required ? 'true' : undefined)}
@focusin=${this.handleFocusIn}
@focusout=${this.handleFocusOut}
>
${this.renderHeader()}
<div role="dialog" aria-modal="true">
${this.renderCalendar()}
</div>
${this.loading ? this.renderLoading() : nothing}
</div>
${this.renderFeedback()}
</div>
`;
    }
    renderOverallLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<div id="${this.labelId}" class="mb-2 text-sm font-medium text-slate-700 dark:text-slate-300">
${unsafeHTML(this.getSlotContent('Label'))}
</div>
`;
    }
    renderHeader() {
        const labelStart = this.hasSlot('LabelStart')
            ? unsafeHTML(this.getSlotContent('LabelStart'))
            : this.msg.startLabel;
        const labelEnd = this.hasSlot('LabelEnd')
            ? unsafeHTML(this.getSlotContent('LabelEnd'))
            : this.msg.endLabel;
        const prevDisabled = !this.canNavigatePrev();
        const nextDisabled = !this.canNavigateNext();
        const navBtnBase = [
            'rounded-md p-1 text-slate-600 dark:text-slate-300',
            'hover:bg-slate-50 dark:hover:bg-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
        ].join(' ');
        const navBtnDisabled = 'opacity-50 cursor-not-allowed';
        return html `
<div class="mb-2 flex items-center justify-between">
<div class="text-sm text-slate-600 dark:text-slate-400">
<span class="font-medium text-slate-700 dark:text-slate-200">${labelStart}</span>
<span class="ml-1 mr-2">${this.getRangeSummary().split(this.msg.rangeSeparator)[0].trim()}</span>
<span class="mx-1 text-slate-400 dark:text-slate-500">${this.msg.rangeSeparator}</span>
<span class="font-medium text-slate-700 dark:text-slate-200">${labelEnd}</span>
<span class="ml-1">${this.getRangeSummary().split(this.msg.rangeSeparator)[1]?.trim() || this.msg.empty}</span>
</div>
<div class="flex items-center gap-2">
<button
type="button"
class="${prevDisabled ? `${navBtnBase} ${navBtnDisabled}` : navBtnBase}"
?disabled=${prevDisabled}
aria-label="${this.msg.prevMonth}"
@click=${this.handlePrevMonth}
>
‹
</button>
<div class="text-sm font-medium text-slate-700 dark:text-slate-200">
${this.getMonthLabel()}
</div>
<button
type="button"
class="${nextDisabled ? `${navBtnBase} ${navBtnDisabled}` : navBtnBase}"
?disabled=${nextDisabled}
aria-label="${this.msg.nextMonth}"
@click=${this.handleNextMonth}
>
›
</button>
</div>
</div>
`;
    }
    renderCalendar() {
        const weekdays = this.getWeekdayLabels();
        const days = this.getCalendarDays();
        const range = this.getActiveRange();
        const todayIso = this.formatIsoDate(new Date());
        return html `
<div class="w-full">
<div class="grid grid-cols-7 gap-1 text-center text-xs text-slate-500 dark:text-slate-400">
${weekdays.map((label) => html `<div class="py-1">${label}</div>`)}
</div>
<div role="grid" class="mt-1 grid grid-cols-7 gap-1">
${days.map((day) => {
            const isStart = range.start === day.iso;
            const isEnd = range.end === day.iso;
            const isInRange = this.isInRange(day.iso, range.start, range.end);
            const isHover = this.hoverDate === day.iso;
            const isDisabled = this.disabled ||
                this.readonly ||
                (!this.selectingEnd && !this.isDateSelectableForStart(day.iso)) ||
                (this.selectingEnd && !this.isDateSelectableForEnd(day.iso));
            const classes = this.getDayClasses({
                isOutside: day.isOutside,
                isDisabled,
                isInRange,
                isStart,
                isEnd,
                isHover,
                isHoverInvalid: isHover && !this.hoverValid,
            });
            return html `
<button
type="button"
class="${classes}"
role="gridcell"
aria-selected="${isInRange ? 'true' : 'false'}"
aria-disabled="${isDisabled ? 'true' : 'false'}"
data-today="${day.iso === todayIso ? 'true' : 'false'}"
@pointerdown=${(e) => this.handleDayPointerDown(e, day.iso)}
@pointerenter=${() => this.handleDayPointerEnter(day.iso)}
@pointerup=${(e) => this.handleDayPointerUp(e, day.iso)}
>
${day.date.getDate()}
</button>
`;
        })}
</div>
</div>
`;
    }
    renderFeedback() {
        if (this.error) {
            return html `
<p id="${this.errorId}" class="mt-2 text-xs text-red-600 dark:text-red-400">
${unsafeHTML(String(this.error))}
</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p id="${this.helperId}" class="mt-2 text-xs text-slate-500 dark:text-slate-400">
${unsafeHTML(this.getSlotContent('Helper'))}
</p>
`;
        }
        return html ``;
    }
    renderLoading() {
        return html `
<div class="absolute inset-0 flex items-center justify-center rounded-lg bg-white/70 dark:bg-slate-800/70">
<span class="text-sm text-slate-600 dark:text-slate-300">${this.msg.loading}</span>
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], DateIntervalDragMolecule.prototype, "startDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateIntervalDragMolecule.prototype, "endDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateIntervalDragMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateIntervalDragMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateIntervalDragMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateIntervalDragMolecule.prototype, "minDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], DateIntervalDragMolecule.prototype, "maxDate", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-range-days' })
], DateIntervalDragMolecule.prototype, "minRangeDays", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-range-days' })
], DateIntervalDragMolecule.prototype, "maxRangeDays", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'first-day-of-week' })
], DateIntervalDragMolecule.prototype, "firstDayOfWeek", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-day' })
], DateIntervalDragMolecule.prototype, "allowSameDay", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], DateIntervalDragMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateIntervalDragMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateIntervalDragMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateIntervalDragMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DateIntervalDragMolecule.prototype, "loading", void 0);
__decorate([
    state()
], DateIntervalDragMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], DateIntervalDragMolecule.prototype, "selectingEnd", void 0);
__decorate([
    state()
], DateIntervalDragMolecule.prototype, "hoverDate", void 0);
__decorate([
    state()
], DateIntervalDragMolecule.prototype, "isDragging", void 0);
__decorate([
    state()
], DateIntervalDragMolecule.prototype, "hoverValid", void 0);
__decorate([
    state()
], DateIntervalDragMolecule.prototype, "currentMonth", void 0);
__decorate([
    state()
], DateIntervalDragMolecule.prototype, "hasFocus", void 0);
DateIntervalDragMolecule = __decorate([
    customElement('groupenterdateinterval--ml-date-interval-drag')
], DateIntervalDragMolecule);
export { DateIntervalDragMolecule };
