/// <mls fileReference="_102040_/l2/molecules/groupenterdateinterval/ml-month-year-range.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// MONTH YEAR RANGE MOLECULE
// =============================================================================
// Skill Group: groupEnterDateInterval
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    loading: 'Loading...',
    noSelection: '—',
    to: '–',
    months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    monthsFull: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
};
const messages = {
    en: message_en,
    pt: {
        loading: 'Carregando...',
        noSelection: '—',
        to: '–',
        months: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
        monthsFull: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
    },
};
let MlMonthYearRangeMolecule = class MlMonthYearRangeMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.startDate = null;
        this.endDate = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.minDate = '';
        this.maxDate = '';
        this.minRangeDays = 0;
        this.maxRangeDays = 0;
        this.allowSameDay = true;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.startYear = new Date().getFullYear();
        this.endYear = new Date().getFullYear();
        this.selectingEnd = false;
        this.hoverMonth = null;
        this.isFocused = false;
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.initializeYears();
    }
    // ===========================================================================
    // STATE CHANGE HANDLER
    // ===========================================================================
    handleIcaStateChange(key, value) {
        const startDateAttr = this.getAttribute('start-date');
        const endDateAttr = this.getAttribute('end-date');
        if (startDateAttr === `{{${key}}}` && typeof value === 'string') {
            this.initializeYearsFromDate(value, 'start');
        }
        if (endDateAttr === `{{${key}}}` && typeof value === 'string') {
            this.initializeYearsFromDate(value, 'end');
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // INITIALIZATION
    // ===========================================================================
    initializeYears() {
        const now = new Date();
        if (this.startDate) {
            const parsed = this.parseDate(this.startDate);
            if (parsed)
                this.startYear = parsed.year;
        }
        else {
            this.startYear = now.getFullYear();
        }
        if (this.endDate) {
            const parsed = this.parseDate(this.endDate);
            if (parsed)
                this.endYear = parsed.year;
        }
        else {
            this.endYear = this.startYear;
        }
    }
    initializeYearsFromDate(dateStr, type) {
        const parsed = this.parseDate(dateStr);
        if (parsed) {
            if (type === 'start') {
                this.startYear = parsed.year;
            }
            else {
                this.endYear = parsed.year;
            }
        }
    }
    // ===========================================================================
    // DATE UTILITIES
    // ===========================================================================
    parseDate(dateStr) {
        if (!dateStr)
            return null;
        const parts = dateStr.split('-');
        if (parts.length !== 3)
            return null;
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        if (isNaN(year) || isNaN(month) || isNaN(day))
            return null;
        return { year, month, day };
    }
    formatDateISO(year, month) {
        const m = String(month + 1).padStart(2, '0');
        return `${year}-${m}-01`;
    }
    formatDisplayDate(dateStr) {
        if (!dateStr)
            return this.msg.noSelection;
        const parsed = this.parseDate(dateStr);
        if (!parsed)
            return this.msg.noSelection;
        const monthName = this.msg.monthsFull[parsed.month];
        return `${monthName} ${parsed.year}`;
    }
    getMonthDiff(startYear, startMonth, endYear, endMonth) {
        return (endYear - startYear) * 12 + (endMonth - startMonth);
    }
    getDaysInRange(startYear, startMonth, endYear, endMonth) {
        const startDate = new Date(startYear, startMonth, 1);
        const endDate = new Date(endYear, endMonth + 1, 0);
        return Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    }
    // ===========================================================================
    // VALIDATION
    // ===========================================================================
    isMonthDisabled(year, month) {
        const dateStr = this.formatDateISO(year, month);
        if (this.minDate) {
            const minParsed = this.parseDate(this.minDate);
            if (minParsed) {
                const minMonthStart = this.formatDateISO(minParsed.year, minParsed.month);
                if (dateStr < minMonthStart)
                    return true;
            }
        }
        if (this.maxDate) {
            const maxParsed = this.parseDate(this.maxDate);
            if (maxParsed) {
                const maxMonthStart = this.formatDateISO(maxParsed.year, maxParsed.month);
                if (dateStr > maxMonthStart)
                    return true;
            }
        }
        return false;
    }
    isEndMonthDisabled(year, month) {
        if (this.isMonthDisabled(year, month))
            return true;
        if (!this.selectingEnd || !this.startDate)
            return false;
        const startParsed = this.parseDate(this.startDate);
        if (!startParsed)
            return false;
        if (!this.allowSameDay && year === startParsed.year && month === startParsed.month) {
            return true;
        }
        const daysInRange = this.getDaysInRange(startParsed.year, startParsed.month, year, month);
        if (this.minRangeDays > 0) {
            const minMonths = Math.ceil(this.minRangeDays / 30);
            const monthDiff = this.getMonthDiff(startParsed.year, startParsed.month, year, month);
            if (monthDiff < minMonths - 1)
                return true;
        }
        if (this.maxRangeDays > 0 && daysInRange > this.maxRangeDays) {
            return true;
        }
        return false;
    }
    // ===========================================================================
    // MONTH DATA GENERATION
    // ===========================================================================
    generateMonthData(year, isEndGrid) {
        const months = [];
        const startParsed = this.startDate ? this.parseDate(this.startDate) : null;
        const endParsed = this.endDate ? this.parseDate(this.endDate) : null;
        for (let m = 0; m < 12; m++) {
            const disabled = isEndGrid
                ? this.isEndMonthDisabled(year, m)
                : this.isMonthDisabled(year, m);
            const isStart = startParsed !== null && startParsed.year === year && startParsed.month === m;
            const isEnd = endParsed !== null && endParsed.year === year && endParsed.month === m;
            let isInRange = false;
            let isHovered = false;
            if (startParsed && endParsed) {
                const currentDate = this.formatDateISO(year, m);
                const startDateStr = this.formatDateISO(startParsed.year, startParsed.month);
                const endDateStr = this.formatDateISO(endParsed.year, endParsed.month);
                isInRange = currentDate > startDateStr && currentDate < endDateStr;
            }
            else if (this.selectingEnd && startParsed && this.hoverMonth && isEndGrid) {
                const currentDate = this.formatDateISO(year, m);
                const startDateStr = this.formatDateISO(startParsed.year, startParsed.month);
                const hoverDateStr = this.formatDateISO(this.hoverMonth.year, this.hoverMonth.month);
                if (hoverDateStr >= startDateStr) {
                    isInRange = currentDate > startDateStr && currentDate < hoverDateStr;
                    isHovered = year === this.hoverMonth.year && m === this.hoverMonth.month;
                }
            }
            months.push({
                year,
                month: m,
                label: this.msg.months[m],
                disabled,
                isStart,
                isEnd,
                isInRange,
                isHovered,
            });
        }
        return months;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleStartYearPrev() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.startYear--;
    }
    handleStartYearNext() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.startYear++;
    }
    handleEndYearPrev() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.endYear--;
    }
    handleEndYearNext() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.endYear++;
    }
    handleStartMonthSelect(monthData) {
        if (this.disabled || this.readonly || this.loading || monthData.disabled)
            return;
        this.startDate = this.formatDateISO(monthData.year, monthData.month);
        this.endDate = null;
        this.selectingEnd = true;
        this.hoverMonth = null;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startDate },
        }));
    }
    handleEndMonthSelect(monthData) {
        if (this.disabled || this.readonly || this.loading || monthData.disabled)
            return;
        if (!this.startDate)
            return;
        const startParsed = this.parseDate(this.startDate);
        if (!startParsed)
            return;
        const selectedDateStr = this.formatDateISO(monthData.year, monthData.month);
        const startDateStr = this.formatDateISO(startParsed.year, startParsed.month);
        if (selectedDateStr < startDateStr) {
            this.endDate = this.startDate;
            this.startDate = selectedDateStr;
        }
        else {
            this.endDate = selectedDateStr;
        }
        this.selectingEnd = false;
        this.hoverMonth = null;
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endDate },
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { startDate: this.startDate, endDate: this.endDate },
        }));
    }
    handleEndMonthHover(monthData) {
        if (this.disabled || this.readonly || this.loading || monthData.disabled)
            return;
        if (!this.selectingEnd)
            return;
        this.hoverMonth = { year: monthData.year, month: monthData.month };
    }
    handleEndMonthLeave() {
        this.hoverMonth = null;
    }
    handleFocus() {
        if (this.disabled || this.loading)
            return;
        this.isFocused = true;
        this.dispatchEvent(new CustomEvent('focus', {
            bubbles: true,
            composed: true,
        }));
    }
    handleBlur() {
        this.isFocused = false;
        this.dispatchEvent(new CustomEvent('blur', {
            bubbles: true,
            composed: true,
        }));
    }
    // ===========================================================================
    // CSS CLASSES
    // ===========================================================================
    getContainerClasses() {
        return [
            'w-full',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
        ].filter(Boolean).join(' ');
    }
    getGridContainerClasses() {
        return [
            'flex flex-col md:flex-row gap-6',
        ].join(' ');
    }
    getGridPanelClasses() {
        return [
            'flex-1 rounded-lg border p-4',
            'bg-white dark:bg-slate-800',
            'border-slate-200 dark:border-slate-700',
            this.isFocused && !this.error ? 'ring-2 ring-sky-500 dark:ring-sky-400' : '',
            this.error ? 'border-red-500 dark:border-red-400' : '',
        ].filter(Boolean).join(' ');
    }
    getYearNavClasses() {
        return [
            'flex items-center justify-between mb-4',
        ].join(' ');
    }
    getNavButtonClasses() {
        return [
            'p-2 rounded-md transition',
            'text-slate-600 dark:text-slate-400',
            'hover:bg-slate-100 dark:hover:bg-slate-700',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
            this.disabled || this.readonly ? 'opacity-50 cursor-not-allowed pointer-events-none' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    getYearLabelClasses() {
        return [
            'text-lg font-semibold',
            'text-slate-900 dark:text-slate-100',
        ].join(' ');
    }
    getMonthGridClasses() {
        return [
            'grid grid-cols-3 gap-2',
        ].join(' ');
    }
    getMonthButtonClasses(monthData) {
        const base = 'px-3 py-2 rounded-md text-sm font-medium transition';
        if (monthData.disabled) {
            return [
                base,
                'opacity-40 cursor-not-allowed',
                'text-slate-400 dark:text-slate-600',
                'bg-slate-50 dark:bg-slate-900',
            ].join(' ');
        }
        if (monthData.isStart || monthData.isEnd) {
            return [
                base,
                'bg-sky-500 dark:bg-sky-600',
                'text-white',
                'cursor-pointer',
            ].join(' ');
        }
        if (monthData.isHovered) {
            return [
                base,
                'bg-sky-200 dark:bg-sky-800',
                'text-sky-900 dark:text-sky-100',
                'cursor-pointer',
            ].join(' ');
        }
        if (monthData.isInRange) {
            return [
                base,
                'bg-sky-100 dark:bg-sky-900/50',
                'text-sky-800 dark:text-sky-200',
                'cursor-pointer',
            ].join(' ');
        }
        return [
            base,
            'bg-white dark:bg-slate-800',
            'text-slate-900 dark:text-slate-100',
            'border border-slate-200 dark:border-slate-700',
            'hover:bg-slate-50 dark:hover:bg-slate-700',
            'cursor-pointer',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
        ].join(' ');
    }
    getLabelClasses() {
        return [
            'block text-sm font-medium mb-2',
            'text-slate-700 dark:text-slate-300',
        ].join(' ');
    }
    getGridLabelClasses() {
        return [
            'text-xs font-medium mb-2',
            'text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    getHelperClasses() {
        return [
            'mt-2 text-xs',
            'text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    getErrorClasses() {
        return [
            'mt-2 text-xs',
            'text-red-600 dark:text-red-400',
        ].join(' ');
    }
    getViewModeClasses() {
        return [
            'text-sm',
            'text-slate-900 dark:text-slate-100',
        ].join(' ');
    }
    getLoadingClasses() {
        return [
            'flex items-center justify-center p-8',
            'text-slate-500 dark:text-slate-400',
        ].join(' ');
    }
    // ===========================================================================
    // RENDER METHODS
    // ===========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label class=${this.getLabelClasses()}>
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="text-red-500 dark:text-red-400 ml-1">*</span>` : html ``}
      </label>
    `;
    }
    renderGridLabel(slotName) {
        if (!this.hasSlot(slotName))
            return html ``;
        return html `
      <div class=${this.getGridLabelClasses()}>
        ${unsafeHTML(this.getSlotContent(slotName))}
      </div>
    `;
    }
    renderYearNav(year, onPrev, onNext) {
        return html `
      <div class=${this.getYearNavClasses()}>
        <button
          type="button"
          class=${this.getNavButtonClasses()}
          @click=${onPrev}
          ?disabled=${this.disabled || this.readonly}
          aria-label="Previous year"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
          </svg>
        </button>
        <span class=${this.getYearLabelClasses()}>${year}</span>
        <button
          type="button"
          class=${this.getNavButtonClasses()}
          @click=${onNext}
          ?disabled=${this.disabled || this.readonly}
          aria-label="Next year"
        >
          <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path>
          </svg>
        </button>
      </div>
    `;
    }
    renderMonthGrid(months, isEndGrid) {
        return html `
      <div class=${this.getMonthGridClasses()} role="grid">
        ${months.map(monthData => this.renderMonthButton(monthData, isEndGrid))}
      </div>
    `;
    }
    renderMonthButton(monthData, isEndGrid) {
        const handleClick = isEndGrid
            ? () => this.handleEndMonthSelect(monthData)
            : () => this.handleStartMonthSelect(monthData);
        const handleMouseEnter = isEndGrid
            ? () => this.handleEndMonthHover(monthData)
            : undefined;
        const handleMouseLeave = isEndGrid
            ? () => this.handleEndMonthLeave()
            : undefined;
        return html `
      <button
        type="button"
        class=${this.getMonthButtonClasses(monthData)}
        @click=${handleClick}
        @mouseenter=${handleMouseEnter}
        @mouseleave=${handleMouseLeave}
        ?disabled=${monthData.disabled || this.disabled || this.readonly}
        role="gridcell"
        aria-selected=${monthData.isStart || monthData.isEnd}
        aria-disabled=${monthData.disabled}
      >
        ${monthData.label}
      </button>
    `;
    }
    renderStartGrid() {
        const months = this.generateMonthData(this.startYear, false);
        return html `
      <div class=${this.getGridPanelClasses()}>
        ${this.renderGridLabel('LabelStart')}
        ${this.renderYearNav(this.startYear, () => this.handleStartYearPrev(), () => this.handleStartYearNext())}
        ${this.renderMonthGrid(months, false)}
      </div>
    `;
    }
    renderEndGrid() {
        const months = this.generateMonthData(this.endYear, true);
        return html `
      <div class=${this.getGridPanelClasses()}>
        ${this.renderGridLabel('LabelEnd')}
        ${this.renderYearNav(this.endYear, () => this.handleEndYearPrev(), () => this.handleEndYearNext())}
        ${this.renderMonthGrid(months, true)}
      </div>
    `;
    }
    renderFeedback() {
        if (this.error) {
            return html `
        <p class=${this.getErrorClasses()} role="alert">
          ${unsafeHTML(this.error)}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class=${this.getHelperClasses()}>
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
    renderViewMode() {
        const startDisplay = this.formatDisplayDate(this.startDate);
        const endDisplay = this.formatDisplayDate(this.endDate);
        let displayText;
        if (!this.startDate && !this.endDate) {
            displayText = this.msg.noSelection;
        }
        else if (this.startDate && !this.endDate) {
            displayText = `${startDisplay} ${this.msg.to} ${this.msg.noSelection}`;
        }
        else {
            displayText = `${startDisplay} ${this.msg.to} ${endDisplay}`;
        }
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()}
        <div class=${this.getViewModeClasses()}>
          ${displayText}
        </div>
      </div>
    `;
    }
    renderLoading() {
        return html `
      <div class=${this.getContainerClasses()}>
        ${this.renderLabel()}
        <div class=${this.getLoadingClasses()}>
          <svg class="animate-spin h-5 w-5 mr-2" fill="none" viewBox="0 0 24 24">
            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          ${this.msg.loading}
        </div>
      </div>
    `;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return html `
      <div
        class=${this.getContainerClasses()}
        @focusin=${this.handleFocus}
        @focusout=${this.handleBlur}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required ? 'true' : 'false'}
      >
        ${this.renderLabel()}
        <div class=${this.getGridContainerClasses()}>
          ${this.renderStartGrid()}
          ${this.renderEndGrid()}
        </div>
        ${this.renderFeedback()}
      </div>
    `;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'start-date' })
], MlMonthYearRangeMolecule.prototype, "startDate", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'end-date' })
], MlMonthYearRangeMolecule.prototype, "endDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlMonthYearRangeMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlMonthYearRangeMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlMonthYearRangeMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-date' })
], MlMonthYearRangeMolecule.prototype, "minDate", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-date' })
], MlMonthYearRangeMolecule.prototype, "maxDate", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-range-days' })
], MlMonthYearRangeMolecule.prototype, "minRangeDays", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-range-days' })
], MlMonthYearRangeMolecule.prototype, "maxRangeDays", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-day' })
], MlMonthYearRangeMolecule.prototype, "allowSameDay", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlMonthYearRangeMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMonthYearRangeMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMonthYearRangeMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMonthYearRangeMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlMonthYearRangeMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlMonthYearRangeMolecule.prototype, "startYear", void 0);
__decorate([
    state()
], MlMonthYearRangeMolecule.prototype, "endYear", void 0);
__decorate([
    state()
], MlMonthYearRangeMolecule.prototype, "selectingEnd", void 0);
__decorate([
    state()
], MlMonthYearRangeMolecule.prototype, "hoverMonth", void 0);
__decorate([
    state()
], MlMonthYearRangeMolecule.prototype, "isFocused", void 0);
MlMonthYearRangeMolecule = __decorate([
    customElement('groupenterdateinterval--ml-month-year-range')
], MlMonthYearRangeMolecule);
export { MlMonthYearRangeMolecule };
