/// <mls fileReference="_102040_/l2/molecules/groupenterdateinterval/ml-date-interval-presets.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// DATE INTERVAL PRESETS MOLECULE
// =============================================================================
// Skill Group: groupEnterDateInterval
// This molecule does NOT contain business logic.
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, svg } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    selectStartDate: 'Select start date',
    selectEndDate: 'Select end date',
    startDate: 'Start',
    endDate: 'End',
    noDateSelected: '—',
    to: '–',
    loading: 'Loading...',
    today: 'Today',
    clear: 'Clear',
    apply: 'Apply',
    cancel: 'Cancel',
    presets: 'Quick Select',
    customRange: 'Custom Range',
    monthNames: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    dayNamesShort: ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'],
};
const messages = {
    en: message_en,
    pt: {
        selectStartDate: 'Selecione a data inicial',
        selectEndDate: 'Selecione a data final',
        startDate: 'Início',
        endDate: 'Fim',
        noDateSelected: '—',
        to: '–',
        loading: 'Carregando...',
        today: 'Hoje',
        clear: 'Limpar',
        apply: 'Aplicar',
        cancel: 'Cancelar',
        presets: 'Seleção Rápida',
        customRange: 'Período Personalizado',
        monthNames: ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'],
        dayNamesShort: ['Do', 'Se', 'Te', 'Qu', 'Qu', 'Se', 'Sá'],
    },
};
let MlDateIntervalPresetsMolecule = class MlDateIntervalPresetsMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper', 'Preset'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.startDate = null;
        this.endDate = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.minDate = '';
        this.maxDate = '';
        this.minRangeDays = 0;
        this.maxRangeDays = 0;
        this.firstDayOfWeek = 0;
        this.allowSameDay = true;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ===========================================================================
        this.isOpen = false;
        this.selectingEnd = false;
        this.hoverDate = null;
        this.viewingMonth = new Date().getMonth();
        this.viewingYear = new Date().getFullYear();
        this.focusedField = null;
        this.parsedPresets = [];
        this.handleOutsideClick = (e) => {
            const target = e.target;
            if (!this.contains(target)) {
                this.isOpen = false;
                this.selectingEnd = false;
                this.hoverDate = null;
                this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            }
        };
    }
    // ===========================================================================
    // LIFECYCLE
    // ===========================================================================
    firstUpdated() {
        this.parsePresets();
        this.initializeViewingMonth();
    }
    updated(changedProperties) {
        if (changedProperties.has('startDate') || changedProperties.has('endDate')) {
            this.initializeViewingMonth();
        }
    }
    // ===========================================================================
    // PRESET PARSING
    // ===========================================================================
    parsePresets() {
        const presetElements = this.getSlots('Preset');
        this.parsedPresets = presetElements.map(el => {
            return {
                label: el.innerHTML.trim(),
                startDate: el.getAttribute('start-date') || '',
                endDate: el.getAttribute('end-date') || '',
            };
        }).filter(p => p.startDate && p.endDate);
    }
    initializeViewingMonth() {
        if (this.startDate) {
            const date = this.parseDate(this.startDate);
            if (date) {
                this.viewingMonth = date.getMonth();
                this.viewingYear = date.getFullYear();
            }
        }
        else {
            const now = new Date();
            this.viewingMonth = now.getMonth();
            this.viewingYear = now.getFullYear();
        }
    }
    // ===========================================================================
    // DATE UTILITIES
    // ===========================================================================
    parseDate(dateStr) {
        if (!dateStr)
            return null;
        const parts = dateStr.split('-');
        if (parts.length !== 3)
            return null;
        const year = parseInt(parts[0], 10);
        const month = parseInt(parts[1], 10) - 1;
        const day = parseInt(parts[2], 10);
        return new Date(year, month, day);
    }
    formatDateISO(date) {
        const year = date.getFullYear();
        const month = String(date.getMonth() + 1).padStart(2, '0');
        const day = String(date.getDate()).padStart(2, '0');
        return `${year}-${month}-${day}`;
    }
    formatDateDisplay(dateStr) {
        if (!dateStr)
            return this.msg.noDateSelected;
        const date = this.parseDate(dateStr);
        if (!date)
            return this.msg.noDateSelected;
        const effectiveLocale = this.locale || 'en-US';
        try {
            return date.toLocaleDateString(effectiveLocale, {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
            });
        }
        catch {
            return date.toLocaleDateString('en-US', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
            });
        }
    }
    formatRangeDisplay() {
        const start = this.formatDateDisplay(this.startDate);
        const end = this.formatDateDisplay(this.endDate);
        return `${start} ${this.msg.to} ${end}`;
    }
    getDaysBetween(start, end) {
        const diffTime = Math.abs(end.getTime() - start.getTime());
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    isDateDisabled(dateStr) {
        const date = this.parseDate(dateStr);
        if (!date)
            return true;
        if (this.minDate) {
            const min = this.parseDate(this.minDate);
            if (min && date < min)
                return true;
        }
        if (this.maxDate) {
            const max = this.parseDate(this.maxDate);
            if (max && date > max)
                return true;
        }
        if (this.selectingEnd && this.startDate) {
            const start = this.parseDate(this.startDate);
            if (start) {
                const days = this.getDaysBetween(start, date);
                if (!this.allowSameDay && days === 0)
                    return true;
                if (this.minRangeDays > 0 && days < this.minRangeDays)
                    return true;
                if (this.maxRangeDays > 0 && days > this.maxRangeDays)
                    return true;
            }
        }
        return false;
    }
    isDateInRange(dateStr) {
        if (!this.startDate)
            return false;
        const date = this.parseDate(dateStr);
        const start = this.parseDate(this.startDate);
        if (!date || !start)
            return false;
        const endDateStr = this.selectingEnd && this.hoverDate ? this.hoverDate : this.endDate;
        if (!endDateStr)
            return false;
        const end = this.parseDate(endDateStr);
        if (!end)
            return false;
        return date >= start && date <= end;
    }
    isRangeStart(dateStr) {
        return dateStr === this.startDate;
    }
    isRangeEnd(dateStr) {
        if (this.selectingEnd && this.hoverDate) {
            return dateStr === this.hoverDate;
        }
        return dateStr === this.endDate;
    }
    // ===========================================================================
    // CALENDAR GENERATION
    // ===========================================================================
    getCalendarDays() {
        const days = [];
        const firstDay = new Date(this.viewingYear, this.viewingMonth, 1);
        const lastDay = new Date(this.viewingYear, this.viewingMonth + 1, 0);
        let startDayOfWeek = firstDay.getDay() - this.firstDayOfWeek;
        if (startDayOfWeek < 0)
            startDayOfWeek += 7;
        // Previous month days
        const prevMonthLastDay = new Date(this.viewingYear, this.viewingMonth, 0);
        for (let i = startDayOfWeek - 1; i >= 0; i--) {
            const day = prevMonthLastDay.getDate() - i;
            const date = new Date(this.viewingYear, this.viewingMonth - 1, day);
            days.push({
                date: this.formatDateISO(date),
                day,
                isCurrentMonth: false,
            });
        }
        // Current month days
        for (let day = 1; day <= lastDay.getDate(); day++) {
            const date = new Date(this.viewingYear, this.viewingMonth, day);
            days.push({
                date: this.formatDateISO(date),
                day,
                isCurrentMonth: true,
            });
        }
        // Next month days
        const remainingDays = 42 - days.length;
        for (let day = 1; day <= remainingDays; day++) {
            const date = new Date(this.viewingYear, this.viewingMonth + 1, day);
            days.push({
                date: this.formatDateISO(date),
                day,
                isCurrentMonth: false,
            });
        }
        return days;
    }
    getOrderedDayNames() {
        const dayNames = [...this.msg.dayNamesShort];
        const reordered = [];
        for (let i = 0; i < 7; i++) {
            reordered.push(dayNames[(this.firstDayOfWeek + i) % 7]);
        }
        return reordered;
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ===========================================================================
    handleTriggerClick() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.isOpen = !this.isOpen;
        if (this.isOpen) {
            this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
        }
    }
    handleDateSelect(dateStr) {
        if (this.disabled || this.readonly || this.isDateDisabled(dateStr))
            return;
        if (!this.selectingEnd) {
            // Selecting start date
            this.startDate = dateStr;
            this.endDate = null;
            this.selectingEnd = true;
            this.dispatchEvent(new CustomEvent('startChange', {
                bubbles: true,
                composed: true,
                detail: { value: this.startDate },
            }));
        }
        else {
            // Selecting end date
            const start = this.parseDate(this.startDate);
            const end = this.parseDate(dateStr);
            if (start && end) {
                if (end < start) {
                    // Swap dates
                    this.endDate = this.startDate;
                    this.startDate = dateStr;
                }
                else {
                    this.endDate = dateStr;
                }
                this.selectingEnd = false;
                this.hoverDate = null;
                this.isOpen = false;
                this.dispatchEvent(new CustomEvent('endChange', {
                    bubbles: true,
                    composed: true,
                    detail: { value: this.endDate },
                }));
                this.dispatchEvent(new CustomEvent('change', {
                    bubbles: true,
                    composed: true,
                    detail: { startDate: this.startDate, endDate: this.endDate },
                }));
                this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
            }
        }
    }
    handleDateHover(dateStr) {
        if (this.selectingEnd && !this.isDateDisabled(dateStr)) {
            this.hoverDate = dateStr;
        }
    }
    handleDateHoverEnd() {
        this.hoverDate = null;
    }
    handlePresetSelect(preset) {
        if (this.disabled || this.readonly)
            return;
        this.startDate = preset.startDate;
        this.endDate = preset.endDate;
        this.selectingEnd = false;
        this.hoverDate = null;
        this.isOpen = false;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startDate },
        }));
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endDate },
        }));
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { startDate: this.startDate, endDate: this.endDate },
        }));
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    handlePrevMonth() {
        if (this.viewingMonth === 0) {
            this.viewingMonth = 11;
            this.viewingYear--;
        }
        else {
            this.viewingMonth--;
        }
    }
    handleNextMonth() {
        if (this.viewingMonth === 11) {
            this.viewingMonth = 0;
            this.viewingYear++;
        }
        else {
            this.viewingMonth++;
        }
    }
    connectedCallback() {
        super.connectedCallback();
        document.addEventListener('click', this.handleOutsideClick);
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        document.removeEventListener('click', this.handleOutsideClick);
    }
    isPresetActive(preset) {
        return this.startDate === preset.startDate && this.endDate === preset.endDate;
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    getTriggerClasses() {
        return [
            'w-full flex items-center justify-between gap-2 px-3 py-2 rounded-lg border text-sm transition',
            'bg-white dark:bg-slate-900',
            'text-slate-900 dark:text-slate-100',
            this.error
                ? 'border-red-500 dark:border-red-400'
                : 'border-slate-200 dark:border-slate-700',
            !this.disabled && !this.readonly
                ? 'hover:border-slate-300 dark:hover:border-slate-600 cursor-pointer'
                : '',
            this.disabled ? 'opacity-50 cursor-not-allowed' : '',
            this.readonly ? 'cursor-default' : '',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
        ].filter(Boolean).join(' ');
    }
    getPresetClasses(isActive) {
        return [
            'w-full px-3 py-2 text-sm rounded-md text-left transition',
            isActive
                ? 'bg-sky-50 dark:bg-sky-900/40 text-sky-700 dark:text-sky-300 border border-sky-500 dark:border-sky-400'
                : 'bg-white dark:bg-slate-800 text-slate-900 dark:text-slate-100 border border-slate-200 dark:border-slate-700',
            !isActive ? 'hover:bg-slate-50 dark:hover:bg-slate-700' : '',
            'focus:outline-none focus:ring-2 focus:ring-sky-500 dark:focus:ring-sky-400',
        ].filter(Boolean).join(' ');
    }
    getDayClasses(day) {
        const isDisabled = this.isDateDisabled(day.date);
        const isInRange = this.isDateInRange(day.date);
        const isStart = this.isRangeStart(day.date);
        const isEnd = this.isRangeEnd(day.date);
        const isToday = day.date === this.formatDateISO(new Date());
        return [
            'w-8 h-8 flex items-center justify-center text-sm rounded-md transition',
            !day.isCurrentMonth ? 'text-slate-400 dark:text-slate-600' : '',
            day.isCurrentMonth && !isDisabled && !isInRange && !isStart && !isEnd
                ? 'text-slate-900 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700'
                : '',
            isInRange && !isStart && !isEnd
                ? 'bg-sky-100 dark:bg-sky-900/30 text-sky-900 dark:text-sky-100'
                : '',
            isStart || isEnd
                ? 'bg-sky-500 dark:bg-sky-600 text-white'
                : '',
            isToday && !isStart && !isEnd && !isInRange
                ? 'ring-1 ring-sky-500 dark:ring-sky-400'
                : '',
            isDisabled ? 'opacity-30 cursor-not-allowed' : 'cursor-pointer',
        ].filter(Boolean).join(' ');
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoading();
        }
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        return this.renderEditMode();
    }
    renderLoading() {
        return html `
      <div class="flex items-center gap-2 px-3 py-2 text-sm text-slate-500 dark:text-slate-400">
        ${this.renderSpinner()}
        <span>${this.msg.loading}</span>
      </div>
    `;
    }
    renderSpinner() {
        return html `
      <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
        ${svg `
          <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
          <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        `}
      </svg>
    `;
    }
    renderViewMode() {
        return html `
      <div class="text-sm text-slate-900 dark:text-slate-100">
        ${this.formatRangeDisplay()}
      </div>
    `;
    }
    renderEditMode() {
        return html `
      <div class="relative w-full">
        ${this.renderLabel()}
        ${this.renderTrigger()}
        ${this.isOpen ? this.renderDropdown() : html ``}
        ${this.renderFeedback()}
      </div>
    `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
      <label class="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">
        ${unsafeHTML(this.getSlotContent('Label'))}
        ${this.required ? html `<span class="text-red-500 dark:text-red-400">*</span>` : html ``}
      </label>
    `;
    }
    renderTrigger() {
        return html `
      <button
        type="button"
        class=${this.getTriggerClasses()}
        ?disabled=${this.disabled}
        aria-haspopup="dialog"
        aria-expanded=${this.isOpen}
        aria-invalid=${this.error ? 'true' : 'false'}
        aria-required=${this.required}
        @click=${this.handleTriggerClick}
      >
        <div class="flex items-center gap-2 flex-1 min-w-0">
          ${this.renderCalendarIcon()}
          <div class="flex items-center gap-1 truncate">
            <span class=${this.startDate ? 'text-slate-900 dark:text-slate-100' : 'text-slate-400 dark:text-slate-500'}>
              ${this.formatDateDisplay(this.startDate)}
            </span>
            <span class="text-slate-400 dark:text-slate-500">${this.msg.to}</span>
            <span class=${this.endDate ? 'text-slate-900 dark:text-slate-100' : 'text-slate-400 dark:text-slate-500'}>
              ${this.formatDateDisplay(this.endDate)}
            </span>
          </div>
        </div>
        ${this.renderChevronIcon()}
      </button>
    `;
    }
    renderCalendarIcon() {
        return html `
      <svg class="w-4 h-4 text-slate-400 dark:text-slate-500 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
        ${svg `
          <path fill-rule="evenodd" d="M6 2a1 1 0 00-1 1v1H4a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V6a2 2 0 00-2-2h-1V3a1 1 0 10-2 0v1H7V3a1 1 0 00-1-1zm0 5a1 1 0 000 2h8a1 1 0 100-2H6z" clip-rule="evenodd"/>
        `}
      </svg>
    `;
    }
    renderChevronIcon() {
        return html `
      <svg class="w-4 h-4 text-slate-400 dark:text-slate-500 flex-shrink-0 transition-transform ${this.isOpen ? 'rotate-180' : ''}" viewBox="0 0 20 20" fill="currentColor">
        ${svg `
          <path fill-rule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clip-rule="evenodd"/>
        `}
      </svg>
    `;
    }
    renderDropdown() {
        return html `
      <div
        class="absolute z-50 mt-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg shadow-lg p-4 min-w-[320px]"
        role="dialog"
        aria-modal="true"
      >
        <div class="flex gap-4">
          ${this.parsedPresets.length > 0 ? this.renderPresets() : html ``}
          <div class="flex-1">
            ${this.renderCalendar()}
          </div>
        </div>
      </div>
    `;
    }
    renderPresets() {
        return html `
      <div class="w-40 border-r border-slate-200 dark:border-slate-700 pr-4">
        <div class="text-xs font-medium text-slate-500 dark:text-slate-400 uppercase tracking-wide mb-2">
          ${this.msg.presets}
        </div>
        <div class="flex flex-col gap-1">
          ${this.parsedPresets.map(preset => html `
            <button
              type="button"
              class=${this.getPresetClasses(this.isPresetActive(preset))}
              @click=${() => this.handlePresetSelect(preset)}
            >
              ${unsafeHTML(preset.label)}
            </button>
          `)}
        </div>
      </div>
    `;
    }
    renderCalendar() {
        const days = this.getCalendarDays();
        const dayNames = this.getOrderedDayNames();
        return html `
      <div>
        ${this.renderCalendarHeader()}
        <div class="grid grid-cols-7 gap-1 mb-2">
          ${dayNames.map(name => html `
            <div class="w-8 h-6 flex items-center justify-center text-xs font-medium text-slate-500 dark:text-slate-400">
              ${name}
            </div>
          `)}
        </div>
        <div class="grid grid-cols-7 gap-1">
          ${days.map(day => html `
            <button
              type="button"
              class=${this.getDayClasses(day)}
              ?disabled=${this.isDateDisabled(day.date)}
              role="gridcell"
              aria-selected=${this.isRangeStart(day.date) || this.isRangeEnd(day.date)}
              aria-disabled=${this.isDateDisabled(day.date)}
              @click=${() => this.handleDateSelect(day.date)}
              @mouseenter=${() => this.handleDateHover(day.date)}
              @mouseleave=${this.handleDateHoverEnd}
            >
              ${day.day}
            </button>
          `)}
        </div>
        ${this.renderSelectionHint()}
      </div>
    `;
    }
    renderCalendarHeader() {
        return html `
      <div class="flex items-center justify-between mb-4">
        <button
          type="button"
          class="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400"
          @click=${this.handlePrevMonth}
        >
          <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
            ${svg `<path fill-rule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clip-rule="evenodd"/>`}
          </svg>
        </button>
        <span class="text-sm font-medium text-slate-900 dark:text-slate-100">
          ${this.msg.monthNames[this.viewingMonth]} ${this.viewingYear}
        </span>
        <button
          type="button"
          class="p-1 rounded hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400"
          @click=${this.handleNextMonth}
        >
          <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
            ${svg `<path fill-rule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clip-rule="evenodd"/>`}
          </svg>
        </button>
      </div>
    `;
    }
    renderSelectionHint() {
        const hintText = this.selectingEnd ? this.msg.selectEndDate : this.msg.selectStartDate;
        return html `
      <div class="mt-3 pt-3 border-t border-slate-200 dark:border-slate-700">
        <p class="text-xs text-slate-500 dark:text-slate-400 text-center">
          ${hintText}
        </p>
      </div>
    `;
    }
    renderFeedback() {
        if (this.error) {
            return html `
        <p class="mt-1 text-xs text-red-600 dark:text-red-400" role="alert">
          ${unsafeHTML(String(this.error))}
        </p>
      `;
        }
        if (this.hasSlot('Helper')) {
            return html `
        <p class="mt-1 text-xs text-slate-500 dark:text-slate-400">
          ${unsafeHTML(this.getSlotContent('Helper'))}
        </p>
      `;
        }
        return html ``;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'start-date' })
], MlDateIntervalPresetsMolecule.prototype, "startDate", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'end-date' })
], MlDateIntervalPresetsMolecule.prototype, "endDate", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDateIntervalPresetsMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDateIntervalPresetsMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], MlDateIntervalPresetsMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-date' })
], MlDateIntervalPresetsMolecule.prototype, "minDate", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-date' })
], MlDateIntervalPresetsMolecule.prototype, "maxDate", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-range-days' })
], MlDateIntervalPresetsMolecule.prototype, "minRangeDays", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-range-days' })
], MlDateIntervalPresetsMolecule.prototype, "maxRangeDays", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'first-day-of-week' })
], MlDateIntervalPresetsMolecule.prototype, "firstDayOfWeek", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-day' })
], MlDateIntervalPresetsMolecule.prototype, "allowSameDay", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], MlDateIntervalPresetsMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDateIntervalPresetsMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDateIntervalPresetsMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDateIntervalPresetsMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], MlDateIntervalPresetsMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlDateIntervalPresetsMolecule.prototype, "isOpen", void 0);
__decorate([
    state()
], MlDateIntervalPresetsMolecule.prototype, "selectingEnd", void 0);
__decorate([
    state()
], MlDateIntervalPresetsMolecule.prototype, "hoverDate", void 0);
__decorate([
    state()
], MlDateIntervalPresetsMolecule.prototype, "viewingMonth", void 0);
__decorate([
    state()
], MlDateIntervalPresetsMolecule.prototype, "viewingYear", void 0);
__decorate([
    state()
], MlDateIntervalPresetsMolecule.prototype, "focusedField", void 0);
__decorate([
    state()
], MlDateIntervalPresetsMolecule.prototype, "parsedPresets", void 0);
MlDateIntervalPresetsMolecule = __decorate([
    customElement('groupenterdateinterval--ml-date-interval-presets')
], MlDateIntervalPresetsMolecule);
export { MlDateIntervalPresetsMolecule };
