/// <mls fileReference="_102040_/l2/molecules/groupenterdatetimeinterval/ml-datetime-interval-timeline.ts" enhancement="_102020_/l2/enhancementAura"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// DATETIME INTERVAL TIMELINE MOLECULE
// =============================================================================
// Skill Group: enter + datetime-interval
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    labelStart: 'Start',
    labelEnd: 'End',
    placeholder: 'Select date and time',
    loading: 'Loading...',
    rangeSeparator: '–',
    empty: '—',
};
const messages = {
    en: message_en,
    pt: {
        labelStart: 'Início',
        labelEnd: 'Fim',
        placeholder: 'Selecione data e hora',
        loading: 'Carregando...',
        rangeSeparator: '–',
        empty: '—',
    },
};
/// **collab_i18n_end**
let DatetimeIntervalTimelineMolecule = class DatetimeIntervalTimelineMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-label {
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  font-weight: var(--font-weight-bold, 500);
  color: var(--text-strong, #1c1b1f);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-helper {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-error-text {
  color: var(--status-error-text, #ef4444);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-text {
  color: var(--text-strong, #1c1b1f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-text-muted {
  color: var(--text-muted, #49454f);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-interval-container {
  background-color: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
  transition: border-color var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-interval-container-readonly {
  background-color: var(--surface-alt-bg, #f5f5f5);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-input {
  background-color: var(--surface-bg, #ffffff);
  color: var(--text-strong, #1c1b1f);
  border-color: var(--border-default, #e2e8f0);
  font-family: var(--font-family-primary, system-ui, -apple-system, sans-serif);
  transition: border-color var(--transition-fast, 200ms ease), box-shadow var(--transition-fast, 200ms ease);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-input-focus:focus,
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-input-focus:focus-within {
  outline: none;
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-input-active {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--focus-ring, rgba(59, 130, 246, 0.4));
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-timeline-track {
  background-color: var(--surface-alt-bg, #f5f5f5);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-timeline-progress {
  background-color: var(--button-primary-bg, #3b82f6);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-timeline-marker {
  background-color: var(--surface-bg, #ffffff);
  border-color: var(--border-default, #e2e8f0);
}
groupenterdatetimeinterval--ml-datetime-interval-timeline .ml-timeline-marker-active {
  background-color: var(--button-primary-bg, #3b82f6);
  border-color: var(--selected-border, #3b82f6);
}
`);
        this.msg = messages.en;
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.startDatetime = null;
        this.endDatetime = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.timezone = '';
        this.minDatetime = '';
        this.maxDatetime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.minuteStep = 1;
        this.allowSameInstant = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // =========================================================================
        // INTERNAL STATE
        // =========================================================================
        this.activeField = null;
        this.uid = `dtint-${Math.random().toString(36).slice(2, 9)}`;
    }
    // =========================================================================
    // EVENT HANDLERS
    // =========================================================================
    onStartFocus() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.activeField = 'start';
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    onEndFocus() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.activeField = 'end';
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    onFieldBlur() {
        this.activeField = null;
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    onStartInput(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        const value = this.fromInputValue(input.value);
        if (!this.isWithinMinMax(value))
            return;
        this.startDatetime = value;
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startDatetime },
        }));
        if (this.startDatetime && this.endDatetime && this.isValidRange(this.startDatetime, this.endDatetime)) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { startDatetime: this.startDatetime, endDatetime: this.endDatetime },
            }));
        }
    }
    onEndInput(e) {
        e.stopPropagation();
        if (this.disabled || this.readonly || this.loading)
            return;
        const input = e.target;
        const value = this.fromInputValue(input.value);
        if (!this.isWithinMinMax(value))
            return;
        if (this.startDatetime && value && !this.isValidRange(this.startDatetime, value))
            return;
        this.endDatetime = value;
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endDatetime },
        }));
        if (this.startDatetime && this.endDatetime) {
            this.dispatchEvent(new CustomEvent('change', {
                bubbles: true,
                composed: true,
                detail: { startDatetime: this.startDatetime, endDatetime: this.endDatetime },
            }));
        }
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    toInputValue(value) {
        if (!value)
            return '';
        return value.length >= 16 ? value.slice(0, 16) : value;
    }
    fromInputValue(value) {
        if (!value)
            return null;
        return value.length === 16 ? `${value}:00` : value;
    }
    toDate(value) {
        if (!value)
            return null;
        const d = new Date(value);
        return isNaN(d.getTime()) ? null : d;
    }
    isWithinMinMax(value) {
        if (!value)
            return true;
        const date = this.toDate(value);
        if (!date)
            return false;
        const min = this.toDate(this.minDatetime || null);
        const max = this.toDate(this.maxDatetime || null);
        if (min && date < min)
            return false;
        if (max && date > max)
            return false;
        return true;
    }
    isValidRange(start, end) {
        const s = this.toDate(start);
        const e = this.toDate(end);
        if (!s || !e)
            return false;
        const diff = e.getTime() - s.getTime();
        if (diff < 0)
            return false;
        if (!this.allowSameInstant && diff === 0)
            return false;
        const minutes = diff / 60000;
        if (this.minDurationMinutes && minutes < this.minDurationMinutes)
            return false;
        if (this.maxDurationMinutes && minutes > this.maxDurationMinutes)
            return false;
        return true;
    }
    formatDateTime(value) {
        if (!value)
            return this.msg.empty;
        const date = this.toDate(value);
        if (!date)
            return this.msg.empty;
        const formatter = new Intl.DateTimeFormat(this.locale || undefined, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hour12: this.locale === 'en-US',
            timeZone: this.timezone || undefined,
        });
        return formatter.format(date);
    }
    formatRange() {
        const start = this.toDate(this.startDatetime);
        const end = this.toDate(this.endDatetime);
        if (!start && !end)
            return this.msg.empty;
        if (start && !end)
            return `${this.formatDateTime(this.startDatetime)} ${this.msg.rangeSeparator} ${this.msg.empty}`;
        if (!start && end)
            return `${this.msg.empty} ${this.msg.rangeSeparator} ${this.formatDateTime(this.endDatetime)}`;
        if (!start || !end)
            return this.msg.empty;
        const sameDay = start.toDateString() === end.toDateString();
        if (sameDay) {
            const dateFormatter = new Intl.DateTimeFormat(this.locale || undefined, {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                timeZone: this.timezone || undefined,
            });
            const timeFormatter = new Intl.DateTimeFormat(this.locale || undefined, {
                hour: '2-digit',
                minute: '2-digit',
                hour12: this.locale === 'en-US',
                timeZone: this.timezone || undefined,
            });
            return `${dateFormatter.format(start)} ${timeFormatter.format(start)} ${this.msg.rangeSeparator} ${timeFormatter.format(end)}`;
        }
        return `${this.formatDateTime(this.startDatetime)} ${this.msg.rangeSeparator} ${this.formatDateTime(this.endDatetime)}`;
    }
    getContainerClasses() {
        return cn('w-full rounded-lg border p-4 transition', 'ml-interval-container', this.error ? 'ml-input-container-error' : '', this.disabled ? 'ml-disabled' : '', this.readonly ? 'ml-interval-container-readonly' : '');
    }
    getInputClasses(active) {
        return cn('w-full rounded-md px-3 py-2 text-sm border transition', 'ml-input', active ? 'ml-input-active' : '', this.error ? 'ml-input-container-error' : '', this.disabled ? 'ml-disabled' : '', 'ml-input-focus');
    }
    getMarkerClasses(active) {
        return cn('h-4 w-4 rounded-full border-2 absolute -top-1 transition', active ? 'ml-timeline-marker-active' : 'ml-timeline-marker', this.disabled ? 'cursor-not-allowed' : 'cursor-pointer');
    }
    getTimelineProgressClasses() {
        return cn('h-2 rounded-full absolute top-0 left-0 transition', 'ml-timeline-progress');
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `<div class="${cn('mb-2 text-sm ml-label', this.getSlotClass('Label'))}">${unsafeHTML(this.getSlotContent('Label'))}</div>`;
    }
    renderHelperOrError() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `<p id="${this.uid}-error" class="mt-2 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>`;
        }
        if (this.hasSlot('Helper')) {
            return html `<p id="${this.uid}-helper" class="${cn('mt-2 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>`;
        }
        return html ``;
    }
    renderViewMode() {
        return html `
<div class="${cn(this.getContainerClasses(), this.cssClass)}">
${this.renderLabel()}
<div class="text-sm ml-text">${this.formatRange()}</div>
</div>
`;
    }
    renderTimeline() {
        const start = this.toDate(this.startDatetime);
        const end = this.toDate(this.endDatetime);
        const min = this.toDate(this.minDatetime || this.startDatetime || null) || start || new Date();
        const max = this.toDate(this.maxDatetime || this.endDatetime || null) || end || new Date(min.getTime() + 3600000);
        const range = Math.max(1, max.getTime() - min.getTime());
        const startPct = start ? Math.max(0, Math.min(100, ((start.getTime() - min.getTime()) / range) * 100)) : 0;
        const endPct = end ? Math.max(0, Math.min(100, ((end.getTime() - min.getTime()) / range) * 100)) : 0;
        const progressLeft = Math.min(startPct, endPct);
        const progressWidth = Math.abs(endPct - startPct);
        return html `
<div class="relative mt-4">
<div class="h-2 rounded-full ml-timeline-track relative">
<div class="${this.getTimelineProgressClasses()}" style="left: ${progressLeft}%; width: ${progressWidth}%;"></div>
<div
class="${this.getMarkerClasses(this.activeField === 'start')}"
style="left: ${startPct}%;"
role="button"
aria-label="${this.msg.labelStart}"
@click=${() => this.onStartFocus()}
></div>
<div
class="${this.getMarkerClasses(this.activeField === 'end')}"
style="left: ${endPct}%;"
role="button"
aria-label="${this.msg.labelEnd}"
@click=${() => this.onEndFocus()}
></div>
</div>
</div>
`;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return this.renderViewMode();
        }
        const labelStart = this.hasSlot('LabelStart') ? this.getSlotContent('LabelStart') : this.msg.labelStart;
        const labelEnd = this.hasSlot('LabelEnd') ? this.getSlotContent('LabelEnd') : this.msg.labelEnd;
        const describedBy = this.error ? `${this.uid}-error` : this.hasSlot('Helper') ? `${this.uid}-helper` : '';
        return html `
<div class="${cn(this.getContainerClasses(), this.cssClass)}">
${this.renderLabel()}
<div class="grid grid-cols-1 gap-3 md:grid-cols-2">
<div>
<label id="${this.uid}-label-start" class="${cn('mb-1 block text-xs ml-text-muted', this.getSlotClass('LabelStart'))}">${unsafeHTML(labelStart)}</label>
<input
class="${this.getInputClasses(this.activeField === 'start')}"
type="datetime-local"
name="${this.name ? `${this.name}_start` : ''}"
.value=${this.toInputValue(this.startDatetime)}
step=${String(Math.max(1, this.minuteStep) * 60)}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
placeholder="${this.msg.placeholder}"
aria-labelledby="${this.uid}-label-start"
aria-describedby="${describedBy}"
aria-invalid="${this.error ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
@focus=${this.onStartFocus}
@blur=${this.onFieldBlur}
@change=${this.onStartInput}

@input="${(e) => e.stopPropagation()}"
/>
</div>
<div>
<label id="${this.uid}-label-end" class="${cn('mb-1 block text-xs ml-text-muted', this.getSlotClass('LabelEnd'))}">${unsafeHTML(labelEnd)}</label>
<input
class="${this.getInputClasses(this.activeField === 'end')}"
type="datetime-local"
name="${this.name ? `${this.name}_end` : ''}"
.value=${this.toInputValue(this.endDatetime)}
step=${String(Math.max(1, this.minuteStep) * 60)}
?disabled=${this.disabled || this.loading}
?readonly=${this.readonly}
placeholder="${this.msg.placeholder}"
aria-labelledby="${this.uid}-label-end"
aria-describedby="${describedBy}"
aria-invalid="${this.error ? 'true' : 'false'}"
aria-required="${this.required ? 'true' : 'false'}"
@focus=${this.onEndFocus}
@blur=${this.onFieldBlur}
@change=${this.onEndInput}

@input="${(e) => e.stopPropagation()}"
/>
</div>
</div>
${this.loading ? html `<div class="mt-3 text-xs ml-text-muted">${this.msg.loading}</div>` : html ``}
${this.renderTimeline()}
${this.renderHelperOrError()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String })
], DatetimeIntervalTimelineMolecule.prototype, "startDatetime", void 0);
__decorate([
    propertyDataSource({ type: String })
], DatetimeIntervalTimelineMolecule.prototype, "endDatetime", void 0);
__decorate([
    propertyDataSource({ type: String })
], DatetimeIntervalTimelineMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], DatetimeIntervalTimelineMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], DatetimeIntervalTimelineMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], DatetimeIntervalTimelineMolecule.prototype, "timezone", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-datetime' })
], DatetimeIntervalTimelineMolecule.prototype, "minDatetime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-datetime' })
], DatetimeIntervalTimelineMolecule.prototype, "maxDatetime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], DatetimeIntervalTimelineMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], DatetimeIntervalTimelineMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], DatetimeIntervalTimelineMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-instant' })
], DatetimeIntervalTimelineMolecule.prototype, "allowSameInstant", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], DatetimeIntervalTimelineMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DatetimeIntervalTimelineMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DatetimeIntervalTimelineMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DatetimeIntervalTimelineMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], DatetimeIntervalTimelineMolecule.prototype, "loading", void 0);
__decorate([
    state()
], DatetimeIntervalTimelineMolecule.prototype, "activeField", void 0);
DatetimeIntervalTimelineMolecule = __decorate([
    customElement('groupenterdatetimeinterval--ml-datetime-interval-timeline')
], DatetimeIntervalTimelineMolecule);
export { DatetimeIntervalTimelineMolecule };
