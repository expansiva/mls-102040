var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupenterdatetimeinterval/ml-enter-datetime-interval.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ENTER DATETIME INTERVAL MOLECULE
// =============================================================================
// Skill Group: enter + datetime-interval
// This molecule does NOT contain business logic.
import { html, nothing } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement, state } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/shared/molecules/cn.js';
/// **collab_i18n_start**
const message_en = {
    labelStart: 'Start',
    labelEnd: 'End',
    placeholderStart: 'Select start datetime',
    placeholderEnd: 'Select end datetime',
    rangeEmpty: '—',
    confirm: 'Confirm',
    clear: 'Clear',
    loading: 'Loading...',
};
const messages = {
    en: message_en,
    pt: {
        labelStart: 'Início',
        labelEnd: 'Fim',
        placeholderStart: 'Selecione início',
        placeholderEnd: 'Selecione fim',
        rangeEmpty: '—',
        confirm: 'Confirmar',
        clear: 'Limpar',
        loading: 'Carregando...',
    },
};
/// **collab_i18n_end**
let EnterDatetimeIntervalMolecule = class EnterDatetimeIntervalMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupenterdatetimeinterval--ml-enter-datetime-interval .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-input {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface, #1c1b1f);
  border-color: var(--ml-outline-variant, #e2e8f0);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  transition: border-color var(--ml-transition, 200ms ease), box-shadow var(--ml-transition, 200ms ease);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-input-focus:focus,
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-input-focus:focus-within {
  outline: none;
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-input-active {
  border-color: var(--ml-outline-focus, #3b82f6);
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-input-container-error {
  border-color: var(--ml-outline-error, #ef4444) !important;
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-interval-picker {
  background-color: var(--ml-surface, #ffffff);
  border-color: var(--ml-outline-variant, #e2e8f0);
  box-shadow: var(--ml-shadow-1, 0 1px 3px rgba(0, 0, 0, 0.1));
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-interval-btn-primary {
  background-color: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
  border-color: var(--ml-primary, #3b82f6);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-interval-btn-primary:hover {
  filter: brightness(0.9);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-interval-btn-primary:disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-interval-btn-secondary {
  background-color: var(--ml-surface, #ffffff);
  color: var(--ml-on-surface-muted, #49454f);
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupenterdatetimeinterval--ml-enter-datetime-interval .ml-interval-btn-secondary:hover {
  background-color: var(--ml-surface-dim, #f5f5f5);
}
`);
        this.msg = messages.en;
        // ===========================================================================
        // SLOT TAGS
        // ==========================================================================='
        this.slotTags = ['Label', 'LabelStart', 'LabelEnd', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================='
        this.startDatetime = null;
        this.endDatetime = null;
        this.error = '';
        this.name = '';
        this.locale = '';
        this.timezone = '';
        this.minDatetime = '';
        this.maxDatetime = '';
        this.minDurationMinutes = 0;
        this.maxDurationMinutes = 0;
        this.minuteStep = 1;
        this.allowSameInstant = false;
        this.isEditing = true;
        this.disabled = false;
        this.readonly = false;
        this.required = false;
        this.loading = false;
        // ===========================================================================
        // INTERNAL STATE
        // ==========================================================================='
        this.activeField = null;
        this.startDraft = '';
        this.endDraft = '';
        this.uid = `edt-${Math.random().toString(36).slice(2, 9)}`;
    }
    // ===========================================================================
    // STATE CHANGE HANDLER — derived values (drafts)
    // ==========================================================================='
    handleIcaStateChange(key, value) {
        const startAttr = this.getAttribute('start-datetime');
        const endAttr = this.getAttribute('end-datetime');
        if (startAttr === `{{${key}}}`) {
            this.startDraft = this.toInputValueFromIso(value);
        }
        if (endAttr === `{{${key}}}`) {
            this.endDraft = this.toInputValueFromIso(value);
        }
        this.requestUpdate();
    }
    // ===========================================================================
    // EVENT DISPATCHERS
    // ==========================================================================='
    dispatchFocus() {
        this.dispatchEvent(new CustomEvent('focus', { bubbles: true, composed: true }));
    }
    dispatchBlur() {
        this.dispatchEvent(new CustomEvent('blur', { bubbles: true, composed: true }));
    }
    dispatchStartChange() {
        this.dispatchEvent(new CustomEvent('startChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.startDatetime },
        }));
    }
    dispatchEndChange() {
        this.dispatchEvent(new CustomEvent('endChange', {
            bubbles: true,
            composed: true,
            detail: { value: this.endDatetime },
        }));
    }
    dispatchChange() {
        this.dispatchEvent(new CustomEvent('change', {
            bubbles: true,
            composed: true,
            detail: { startDatetime: this.startDatetime, endDatetime: this.endDatetime },
        }));
    }
    // ===========================================================================
    // EVENT HANDLERS
    // ==========================================================================='
    handleOpenField(field) {
        if (this.disabled || this.readonly || this.loading)
            return;
        const nextField = this.activeField === field ? null : field;
        this.setActiveField(nextField);
        if (nextField === 'start') {
            this.startDraft = this.toInputValueFromIso(this.startDatetime);
        }
        if (nextField === 'end') {
            this.endDraft = this.toInputValueFromIso(this.endDatetime);
        }
    }
    setActiveField(field) {
        const previous = this.activeField;
        this.activeField = field;
        if (previous === null && field !== null)
            this.dispatchFocus();
        if (previous !== null && field === null)
            this.dispatchBlur();
    }
    handleStartDraftInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.startDraft = input.value;
    }
    handleEndDraftInput(e) {
        e.stopPropagation();
        const input = e.target;
        this.endDraft = input.value;
    }
    handleConfirmStart() {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (!this.isStartDraftValid())
            return;
        this.startDatetime = this.toIsoFromInput(this.startDraft);
        this.dispatchStartChange();
        if (!this.endDatetime) {
            this.setActiveField('end');
            this.endDraft = this.toInputValueFromIso(this.endDatetime);
        }
        else {
            this.setActiveField(null);
        }
    }
    handleConfirmEnd() {
        if (this.disabled || this.readonly || this.loading)
            return;
        if (!this.isEndDraftValid())
            return;
        this.endDatetime = this.toIsoFromInput(this.endDraft);
        this.dispatchEndChange();
        this.dispatchChange();
        this.setActiveField(null);
    }
    handleClearStart() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.startDraft = '';
        this.startDatetime = null;
        this.dispatchStartChange();
        this.setActiveField(null);
    }
    handleClearEnd() {
        if (this.disabled || this.readonly || this.loading)
            return;
        this.endDraft = '';
        this.endDatetime = null;
        this.dispatchEndChange();
        this.dispatchChange();
        this.setActiveField(null);
    }
    // ===========================================================================
    // VALIDATION HELPERS (UI-level constraints)
    // ==========================================================================='
    isStartDraftValid() {
        if (!this.startDraft)
            return false;
        const iso = this.toIsoFromInput(this.startDraft);
        if (!iso)
            return false;
        const min = this.minDatetime || null;
        const max = this.maxDatetime || null;
        return this.isWithinRange(iso, min, max);
    }
    isEndDraftValid() {
        if (!this.endDraft)
            return false;
        const iso = this.toIsoFromInput(this.endDraft);
        if (!iso)
            return false;
        const min = this.getMinEndIso();
        const max = this.getMaxEndIso();
        return this.isWithinRange(iso, min, max);
    }
    isWithinRange(value, min, max) {
        const valueTime = this.parseIsoToTime(value);
        if (valueTime === null)
            return false;
        if (min) {
            const minTime = this.parseIsoToTime(min);
            if (minTime !== null && valueTime < minTime)
                return false;
        }
        if (max) {
            const maxTime = this.parseIsoToTime(max);
            if (maxTime !== null && valueTime > maxTime)
                return false;
        }
        return true;
    }
    getMinEndIso() {
        let minCandidate = null;
        if (this.startDatetime) {
            const baseMin = this.minDurationMinutes > 0
                ? this.minDurationMinutes
                : this.allowSameInstant
                    ? 0
                    : Math.max(this.minuteStep, 1);
            minCandidate = this.addMinutes(this.startDatetime, baseMin);
        }
        if (this.minDatetime) {
            minCandidate = this.maxIso(minCandidate, this.minDatetime);
        }
        return minCandidate;
    }
    getMaxEndIso() {
        let maxCandidate = null;
        if (this.startDatetime && this.maxDurationMinutes > 0) {
            maxCandidate = this.addMinutes(this.startDatetime, this.maxDurationMinutes);
        }
        if (this.maxDatetime) {
            maxCandidate = this.minIso(maxCandidate, this.maxDatetime);
        }
        return maxCandidate;
    }
    // ===========================================================================
    // FORMATTERS
    // ==========================================================================='
    getDisplayRange() {
        if (!this.startDatetime && !this.endDatetime)
            return this.msg.rangeEmpty;
        if (this.startDatetime && !this.endDatetime) {
            return `${this.formatDateTime(this.startDatetime)} – ${this.msg.rangeEmpty}`;
        }
        if (!this.startDatetime && this.endDatetime) {
            return `${this.msg.rangeEmpty} – ${this.formatDateTime(this.endDatetime)}`;
        }
        const start = this.startDatetime;
        const end = this.endDatetime;
        const sameDay = this.getDateKey(start) === this.getDateKey(end);
        if (sameDay) {
            return `${this.formatDate(start)} ${this.formatTime(start)} – ${this.formatTime(end)}`;
        }
        return `${this.formatDateTime(start)} – ${this.formatDateTime(end)}`;
    }
    formatDateTime(iso) {
        const date = this.parseIso(iso);
        if (!date)
            return this.msg.rangeEmpty;
        const locale = this.locale || 'en-US';
        const timeZone = this.timezone || undefined;
        const formatter = new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            hour12: locale === 'en-US',
            timeZone,
        });
        return formatter.format(date);
    }
    formatDate(iso) {
        const date = this.parseIso(iso);
        if (!date)
            return this.msg.rangeEmpty;
        const locale = this.locale || 'en-US';
        const timeZone = this.timezone || undefined;
        const formatter = new Intl.DateTimeFormat(locale, {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            timeZone,
        });
        return formatter.format(date);
    }
    formatTime(iso) {
        const date = this.parseIso(iso);
        if (!date)
            return this.msg.rangeEmpty;
        const locale = this.locale || 'en-US';
        const timeZone = this.timezone || undefined;
        const formatter = new Intl.DateTimeFormat(locale, {
            hour: '2-digit',
            minute: '2-digit',
            hour12: locale === 'en-US',
            timeZone,
        });
        return formatter.format(date);
    }
    getDateKey(iso) {
        const date = this.parseIso(iso);
        if (!date)
            return '';
        const timeZone = this.timezone || undefined;
        const formatter = new Intl.DateTimeFormat('en-CA', {
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            timeZone,
        });
        return formatter.format(date);
    }
    parseIso(iso) {
        if (!iso)
            return null;
        const date = new Date(iso);
        return isNaN(date.getTime()) ? null : date;
    }
    parseIsoToTime(iso) {
        const date = this.parseIso(iso);
        return date ? date.getTime() : null;
    }
    toInputValueFromIso(iso) {
        const date = this.parseIso(iso);
        if (!date)
            return '';
        return this.formatInputValue(date);
    }
    formatInputValue(date) {
        const y = date.getFullYear();
        const m = this.pad(date.getMonth() + 1);
        const d = this.pad(date.getDate());
        const h = this.pad(date.getHours());
        const min = this.pad(date.getMinutes());
        return `${y}-${m}-${d}T${h}:${min}`;
    }
    toIsoFromInput(value) {
        if (!value)
            return null;
        if (value.length === 16)
            return `${value}:00`;
        if (value.length >= 19)
            return value.slice(0, 19);
        return value;
    }
    addMinutes(iso, minutes) {
        const date = this.parseIso(iso);
        if (!date)
            return iso;
        date.setMinutes(date.getMinutes() + minutes);
        return this.toIsoString(date);
    }
    toIsoString(date) {
        const y = date.getFullYear();
        const m = this.pad(date.getMonth() + 1);
        const d = this.pad(date.getDate());
        const h = this.pad(date.getHours());
        const min = this.pad(date.getMinutes());
        const s = this.pad(date.getSeconds());
        return `${y}-${m}-${d}T${h}:${min}:${s}`;
    }
    maxIso(a, b) {
        if (!a)
            return b;
        if (!b)
            return a;
        return this.parseIsoToTime(a) >= this.parseIsoToTime(b) ? a : b;
    }
    minIso(a, b) {
        if (!a)
            return b;
        if (!b)
            return a;
        return this.parseIsoToTime(a) <= this.parseIsoToTime(b) ? a : b;
    }
    pad(value) {
        return value < 10 ? `0${value}` : String(value);
    }
    // ===========================================================================
    // RENDER HELPERS
    // ==========================================================================='
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        return html `
<label class="${cn('block text-sm font-medium ml-label', this.getSlotClass('Label'))}">
${unsafeHTML(this.getSlotContent('Label'))}
</label>
`;
    }
    renderPreview() {
        const preview = this.getDisplayRange();
        return html `
<div class="text-sm ml-text-muted">
${preview}
</div>
`;
    }
    renderInputBlock(field) {
        const isStart = field === 'start';
        const labelId = `${this.uid}-${field}-label`;
        const inputId = `${this.uid}-${field}-input`;
        const errorId = `${this.uid}-error`;
        const labelContent = isStart
            ? (this.hasSlot('LabelStart') ? unsafeHTML(this.getSlotContent('LabelStart')) : this.msg.labelStart)
            : (this.hasSlot('LabelEnd') ? unsafeHTML(this.getSlotContent('LabelEnd')) : this.msg.labelEnd);
        const value = isStart ? this.startDatetime : this.endDatetime;
        const placeholder = isStart ? this.msg.placeholderStart : this.msg.placeholderEnd;
        const displayValue = value ? this.formatDateTime(value) : placeholder;
        const isActive = this.activeField === field;
        const hasError = Boolean(this.error) && this.isEditing;
        const buttonClasses = cn('w-full flex items-center justify-between gap-2 rounded-lg border px-3 py-2 text-sm transition', 'ml-input', value ? 'ml-text' : 'ml-text-muted', hasError
            ? 'ml-input-container-error'
            : isActive
                ? 'ml-input-active'
                : '', this.disabled ? 'ml-disabled' : '', this.readonly ? 'cursor-default' : 'cursor-pointer');
        return html `
<div class="flex flex-col gap-1">
<label id=${labelId} for=${inputId} class="text-xs font-medium ml-text-muted">
${labelContent}
</label>
<button
id=${inputId}
type="button"
class=${buttonClasses}
aria-labelledby=${labelId}
aria-invalid=${hasError ? 'true' : 'false'}
aria-required=${this.required ? 'true' : 'false'}
aria-describedby=${hasError ? errorId : nothing}
?disabled=${this.disabled}
@click=${() => this.handleOpenField(field)}
>
<span class="truncate">${displayValue}</span>
<span class="ml-text-muted">▾</span>
</button>
${isActive ? this.renderPickerPanel(field) : html ``}
</div>
`;
    }
    renderPickerPanel(field) {
        const isStart = field === 'start';
        const minIso = isStart ? (this.minDatetime || null) : this.getMinEndIso();
        const maxIso = isStart ? (this.maxDatetime || null) : this.getMaxEndIso();
        const minValue = minIso ? this.toInputValueFromIso(minIso) : undefined;
        const maxValue = maxIso ? this.toInputValueFromIso(maxIso) : undefined;
        const step = Math.max(this.minuteStep, 1) * 60;
        const value = isStart ? this.startDraft : this.endDraft;
        const confirmDisabled = isStart ? !this.isStartDraftValid() : !this.isEndDraftValid();
        return html `
<div class="mt-2 rounded-lg border p-3 ml-interval-picker" role="dialog" aria-modal="true">
<div class="flex flex-col gap-2">
<input
class="w-full rounded-lg border px-3 py-2 text-sm ml-input ml-input-focus"
type="datetime-local"
step=${step}
.value=${value}
min=${ifDefined(minValue)}
max=${ifDefined(maxValue)}
@input=${isStart ? this.handleStartDraftInput : this.handleEndDraftInput}

@change=${(e) => e.stopPropagation()}
/>
<div class="flex items-center justify-end gap-2">
<button
class="rounded-md px-3 py-1 text-xs border ml-interval-btn-secondary"
type="button"
@click=${isStart ? this.handleClearStart : this.handleClearEnd}
>
${this.msg.clear}
</button>
<button
class="rounded-md px-3 py-1 text-xs border ml-interval-btn-primary"
type="button"
?disabled=${confirmDisabled}
@click=${isStart ? this.handleConfirmStart : this.handleConfirmEnd}
>
${this.msg.confirm}
</button>
</div>
</div>
</div>
`;
    }
    renderFeedback() {
        if (!this.isEditing)
            return html ``;
        if (this.error) {
            return html `
<p id="${this.uid}-error" class="mt-1 text-xs ml-error-text">${unsafeHTML(String(this.error))}</p>
`;
        }
        if (this.hasSlot('Helper')) {
            return html `
<p class="${cn('mt-1 text-xs ml-helper', this.getSlotClass('Helper'))}">${unsafeHTML(this.getSlotContent('Helper'))}</p>
`;
        }
        return html ``;
    }
    renderLoading() {
        if (!this.loading)
            return html ``;
        return html `
<div class="mt-2 text-xs ml-text-muted">
${this.msg.loading}
</div>
`;
    }
    // ===========================================================================
    // RENDER
    // ==========================================================================='
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (!this.isEditing) {
            return html `
<div class="${cn('w-full space-y-2', this.cssClass)}">
${this.renderLabel()}
<div class="text-sm ml-text">
${this.getDisplayRange()}
</div>
</div>
`;
        }
        return html `
<div class="${cn('w-full space-y-3', this.cssClass)}">
${this.renderLabel()}
${this.renderPreview()}
<div class="grid grid-cols-1 gap-3">
${this.renderInputBlock('start')}
${this.renderInputBlock('end')}
</div>
${this.renderLoading()}
${this.renderFeedback()}
</div>
`;
    }
};
__decorate([
    propertyDataSource({ type: String, attribute: 'start-datetime' })
], EnterDatetimeIntervalMolecule.prototype, "startDatetime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'end-datetime' })
], EnterDatetimeIntervalMolecule.prototype, "endDatetime", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterDatetimeIntervalMolecule.prototype, "error", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterDatetimeIntervalMolecule.prototype, "name", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterDatetimeIntervalMolecule.prototype, "locale", void 0);
__decorate([
    propertyDataSource({ type: String })
], EnterDatetimeIntervalMolecule.prototype, "timezone", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'min-datetime' })
], EnterDatetimeIntervalMolecule.prototype, "minDatetime", void 0);
__decorate([
    propertyDataSource({ type: String, attribute: 'max-datetime' })
], EnterDatetimeIntervalMolecule.prototype, "maxDatetime", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'min-duration-minutes' })
], EnterDatetimeIntervalMolecule.prototype, "minDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'max-duration-minutes' })
], EnterDatetimeIntervalMolecule.prototype, "maxDurationMinutes", void 0);
__decorate([
    propertyDataSource({ type: Number, attribute: 'minute-step' })
], EnterDatetimeIntervalMolecule.prototype, "minuteStep", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'allow-same-instant' })
], EnterDatetimeIntervalMolecule.prototype, "allowSameInstant", void 0);
__decorate([
    propertyDataSource({ type: Boolean, attribute: 'is-editing' })
], EnterDatetimeIntervalMolecule.prototype, "isEditing", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterDatetimeIntervalMolecule.prototype, "disabled", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterDatetimeIntervalMolecule.prototype, "readonly", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterDatetimeIntervalMolecule.prototype, "required", void 0);
__decorate([
    propertyDataSource({ type: Boolean })
], EnterDatetimeIntervalMolecule.prototype, "loading", void 0);
__decorate([
    state()
], EnterDatetimeIntervalMolecule.prototype, "activeField", void 0);
__decorate([
    state()
], EnterDatetimeIntervalMolecule.prototype, "startDraft", void 0);
__decorate([
    state()
], EnterDatetimeIntervalMolecule.prototype, "endDraft", void 0);
EnterDatetimeIntervalMolecule = __decorate([
    customElement('groupenterdatetimeinterval--ml-enter-datetime-interval')
], EnterDatetimeIntervalMolecule);
export { EnterDatetimeIntervalMolecule };
