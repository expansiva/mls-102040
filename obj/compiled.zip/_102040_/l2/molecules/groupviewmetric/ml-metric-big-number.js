/// <mls fileReference="_102040_/l2/molecules/groupviewmetric/ml-metric-big-number.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// Do not change – automatically generated code. 
// =============================================================================
// ML METRIC BIG NUMBER MOLECULE
// =============================================================================
// Skill Group: groupViewMetric
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
let MlMetricBigNumberMolecule = class MlMetricBigNumberMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-big-number .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-big-number .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-big-number .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-big-number .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewmetric--ml-metric-big-number .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-big-number .ml-success-text {
  color: var(--ml-success, #16a34a);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-big-number .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-big-number .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-big-number .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewmetric--ml-metric-big-number .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-big-number .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupviewmetric--ml-metric-big-number .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-big-number .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-big-number .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewmetric--ml-metric-big-number .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewmetric--ml-metric-big-number .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewmetric--ml-metric-big-number .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-big-number .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewmetric--ml-metric-big-number .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        // ===========================================================================
        // SLOT TAGS
        // ===========================================================================
        this.slotTags = ['Label', 'Value', 'Icon', 'Trend', 'Helper'];
        // ===========================================================================
        // PROPERTIES — From Contract
        // ===========================================================================
        this.loading = false;
    }
    // ===========================================================================
    // RENDER
    // ===========================================================================
    render() {
        if (this.loading) {
            return this.renderLoadingSkeleton();
        }
        if (!this.hasSlot('Value')) {
            return html ``;
        }
        const ariaLabel = this.getAriaLabel();
        return html `
 <div class="${cn(this.getContainerClasses(), this.cssClass)}" role="figure" aria-label="${ariaLabel}">
 ${this.hasSlot('Icon') ? this.renderIcon() : html ``}
 ${this.hasSlot('Label') ? this.renderLabel() : html ``}
 ${this.renderValue()}
 ${this.hasSlot('Trend') ? this.renderTrend() : html ``}
 ${this.hasSlot('Helper') ? this.renderHelper() : html ``}
 </div>
 `;
    }
    // ===========================================================================
    // RENDER HELPERS
    // ===========================================================================
    renderIcon() {
        const content = this.getSlotContent('Icon');
        return html `
 <div class="${cn('flex items-center ml-text-muted', this.getSlotClass('Icon'))}">
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderLabel() {
        const content = this.getSlotContent('Label');
        return html `
 <div class="${cn('text-sm font-medium ml-text-muted', this.getSlotClass('Label'))}">
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderValue() {
        const content = this.getSlotContent('Value');
        return html `
 <div
 class="${cn('text-4xl leading-tight font-semibold ml-text', this.getSlotClass('Value'))}"
 aria-live="polite"
 >
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderTrend() {
        const direction = this.getTrendDirection();
        const content = this.getSlotContent('Trend');
        return html `
 <div
 class="${cn(this.getTrendClasses(direction), this.getSlotClass('Trend'))}"
 aria-label="Trend: ${direction}"
 >
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderHelper() {
        const content = this.getSlotContent('Helper');
        return html `
 <div class="${cn('text-xs ml-text-muted', this.getSlotClass('Helper'))}">
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderLoadingSkeleton() {
        return html `
 <div class="${this.getContainerClasses()}" role="figure" aria-busy="true">
 <div class="h-4 w-24 rounded ml-surface-dim-bg animate-pulse"></div>
 <div class="mt-2 h-10 w-40 rounded ml-surface-dim-bg animate-pulse"></div>
 <div class="mt-2 h-4 w-20 rounded ml-surface-dim-bg animate-pulse"></div>
 </div>
 `;
    }
    // ===========================================================================
    // CLASS HELPERS
    // ===========================================================================
    getContainerClasses() {
        return [
            'flex flex-col gap-1 rounded-lg p-4',
            'ml-surface-bg',
            'border ml-border',
        ].join(' ');
    }
    getTrendClasses(direction) {
        const color = direction === 'up'
            ? 'ml-success-text'
            : direction === 'down'
                ? 'ml-error-text'
                : 'ml-text-muted';
        return [
            'inline-flex items-center gap-1 text-sm font-medium',
            color,
        ].join(' ');
    }
    // ===========================================================================
    // UTILITIES
    // ===========================================================================
    getTrendDirection() {
        const dir = this.getSlotAttr('Trend', 'direction');
        if (dir === 'up' || dir === 'down' || dir === 'neutral')
            return dir;
        return 'neutral';
    }
    getAriaLabel() {
        const raw = this.getSlotContent('Label') || 'Metric';
        return raw.replace(/<[^>]*>/g, '').trim() || 'Metric';
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlMetricBigNumberMolecule.prototype, "loading", void 0);
MlMetricBigNumberMolecule = __decorate([
    customElement('groupviewmetric--ml-metric-big-number')
], MlMetricBigNumberMolecule);
export { MlMetricBigNumberMolecule };
