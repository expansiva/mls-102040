/// <mls fileReference="_102040_/l2/molecules/groupviewmetric/ml-metric-gauge.ts" enhancement="_102020_/l2/enhancementAura" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
// =============================================================================
// METRIC GAUGE MOLECULE
// =============================================================================
// Skill Group: groupViewMetric
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { ifDefined } from 'lit/directives/if-defined.js';
import { customElement } from 'lit/decorators.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
import { cn } from '/_102033_/l2/cn.js';
let MetricGaugeMolecule = class MetricGaugeMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        if(this.loadStyle) this.loadStyle(`groupviewmetric--ml-metric-gauge .ml-text {
  color: var(--ml-on-surface, #1c1b1f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-gauge .ml-text-muted {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-gauge .ml-text-faint {
  color: var(--ml-on-surface-faint, #79747e);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-gauge .ml-label {
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
  font-weight: var(--ml-font-weight-medium, 500);
  color: var(--ml-on-surface, #1c1b1f);
}
groupviewmetric--ml-metric-gauge .ml-helper {
  color: var(--ml-on-surface-muted, #49454f);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-gauge .ml-success-text {
  color: var(--ml-success, #16a34a);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-gauge .ml-success-dim-bg {
  background: var(--ml-success-dim, #f0fdf4);
}
groupviewmetric--ml-metric-gauge .ml-success-border {
  border-color: var(--ml-success-border, #bbf7d0);
}
groupviewmetric--ml-metric-gauge .ml-error-text {
  color: var(--ml-error, #ef4444);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-gauge .ml-primary-text {
  color: var(--ml-primary, #3b82f6);
  font-family: var(--ml-font-family, system-ui, -apple-system, sans-serif);
}
groupviewmetric--ml-metric-gauge .ml-surface-bg {
  background: var(--ml-surface, #ffffff);
}
groupviewmetric--ml-metric-gauge .ml-surface-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-gauge .ml-primary-bg {
  background: var(--ml-primary, #3b82f6);
  color: var(--ml-on-primary, #ffffff);
}
groupviewmetric--ml-metric-gauge .ml-primary-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-gauge .ml-error-dim-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-gauge .ml-border {
  border-color: var(--ml-outline-variant, #e2e8f0);
}
groupviewmetric--ml-metric-gauge .ml-border-focus {
  border-color: var(--ml-outline-focus, #3b82f6);
}
groupviewmetric--ml-metric-gauge .ml-border-error {
  border-color: var(--ml-outline-error, #ef4444);
}
groupviewmetric--ml-metric-gauge .ml-hover-bg {
  background: var(--ml-surface-dim, #f5f5f5);
}
groupviewmetric--ml-metric-gauge .ml-focus-ring {
  box-shadow: 0 0 0 var(--ml-focus-ring-width, 2px) var(--ml-focus-ring-color, rgba(59, 130, 246, 0.4));
}
groupviewmetric--ml-metric-gauge .ml-disabled {
  opacity: var(--ml-disabled-opacity, 0.5);
  cursor: not-allowed;
  pointer-events: none;
}
`);
        // =========================================================================
        // SLOT TAGS
        // =========================================================================
        this.slotTags = ['Label', 'Value', 'Icon', 'Trend', 'Helper'];
        // =========================================================================
        // PROPERTIES — From Contract
        // =========================================================================
        this.loading = false;
    }
    // =========================================================================
    // RENDER
    // =========================================================================
    render() {
        if (this.loading) {
            return this.renderLoading();
        }
        const ariaLabel = this.getAriaLabel();
        return html `
 <div
 class="${cn('w-full rounded-xl border ml-border ml-surface-bg p-4', this.cssClass)}"
 role="figure"
 aria-label=${ifDefined(ariaLabel)}
 >
 <div class="flex items-start gap-3">
 ${this.renderIcon()}
 <div class="flex-1 min-w-0">
 ${this.renderLabel()}
 <div class="mt-1 flex items-end justify-between gap-3">
 ${this.renderValue()}
 ${this.renderTrend()}
 </div>
 ${this.renderGauge()}
 ${this.renderHelper()}
 </div>
 </div>
 </div>
 `;
    }
    // =========================================================================
    // RENDER PARTS
    // =========================================================================
    renderIcon() {
        if (!this.hasSlot('Icon'))
            return html ``;
        const content = this.getSlotContent('Icon');
        return html `
 <div
 class="${cn('flex h-10 w-10 items-center justify-center rounded-lg ml-surface-dim-bg ml-text-muted', this.getSlotClass('Icon'))}"
 >
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const content = this.getSlotContent('Label');
        return html `
 <div class="${cn('text-sm font-medium ml-text-muted', this.getSlotClass('Label'))}">
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderValue() {
        const content = this.getSlotContent('Value');
        return html `
 <div
 class="${cn('text-2xl font-semibold ml-text', this.getSlotClass('Value'))}"
 aria-live="polite"
 >
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderTrend() {
        if (!this.hasSlot('Trend'))
            return html ``;
        const direction = this.getSlotAttr('Trend', 'direction') || 'neutral';
        const content = this.getSlotContent('Trend');
        const classes = cn(this.getTrendClasses(direction), this.getSlotClass('Trend'));
        return html `
 <div
 class=${classes}
 aria-label=${`Trend: ${direction}`}
 >
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        const content = this.getSlotContent('Helper');
        return html `
 <div class="${cn('mt-2 text-xs ml-text-muted', this.getSlotClass('Helper'))}">
 ${unsafeHTML(content)}
 </div>
 `;
    }
    renderGauge() {
        return html `
 <div class="mt-3">
 <div
 class="relative h-2 w-full rounded-full ml-surface-dim-bg overflow-hidden"
 >
 <div
 class="absolute left-0 top-0 h-2 w-2/3 ml-primary-dim-bg0/60"
 ></div>
 <div
 class="absolute left-2/3 top-1/2 -translate-y-1/2 h-3 w-3 rounded-full ml-primary-dim-bg0 border-2 border-white"
 ></div>
 </div>
 </div>
 `;
    }
    // =========================================================================
    // LOADING
    // =========================================================================
    renderLoading() {
        return html `
 <div
 class="w-full rounded-xl border ml-border ml-surface-bg p-4 animate-pulse"
 role="figure"
 >
 <div class="flex items-start gap-3">
 <div class="h-10 w-10 rounded-lg ml-surface-dim-bg"></div>
 <div class="flex-1">
 <div class="h-4 w-32 rounded ml-surface-dim-bg"></div>
 <div class="mt-2 h-7 w-40 rounded ml-surface-dim-bg"></div>
 <div class="mt-3 h-2 w-full rounded ml-surface-dim-bg"></div>
 <div class="mt-2 h-3 w-24 rounded ml-surface-dim-bg"></div>
 </div>
 </div>
 </div>
 `;
    }
    // =========================================================================
    // HELPERS
    // =========================================================================
    getAriaLabel() {
        const labelEl = this.getSlot('Label');
        const text = labelEl?.textContent?.trim() || '';
        return text ? text : undefined;
    }
    getTrendClasses(direction) {
        const base = [
            'inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium border',
        ];
        if (direction === 'up') {
            base.push('ml-success-text', 'ml-success-dim-bg', 'ml-success-border');
        }
        else if (direction === 'down') {
            base.push('ml-error-text', 'ml-error-dim-bg', 'ml-border-error');
        }
        else {
            base.push('ml-text-muted', 'ml-surface-dim-bg', 'ml-border');
        }
        return base.join(' ');
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MetricGaugeMolecule.prototype, "loading", void 0);
MetricGaugeMolecule = __decorate([
    customElement('groupviewmetric--ml-metric-gauge')
], MetricGaugeMolecule);
export { MetricGaugeMolecule };
