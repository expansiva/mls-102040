var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
/// <mls fileReference="_102040_/l2/molecules/groupviewmetric/ml-metric-trend-compare.ts" enhancement="_102020_/l2/enhancementAura"/>
// =============================================================================
// ML METRIC TREND COMPARE MOLECULE
// =============================================================================
// Skill Group: groupViewMetric
// This molecule does NOT contain business logic.
import { html } from 'lit';
import { customElement, state } from 'lit/decorators.js';
import { unsafeHTML } from 'lit/directives/unsafe-html.js';
import { propertyDataSource } from '/_102029_/l2/collabDecorators.js';
import { MoleculeAuraElement } from '/_102033_/l2/moleculeBase.js';
/// **collab_i18n_start**
const message_en = {
    metric: 'Metric',
    loadingMetric: 'Loading metric',
    trendUp: 'Trend: up',
    trendDown: 'Trend: down',
    trendNeutral: 'Trend: neutral',
};
const messages = {
    en: message_en,
};
/// **collab_i18n_end**
let MlMetricTrendCompareMolecule = class MlMetricTrendCompareMolecule extends MoleculeAuraElement {
    constructor() {
        super(...arguments);
        this.msg = messages.en;
        // ==========================================================================
        // SLOT TAGS
        // ==========================================================================
        this.slotTags = ['Label', 'Value', 'Icon', 'Trend', 'Helper'];
        // ==========================================================================
        // PROPERTIES — From Contract
        // ==========================================================================
        this.loading = false;
        // ==========================================================================
        // INTERNAL STATE
        // ==========================================================================
        this.announceKey = 0;
    }
    // ==========================================================================
    // RENDER
    // ==========================================================================
    render() {
        const lang = this.getMessageKey(messages);
        this.msg = messages[lang];
        if (this.loading) {
            return this.renderLoadingSkeleton();
        }
        const labelText = this.getLabelText();
        return html `
      <div
        class="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4"
        role="figure"
        aria-label="${labelText || this.msg.metric}"
      >
        <div class="flex items-start justify-between gap-3">
          <div class="flex-1">
            ${this.renderLabel()}
            ${this.renderValue()}
          </div>
          ${this.renderIcon()}
        </div>
        <div class="mt-2 flex items-center gap-3">
          ${this.renderTrend()}
          ${this.renderHelper()}
        </div>
      </div>
    `;
    }
    // ==========================================================================
    // RENDER HELPERS
    // ==========================================================================
    renderLabel() {
        if (!this.hasSlot('Label'))
            return html ``;
        const content = this.getSlotContent('Label');
        return html `
      <div class="text-sm font-medium text-slate-600 dark:text-slate-400">
        ${unsafeHTML(content)}
      </div>
    `;
    }
    renderValue() {
        const content = this.hasSlot('Value') ? this.getSlotContent('Value') : '';
        // Update announce key to re-announce on external content changes
        this.announceKey += 1;
        return html `
      <div
        class="mt-1 text-3xl font-semibold text-slate-900 dark:text-slate-100"
        aria-live="polite"
        data-announce-key="${this.announceKey}"
      >
        ${unsafeHTML(content)}
      </div>
    `;
    }
    renderIcon() {
        if (!this.hasSlot('Icon'))
            return html ``;
        const content = this.getSlotContent('Icon');
        return html `
      <div class="flex items-center text-slate-500 dark:text-slate-400">
        ${unsafeHTML(content)}
      </div>
    `;
    }
    renderTrend() {
        if (!this.hasSlot('Trend'))
            return html ``;
        const direction = (this.getSlotAttr('Trend', 'direction') || 'neutral');
        const content = this.getSlotContent('Trend');
        const ariaLabel = this.getTrendAriaLabel(direction);
        return html `
      <div
        class="inline-flex items-center gap-1 rounded-full px-2 py-1 text-xs font-medium ${this.getTrendClasses(direction)}"
        aria-label="${ariaLabel}"
      >
        ${unsafeHTML(content)}
      </div>
    `;
    }
    renderHelper() {
        if (!this.hasSlot('Helper'))
            return html ``;
        const content = this.getSlotContent('Helper');
        return html `
      <div class="text-xs text-slate-500 dark:text-slate-400">
        ${unsafeHTML(content)}
      </div>
    `;
    }
    renderLoadingSkeleton() {
        return html `
      <div
        class="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 p-4"
        role="figure"
        aria-label="${this.msg.loadingMetric}"
        aria-busy="true"
      >
        <div class="animate-pulse">
          <div class="h-4 w-32 rounded bg-slate-200 dark:bg-slate-700"></div>
          <div class="mt-2 h-8 w-40 rounded bg-slate-200 dark:bg-slate-700"></div>
          <div class="mt-3 flex items-center gap-3">
            <div class="h-5 w-20 rounded-full bg-slate-200 dark:bg-slate-700"></div>
            <div class="h-3 w-28 rounded bg-slate-200 dark:bg-slate-700"></div>
          </div>
        </div>
      </div>
    `;
    }
    // ==========================================================================
    // UTILITIES
    // ==========================================================================
    getTrendClasses(direction) {
        const base = 'border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 bg-slate-50 dark:bg-slate-900';
        if (direction === 'up') {
            return [
                'border border-emerald-500 dark:border-emerald-400',
                'text-emerald-700 dark:text-emerald-300',
                'bg-emerald-50 dark:bg-emerald-900/40',
            ].join(' ');
        }
        if (direction === 'down') {
            return [
                'border border-red-500 dark:border-red-400',
                'text-red-700 dark:text-red-300',
                'bg-red-50 dark:bg-red-900/40',
            ].join(' ');
        }
        return base;
    }
    getTrendAriaLabel(direction) {
        if (direction === 'up')
            return this.msg.trendUp;
        if (direction === 'down')
            return this.msg.trendDown;
        return this.msg.trendNeutral;
    }
    getLabelText() {
        if (!this.hasSlot('Label'))
            return '';
        const content = this.getSlotContent('Label');
        return this.stripHtml(content).trim();
    }
    stripHtml(value) {
        return value.replace(/<[^>]*>/g, '');
    }
};
__decorate([
    propertyDataSource({ type: Boolean })
], MlMetricTrendCompareMolecule.prototype, "loading", void 0);
__decorate([
    state()
], MlMetricTrendCompareMolecule.prototype, "announceKey", void 0);
MlMetricTrendCompareMolecule = __decorate([
    customElement('groupviewmetric--ml-metric-trend-compare')
], MlMetricTrendCompareMolecule);
export { MlMetricTrendCompareMolecule };
